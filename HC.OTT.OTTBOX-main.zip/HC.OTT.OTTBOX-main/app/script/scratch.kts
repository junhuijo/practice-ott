import java.io.*

var fileName : List<String> = listOf("item_my_service_log_list.xml","fragment_series.xml","fragment_detail.xml","fragment_my_change_card.xml",
        "fragment_my_change_password.xml","fragment_my_change_user_info.xml" , "fragment_my_member_login.xml", "fragment_my_member_logout.xml" ,"dialog_resign_member_pop.xml" , "fragment_my_service_list.xml"
,"dialog_play_series_exit.xml","fragment_notice_list.xml" ,"item_notice_list.xml","item_notice_text_list.xml","notice_button_item.xml","dialog_notice_pop.xml" ,"button_item.xml","episode_no_item.xml"
    )

fileName.forEach {
    var file = File("/Users/pilsu/IdeaProjects/DLIVEON/app/src/main/res/layout-xhdpi/${it}")
    var outFile = File("/Users/pilsu/IdeaProjects/DLIVEON/app/src/main/res/layout-mdpi/${it}")
    outFile.createNewFile()
    var reader = BufferedReader(FileReader(file))

    var writer = BufferedWriter(FileWriter(outFile))

    reader.forEachLine { line ->
        var regex = """([0-9.]+)dp""".toRegex()
        var spRegex = """([0-9.]+)sp""".toRegex()
        val replacedStr = regex.replace(line) {
            val data = it.value.substring(0, it.value.length - 2)
            "${Math.round(data.toFloat() * 1.333f)}dp"

        }

        val result = spRegex.replace(replacedStr) {
            val data = it.value.substring(0, it.value.length - 2)
            "${Math.round(data.toFloat() * 1.333f)}sp"

        }

        writer.append(result)
        writer.newLine()

    }

    writer.close()
    reader.close()


}

