package com.homechoice.ott.vod.ui.pack

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.ItemPackageListBinding
import com.homechoice.ott.vod.model.content.Content

class PackageListAdapter(private var items: List<Content>) : RecyclerView.Adapter<PackageListAdapter.ViewHolder>() {

    private var viewHolderList: ArrayList<ViewHolder> = arrayListOf()

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        viewHolderList.add(position, holder)
        holder.bindViews(items[position], position)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPackageListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding, parent.context)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    private interface UpdateViewHolder {
        fun bindViews(data: Content, position: Int)
    }

    fun init() {
        viewHolderList[0].binding.contentPoster.requestFocus()
    }

    fun getView(): View {
        return viewHolderList[0].binding.contentPoster
    }

    class ViewHolder(val binding: ItemPackageListBinding, val ctx: Context) : RecyclerView.ViewHolder(binding.root), UpdateViewHolder {
        override fun bindViews(data: Content, position: Int) {
            binding.content = PackageItemModel(data)
            if (data.posterUrl != "")
                Glide.with(ctx).load(data.posterUrl).placeholder(R.drawable.poster).into(binding.contentPoster)

            binding.rating.setImageResource(UIAgent.getRatingImageResource(data.rating!!))
            binding.contentPoster.tag = data
            binding.contentPoster.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                var animationId = R.anim.anim_package_scale_down
                if (hasFocus)
                    animationId = R.anim.anim_package_scale_up

                AnimationUtils.loadAnimation(ctx, animationId).also {
                    it.fillAfter = true
                    v.startAnimation(it)
                }
            }
        }
    }

}