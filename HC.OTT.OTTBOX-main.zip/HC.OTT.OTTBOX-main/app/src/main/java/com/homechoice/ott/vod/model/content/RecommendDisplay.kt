package com.homechoice.ott.vod.model.content


data class RecommendDisplay(
    var posterUrlList : List<String>
)