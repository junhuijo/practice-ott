package com.homechoice.ott.vod.agent

import android.util.Log
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.model.HomeCategoryList
import com.homechoice.ott.vod.ui.screens.ContentFilter
import com.homechoice.ott.vod.util.Logger

object CategoryAgent {
    private var myCategoryList: HashMap<Int, Category> = hashMapOf()
    private var returnMyCategoryList: Map<Int, Category> = hashMapOf()

    // 서브 카테고리 캐쉬
    private var subCategoryList: HashMap<Int, List<CategoryList>> = hashMapOf()

    private lateinit var homeCategoryList: HomeCategoryList
    private var ROOT = 0
    private var NOTICE = ROOT + 100
    private var SEEN = ROOT + 200
    private var FAV = ROOT + 300
    private var KIDS_LOCK = ROOT + 400
    private var ADULT = ROOT + 500
    private var MY = ROOT + 600
    private var EXIT = ROOT + 700

    init {
    }

    fun init() {
        Logger.Log(Log.DEBUG, this, "CategoryAgent Init linkedHomeChoice : ${STBAgent.linkedHomeChoice}")

        myCategoryList.clear()
        myCategoryList[ROOT] = Category(parentId = -1, id = ROOT, name = "MY 프로필", target = "root", hasCategory = true, iconResourceId = R.drawable.icon_notice)

        var displayOrder = 0

        // 알림
        myCategoryList[NOTICE] = Category(parentId = ROOT, id = NOTICE, name = "알림", target = CategoryTarget.NOTICE_LIST, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_notice)
        displayOrder++

        // 시청목록
        myCategoryList[SEEN] = Category(parentId = ROOT, id = SEEN, name = "시청 목록", target = CategoryTarget.WAT_NORMAL, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_wat)
        displayOrder++

        // 찜목록
        myCategoryList[FAV] = Category(parentId = ROOT, id = FAV, name = "찜 목록", target = CategoryTarget.FAV_NORMAL, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_fav)
        displayOrder++

        // 성인 비밀번호 변경
//        myCategoryList[ADULT] = Category(parentId = ROOT, id = ADULT, name = "성인 확인 비밀번호 설정", target = CategoryTarget.ADULT, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_pw)
//        displayOrder++

        // 키즈락 (청불 콘텐츠 차단)
//        myCategoryList[KIDS_LOCK] = Category(parentId = ROOT, id = KIDS_LOCK, name = "키즈락 설정", target = CategoryTarget.KIDS_LOCK, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_pw)
//        displayOrder++

        // 마이관리
        Logger.Log(Log.DEBUG, this, "마이 관리 메뉴")
//        myCategoryList[MY] = Category(parentId = ROOT, id = MY, name = "로그인/로그아웃", target = CategoryTarget.LOGIN, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_logout)
        myCategoryList[MY] = Category(parentId = ROOT, id = MY, name = "로그아웃", target = CategoryTarget.LOGIN, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_logout)
//            myCategoryList[MY + 2] = Category(parentId = MY, id = MY + 2, name = "성인 비밀번호 변경", target = CategoryTarget.PIN_ADULT, leaf = true, displayOrder = 1)

        myCategoryList[EXIT] = Category(parentId = ROOT, id = MY, name = "종료하기", target = CategoryTarget.EXIT, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_quit_app)


        // H3에서 순서가 섞이는 이슈가 있음. -> 정렬 처리
        returnMyCategoryList = myCategoryList.toList().sortedWith(compareBy { it.first }).toMap()

        Logger.Log(Log.DEBUG, this, "CategoryAgent Init linkedHomeChoice : ${myCategoryList}")
    }

    fun onUserDataLoaded() {
        val isAdult = ContentFilter.isAdultUser()
        val isSpecificMsoName = ContentFilter.isSpecificMsoName()

        if (isAdult && !isSpecificMsoName) {
            addAdultCategories()
        } else if (isAdult && isSpecificMsoName) {
            addAdultCategories(isSpecificMsoName = true)
        } else {
            removeAdultCategories()
        }
        // 재정렬
        returnMyCategoryList = myCategoryList.toList().sortedWith(compareBy { it.first }).toMap()
    }

    private fun addAdultCategories(isSpecificMsoName: Boolean = false) {
        var displayOrder = myCategoryList.size
        // 키즈락 (청불 콘텐츠 차단)
        myCategoryList[KIDS_LOCK] = Category(parentId = ROOT, id = KIDS_LOCK, name = "키즈락 설정", target = CategoryTarget.KIDS_LOCK, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_pw)
        displayOrder++

        // 성인 비밀번호 변경
        if (!isSpecificMsoName) { myCategoryList[ADULT] = Category(parentId = ROOT, id = ADULT, name = "성인 비밀번호 변경", target = CategoryTarget.ADULT, leaf = true, displayOrder = displayOrder, hasCategory = true, iconResourceId = R.drawable.icon_pw) }
    }

    private fun removeAdultCategories() {
        myCategoryList.remove(KIDS_LOCK)
        myCategoryList.remove(ADULT)
    }

    fun getTargetCategory(target: String): Category? {
        var targetCategory: Category? = null
        for (item in myCategoryList) {
            Logger.Log(Log.DEBUG, this, "item $item")
            if (item.value.target == target) {
                targetCategory = item.value
                break;
            }
        }
        return targetCategory
    }

    fun getHomeCategoryList(): HomeCategoryList {
        return homeCategoryList
    }

    fun setHomeCategoryList(list: HomeCategoryList) {
        homeCategoryList = list
    }

    /**
    TODO: 카테고리 업데이트 적용 필요
    // */
    fun updateHomeCategoryList() {
        for (i in homeCategoryList.categoryList.indices) {
            if (homeCategoryList.categoryList[i].id == 977) {
                homeCategoryList.categoryList[i].title = STBAgent.userName + homeCategoryList.categoryList[i].title
                break
            }
        }
    }

    fun getHomeCategoryIndex(id: Int): Int {
        var index = 0
        for (i in homeCategoryList.categoryList.indices) {
            if (homeCategoryList.categoryList[i].id == id) {
                index = i
                break
            }
        }
        Logger.Log(Log.DEBUG, this, "getHomeCategoryIndex id:$id / index:$index")
        return index
    }

    fun getMyCategoryList(id: Int): ArrayList<Category> {
        val list: ArrayList<Category> = arrayListOf()
        for (entry: Map.Entry<Int, Category> in returnMyCategoryList.entries) {
            if (id == entry.value.parentId) {
                Logger.Log(Log.DEBUG, this, "entry : $entry")
                //                if (STBAgent.linkedHomeChoice) {
                //                    if (entry.value.target != CategoryTarget.USER && entry.value.target != CategoryTarget.LOGIN) {
                //                        list.add(entry.value)
                //                    }
                //                }
                //                else {
                list.add(entry.value)
                //                }
            }
        }
        return list
    }

    fun getMyCategory(id: Int): Category? {
        Logger.Log(Log.DEBUG, this, "getMyCategory id:$id / myCategoryList[id] : ${myCategoryList[id]}")
        return myCategoryList[id]
    }

    //===========
    fun setCategoryList(id: Int, list: List<CategoryList>) {
        subCategoryList[id] = list
    }

    fun getCategoryList(id: Int): List<CategoryList>? {
        return subCategoryList[id]
    }

    fun clearCategoryList() {
        subCategoryList.clear()
    }
}

data class Category(
    val parentId: Int = -1,
    val id: Int = -1,
    var name: String = "",
    val target: String = "none",
    val visible: Boolean = true,
    val leaf: Boolean = false,
    val displayOrder: Int = -1,
    val hasCategory: Boolean = false,
    val iconResourceId: Int
)

object GroupType {
    val CATEGORY_ADULT: String = "category_adult"
    val PURCHASE_LOG_NORMAL: String = "purchase_log_normal"
    val PURCHASE_LOG_SERIES: String = "purchase_log_series"
    val PURCHASE_LOG_SUBSCRIBE: String = "purchase_log_subscribe"
    val PURCHASE_LOG_BUNDLE: String = "purchase_log_package"
    val PURCHASE_LOG_ADULT: String = "purchase_log_adult"
    val SERVICE_LOG_NORMAL: String = "service_log_normal"
    val SERVICE_LOG_SERIES: String = "service_log_series"
    val SERVICE_LOG_SUBSCRIBE: String = "service_log_subscribe"
    val SERVICE_LOG_BUNDLE: String = "service_log_package"
    val SERVICE_LOG_ADULT: String = "service_log_adult"
}

object CategoryTarget {
    const val ROOT: String = "root"
    const val USER: String = "user"
    const val LOGIN: String = "login"
    const val PIN_ADULT: String = "change_auth"
    const val CARD: String = "change_card"
    const val PW: String = "change_pw"
    const val INFO: String = "change_user_info"

    const val PAY: String = "pay"
    const val PAY_NORMAL: String = "normal"
    const val PAY_SERIES: String = "series"
    const val PAY_MONTH: String = "month"
    const val PAY_BUNDLE: String = "bundle"
    const val PAY_ADULT: String = "adult"

    const val HOME : String = "home"

    const val WAT: String = "watching"
    const val WAT_NORMAL: String = "watching_normal"
    const val WAT_ADULT: String = "watching_adult"

    const val FAV: String = "favorite"
    const val FAV_NORMAL: String = "favorite_normal"
    const val FAV_ADULT: String = "favorite_adult"

    const val NOTICE: String = "notice"
    const val NOTICE_LIST: String = "notice_list"
    const val EVENT: String = "event"
    const val FAQ: String = "faq"
    const val POINT_FAQ: String = "point_faq"
    const val SERVICE: String = "service"
    const val POINT: String = "point"
    const val POINT_PURCHASE: String = "point_purchase"
    const val POINT_HISTORY: String = "point_history"
    const val POINT_REGISTER: String = "point_register"

    const val ADULT: String = "adult_category"
    const val KIDS_LOCK: String = "kids_lock"

    const val EXIT: String = "exit"
}