package com.homechoice.ott.vod.ui.pack

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.content.OfferContent
import java.text.DecimalFormat

class PackageViewModel(offerContent: OfferContent) : ViewModel() {
    var productTitle: MutableLiveData<String> = MutableLiveData()
    var viewablePeriod: MutableLiveData<String> = MutableLiveData()
    var viewablePeriodStr: MutableLiveData<String> = MutableLiveData()
    var viewablePeriodUnit: MutableLiveData<String> = MutableLiveData()
    var originProductInfo: MutableLiveData<String> = MutableLiveData()
    var discountPriceStr: MutableLiveData<String> = MutableLiveData()
    var isPurchase: MutableLiveData<Boolean> = MutableLiveData()

    init {
        var price = 0
        for (item in offerContent.contentList) {
            for (offer in item.offerList) {
                if (offer.packageType == "single") {
                    price += offer.price!!
                    break
                }
            }
        }

        productTitle.value = offerContent.title
        viewablePeriod.value = offerContent.viewablePeriod?.replace(("[^\\d.]").toRegex(), "")
        if (offerContent.viewablePeriod?.indexOf("시간")!! > -1)
            viewablePeriodUnit.value = "시간"
        else if (offerContent.viewablePeriod.indexOf("분") > -1)
            viewablePeriodUnit.value = "분"
        else
            viewablePeriodUnit.value = "일"
        viewablePeriodStr.value = "구매일로부터 ${offerContent.viewablePeriod} 시청 가능"
        originProductInfo.value = " ${offerContent.contentList.size}편  ${DecimalFormat("#,###").format(price)}원 "

        if (offerContent.discountPrice!! > 0)
            discountPriceStr.value = DecimalFormat("#,###").format(offerContent.discountPrice)
        else
            discountPriceStr.value = DecimalFormat("#,###").format(offerContent.price)
    }
}