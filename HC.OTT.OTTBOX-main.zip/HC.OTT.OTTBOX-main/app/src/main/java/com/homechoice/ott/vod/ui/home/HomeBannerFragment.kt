package com.homechoice.ott.vod.ui.home

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.activity.addCallback
import androidx.core.view.marginEnd
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.ActivityChangeAgent
import com.homechoice.ott.vod.agent.CategoryItemType
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.SessionState
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.response.ResponseCpItemList
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.UUID

class HomeBannerFragment(val ctx: HomeActivity2) : NavigationView2() {

    var homeContentGroupV2ListFragment: HomeContentGroupV2ListFragment? = null
    private lateinit var jtbcFrame: FrameLayout
    private lateinit var tvChosunFrame: FrameLayout
    private lateinit var channelAFrame: FrameLayout
    private lateinit var mbnFrame: FrameLayout
    private lateinit var ebsFrame: FrameLayout
    private lateinit var bannerBtn: FrameLayout
    private lateinit var cpScrollView: HorizontalScrollView

    private val contentScrollView = ctx.findViewById<ScrollView>(R.id.home_content_main_scrollview)
    private val categoryScrollView = ctx.findViewById<ScrollView>(R.id.home_category_scrollview)

    override fun onKeyDown(keyCode: Int): Boolean {
        TODO("Not yet implemented")
    }

    override fun active() {
        TODO("Not yet implemented")
    }


    override fun lateActive() {
        TODO("Not yet implemented")
    }

    override fun setVisible(visible: Int) {
        TODO("Not yet implemented")
    }

    @SuppressLint("InflateParams")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var view = inflater.inflate(R.layout.fragment_home_banner, null)

        cpScrollView = view.findViewById(R.id.cp_scrollview)
        jtbcFrame = view.findViewById(R.id.cp_jtbc_border)
        channelAFrame = view.findViewById(R.id.cp_channel_a_border)
        mbnFrame = view.findViewById(R.id.cp_mbn_border)
        ebsFrame = view.findViewById(R.id.cp_ebs_border)
        tvChosunFrame = view.findViewById(R.id.tv_chosun_frame)

        val cpLayoutList = mutableListOf<FrameLayout>()
        cpLayoutList.add(jtbcFrame)
        cpLayoutList.add(channelAFrame)
        cpLayoutList.add(mbnFrame)
        cpLayoutList.add(ebsFrame)
        cpLayoutList.add(tvChosunFrame)

        cpLayoutList.forEach { cpIcon ->
            cpIcon.setOnFocusChangeListener { view, b ->
                if(b){
                    val location = IntArray(2)
                    view.getLocationOnScreen(location)
                    val locationTwo = IntArray(2)
                    cpScrollView.getLocationOnScreen(locationTwo)
                    //가로 스크롤뷰의 시작 위치 + (포스터 width + margin)* 3 = 4번째 포스터 위치
                    val fourthLocation = locationTwo[0] + (cpIcon.width+cpIcon.marginEnd)*3
                    Log.d("cp locations","${fourthLocation} ${locationTwo[0]} ${cpIcon.width} ${cpIcon.marginEnd} ${location[0]}")
                    //오른쪽으로 스크롤 할 때
                    if(location[0]>fourthLocation){
                        cpScrollView.smoothScrollBy(location[0]-fourthLocation,0)
                    }
                }
            }
        }

        bannerBtn = view.findViewById(R.id.banner_button_frame)

        bannerBtn.setOnFocusChangeListener { view, hasFocus ->
            if(hasFocus){
                contentScrollView.smoothScrollTo(0,0)
            }
        }
        ebsFrame.nextFocusRightId = ebsFrame.id

        jtbcFrame.setOnClickListener {
            selectCpIcon("JTBC",jtbcFrame)
        }

        tvChosunFrame.setOnClickListener {
            selectCpIcon("TV조선", tvChosunFrame)
        }

        channelAFrame.setOnClickListener {
            selectCpIcon("CHANNEL A",channelAFrame)
        }

        mbnFrame.setOnClickListener {
            selectCpIcon("MBN",mbnFrame)
        }

        ebsFrame.setOnClickListener {
            selectCpIcon("EBS",ebsFrame)
        }



        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 뷰가 완전히 생성된 후에 포커스 요청
        jtbcFrame?.requestFocus()

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            requireActivity().supportFragmentManager.popBackStack()
        }
    }


    private fun selectCpIcon(title: String, view: View){
        contentScrollView.visibility = View.GONE
        categoryScrollView.visibility = View.VISIBLE

        var cpId = 0
        when(title){
            "JTBC"->cpId=364
            "TV조선"->cpId=365
            "CHANNEL A"->cpId=378
            "MBN"->cpId=362
            "EBS"->cpId=361
        }

        MBSAgent.getCpItemList(
            MBSAgent.terminalKey,
            cpId,
            STBAgent.isAdultAuth,
            STBAgent.includeRrated,
            1,
            10,
            object : Callback<ResponseCpItemList> {
                override fun onFailure(call: Call<ResponseCpItemList>, t: Throwable) {
                    Log.e("getCategoryList Error","${call}")
                }


                override fun onResponse(
                    call: Call<ResponseCpItemList>,
                    response: Response<ResponseCpItemList>
                ) {
                    if (response.isSuccessful && response.body() != null) {
                        val cpItemList: ResponseCpItemList = response.body()!!
                        Log.d("cpItemList","${cpItemList}")
                        when (cpItemList.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                            }
                            else -> {
                                val homeContentGroupV2ListFragment = HomeContentGroupV2ListFragment(title,cpItemList.cpItemList,true)
                                val transaction = parentFragmentManager
                                transaction.beginTransaction().add(R.id.home_category_scrollbody,homeContentGroupV2ListFragment!!).commit()
                            }
                        }

                    }
                    else {
                        // 장애팝업
                        Log.e("error","HomeCategoryFragment 227")
                    }
                }
            })
    }
}