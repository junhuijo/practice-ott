package com.homechoice.ott.vod.model.search

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class SearchItem(
    var title: String = "",
    var director: String = "",
    var starring: String = "",
    var isTitleTarget: Boolean = false,
    var isDirectorTarget: Boolean = false,
    var isStarringTarget: Boolean = false,
    var posterUrl: String = "",
    var posterWidth: Int = 0,
    var posterHeight: Int = 0,
    var searchItemTargetList: List<SearchItemTarget>
) : Parcelable