package com.homechoice.ott.vod.model.play

data class CustomThumbnail(
    var framecnt: Int = 0,
    var img: String = "",
    var tc: Int = 0,
    var visible: Boolean = false
)