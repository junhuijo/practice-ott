package com.homechoice.ott.vod.ui.navigation.linear
import android.content.Context
import android.widget.LinearLayout

abstract class NavigationLinearLayoutView(ctx: Context) : LinearLayout(ctx) {

    var controller: NavigationLinearLayoutController? = null

    fun setModel(navigationModel: NavigationLinearLayoutModel, event: NavigationLinearLayoutEvent) {
        controller =
            NavigationLinearLayoutController(
                navigationModel,
                event
            )
    }


    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    abstract fun onKeyDown(keyCode: Int): Boolean

}