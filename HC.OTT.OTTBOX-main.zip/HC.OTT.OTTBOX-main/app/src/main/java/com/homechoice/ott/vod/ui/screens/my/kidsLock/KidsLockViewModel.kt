package com.homechoice.ott.vod.ui.screens.my.kidsLock

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.homechoice.ott.vod.agent.AdultContentState
import com.homechoice.ott.vod.agent.STBAgent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class KidsLockViewModel : ViewModel() {

    private val _adultContentState = MutableStateFlow(
        AdultContentState(
            isAdultAuth = STBAgent.isAdultAuth,
            includeRrated = STBAgent.includeRrated
        )
    )
    val adultContentState: StateFlow<AdultContentState> = _adultContentState

    private val _inputPassword = mutableStateListOf<Char>()
    val inputPassword: List<Char> = _inputPassword

    private val _alertMessage = MutableStateFlow<Message?>(null)
    val alertMessage: StateFlow<Message?> = _alertMessage.asStateFlow()

    val isKidsLockEnabled: StateFlow<Boolean> = adultContentState.map { state ->
        !(state.isAdultAuth || state.includeRrated)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    init {
        updateKidsLockSettings()
    }

    private fun toggleKidsLock() {
        val currentState = _adultContentState.value
        val newState = if (currentState.isAdultAuth && currentState.includeRrated) {
            AdultContentState(isAdultAuth = false, includeRrated = false)
        } else {
            AdultContentState(isAdultAuth = true, includeRrated = true)
        }
        _adultContentState.value = newState
        updateKidsLockSettings()
    }

    private fun updateKidsLockSettings() {
        val currentState = _adultContentState.value
        STBAgent.isAdultAuth = currentState.isAdultAuth
        STBAgent.includeRrated = currentState.includeRrated
    }

    fun inputPassword(char: Char) {
        if (_inputPassword.size < 4) {
            _inputPassword.add(char)
        }
    }

    fun deletePassword() {
        if (_inputPassword.isNotEmpty()) {
            _inputPassword.removeLast()
        }
    }

    fun checkPassword() {
        if (_inputPassword.size == 4) {
            val enteredPassword = _inputPassword.joinToString("")
            when {
                !isKidsLockEnabled.value && STBAgent.storedPassword == null -> {
                    STBAgent.storedPassword = enteredPassword
                    _alertMessage.value = Message.KidsLockOn
                    toggleKidsLock()
                }
                isKidsLockEnabled.value && enteredPassword == STBAgent.storedPassword -> {
                    _alertMessage.value = Message.KidsLockOff
                    toggleKidsLock()
                    clearStoredPassword()
                }
                else -> {
                    _alertMessage.value = Message.PasswordMismatch
                }
            }
        } else {
            _alertMessage.value = Message.InvalidPasswordFormat
        }

        clearInputPassword()
    }

    private fun clearInputPassword() {
        _inputPassword.clear()
    }

    private fun clearStoredPassword() {
        STBAgent.storedPassword = null
    }

    fun onLogout() {
        clearStoredPassword()
    }
}

sealed class Message {
    object KidsLockOn: Message()
    object KidsLockOff: Message()
    object PasswordMismatch: Message()
    object InvalidPasswordFormat: Message()
}