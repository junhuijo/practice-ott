package com.homechoice.ott.vod.util

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners

class BindingAdapters {
    companion object {

        @JvmStatic
        @BindingAdapter("imageUrl", "cornerRadius")
        fun loadImage(view: ImageView, imageUrl: String?, cornerRadius: Int) {
            if (!imageUrl.isNullOrEmpty()) {
                Glide.with(view.context)
                    .load(imageUrl)
                    .transform(RoundedCorners(cornerRadius))
                    .into(view)
            }
        }

    }
}