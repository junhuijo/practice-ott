package com.homechoice.ott.vod.ui.popup.purchase

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.view.LayoutInflater
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogPurchaseSuccessBinding
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.PopupType.NormalPopupType
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.PopupViewModel

class PurchaseSuccessPopupView(
    ctx: Context,
    var title: String,
    popupType: NormalPopupType,
    event: PopupEvent
) : Dialog(
    ctx,
    R.style.Theme_Design_NoActionBar
) {
    private var binding: DialogPurchaseSuccessBinding
    private var model: PopupViewModel = PopupViewModel(popupType)

    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        title = if (title.length > 26) "${title.substring(0, 26)}..>" else "<${title}>"
        model.content.value?.sub = title
        binding = DialogPurchaseSuccessBinding.inflate(LayoutInflater.from(ctx))
        binding.apply {
            viewModel = model
        }
        setContentView(binding.root)

        Handler().postDelayed({
            dismiss()
            event.onClick(this, BtnLabel.SUCCESS)
        }, popupType.timer * 1000L)

        show()
    }

}