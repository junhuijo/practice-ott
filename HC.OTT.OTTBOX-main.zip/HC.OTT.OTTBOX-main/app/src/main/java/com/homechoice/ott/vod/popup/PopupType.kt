package com.homechoice.ott.vod.popup

import com.google.android.exoplayer2.ExoPlaybackException

// 임시로 정함
object TYPE {
    const val DEFAULT = "default"
    const val PAY = "pay"
    const val ADULT = "adult"
    const val AUTH = "auth"
    const val PLAY = "play"
    const val LOGOUT = "LOGOUT"
}

object CODE {
    const val NONE = 0
    const val ACCEPTED = 202
    const val BAD = 400
    const val UNAUTHORIZED = 401
    const val FORBIDDEN = 403
    const val NOT = 404
    const val CONFLICT = 409
    const val INVALID = 410
    const val SERVER = 500
    const val PIN_CHECK = 516
    const val PIN_FAIL = 517
    const val UNAVAILABLE_CARD = 600
    const val LOGIN_CANCEL = 1000

}

object BtnLabel {
    const val INIT = "초기화"
    const val SUCCESS = "성공"
    const val FAIL = "실패"
    const val OK = "확인"
    const val CANCEL = "취소"
    const val REG_REMOVE = "탈퇴하기"
    const val REG_FINISH = "회원가입 완료"
    const val CHANGE_FINISH = "변경 완료"
    const val REG_CARD_FINISH = "카드등록 완료"
    const val LOGOUT = "로그아웃 완료"
    const val LOGIN = "로그인"
    const val DELETE = "삭제"
    const val ADULT_AUTH = "성인인증 완료"
    const val FIND = "아이디/비밀번호 찾기"
    const val BACK = "뒤로"
    const val PLAY_STOP = "종료하기"
    const val PREVIEW = "미리보기"
    const val TRAILER = "예고편"
    const val PACKAGE = "묶음상품"
    const val CONTINUE = "이어보기"
    const val FIRST = "처음부터 보기"
    const val DETAIL = "상세 보기"
    const val CLOSE = "닫기"
    const val TODAY = "오늘은 보지 않기"
}

object PopupType {
    enum class Label(
        val label: String
    ) {
        OK(label = "확인"),
        CANCEL(label = "취소"),
        REG_FINISH(label = "회원가입 완료"),
        CHANGE_FINISH(label = "변경 완료"),
        REG_CARD_FINISH(label = "카드등록 완료"),
        LOGIN(label = "로그인"),
        ADULT_AUTH(label = "성인인증 완료"),
        REG_CARD(label = "카드등록"),
        POINT_CONFIRM(label = "쿠폰 확인")
    }

    /**
     * 장애 상황에 맞게 타입 추가
     * */
    enum class ErrorType(
        val type: String = "장애",
        var code: Int = 0,
        val head: String = "",
        val defaultBody: String = "",
        var body: String = "",
        val btns: ArrayList<Label> = arrayListOf(Label.OK),
        val timer: Int = 0
    ) {
        ERROR(
            type = TYPE.DEFAULT,
            head = "서비스 장애",
            defaultBody = "잠시 후 다시 시도해 주세요."
        ),
        FAIL(
            type = TYPE.DEFAULT,
            head = "네트워크 장애",
            defaultBody = "잠시 후 다시 시도해 주세요."
        ),
        BAD(
            type = TYPE.DEFAULT,
            code = CODE.BAD,
            head = "유효하지 않은 요청",
            defaultBody = "잘못된 요청입니다"
        ),
        FORBIDDEN(
            type = TYPE.DEFAULT,
            code = CODE.FORBIDDEN,
            head = "서비스 장애",
            defaultBody = "터미널키가 유효하지 않음",
            btns = arrayListOf(Label.OK)
        ),
        NOT(
            type = TYPE.DEFAULT,
            code = CODE.NOT,
            head = "정보를 찾을 수 없음",
            defaultBody = "해당 컨텐츠는 라이센스가 만료되어 시청할 수 없습니다."
        ),
        CONFLICT(
            type = TYPE.DEFAULT,
            code = CODE.CONFLICT,
            head = "로그아웃 안내",
            defaultBody = "다른 기기에서 로그인 되어 연결이 종료되었습니다.\n재 로그인 하시겠습니까?",
            btns = arrayListOf(Label.OK, Label.CANCEL)
        ),
        SERVER(
            type = TYPE.DEFAULT,
            code = CODE.SERVER,
            head = "예상하지 못한 에러",
            defaultBody = "예상치 못한 문제가 발생했습니다.\n잠시 후에 다시 확인해 주시기 바랍니다.(500)"
        ),
        ACCEPTED_PAY(
            type = TYPE.PAY,
            code = 202,
            head = "요청처리중",
            defaultBody = "결제가 진행중입니다"
        ),
        UNAUTHORIZED_PAY(
            type = TYPE.PAY,
            code = 401,
            head = "비밀번호가 잘못됨",
            defaultBody = "비밀번호가 잘못 되었습니다"
        ),
        ACCEPTED_ADULT(
            type = TYPE.ADULT,
            code = 202,
            head = "요청처리중",
            defaultBody = "인증이 진행중입니다"
        ),
        UNAUTHORIZED_ADULT(
            type = TYPE.ADULT,
            code = 401,
            head = "성인인증",
            defaultBody = "비밀번호가 잘못 되었습니다"
        ),
        UNAUTHORIZED_AUTH(
            type = TYPE.AUTH,
            code = 401,
            head = "로그인",
            defaultBody = "아이디 또는 비밀번호가 잘못 되었습니다."
        ),
        TYPE_SOURCE_PLAY(
            type = TYPE.PLAY,
            code = ExoPlaybackException.TYPE_SOURCE,
            head = "재생 실패"
        ),
        TYPE_RENDERER_PLAY(
            type = TYPE.PLAY,
            code = ExoPlaybackException.TYPE_RENDERER,
            head = "재생 실패"
        ),
        TYPE_REMOTE_PLAY(
            type = TYPE.PLAY,
            code = ExoPlaybackException.TYPE_REMOTE,
            head = "재생 실패"
        ),
        NOT_FOUND_CONTENT(
            type = TYPE.DEFAULT,
            code = 408,
            head = "정보를 찾을 수 없음",
            defaultBody = "해당 컨텐츠는 라이센스가 만료되어 시청할 수 없습니다."
        ),
        TYPE_UNEXPECTED_PLAY(
            type = TYPE.PLAY,
            code = ExoPlaybackException.TYPE_UNEXPECTED,
            head = "재생 실패"
        );

        fun build(type: ErrorType): ErrorType {
            type.body = ""
            return type
        }

        fun build(type: ErrorType, body: String): ErrorType {
            type.body = body
            return type
        }
    }

    /**
     * 등록된 error code의 문구를 출력 할 때 사용
     * */
    fun getErrorType(type: String, code: Int): ErrorType {
        return when (type) {
            TYPE.PAY -> {
                when (code) {
                    202 -> ErrorType.ACCEPTED_PAY.build(
                        ErrorType.ACCEPTED_PAY
                    )
                    401 -> ErrorType.UNAUTHORIZED_PAY.build(
                        ErrorType.UNAUTHORIZED_PAY
                    )
                    else -> getDefaultErrorType(
                        code
                    )
                }
            }
            TYPE.ADULT -> {
                when (code) {
                    202 -> ErrorType.ACCEPTED_ADULT
                    401 -> ErrorType.UNAUTHORIZED_ADULT
                    else -> getDefaultErrorType(
                        code
                    )
                }
            }
            TYPE.AUTH -> {
                when (code) {
                    401 -> ErrorType.UNAUTHORIZED_AUTH
                    else -> getDefaultErrorType(
                        code
                    )
                }
            }
            else -> getDefaultErrorType(code)
        }
    }

    /**
     * 등록된 error code의 문구가 아닌 사용자 문구를 출력할 때 사용
     * */
    fun getErrorType(type: String, code: Int, body: String): ErrorType {
        return when (type) {
            TYPE.PAY -> {
                when (code) {
                    202 -> ErrorType.ACCEPTED_PAY.build(
                        ErrorType.ACCEPTED_PAY, body
                    )
                    401 -> ErrorType.UNAUTHORIZED_PAY.build(
                        ErrorType.UNAUTHORIZED_PAY, body
                    )
                    else -> getDefaultErrorType(
                        code,
                        body
                    )
                }
            }
            TYPE.ADULT -> {
                when (code) {
                    202 -> ErrorType.ACCEPTED_ADULT.build(
                        ErrorType.ACCEPTED_ADULT, body
                    )
                    401 -> ErrorType.UNAUTHORIZED_ADULT.build(
                        ErrorType.UNAUTHORIZED_ADULT, body
                    )
                    else -> getDefaultErrorType(
                        code,
                        body
                    )
                }
            }
            TYPE.AUTH -> {
                when (code) {
                    401 -> ErrorType.UNAUTHORIZED_AUTH.build(
                        ErrorType.UNAUTHORIZED_AUTH, body
                    )
                    else -> getDefaultErrorType(
                        code,
                        body
                    )
                }
            }
            TYPE.PLAY -> {
                when (code) {
                    0 -> ErrorType.TYPE_SOURCE_PLAY.build(
                        ErrorType.TYPE_SOURCE_PLAY, body
                    )
                    1 -> ErrorType.TYPE_RENDERER_PLAY.build(
                        ErrorType.TYPE_RENDERER_PLAY, body
                    )
                    2 -> ErrorType.TYPE_REMOTE_PLAY.build(
                        ErrorType.TYPE_REMOTE_PLAY, body
                    )
                    3 -> ErrorType.TYPE_UNEXPECTED_PLAY.build(
                        ErrorType.TYPE_UNEXPECTED_PLAY, body
                    )
                    else -> getDefaultErrorType(
                        code,
                        body
                    )
                }
            }
            else -> getDefaultErrorType(
                code,
                body
            )
        }
    }

    enum class NormalPopupType(
        val head: String,
        val sub: String = "",
        var body: String,
        val btns: ArrayList<Label>,
        val timer: Int = 0
    ) {
        REG_ADD(
            head = "URL 발송 완료",
            body = "입력하신 휴대폰 번호로 회원가입을 위한 URL이 전달되었습니다.\n회원가입을 완료하신 후 <회원가입 완료> 버튼을 눌러주세요.",
            btns = arrayListOf(Label.REG_FINISH),
            timer = 0
        ),
        USER_INFO_CHANGE(
            head = "URL 발송 완료",
            body = "입력하신 휴대폰 번호로 회원정보 변경을 위한 URL이 전달되었습니다.\n회원정보 변경을 완료하신 후 <변경 완료> 버튼을 눌러주세요.",
            btns = arrayListOf(Label.CHANGE_FINISH),
            timer = 0
        ),
        ADULT_AUTH(
            head = "URL 발송 완료",
            body = "입력하신 휴대폰 번호로 URL이 전달되었습니다.\n성인인증을 완료하신 후 <성인인증 완료> 버튼을 눌러주세요.",
            btns = arrayListOf(Label.ADULT_AUTH),
            timer = 0
        ),
        ADULT_PASSWORD_CHANGE(
            head = "URL 발송 완료",
            body = "입력하신 휴대폰 번호로 성인인증 번호 변경을 위한 URL이 전달되었습니다.\n성인인증 번호 변경을 완료하신 후 <변경 완료> 버튼을 눌러주세요.",
            btns = arrayListOf(Label.CHANGE_FINISH),
            timer = 0
        ),
        PURCHASE_PASSWORD_CHANGE(
            head = "URL 발송 완료",
            body = "입력하신 휴대폰 번호로 결제인증번호 변경을 위한 URL이 전달되었습니다.\n결제인증번호 변경을 완료하신 후 <변경 완료> 버튼을 눌러주세요.",
            btns = arrayListOf(Label.CHANGE_FINISH),
            timer = 0
        ),
        REG_REMOVE(
            head = "홈초이스 탈퇴완료",
            body = "그 동안 이용해 주셔서 감사합니다.\n더 좋은 서비스 제공을 위해 최선을 다하겠습니다. ",
            btns = arrayListOf(Label.OK),
            timer = 0
        ),
        REG_FIND(
            head = "URL 발송 완료",
            body = "입력하신 휴대폰 번호로 아이디/비밀번호 찾기를 위한\nURL이 전달되었습니다.",
            btns = arrayListOf(),
            timer = 3
        ),
        PURCHASE_SUCCESS(
            head = "구매 완료",
            body = "구매가 완료되었습니다.\nMY > 구매목록에서 구매 내역을 확인하실 수 있습니다.",
            btns = arrayListOf(),
            timer = 3
        ),
        RESIGN_MEMBER(
            head = "홈초이스 탈퇴완료",
            body = "그 동안 이용해 주셔서 감사합니다.\n 더 좋은 서비스 제공을 위해 최선을 다하겠습니다.",
            btns = arrayListOf(Label.OK),
            timer = 0
        ),

        PURCHASE_FAIL(
            head = "구매 불가",
            body = "사용할 수 없는 카드 입니다\n[ MY > 카드 관리 > 카드 등록/해지 ]에서\n 다른 카드로 변경 후 사용 가능 합니다.",
            btns = arrayListOf(Label.OK),
            timer = 0
        ),
        PURCHASE_PIN_CHECK(
            head = "카드 비밀번호 오류",
            body = "신용카드 정보 확인/변경 : 홈→MY→카드변경\n※ 5회 오류 시, 신용카드 이용제한",
            btns = arrayListOf(Label.OK),
            timer = 0
        ),
        PURCHASE_PIN_FAIL(
            head = "카드 비밀번호 인증 오류 횟수 초과",
            body = "카드사에 문의하여, 변경된 카드 비밀번호를 회원 정보에 등록해 주세요.\n(신용카드 정보 확인/변경 : 홈→MY→카드변경)",
            btns = arrayListOf(Label.OK),
            timer = 0
        ),
        CARD_ADD(
            head = "URL 발송 완료",
            body = "입력하신 휴대폰 번호로 카드등록을 위한 URL이 전달되었습니다.\n카드등록을 완료하신 후 <카드등록 완료> 버튼을 눌러주세요.",
            btns = arrayListOf(Label.REG_CARD_FINISH),
            timer = 0
        ),
        CARD_REGISTER(
            head = "카드 등록 안내",
            body = "포인트는 간편결제를 통해서만 구매가 가능하므로\n카드 등록 후 구매해 주시기 바랍니다.",
            btns = arrayListOf(Label.REG_CARD, Label.OK)
        ),
        LOGIN(
            head = "로그인",
            body = "로그인이 완료되었습니다.",
            btns = arrayListOf(),
            timer = 3
        ),
        LOGOUT(
            head = "로그아웃 완료",
            body = "로그아웃이 완료되었습니다.",
            btns = arrayListOf(),
            timer = 3
        ),
        UN_SUBSCRIPTION(
            head = "해지 완료",
            body = "해지가 완료 되었습니다",
            btns = arrayListOf(Label.OK),
            timer = 0
        ),
        DORMANT_ACCOUNT(
            head = "휴먼계정",
            body = "모바일 내에서 로그인 시 휴면 상태가 해제되었습니다.\n앞으로 제한 없이 홈초이스를 즐기실 수 있습니다.",
            btns = arrayListOf(Label.OK),
            timer = 0
        ),
        DOUBLE_CHECK_LOGIN(
            head = "로그인 안내",
            body = "다른 기기에서 동일한 아이디로 로그인 되어 있습니다.\n현재 기기에서 로그인 하시겠습니까?\n(다른 기기에서는 자동 로그아웃 됩니다)",
            btns = arrayListOf(Label.LOGIN, Label.CANCEL),
            timer = 0
        ),
        PURCHASE_POINT(
            head = "포인트 충전 완료",
            body = "포인트가 충전되었습니다.\n" +
                    "충전하신 포인트로 콘텐츠를 구매하실 수 있습니다.",
            btns = arrayListOf(),
            timer = 3
        ),
        POINT_REGISTER_SUCCESS(
            head = "포인트 등록 완료",
            body = "포인트가 등록되었습니다.\n" +
                    "등록하신 포인트로 콘텐츠를 구매하실 수 있습니다.",
            btns = arrayListOf(),
            timer = 3
        ),
        POINT_ISSUE(
            head = "쿠폰 발행",
            body = "쿠폰이 발행되었습니다.\n" +
                    "MY > 포인트 > 포인트 내역에서 확인하실 수 있습니다.",
            btns = arrayListOf(Label.POINT_CONFIRM),
            timer = 0
        ),
        REG_ZZIM(
            head = "찜하기",
            body = "찜하기가 완료되었습니다.\n" +
                    "MY > 찜 목록에서 확인하실 수 있습니다.",
            btns = arrayListOf(),
            timer = 3
        ),
        LOGIN_GUIDE(
            head = "회원가입",
            body = "가입확인이 필요합니다.\n" +
                "고객센터로 문의하세요.(070-7163-5757)",
            btns = arrayListOf(Label.OK),
            timer = 0
        );

    }

    private fun getDefaultErrorType(code: Int): ErrorType {
        return when (code) {
            0 -> ErrorType.FAIL.build(
                ErrorType.FAIL
            )
            CODE.BAD -> ErrorType.BAD.build(
                ErrorType.BAD
            )
            CODE.FORBIDDEN -> ErrorType.FORBIDDEN.build(
                ErrorType.FORBIDDEN
            )
            CODE.NOT -> ErrorType.NOT.build(
                ErrorType.NOT
            )
            CODE.CONFLICT -> ErrorType.CONFLICT.build(
                ErrorType.CONFLICT
            )
            408 -> ErrorType.NOT_FOUND_CONTENT.build(
                ErrorType.NOT_FOUND_CONTENT
            )
            else -> ErrorType.SERVER.build(
                ErrorType.SERVER
            )
        }
    }

    private fun getDefaultErrorType(code: Int, body: String): ErrorType {
        return when (code) {
            400 -> ErrorType.BAD.build(
                ErrorType.BAD, body
            )
            403 -> ErrorType.FORBIDDEN.build(
                ErrorType.FORBIDDEN, body
            )
            404 -> ErrorType.NOT.build(
                ErrorType.NOT, body
            )
            409 -> ErrorType.CONFLICT.build(
                ErrorType.CONFLICT, body
            )
            408 -> ErrorType.NOT_FOUND_CONTENT.build(
                ErrorType.NOT_FOUND_CONTENT, body
            )
            else -> ErrorType.SERVER.build(
                ErrorType.SERVER, body
            )
        }
    }

}
