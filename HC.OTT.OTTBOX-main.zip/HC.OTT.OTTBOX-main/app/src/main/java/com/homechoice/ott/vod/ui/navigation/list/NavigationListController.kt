package com.homechoice.ott.vod.ui.navigation.list

import android.util.Log
import com.homechoice.ott.vod.util.Logger

class NavigationListController(listData: NavigationListData, var event: NavigationListEvent) {
    var data = listData

    fun setNavigationData(newData: NavigationListData) {
        data = newData
    }

    fun removeItem(index: Int) {
        data.list.removeAt(index)
    }

    fun resetRemoveData() {
        if (data.curIndex == data.totalIndex) {
            data.curIndex -= 1
        }
        data.totalCount = data.totalCount - 1
        data.totalIndex = data.totalCount - 1
    }

    fun decrease(): Boolean {
        return if (data.curIndex > 0) {
            data.preIndex = data.curIndex
            data.curIndex--

            if (data.visibleIndex > 0) {
                Logger.Log(Log.WARN, this, "라인이 안넘어 갔음")
                data.visibleIndex--
            } else {
                Logger.Log(Log.WARN, this, "라인이 넘어 갔음")
                data.startIndex--
                event.minusLineChange()
            }
            event.focusChange()
            printString()
            true
        } else {
            printString()
            false
        }
    }

    fun increase(): Boolean {
        return if (data.curIndex < (data.totalCount - 1)) {
            data.preIndex = data.curIndex
            data.curIndex++

            if (data.visibleIndex < data.visibleThreshold - 1) {
                Logger.Log(Log.WARN, this, "라인이 안넘어 갔음")
                data.visibleIndex++
            } else {
                Logger.Log(Log.WARN, this, "라인이 넘어 갔음")
                data.startIndex++
                event.plusLineChange()
            }
            event.focusChange()

            printString()
            true
        } else {
            printString()
            false
        }
    }

    private fun printString() {
        Logger.Log(
            Log.DEBUG,
            this,
            "NavigationView $data"
        )
    }

    fun visibleThreshold(): Int {
        return data.visibleThreshold
    }

    fun getCurItem(): Any? {
        return data.list[data.curIndex]
    }

    fun getItem(position: Int): Any? {
        return data.list[position]
    }

    fun getCurIndex(): Int {
        return data.curIndex
    }

    fun getVisibleIndex(): Int {
        return data.visibleIndex
    }

    fun getDataList(): List<Any>? {
        return data.list
    }

    fun getTotalCount(): Int {
        return data.totalCount
    }

    fun getTotalIndex(): Int {
        return data.totalIndex
    }

    fun getPreIndex(): Int {
        return data.preIndex
    }

    fun getStartIndex(): Int {
        return data.startIndex
    }


    fun getVisibleThreshold(): Int {
        return data.visibleThreshold
    }


    fun isLastItem(): Boolean {
        return data.curIndex == data.totalIndex
    }

}