package com.homechoice.ott.vod.ui.my.member

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.activity.OnBackPressedCallback
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.CategoryAgent
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentMyMemberLogoutBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_my_member_logout.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlinx.coroutines.Dispatchers


class MemberLogoutFragment(val activityHandler: Handler) : NavigationView2() {

    private lateinit var bind: FragmentMyMemberLogoutBinding
    private lateinit var inputMethodManager: InputMethodManager
    private lateinit var viewModel: MemberLogoutViewModel

    private lateinit var callback: OnBackPressedCallback

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_my_member_logout, container, false)
        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        inputMethodManager = context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        viewModel = ViewModelProvider(this).get(MemberLogoutViewModel::class.java)
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (btn_cancel.hasFocus()) {
                    logout_button.requestFocus()
                } else if (logout_button.hasFocus()) {
                    false
                }
                true
//                if (bind.btnCancel.isSelected) {
//                    controller.decrease()
//                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (logout_button.hasFocus()) {
                    btn_cancel.requestFocus()
                } else if (btn_cancel.hasFocus()) {
                    false
                }
                true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                true
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_BUTTON_A,
            KeyEvent.KEYCODE_ENTER -> {
                if (logout_button.hasFocus()) {
                    logout()
                } else if (btn_cancel.hasFocus()) {
                    requireActivity().supportFragmentManager.beginTransaction().remove(this).commit()
                    activityHandler.obtainMessage(2).sendToTarget()
                }
                true
            }
            KeyEvent.KEYCODE_BACK, 97 -> {
                requireActivity().supportFragmentManager.beginTransaction().remove(this).commit()
                activityHandler.obtainMessage(2).sendToTarget()
                true
            }
            else -> {
                false
            }
        }
    }

    override fun active() {
    }

    private fun logout() {
            MBSAgent.logout(object : Callback<ResponseNoBody> {
                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, "onFailure : ${t.localizedMessage}")
                    context?.let {
                        PopupAgent.showNormalPopup(
                            it,
                            PopupType.getErrorType(
                                TYPE.AUTH,
                                CODE.NONE
                            ),
                            object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    when (btn) {
                                        BtnLabel.OK -> {
                                            d.dismiss()
                                        }
                                    }
                                }
                            })
                    }
                }

                override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                    if (response.isSuccessful && response.body() != null) {
                        context?.let {
                            STBAgent.isAuth = false
                            STBAgent.isMyAdultAuth = false
                            STBAgent.cardName = ""

                            STBAgent.logout()
                            STBAgent.initPreference()
                            activityHandler.obtainMessage(4).sendToTarget()
                            STBAgent.clearData(it)
                        }
                        parentFragmentManager.popBackStack("MY_CATEGORY_LIST", 1)

                    } else {
                        context?.let {
                            when (response.code()) {
                                CODE.CONFLICT -> {
                                    UIAgent.showPopupForMyMenu(it, response.code(), object : RetryCallback {
                                        override fun call() {
                                            logout()
                                        }

                                        override fun cancel() {
                                        }
                                    })
                                }
                                else -> {
                                    val error = response.errorBody()?.let { MBSAgent.error(it) }
                                    PopupAgent.showNormalPopup(
                                        it,
                                        PopupType.getErrorType(
                                            TYPE.LOGOUT,
                                            response.code(),
                                            error?.errorString!!
                                        ),
                                        object : PopupEvent {
                                            override fun onClick(d: Dialog, btn: String) {
                                                when (btn) {
                                                    BtnLabel.OK -> {
                                                        d.dismiss()
                                                    }
                                                }
                                            }
                                        })
                                }
                            }
                        }
                    }
                }

            })
    }

    fun focus() {
        bind.logoutButton.requestFocus()
    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        TODO("Not yet implemented")
    }

    //    뒤로가기 (카테고리 수정 후 fragment 전환으로 변경 예정)
    override fun onAttach(context: Context) {
        super.onAttach(context)

        callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                requireActivity().supportFragmentManager.beginTransaction()
                    .remove(this@MemberLogoutFragment)
                    .commit()
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(this, callback)
    }
}