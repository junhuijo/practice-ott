package com.homechoice.ott.vod.ui.detail.series


import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.foundation.PivotOffsets
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.items
import com.homechoice.ott.vod.model.content.Content
import kotlinx.coroutines.flow.StateFlow

@Composable
fun ContentList(
    contents: StateFlow<List<Content>>,
    modifier: Modifier = Modifier,
    viewModel: SeriesViewModel,
    playerManager: PlayerManager
) {
    val focusRequester = remember { FocusRequester() }
    val contentList by contents.collectAsState()

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .height(60.dp)
                .fillMaxWidth()
//                .background(Color.Black)
        ) {
            Text(
                text = "에피소드",
                color = Color.White,
                fontSize = 18.sp,
                modifier = Modifier
                    .align(Alignment.CenterVertically)
                    .padding(start = 30.dp)
            )
        }

        TvLazyColumn(pivotOffsets = PivotOffsets(0.1f)) {
            items(contentList) { content ->
                val index = contentList.indexOf(content)
                EpisodeItem(
                    content = content,
                    onFocusChanged = { focused ->
                        if (focused) {
                            viewModel.updateCurrentEpisodeIndex(index)
                        }
                    },
                    focusRequest = focusRequester,
                    viewModel = viewModel,
                    playerManager = playerManager
                )
            }
        }
    }
}
