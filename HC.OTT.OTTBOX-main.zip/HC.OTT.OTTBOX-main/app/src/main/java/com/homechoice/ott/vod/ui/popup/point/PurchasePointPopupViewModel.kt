package com.homechoice.ott.vod.ui.popup.point

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.point.PointProduct

class PurchasePointPopupViewModel(data: PointProduct) : ViewModel() {
    val pointProduct = data
    var price: MutableLiveData<String> = MutableLiveData()
    var validity: MutableLiveData<String> = MutableLiveData()
    var accumulate: MutableLiveData<String> = MutableLiveData()
    var password : MutableLiveData<String> = MutableLiveData()


    init {
        price.value = data.priceStr
        validity.value = data.validDate
        accumulate.value = data.mileagePriceStr + "P 적립"
        password.value = ""
    }
}