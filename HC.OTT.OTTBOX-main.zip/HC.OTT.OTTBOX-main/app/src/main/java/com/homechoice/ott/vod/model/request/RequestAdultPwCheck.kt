package com.homechoice.ott.vod.model.request

data class RequestAdultPwCheck(
    val terminalKey: String,
    val adultPw: String
)
