package com.homechoice.ott.vod.ui.navigation.linear

import com.homechoice.ott.vod.agent.HomeContentFocusType

interface NavigationLinearLayoutEvent {
    fun rightLineChange(position: Int, count: Int)
    fun leftLineChange(count: Int)
    fun lastLineChange()
    fun firstLineChange(count: Int)
    fun focusChange(focusType: HomeContentFocusType)
    fun exitChange()
}