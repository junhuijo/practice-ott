package com.homechoice.ott.vod.model.response

import com.homechoice.ott.vod.model.serviceLog.ServiceLog

data class  ResponseServiceLogList (
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val totalCount: Int,
    val serviceLogList: List<ServiceLog>
)