package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.point.PointHistory
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponsePointHistoryList(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val totalCount : Int,
    val historyList : List<PointHistory>
): Parcelable