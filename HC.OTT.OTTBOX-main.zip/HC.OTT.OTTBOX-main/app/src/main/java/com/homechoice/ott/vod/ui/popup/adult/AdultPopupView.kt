package com.homechoice.ott.vod.ui.popup.adult

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.DialogAdultBinding
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.model.popup.Phone
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AdultPopupView(
    ctx: Context,
    login: Login,
    val event: PopupEvent
) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {

    private var binding: DialogAdultBinding = DialogAdultBinding.inflate(LayoutInflater.from(ctx))
    private var model: AdultPopupViewModel = AdultPopupViewModel(login)
    private val dialog = this
    private var pinNumber = ""
    private var pinInput: ArrayList<TextView?> = arrayListOf()

    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        binding.apply {
            viewModel = model
        }
        if (login.bodyText.isNotEmpty()) {
            binding.adultBodyText.text = login.bodyText
        }

        setContentView(binding.root)
        pinInput = arrayListOf(binding.newKeypadInput0, binding.newKeypadInput1, binding.newKeypadInput2, binding.newKeypadInput3)
        val keyPadList: ArrayList<LinearLayout> =
            arrayListOf(
                binding.numDel, // 0 <-
                binding.num0, // 1
                binding.numOk, // 2
                binding.num1, // 3 <-
                binding.num2, // 4
                binding.num3, // 5
                binding.num4, // 6 <-
                binding.num5, // 7
                binding.num6, // 8
                binding.num7, // 9 <-
                binding.num8, // 10
                binding.num9  // 11
            )

        for (item in keyPadList) {
            item.setOnClickListener {
                pushKey(it)
            }
        }

        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            Logger.Log(Log.DEBUG, this, "kCode:$kCode")
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    }
                }
            }
            result
        }
        binding.num0.requestFocus()
    }

    private fun pushKey(view: View) {
        when (view.id) {
            binding.numOk.id -> okNumber()
            binding.numDel.id -> removeNumber()
            else ->
                appendNumber(view.tag as String)
        }
    }

    private fun appendNumber(num: String) {
        // PhoneNumberUtils.formatNumber(yourStringPhone, Locale.getDefault().getCountry())
        Logger.Log(Log.DEBUG, this, "appendNumber $num")
        if (pinNumber.length < 4)
            pinNumber += num
        showPinNumber()
    }

    private fun removeNumber() {
        if (pinNumber.isNotEmpty())
            pinNumber = pinNumber.substring(0, pinNumber.length - 1)
        showPinNumber()
    }

    private fun showPinNumber() {
        for (i in 0..3) {
            if (i > pinNumber.length - 1) {
                pinInput[i]?.text = ""
            }
            else {
                pinInput[i]?.text = "●"
            }
        }
        if (pinNumber.length == 4) {
            binding.numOk.requestFocus()
        }
    }

    //
    private fun okNumber() {
        if (pinNumber.length > 3) {
            MBSAgent.adultPwCheck(STBAgent.encrypt(pinNumber)!!, object : Callback<ResponseNoBody> {
                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                    PopupAgent.showNormalPopup(
                        context,
                        PopupType.getErrorType(
                            TYPE.AUTH,
                            CODE.NONE
                        ),
                        object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                when (btn) {
                                    BtnLabel.OK -> {
                                        d.dismiss()
                                    }
                                }
                            }
                        })
                }

                override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                    if (response.isSuccessful && response.body() != null) {
                        STBAgent.isAdultAuth = true
                        event.onClick(dialog, BtnLabel.OK)
                    }
                    else {
                        // 성인 인증 실패
                        // 초기화 처리
//                        STBAgent.isAdultAuth = false
                        when (response.code()) {
                            401 -> {
                                binding.warnText.text = "* 잘못된 비밀번호 입니다."
                                binding.warnText.visibility = View.VISIBLE
                            }
                            412 -> {
                                binding.warnText.text = "* 성인인증 번호를 등록해주세요."
                                binding.warnText.visibility = View.VISIBLE
                            }
                            CODE.CONFLICT -> {
                                UIAgent.showPopup(context, CODE.CONFLICT, null)
                            }
                            else -> {
                                binding.warnText.text = "* 잘못된 비밀번호 입니다."
                                binding.warnText.visibility = View.VISIBLE
                            }
                        }
                        pinNumber = ""
                        showPinNumber()
                    }
                }
            })
        }
        else {
            binding.warnText.text = "비밀번호 4자리를 입력해 주세요."
        }
    }

}