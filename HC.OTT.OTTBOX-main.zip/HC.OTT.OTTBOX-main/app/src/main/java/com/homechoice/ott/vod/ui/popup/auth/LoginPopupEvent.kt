package com.homechoice.ott.vod.ui.popup.auth

import android.app.Dialog

interface LoginPopupEvent {
    fun onLogin(loginDialog: Dialog, btn: String)
}