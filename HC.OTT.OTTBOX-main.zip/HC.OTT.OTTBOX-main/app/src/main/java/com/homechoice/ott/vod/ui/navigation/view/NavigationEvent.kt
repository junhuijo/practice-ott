package com.homechoice.ott.vod.ui.navigation.view

interface NavigationEvent {
    fun rightLineChange(position: Int)
    fun leftLineChange()
    fun lastLineChange()
    fun firstLineChange()
    fun focusChange()
    fun addEmptyRow()
    fun lineChange(isDown: Boolean)
}