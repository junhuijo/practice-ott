package com.homechoice.ott.vod.ui.popup.pay

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogDeletePurchaseLogBinding
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger

class DeletePurchaseLogPopupView : Dialog {
    private var binding: DialogDeletePurchaseLogBinding

    constructor(
        ctx: Context,
        event: PopupEvent
    ) : super(ctx, R.style.Theme_Design_NoActionBar) {
        binding = DialogDeletePurchaseLogBinding.inflate(LayoutInflater.from(ctx))
        init()
        showNormalPopup(event)
    }

    private fun init() {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        setContentView(binding.root)
    }

    private fun showNormalPopup(
        event: PopupEvent
    ) {
        binding.btnDelete.setOnClickListener {
            event.onClick(this, (it as TextView).text.toString())
        }

        binding.btnCancel.setOnClickListener {
            event.onClick(this, (it as TextView).text.toString())
        }

        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            Logger.Log(Log.DEBUG, this, "kCode:$kCode")
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97-> {
                        dismiss()
                        result = true
                    }
                }
            }
            result
        }

        binding.btnDelete.requestFocus()

        show()
    }
}