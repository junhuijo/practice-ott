package com.homechoice.ott.vod.util

import java.util.*

object DateUtil {

    fun getDate(dateStr: String): Date {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, dateStr.substring(0, 4).toInt())
        cal.set(Calendar.DAY_OF_MONTH, dateStr.substring(5, 7).toInt())
        cal.set(Calendar.DATE, dateStr.substring(8, 10).toInt())

        cal.set(Calendar.HOUR, dateStr.substring(11, 13).toInt())
        cal.set(Calendar.MINUTE, dateStr.substring(14, 16).toInt())
        cal.set(Calendar.SECOND, dateStr.substring(17, 19).toInt())
        return cal.time
    }

    fun getTime(dateStr: String): Long {
        return getDate(dateStr).time
    }

    fun getCurrentTime(): Long {
        val cal = Calendar.getInstance()
        return cal.time.time
    }

}