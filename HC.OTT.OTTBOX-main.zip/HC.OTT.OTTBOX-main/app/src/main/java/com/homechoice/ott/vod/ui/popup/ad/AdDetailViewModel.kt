package com.homechoice.ott.vod.ui.popup.ad

import androidx.lifecycle.ViewModel

class AdDetailViewModel: ViewModel() {

}