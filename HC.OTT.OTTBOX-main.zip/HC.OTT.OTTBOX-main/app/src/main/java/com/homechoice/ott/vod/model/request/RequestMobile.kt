package com.homechoice.ott.vod.model.request

data class RequestMobile(
    val terminalKey: String,
    val mobileNumber: String
)
