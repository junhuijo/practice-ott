package com.homechoice.ott.vod.model.response

import com.homechoice.ott.vod.model.content.Offer

data class CheckPermissionResponse(
    val transactionId: String,
    val errorString: String,
    val sessionState: String,
    val dliveterminalKey: String,
    val offerList: List<Offer>
)