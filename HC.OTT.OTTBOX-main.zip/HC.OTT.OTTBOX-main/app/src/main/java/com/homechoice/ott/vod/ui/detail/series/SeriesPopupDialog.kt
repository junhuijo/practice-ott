package com.homechoice.ott.vod.ui.detail.series

import AgeGrade
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.unit.dp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.window.Dialog
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.rememberTvLazyListState


@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun SeriesPopupDialog(
    genre: String,
    duration: String,
    rating: String,
    synopsis: String,
    director: String,
    cast: List<String>,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = modifier
                .background(Color.DarkGray)
                .padding(16.dp)
                .focusable(true)
                .onKeyEvent { keyEvent ->
                    if (keyEvent.key == Key.Enter) {
                        onDismiss()
                        true
                    } else {
                        false
                    }
                }
        ) {
            TvLazyColumn(
                state = rememberTvLazyListState(),
                modifier = Modifier.fillMaxHeight()
            ) {
                item {
                    // 기본 정보
                    Column(
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Text(text = "기본 정보", color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(modifier = Modifier.padding(horizontal = 8.dp)) {
                            Row {
                                Text(text = "장르: ", color = Color.LightGray)
                                Text(text = genre, color = Color.White)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row {
                                Text(text = "상영시간: ", color = Color.LightGray)
                                Text(text = duration, color = Color.White)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "연령 등급: ", color = Color.LightGray)
                                AgeGrade(grade = rating, modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                    Divider(color = Color.White, thickness = 1.dp)  // 흰색 줄 추가

                }
                item {
                    // 줄거리
                    Column(
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Text(text = "줄거리", color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = synopsis,
                            color = Color.White,
                            maxLines = 7,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                    Divider(color = Color.White, thickness = 1.dp)  // 흰색 줄 추가
                }
                item {
                    // 감독 / 출연
                    Column(
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Text(text = "감독 / 출연", color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(modifier = Modifier.padding(horizontal = 8.dp)) {
                            Row {
                                Text(text = "감독: ", color = Color.LightGray)
                                Text(text = director, color = Color.White)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row {
                                Text(text = "출연: ", color = Color.LightGray)
                                Text(text = cast.joinToString(", "), color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}






