package com.homechoice.ott.vod.ui.home.category

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Typeface
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.CustomColor
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.util.Logger

@SuppressLint("ViewConstructor")
class CategoryView {

    private lateinit var viewHolder: ViewHolder

    var isChangeMarginTop = false

    constructor(ctx: Context, layout: LinearLayout) {
        val view = LayoutInflater.from(ctx).inflate(R.layout.home_category_list_item, layout, false)
        view.visibility = View.INVISIBLE
        layout.addView(view)
    }

    constructor(ctx: Context, item: CategoryList, layout: LinearLayout) {
        init(ctx, item, layout)
    }

    private fun init(ctx: Context, item: CategoryList, layout: LinearLayout) {
        val view = LayoutInflater.from(ctx).inflate(R.layout.home_category_list_item, layout, false)

        viewHolder = ViewHolder()
        viewHolder.view = view
        viewHolder.titleView = view.findViewById(R.id.main_category_title)
        viewHolder.okImageView = view.findViewById(R.id.main_category_list_ok_f)
        viewHolder.inImageView = view.findViewById(R.id.main_category_list_indicator)
        viewHolder.selectedImageView = view.findViewById(R.id.main_category_selected_f)
        viewHolder.unSelectedImageView = view.findViewById(R.id.main_category_selected_n)

        viewHolder.titleView.text = item.title
        view.visibility = View.VISIBLE

        layout.addView(view)
    }

    fun initFocus() {
        Logger.Log(Log.DEBUG, this, "initFocus")
        viewHolder.titleView.visibility = View.INVISIBLE
        viewHolder.okImageView.visibility = View.INVISIBLE
        viewHolder.inImageView.visibility = View.INVISIBLE
        viewHolder.selectedImageView.visibility = View.GONE
        viewHolder.unSelectedImageView.visibility = View.VISIBLE
        viewHolder.view.layoutParams = UIAgent.createLayoutParamsWithMargin(
            LinearLayout.LayoutParams.MATCH_PARENT,
            CMBApp.getPixelSize(R.dimen.home_category_layout_height),
            0,
            0,
            0,
            0
        )
        isChangeMarginTop = false
    }

    fun focus() {
        viewHolder.titleView.setTypeface(CMBApp.TYPEFACE, Typeface.BOLD)
        viewHolder.titleView.setTextSize(TypedValue.COMPLEX_UNIT_PX, CMBApp.getPixelSize(R.dimen.home_category_font_focus).toFloat())
        viewHolder.titleView.setTextColor(CustomColor.CATEGORY_TEXT_FOCUS.rgb())
        viewHolder.okImageView.visibility = View.VISIBLE
        viewHolder.inImageView.visibility = View.VISIBLE
        viewHolder.titleView.isSelected = true
    }

    fun unfocus() {
        viewHolder.titleView.setTypeface(CMBApp.TYPEFACE, Typeface.NORMAL)
        viewHolder.titleView.setTextSize(TypedValue.COMPLEX_UNIT_PX, CMBApp.getPixelSize(R.dimen.home_category_font_unfocus).toFloat())
        viewHolder.titleView.setTextColor(CustomColor.CATEGORY_TEXT_UNFOCUS.rgb())
        viewHolder.okImageView.visibility = View.INVISIBLE
        viewHolder.inImageView.visibility = View.INVISIBLE
        viewHolder.view.layoutParams?.height = CMBApp.getPixelSize(R.dimen.home_category_layout_height)
        viewHolder.titleView.isSelected = false
    }

    fun selectedFocus() {
        viewHolder.titleView.visibility = View.INVISIBLE
        viewHolder.okImageView.visibility = View.GONE
        viewHolder.inImageView.visibility = View.INVISIBLE

        viewHolder.selectedImageView.visibility = View.VISIBLE
        viewHolder.unSelectedImageView.visibility = View.GONE

        //xhdmp = 22 / mdip 25
        viewHolder.view.layoutParams = UIAgent.createLayoutParamsWithMargin(
            LinearLayout.LayoutParams.MATCH_PARENT,
            CMBApp.getPixelSize(R.dimen.home_category_layout_height).plus(25),
            0,
            5,
            0,
            0
        )
        isChangeMarginTop = false
    }

    fun unSelectedFocus() {
        unfocus()
        viewHolder.titleView.visibility = View.INVISIBLE
        viewHolder.okImageView.visibility = View.INVISIBLE
        viewHolder.inImageView.visibility = View.INVISIBLE

        viewHolder.selectedImageView.visibility = View.GONE
        viewHolder.unSelectedImageView.visibility = View.VISIBLE

        viewHolder.view.layoutParams = UIAgent.createLayoutParamsWithMargin(
            LinearLayout.LayoutParams.MATCH_PARENT,
            CMBApp.getPixelSize(R.dimen.home_category_layout_height),
            0,
            0,
            0,
            0
        )
        isChangeMarginTop = false
    }

    fun offSelectedFocus() {
        viewHolder.titleView.visibility = View.VISIBLE
        viewHolder.okImageView.visibility = View.INVISIBLE
        viewHolder.inImageView.visibility = View.INVISIBLE
        viewHolder.selectedImageView.visibility = View.GONE
        viewHolder.unSelectedImageView.visibility = View.GONE
        viewHolder.view.layoutParams = UIAgent.createLayoutParamsWithMargin(
            LinearLayout.LayoutParams.MATCH_PARENT,
            CMBApp.getPixelSize(R.dimen.home_category_layout_height),
            0,
            0,
            0,
            0
        )
        isChangeMarginTop = false
    }

    //xhdmp = 25 / mdip 20
    fun selectedUnFocus() {
        viewHolder.view.layoutParams = UIAgent.createLayoutParamsWithMargin(
            LinearLayout.LayoutParams.MATCH_PARENT,
            CMBApp.getPixelSize(R.dimen.home_category_layout_height),
            0,
            -25,
            0,
            0
        )
        isChangeMarginTop = true
    }

    class ViewHolder {
        lateinit var item: CategoryList
        lateinit var view: View
        lateinit var titleView: TextView
        lateinit var okImageView: ImageView
        lateinit var inImageView: ImageView
        lateinit var selectedImageView: ImageView
        lateinit var unSelectedImageView: ImageView
    }

}