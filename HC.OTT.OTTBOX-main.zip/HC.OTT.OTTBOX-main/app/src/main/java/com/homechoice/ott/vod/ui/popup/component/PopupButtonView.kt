package com.homechoice.ott.vod.ui.popup.component

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import com.homechoice.ott.vod.R


@SuppressLint("ViewConstructor")
class PopupButtonView(
    ctx: Context,
    layout: LinearLayout,
    label: String
) : LinearLayout(ctx) {
    var btn: TextView

    init {
        val view = LayoutInflater.from(ctx).inflate(R.layout.dialog_button_item, layout, false)
        btn = view.findViewById(R.id.btn_label)
        btn.text = label
        layout.addView(view)
    }

    fun focus() {
        btn.requestFocus()
    }
}