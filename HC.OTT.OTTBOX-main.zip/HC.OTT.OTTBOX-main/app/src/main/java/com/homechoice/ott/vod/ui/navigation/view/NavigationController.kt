package com.homechoice.ott.vod.ui.navigation.view

import android.util.Log
import com.homechoice.ott.vod.util.Logger

class NavigationController {
    lateinit var data: NavigationData
    lateinit var event: NavigationEvent
    lateinit var model: NavigationModel
    constructor() {
    }

    constructor(model: NavigationModel, event: NavigationEvent) {
        this.model = model
        this.data = model.data
        this.event = event
    }

    fun setNavigationData(newData: NavigationData) {
        data = newData
    }

    fun getNavigationData(): NavigationData {
        return data
    }

    fun decrease(): Boolean {
        return if (data.curIndex > 0) {
            data.preIndex = data.curIndex
            data.curIndex--

            if (data.visibleIndex > data.leftFixedIndex) {
                data.visibleIndex--
                event.focusChange()
            } else {
                Logger.Log(Log.WARN, this, "0")
                if (data.startIndex > 0)
                    data.startIndex--
                if (data.curIndex == 0 && getVisibleIndex() > 0) {
                    data.visibleIndex--
                    event.leftLineChange()
                } else if (data.curIndex == 0) {
                    event.firstLineChange()
                } else {
                    Logger.Log(Log.WARN, this, "1")
                    if (data.visibleIndex == data.leftFixedIndex) {
                        Logger.Log(Log.WARN, this, "2")
                        event.leftLineChange()
                    }

                }
                event.focusChange()
            }
            printString()
            true
        } else {
            printString()
            false
        }
    }

    fun increase(): Boolean {
        return if (data.curIndex < (data.totalCount - 1)) {
            data.preIndex = data.curIndex
            data.curIndex++

            if (data.visibleIndex < data.rightFixedIndex) {
                Logger.Log(Log.WARN, this, "라인이 안넘어 갔음")
                data.visibleIndex++
                if (data.curIndex == data.totalIndex) {
                    Logger.Log(Log.WARN, this, "마지막 라인")
                    event.lastLineChange()
                }
                event.focusChange()
            } else {
                if (data.startIndex + data.visibleThreshold < data.totalCount)
                    data.startIndex++

                if (data.totalIndex < data.totalCount - 1) {
                    Logger.Log(Log.WARN, this, "라인이 모두 로드 안 되었음 -> 다음 라인 불러오기")
                    // 홈 화면에선 한번에 다 불러와서 사용하지 않음
                    // 서브 카테고리 화면에서 사용함

                    data.requestIndex += data.visibleThreshold

                    event.rightLineChange(0)
                } else {
                    Logger.Log(Log.WARN, this, "더 불러올 라인이 없음")
                    if (!data.isLoaded) {

                        if (data.totalIndex == data.totalCount - 1) {
                            data.isLoaded = true
                        }
                        if (data.curIndex == data.totalIndex) {
                            Logger.Log(Log.WARN, this, "마지막 라인")
                            event.lastLineChange()
                        } else {
                            Logger.Log(Log.WARN, this, "빈 라인 만들기")
                            data.isEmpty = true
                            event.addEmptyRow()
                        }
                    } else {
                        Logger.Log(Log.WARN, this, "빈 라인 안만들기")
                        if (data.curIndex == data.totalIndex) {
                            Logger.Log(Log.WARN, this, "마지막 라인")
                            data.visibleIndex++
                            event.lastLineChange()
                        } else {
                            event.lineChange(true)
                        }

                    }

                }
                event.focusChange()
            }
            printString()
            true
        } else {
            printString()
            false
        }
    }

    private fun printString() {
        Logger.Log(
            Log.DEBUG,
            this,
            "NavigationView ${data.toString()}"
        )
    }

    fun appendData(list: ArrayList<Any>) {
        model.addModel(list)
        Logger.Log(
            Log.DEBUG,
            this,
            "NavigationView ${data.toString()}"
        )
    }

    fun visibleThreshold(): Int {
        return data.visibleThreshold
    }

    fun getCurItem(): Any? {
        return data.list[data.curIndex]
    }

    fun getItem(position: Int): Any? {
        return data.list[position]
    }

    fun getCurIndex(): Int {
        return data.curIndex
    }

    fun getVisibleIndex(): Int {
        return data.visibleIndex
    }

    fun getDataList(): List<Any>? {
        return data.list
    }

    fun getTotalCount(): Int {
        return data.totalCount
    }

    fun getTotalIndex(): Int {
        return data.totalIndex
    }

    fun getPreIndex(): Int {
        return data.preIndex
    }

    fun getStartIndex(): Int {
        return data.startIndex
    }

    fun isEmpty(): Boolean {
        return data.isEmpty
    }

    fun getVisibleThreshold(): Int {
        return data.visibleThreshold
    }

    fun getRequestIndex(): Int {
        return data.requestIndex
    }

    fun isLastItem(): Boolean {
        return data.curIndex == data.totalIndex
    }

    fun setCurrentIndex(index: Int) {
        data.curIndex = index
    }


}