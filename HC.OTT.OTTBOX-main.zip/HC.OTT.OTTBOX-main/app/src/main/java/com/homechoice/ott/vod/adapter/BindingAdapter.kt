package com.homechoice.ott.vod.adapter

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.util.Log
import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.EventType
import com.homechoice.ott.vod.agent.StickerType
import com.homechoice.ott.vod.agent.TranslationType
import com.homechoice.ott.vod.util.Logger

object BindingAdapter {
    @JvmStatic
    @BindingAdapter("bind:imgRes")
    fun imgRes(imageView: ImageView, resid: Int) = imageView.setImageResource(resid)

    @JvmStatic
    @BindingAdapter("bind:imageUrl")
    fun imageUrl(imageView: ImageView, imageUrl: String?) {
        if (imageUrl != null && imageUrl.isNotEmpty()) {
            Glide.with(imageView).load(imageUrl).placeholder(R.drawable.poster).into(imageView)

        } else {
            Glide.with(imageView).load(R.drawable.poster).into(imageView)
        }
    }

    //bannerListImageUrl
    @JvmStatic
    @BindingAdapter("bind:bannerListImageUrl")
    fun bannerListImageUrl(imageView: ImageView, imageUrl: String?) {
        if (imageUrl != null && imageUrl.isNotEmpty()) {
            Glide.with(imageView).asBitmap().load(imageUrl).placeholder(R.drawable.default_event).into(object : CustomTarget<Bitmap?>() {
                override fun onLoadCleared(placeholder: Drawable?) {
                    Logger.Log(Log.WARN, this, "onLoadCleared")
                }

                override fun onLoadStarted(placeholder: Drawable?) {
                    super.onLoadStarted(placeholder)
                    Logger.Log(Log.WARN, this, "onLoadStarted")
                    imageView.setImageDrawable(placeholder)
                }

                override fun onLoadFailed(errorDrawable: Drawable?) {
                    super.onLoadFailed(errorDrawable)
                    imageView.scaleType = ImageView.ScaleType.FIT_XY
                }

                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                    Logger.Log(Log.WARN, this, "onResourceReady byteCount ${resource.byteCount} / rowBytes ${resource.rowBytes}")
                    imageView.setImageBitmap(resource)
                }
            })
        } else {
            Glide.with(imageView).load(R.drawable.default_event).into(imageView)
        }
    }

    @JvmStatic
    @BindingAdapter("bind:bannerImageUrl")
    fun bannerUrl(imageView: ImageView, imageUrl: String?) {
        if (imageUrl != null && imageUrl.isNotEmpty()) {
            Logger.Log(Log.INFO, this, "imageUrl : $imageUrl")
            Glide.with(imageView).load(imageUrl).into(imageView)
        }
    }

    @JvmStatic
    @BindingAdapter("bind:eventType")
    fun eventSticker(imageView: ImageView, eventType: String?) {
        when (eventType) { //TODO: eventType 별 이미지를 추가해야함.
            EventType.NOWING -> imageView.setImageResource(R.drawable.sticker_01)
            EventType.FIRST -> imageView.setImageResource(R.drawable.sticker_02)
            EventType.MONOFOLY -> imageView.setImageResource(R.drawable.sticker_04)
            EventType.SALE -> imageView.setImageResource(R.drawable.sticker_03)
            else -> imageView.setImageResource(0)
        }
    }

    @JvmStatic
    @BindingAdapter("bind:stickerType")
    fun sticker(imageView: ImageView, stickerType: String?) {
        when (stickerType) { //TODO: stickerType 별 이미지를 추가해야함.
            StickerType.HOT -> imageView.setImageResource(R.drawable.sticker_hot)
            StickerType.NEW -> imageView.setImageResource(R.drawable.sticker_new)
            StickerType.DISCOUNT -> imageView.setImageResource(R.drawable.sticker_sale)
            StickerType.AUDIO_VISUAL -> imageView.setImageResource(R.drawable.sticker_ex)
            else -> imageView.setImageResource(0)
        }
    }

    @JvmStatic
    @BindingAdapter("bind:translationType")
    fun translationSticker(imageView: ImageView, translationType: String?) {
        when (translationType) { //TODO : translationType 별 이미지를 추가해야함
            TranslationType.DUB -> imageView.setImageResource(R.drawable.sticker_dubbing)
            TranslationType.SUB -> imageView.setImageResource(R.drawable.sticker_subtitles)
            else -> imageView.setImageResource(0)
        }
    }


}