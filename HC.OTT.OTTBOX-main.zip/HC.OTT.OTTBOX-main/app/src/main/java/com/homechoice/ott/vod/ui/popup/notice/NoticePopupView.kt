package com.homechoice.ott.vod.ui.popup.notice

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import androidx.core.view.get
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogNoticePopBinding
import com.homechoice.ott.vod.ui.navigation.navigator.NavigatorModel
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.dialog_notice_pop.*
import kotlinx.android.synthetic.main.notice_button_item.view.*

class NoticePopupView : Dialog {
    private var binding: DialogNoticePopBinding = DialogNoticePopBinding.inflate(LayoutInflater.from(context))

    private lateinit var navigatorModel : NavigatorModel

    private var viewModel : NoticePopupModel = NoticePopupModel()
    object Buttons {
        val NOTICE = arrayListOf<String>(Label.DETAIL,Label.CLOSE)
        val FAQ = arrayListOf<String>(Label.CLOSE)
    }

    object Label{
        const val DETAIL = "자세히보기"
        const val CLOSE = "닫기"
    }

    constructor(
        title : String?,
        imgUrl : String?,
        description : String?,
        useLinkDetail : Boolean,
        context: Context,
        event: PopupEvent
    ) : super(context, R.style.Theme_Design_NoActionBar) {
        //DialogDeletePurchaseLogBinding.inflate(LayoutInflater.from(ctx))
        init()

        viewModel.title.value = title
        if(description.isNullOrBlank()){
            Logger.Log(Log.DEBUG, this, "description is empty")
            viewModel.description.value = null
        }else {
            viewModel.description.value = description
        }

        if(imgUrl.isNullOrBlank()) {
            Logger.Log(Log.DEBUG, this, "imgUrl is empty")
            viewModel.imgUrl.value = null
        }else{
            viewModel.imgUrl.value = imgUrl
        }
        //notice_pop_title.text = title
        //notice_pop_description.text = description
        Logger.Log(Log.DEBUG, this, "showPopup : $title , $imgUrl , $description ")
        var btns: ArrayList<String> = if(useLinkDetail){ Buttons.NOTICE}else{Buttons.FAQ}
        showNormalPopup(event , btns)
    }

    private fun init() {
        viewModel = NoticePopupModel()
        binding.viewModel = viewModel
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        setContentView(binding.root)
    }

    private fun createButtons(buttons : List<String> , eventListener : PopupEvent){
        for (item in buttons) {
            val view = LayoutInflater.from(context).inflate(R.layout.notice_button_item, btn_layout , false)
            view.notice_detail_button.text = item
            btn_layout.addView(view)
        }

        navigatorModel  = NavigatorModel(0 , 0 , buttons.size , 5, object:NavigatorModel.Callback{
            override fun init(index: Int) {
                btn_layout[index].isSelected = true
            }

            override fun pageStartIndexChanged() {

            }

            override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
                btn_layout[previousIndex].isSelected = false
                btn_layout[index].isSelected = true
            }

        })

    }

    private fun showNormalPopup(
        event: PopupEvent, buttons : List<String>
    ) {

        createButtons(buttons = buttons , eventListener = event)

        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {

                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        notice_scroll.pageScroll(View.FOCUS_UP)
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN ->{
                        notice_scroll.pageScroll(View.FOCUS_DOWN)
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT ->{
                        navigatorModel.right()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT ->{
                        navigatorModel.left()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER->{
                        event.onClick(this , btn_layout[navigatorModel.currentIndex].notice_detail_button.text.toString())
                        result = true
                    }

                }
            }
            result
        }

  //      binding.btnDelete.requestFocus()
        show()
    }
}