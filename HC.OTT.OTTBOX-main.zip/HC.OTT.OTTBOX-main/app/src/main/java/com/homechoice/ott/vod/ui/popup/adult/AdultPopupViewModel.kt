package com.homechoice.ott.vod.ui.popup.adult

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.popup.Login

class AdultPopupViewModel(data: Login) : ViewModel() {
    var login: MutableLiveData<Login> = MutableLiveData()

    init {
        login.value = data
    }
}