package com.homechoice.ott.vod.model.request

data class RequestReviewRating (
    val terminalKey: String,
    val contentId: Long,
    val reviewRating: Int
)