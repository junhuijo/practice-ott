package com.homechoice.ott.vod.model.response

import com.homechoice.ott.vod.model.wish.WishItem

data class ResponseWishItemList(
    val transactionId: String,
    val sessionState: String = "",
    val errorString: String,
    val totalCount: Int,
    val wishItemList: List<WishItem>
)