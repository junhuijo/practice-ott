package com.homechoice.ott.vod.ui.sub

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.SessionState
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.model.response.ResponseCategoryList
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.ui.navigation.view.*
import com.homechoice.ott.vod.ui.sub.topCategory.SubTopCategoryView
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class SubTopCategoryListFragment(private val navigationController: NavigationController, var actionEventHandler: Handler) : NavigationView2() {

    var categoryViewList: ArrayList<SubTopCategoryView> = arrayListOf()
    var linearLayout: LinearLayout? = null
    var horizontalScrollView: HorizontalScrollView? = null
    var transactionId = ""

    @SuppressLint("InflateParams")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_sub_top_category_list, null)

        horizontalScrollView = view.findViewById(R.id.sub_category_list_scrollview)
        linearLayout = view.findViewById(R.id.sub_top_category_list)

        val event: NavigationEvent = object : NavigationEvent {
            override fun rightLineChange(position: Int) {
                requestTopCategoryList(
                    (controller.getCurItem() as CategoryList).id,
                    controller.getRequestIndex(),
                    controller.getVisibleThreshold()
                )
            }

            override fun leftLineChange() {
                smoothScrollDxBy(false)
            }

            override fun lastLineChange() {
                smoothScrollDxBy(true)
            }

            override fun firstLineChange() {
                smoothScrollDxBy(false)
            }

            override fun focusChange() {
                categoryViewList[controller.getPreIndex()].unfocus()
                categoryViewList[controller.getCurIndex()].focus()
            }

            override fun addEmptyRow() {
                val subView = SubTopCategoryView(context!!)
                linearLayout?.addView(subView)
                categoryViewList.add(subView)
                smoothScrollDxBy(true)
            }

            override fun lineChange(isDown: Boolean) {
                smoothScrollDxBy(isDown)
            }
        }


        setNavigationController(navigationController)
        setEvent(event)


        for (item in controller.getDataList()!!) {
            val subView = SubTopCategoryView(context!!, (item as CategoryList).title)
            linearLayout?.addView(subView)
            categoryViewList.add(subView)
        }

        GlobalScope.launch(Dispatchers.Main) {
            delay(500)
            horizontalScrollView?.smoothScrollBy(
                CMBApp.RES.getDimensionPixelSize(R.dimen.sub_category_layout_col_Width) * (controller.getStartIndex())
                , 0
            )
            selectFocus()
        }

        // 처리
        return view
    }

    fun focus() {
        categoryViewList[controller.getCurIndex()].focus()
    }

    private fun selectFocus() {
        categoryViewList[controller.getCurIndex()].selectFocus()
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.INFO, this, "onKeyDown keyCode : $keyCode")
        var result = false
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.CONTENTS_FOCUS).sendToTarget()
                result = true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                result = true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (controller.increase()) {
                    actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.CONTENTS_UPDATE, controller.getCurItem()).sendToTarget()
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (controller.getCurIndex() == 0) {
                    categoryViewList[controller.getCurIndex()].selectFocus()
                    actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.MAIN_CATEGORY_FOCUS).sendToTarget()
                } else {
                    if (controller.decrease()) {
                        actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.CONTENTS_UPDATE, controller.getCurItem()).sendToTarget()
                    }
                }
                result = true
            }
        }
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode :$keyCode / result : $result")
        return result
    }

    override fun active() {
    }

    fun requestTopCategoryList(id: Int, startIndex: Int, pageSize: Int) {
        transactionId = UUID.randomUUID().toString()
        MBSAgent.getCategoryList(
            "transactionId",
            id,
            false,
            STBAgent.isAdultAuth,
            STBAgent.isAdultAuth,
            startIndex,
            pageSize,
            object : Callback<ResponseCategoryList> {
                override fun onResponse(call: Call<ResponseCategoryList>, res: Response<ResponseCategoryList>) {
                    if (res.isSuccessful && res.body() != null) {
                        val response: ResponseCategoryList = res.body()!!
                        when (response.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                                UIAgent.showPopup(context!!, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                        requestTopCategoryList(id, startIndex, pageSize)
                                    }
                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                if (response.transactionId == transactionId) {
                                    val arrayList: ArrayList<Any> = arrayListOf()
                                    for (item in response.categoryList) {
                                        arrayList.add(item)
                                    }
                                    controller.appendData(arrayList)

                                    for (item in response.categoryList) {
                                        val subView = SubTopCategoryView(context!!, item.title)
                                        linearLayout?.addView(subView)
                                        categoryViewList.add(subView)
                                    }
                                    smoothScrollDxBy(true)
                                }
                            }
                        }

                    } else {
                        Logger.Log(Log.ERROR, this, "실패")
                    }
                }

                override fun onFailure(call: Call<ResponseCategoryList>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, "실패")
                }
            })
    }

    private fun smoothScrollDxBy(isDown: Boolean) {
        if (isDown)
            horizontalScrollView?.smoothScrollBy(
                CMBApp.RES.getDimensionPixelSize(R.dimen.sub_category_layout_col_Width),
                0
            )
        else
            horizontalScrollView?.smoothScrollBy(
                -CMBApp.RES.getDimensionPixelSize(R.dimen.sub_category_layout_col_Width),
                0
            )
    }

    fun selected() {
        categoryViewList[controller.getCurIndex()].selectFocus()
    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        TODO("Not yet implemented")
    }

}

