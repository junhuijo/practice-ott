package com.homechoice.ott.vod.ui.my.notice

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class NoticeListViewModel(idx : Int , value: NoticeListFragment.Display) : ViewModel() {

    var notice: MutableLiveData<NoticeListFragment.Display> = MutableLiveData()

    var number: MutableLiveData<String> = MutableLiveData()

    init {
        notice.value = value
        number.value = (idx + 1).toString()
    }
}