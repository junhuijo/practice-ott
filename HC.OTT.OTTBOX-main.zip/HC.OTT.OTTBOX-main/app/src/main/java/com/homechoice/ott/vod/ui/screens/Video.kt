package com.homechoice.ott.vod.ui.screens

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaSession2
import android.media.metrics.PlaybackStateEvent
import android.media.session.MediaSession
import android.util.Log
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.ui.PlayerView
import com.google.android.exoplayer2.upstream.DataSource
import com.google.android.exoplayer2.upstream.DefaultDataSource
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import kotlinx.coroutines.delay

@Composable
fun VideoContent(
    movieUrl: String= "",
    onEnded: ()->Unit,
    lifecycleOwner: LifecycleOwner = LocalLifecycleOwner.current
){
    var flag = true
    val context = LocalContext.current
    val exoPlayer = remember {
        SimpleExoPlayer.Builder(context).build().apply {
            val defaultDataSourceFactory = DefaultDataSourceFactory(context)
            val dataSourceFactory: DataSource.Factory = DefaultDataSourceFactory(context,defaultDataSourceFactory)

            val source = MediaItem.fromUri(movieUrl)

            setMediaItem(source)
            prepare()
        }
    }
    if(flag) Text(text = "나와라요",color = Color.Transparent)
    AndroidView(factory = { context ->
        PlayerView(context).apply {
            useController = false
            player = exoPlayer
        }
    })

    DisposableEffect(movieUrl, lifecycleOwner) {
        val listener = object : Player.EventListener {
            override fun onPlaybackStateChanged(state: Int) {
                when(state) {
                    Player.STATE_ENDED -> {
                        onEnded()
                    }
                    Player.STATE_READY -> {
                        exoPlayer.play()
                        flag = false
                    }
                }
            }
        }

        val observer = LifecycleEventObserver { _, event ->
            when(event) {
                Lifecycle.Event.ON_PAUSE -> {
                    exoPlayer.release()
                }
                Lifecycle.Event.ON_RESUME -> {
                    when(exoPlayer.playbackState){
                        1 -> {
                            onEnded()
                        }
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            flag = true
            lifecycleOwner.lifecycle.removeObserver(observer)
        }

    }



//    val simpleExoPlayer = rememberSimpleExoPlayer(context)
//    DisposableEffect(movieUrl) {
//
//        val listener = object : Player.EventListener {
//            override fun onPlaybackStateChanged(state: Int) {
//                when(state) {
//                    Player.STATE_ENDED -> {
//                        onEnded()
//                    }
//                }
//            }
//        }
//
//
//        val mediaItem = MediaItem.fromUri(movieUrl)
//        simpleExoPlayer.apply {
//            setMediaItem(mediaItem)
//            prepare()
//        }
//        simpleExoPlayer.setMediaItem(mediaItem)
//        simpleExoPlayer.prepare()
//        simpleExoPlayer.playWhenReady = true
//
//        simpleExoPlayer.addListener(listener)
//
//        onDispose {
//            simpleExoPlayer.removeListener(listener)
//            simpleExoPlayer.release()
//        }
//    }
//    AndroidView(
//        factory = {
//            PlayerView(context).apply {
//                useController = false
//                player = simpleExoPlayer
//            }
//        },
//        modifier = Modifier.fillMaxSize()
//    )

}

@SuppressLint("RememberReturnType")
@Composable
private fun rememberSimpleExoPlayer(context: Context) = remember {
    val trackSelector = DefaultTrackSelector(context).apply {
        setParameters(buildUponParameters().apply {
            setMaxVideoSize(360,240)
        })
    }
    SimpleExoPlayer.Builder(context)
        .setTrackSelector(trackSelector)
        .build()
}