package com.homechoice.ott.vod.ui.screens.adultpassqrscan

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.ui.screens.home.HomeViewModel


@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun AdultQrDialog(
    onDismiss: () -> Unit,
    homeViewModel: HomeViewModel
) {
    val focusRequester = FocusRequester()

    Dialog(
        onDismissRequest = {
            homeViewModel.checkAndShowAdultVerification()
            onDismiss()
        },
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Card(
            modifier = Modifier
                .width(600.dp)
                .height(224.dp)
                .background(Color.Black)
                .border(BorderStroke(4.dp, color = Color.White), RectangleShape),
            colors = CardDefaults.cardColors(
                containerColor = colorResource(R.color.quit_app_dialog_bg)
            ),
            border = BorderStroke(dimensionResource(R.dimen.border_width), colorResource(R.color.dialog_border3))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Spacer(modifier = Modifier.height(32.dp))
                    Text(
                        text = stringResource(R.string.adult_pass_verification),
                        textAlign = TextAlign.Center,
                        style = TextStyle(
                            fontSize = 24.sp,
                            color = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(38.dp))
                    TextButton(
                        onClick = {
                            homeViewModel.checkAndShowAdultVerification()
                            onDismiss()
                        },
                        modifier = Modifier
                            .width(226.dp)
                            .height(48.dp)
                            .focusRequester(focusRequester)
                            .focusable(),
                        shape = RoundedCornerShape(dimensionResource(R.dimen.adult_content_dialog_radius)),
                        colors = ButtonDefaults.buttonColors(Color.Red),
                        border = BorderStroke(dimensionResource(R.dimen.border_width), Color.White)
                    ) {
                        Text(
                            text = stringResource(R.string.adult_password_setting_ok_button),
                            textAlign = TextAlign.Center,
                            style = TextStyle(
                                fontSize = 20.sp,
                                color = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(modifier = Modifier.height(46.dp))
                }
            }
        }
        LaunchedEffect(Unit) {
            focusRequester.requestFocus()
        }
    }
}









