//package com.homechoice.ott.vod.ui.search.recommend
//
//import android.content.Context
//import android.os.Handler
//import android.util.Log
//import android.view.KeyEvent
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.view.animation.AnimationUtils
//import androidx.recyclerview.widget.RecyclerView
//import com.bumptech.glide.Glide
//import com.homechoice.ott.vod.CMBApp
//import com.homechoice.ott.vod.R
//import com.homechoice.ott.vod.agent.*
//import com.homechoice.ott.vod.databinding.ItemSearchRecommendListBinding
//import com.homechoice.ott.vod.model.CategoryItem
//import com.homechoice.ott.vod.ui.search.SearchActivity
//import com.homechoice.ott.vod.util.Logger
//import kotlin.collections.ArrayList
//
//class SearchRecommendAdapter(private var items: List<CategoryItem>, private val eventHandler: Handler) :
//    RecyclerView.Adapter<SearchRecommendAdapter.ViewHolder>() {
//
//    private var viewList: ArrayList<ViewHolder> = arrayListOf()
//
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        viewList.add(holder)
//        holder.bindViews(items[position], position, items.size)
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, index: Int): ViewHolder {
//        val binding = ItemSearchRecommendListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
//        return ViewHolder(binding, parent.context, eventHandler)
//    }
//
//    override fun getItemCount(): Int {
//        return items.size
//    }
//
//    private interface UpdateViewHolder {
//        fun bindViews(data: CategoryItem, position: Int, totalCount: Int)
//    }
//
//    fun init() {
//        viewList[0].binding.subContentListPoster.requestFocus()
//    }
//
//    class ViewHolder(val binding: ItemSearchRecommendListBinding, val ctx: Context, private val eventHandler: Handler) :
//        RecyclerView.ViewHolder(binding.root), UpdateViewHolder {
//
//        override fun bindViews(data: CategoryItem, position: Int, totalCount: Int) {
//            if (data.posterUrl != "")
//                Glide.with(ctx).load(data.posterUrl).thumbnail(0.3F)
//                    .override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height))
//                    .placeholder(R.drawable.main_poster_1_d)
//                    .into(binding.subContentListPoster)
//
//            binding.subContentListPoster.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
//                var animationId = R.anim.anim_search_content_scale_down
//                if (hasFocus)
//                    animationId = R.anim.anim_search_content_scale_up
//
//                AnimationUtils.loadAnimation(ctx, animationId).also {
//                    it.fillAfter = true
//                    v.startAnimation(it)
//                }
//            }
//
//            binding.subContentListPoster.setOnClickListener {
//                val enterPath = UIAgent.createEnterPath(EnterPath.RECOMMEND_FOR_SEARCH, 0)
//                Logger.Log(Log.INFO, this, "setOnClickListener $enterPath")
//                // CMS에서 Content, Series 만 걸도록 되어 있음.
//                when (data.type) {
//                    CategoryItemType.CONTENTGROUP -> {
//                        ActivityChangeAgent.goToContent(ctx, data.id, enterPath, null)
//                    }
//                    CategoryItemType.SERIES -> {
//                        ActivityChangeAgent.goToSeriesContent(data.id, 0, ctx, enterPath, null)
//                    }
////                    CategoryItemType.CATEGORY -> {
////                        ActivityChangeAgent.goToSubCategoryList(
////                            ctx,
////                            data.linkInfo!!.toInt(),
////                            SubCategoryActivity.ActionType.CONTENTS_FOCUS
////                        )
////                    }
////                    CategoryItemType.PACKAGE_OFFER -> {
////                        ActivityChangeAgent.goToPackage(
////                            ctx,
////                            UUID.randomUUID().toString(),
////                            data.linkInfo!!.toLong(),
////                            EnterPath.RECOMMEND_FOR_SEARCH,
////                            null
////                        )
////                    }
//                }
//            }
//
//            binding.subContentListPoster.setOnKeyListener { _, keyCode, event ->
//                Logger.Log(Log.INFO, this, "setOnKeyListener $keyCode / adapterPosition : $adapterPosition / totalCount : $totalCount")
//
//                if (event.action == KeyEvent.ACTION_DOWN) {
//                    when (keyCode) {
//                        KeyEvent.KEYCODE_BACK -> {
//                            eventHandler.obtainMessage(SearchActivity.ActionType.SEARCH_EXIT).sendToTarget()
//                            true
//                        }
//                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
//                            adapterPosition == totalCount - 1
//                        }
//
//                        else -> false
//                    }
//                } else
//                    false
//            }
//        }
//    }
//
//}