package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.CategoryList
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseSiblingCategoryList(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val parentCategoryId: Int,
    var categoryList: List<CategoryList>
) : Parcelable