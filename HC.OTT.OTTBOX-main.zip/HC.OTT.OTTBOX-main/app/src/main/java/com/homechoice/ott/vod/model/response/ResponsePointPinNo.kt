package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
class ResponsePointPinNo(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val pointBalance: Int = -1,
    val registerPrice: Int = 0
) : Parcelable