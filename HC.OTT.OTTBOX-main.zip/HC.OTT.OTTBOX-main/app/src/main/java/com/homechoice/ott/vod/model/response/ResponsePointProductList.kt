package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.point.PointProduct
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponsePointProductList(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val totalCount : Int,
    val productList : List<PointProduct>
): Parcelable