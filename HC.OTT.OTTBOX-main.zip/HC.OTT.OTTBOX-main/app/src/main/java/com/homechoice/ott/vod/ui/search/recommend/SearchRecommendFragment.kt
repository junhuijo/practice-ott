//package com.homechoice.ott.vod.ui.search.recommend
//
//import android.annotation.SuppressLint
//import android.os.Bundle
//import android.os.Handler
//import android.util.Log
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import androidx.recyclerview.widget.LinearLayoutManager
//import com.homechoice.ott.vod.databinding.FragmentSearchRecommendBinding
//import com.homechoice.ott.vod.model.CategoryItem
//import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
//import com.homechoice.ott.vod.util.Logger
//
//class SearchRecommendFragment(val categoryItemList: List<CategoryItem>, private val eventHandler: Handler) : NavigationListView() {
//
//    private lateinit var binding: FragmentSearchRecommendBinding
//    private lateinit var adapter: SearchRecommendAdapter
//
//    @SuppressLint("InflateParams")
//    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        binding = FragmentSearchRecommendBinding.inflate(inflater)
//        binding.apply {
//        }
//
//        if (categoryItemList.isNotEmpty()) {
//            adapter = SearchRecommendAdapter(categoryItemList, eventHandler)
//            binding.searchRecommendList.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
//            binding.searchRecommendList.adapter = adapter
//        } else {
//            binding.searchRecommendEmptyLayout.visibility = View.VISIBLE
//        }
//
//        return binding.root
//    }
//
//    /**
//     * 키 이벤트
//     * return false: 키 이벤트 넘기기
//     * return true: 키 이벤트 넘기지 않기
//     * */
//    override fun onKeyDown(keyCode: Int): Boolean {
//        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
//        return true
//    }
//
//    override fun active() {
//    }
//
//    fun focus() {
//        Logger.Log(Log.DEBUG, this, "onKeyDown focus / isNullOrEmpty ${categoryItemList.isNullOrEmpty()}")
//        if (!categoryItemList.isNullOrEmpty())
//            adapter.init()
//    }
//
//    fun select() {
//    }
//
//    override fun setVisible(visible: Int) {
//    }
//
//    override fun lateActive() {
//    }
//
//    fun back() {
//    }
//
//}