package com.homechoice.ott.vod.ui.navigation.view

interface NavigationViewEvent {
    fun rightLineChange(position: Int)
    fun leftLineChange()
    fun lastLineChange()
    fun firstLineChange()
    fun focusChange()
}