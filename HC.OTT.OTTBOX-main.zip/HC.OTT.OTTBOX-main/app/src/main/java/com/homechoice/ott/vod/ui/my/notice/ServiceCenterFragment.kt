package com.homechoice.ott.vod.ui.my.notice

import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.Category
import com.homechoice.ott.vod.databinding.FragmentServiceCenterBinding
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.util.Logger

class ServiceCenterFragment(private val activityHandler: Handler, val category: Category) : NavigationView2() {

    private lateinit var bind: FragmentServiceCenterBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_service_center, container, false)
        bind.lifecycleOwner = this
        return bind.root
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume")
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }


    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
            return false;
    }

    override fun active() {

    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {

    }

}