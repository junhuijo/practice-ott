package com.homechoice.ott.vod.ui.my.pay

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentMyMonthListBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.purchaseLog.PurchaseLog
import com.homechoice.ott.vod.model.response.ResponsePurchaseLogList
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.ui.navigation.list.NavigationListData
import com.homechoice.ott.vod.ui.navigation.list.NavigationListEvent
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.pay.UnSubscriptionPopupView
import com.homechoice.ott.vod.util.Logger
import com.homechoice.ott.vod.util.StringUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MonthListFragment(private val activityHandler: Handler) : NavigationListView() {

    private lateinit var binding: FragmentMyMonthListBinding
    private lateinit var adapter: MonthLogListAdapter
    private lateinit var viewHolder: MonthLogListAdapter.ViewHolder

    private var logList: ArrayList<PurchaseLog> = arrayListOf()

    private var heightList: IntArray = intArrayOf()

    @SuppressLint("InflateParams")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMyMonthListBinding.inflate(inflater)
        requestPurchaseLogList()
        return binding.root
    }

    private fun requestPurchaseLogList() {
        GlobalScope.launch(Dispatchers.Main) {
            MBSAgent.purchaseLogList(
                StringUtil.getInstance().getEndDate(-2, 0),
                StringUtil.getInstance().getStartDate(),
                false,
                "subscribe",
                1,
                0,
                object : Callback<ResponsePurchaseLogList> {
                    override fun onFailure(call: Call<ResponsePurchaseLogList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure")
                    }

                    override fun onResponse(call: Call<ResponsePurchaseLogList>, res: Response<ResponsePurchaseLogList>) {
                        Logger.Log(Log.INFO, this, "onResponse ${res.body()}")

                        if (res.isSuccessful && res.body() != null) {
                            val purchaseLogList = res.body()!!.purchaseLogList
                            val totalCount = res.body()!!.totalCount

                            if (purchaseLogList.isNotEmpty()) {
                                // 아답터에 있는 ViewHolder에 클릭 이벤트가 전달이 안됨.
                                // 일단 여기서 처리 진행
                                val actionHandler = Handler {
                                    Logger.Log(Log.DEBUG, this, "actionHandler ${it.what}")
                                    when (it.what) {
                                        0 -> {
                                            viewHolder = it.obj as MonthLogListAdapter.ViewHolder
                                        }
                                    }
                                    true
                                }
//
                                for (item in purchaseLogList) {
                                    logList.add(item)
                                }
                                adapter = MonthLogListAdapter(binding.logList, logList, actionHandler)

                                setModel(
                                    NavigationListData(
                                        curIndex = 0,
                                        visibleThreshold = 6
                                    ).build(purchaseLogList), object : NavigationListEvent {
                                        override fun focusChange() {
                                            Logger.Log(Log.DEBUG, this, "focusChange")
                                            adapter.focus(controller.getCurIndex(), controller.getPreIndex())
                                            checkArrow()
                                        }

                                        override fun plusLineChange() {
                                            Logger.Log(Log.DEBUG, this, "plusLineChange")
                                            binding.logListScrollView.smoothScrollBy(0, CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                                        }

                                        override fun minusLineChange() {
                                            Logger.Log(Log.DEBUG, this, "minusLineChange")
                                            binding.logListScrollView.smoothScrollBy(0, -CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                                        }
                                    })

                                binding.logListLayout.visibility = View.VISIBLE
                                binding.myPurchaseLogArrow.visibility = View.VISIBLE
                                activityHandler.obtainMessage(11).sendToTarget()
                            } else {
                                binding.loginLine.visibility = View.VISIBLE
                                binding.logListEmptyLayout.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()
                            }
                        } else {
                            Logger.Log(Log.ERROR, this, "실패 팝업 처리")
                            when(res.code()){
                                CODE.CONFLICT -> {
                                    UIAgent.showPopup(context!!, CODE.CONFLICT, object : RetryCallback {
                                        override fun call() {
                                            requestPurchaseLogList()
                                        }
                                        override fun cancel() {
                                        }
                                    })
                                }
                                else ->{
                                    binding.loginLine.visibility = View.VISIBLE
                                    binding.logListEmptyLayout.visibility = View.VISIBLE
                                    activityHandler.obtainMessage(2).sendToTarget()
                                }
                            }
                        }
                    }
                })
        }
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
        if (!::viewHolder.isInitialized) {
            return false
        }
        if (!STBAgent.enableKeyInput(STBAgent.GapTime)) {
            return true
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (viewHolder.binding.itemMyPurchaseLogLayout!!.isSelected) {
                    true
                } else {
                    controller.decrease()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (viewHolder.binding.itemMyPurchaseLogLayout!!.isSelected) {
                    true
                } else {
                    controller.increase()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                !viewHolder.binding.itemMyPurchaseLogLayout!!.isSelected
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (viewHolder.binding.itemMyPurchaseLogLayout!!.isSelected) {
                    true
                } else {
                    adapter.unfocus(controller.getCurIndex())
                    activityHandler.obtainMessage(2).sendToTarget()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                if (!viewHolder.binding.itemMyPurchaseLogLayout!!.isSelected) {
                    viewHolder.select()
                    viewHolder.binding.itemMyPurchaseLogBtnLayout.requestFocus()
                } else {
                    viewHolder.unSelect()
                    UnSubscriptionPopupView(context!!, controller.getCurItem() as PurchaseLog, object : PopupEvent {
                        override fun onClick(d: Dialog, btn: String) {
                            when (btn) {
                                BtnLabel.OK -> {
                                    adapter.removeItem(controller.getCurIndex())
                                    controller.removeItem(controller.getCurIndex())
                                    controller.resetRemoveData()

                                    if (controller.getTotalCount() > 1) {
                                        adapter.focus(controller.getCurIndex(), -1)
                                        checkArrow()
                                    } else {
                                        binding.loginLine.visibility = View.VISIBLE
                                        binding.logListLayout.isVisible = false
                                        binding.logListEmptyLayout.visibility = View.VISIBLE
                                    }
                                    d.dismiss()
                                }
                            }
                        }
                    })
                }
                true
            }

            KeyEvent.KEYCODE_BACK, 97 -> {
                if (viewHolder.binding.itemMyPurchaseLogLayout!!.isSelected) {
                    viewHolder.unSelect()
                } else {
                    adapter.unfocus(controller.getCurIndex())
                    activityHandler.obtainMessage(2).sendToTarget()
                }
                true
            }
            else -> false
        }
    }

    override fun active() {
        focus()
    }

    private fun checkArrow() {
        if (controller.getTotalCount() > controller.getVisibleThreshold()) {
            if (controller.isLastItem())
                binding.myPurchaseLogArrow.visibility = View.INVISIBLE
            else
                binding.myPurchaseLogArrow.visibility = View.VISIBLE
        }
    }

    fun isEnable(): Boolean {
        return binding.logListLayout.isVisible!!
    }

    fun focus() {
        Logger.Log(Log.DEBUG, this, "로그 리스트 focus")
        adapter.focus(controller.getCurIndex(), controller.getPreIndex())
    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        binding.root.visibility = visible
    }

}