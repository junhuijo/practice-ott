package com.homechoice.ott.vod.model.notice

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class FAQ (
    var id: Long = 0,
    var title: String? = "",
    var type : String? = "",
    var text : String? = "",
    var imgUrl : String? = ""
) : Parcelable