package com.homechoice.ott.vod.ui

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.VideoView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.STBAgent
import org.json.JSONObject

class SplashScreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d("Splash start","Splash start")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        val videoView = findViewById<VideoView>(R.id.videoViewSplash)
        val videoPath = "https://d1h3jce690ir5k.cloudfront.net/intro/ochoice_intro_5s.mp4"

        val videoUri = Uri.parse(videoPath)
        videoView.setVideoURI(videoUri)
        videoView.start()

        STBAgent.linkedHomeChoice = true

        var loginId = ""
        var loginPw = ""
        var arg = ""

        if (intent.hasExtra("loginData")) {
            val jsonString = intent.getStringExtra("loginData")!!
//            val jsonString = loginDataToJson("testuser4","8D969EEF6ECAD3C29A3A629280E686CF0C3F5D5A86AFF3CA12020C923ADC6C92")
            Log.d("jsonString", jsonString)
            val (extractedLoginId, extractedLoginPw) = loginDataToString(jsonString)
            Log.d("extractedLoginId", "$extractedLoginId")
            Log.d("extractedLoginPw", "$extractedLoginPw")
            loginId = extractedLoginId ?: ""
            loginPw = extractedLoginPw ?: ""
        } else if(intent.hasExtra("loginId")){
            loginId = intent.getStringExtra("loginId")!!
            loginPw = intent.getStringExtra("loginPw")!!
        }
        if (intent.hasExtra("arg")) {
            arg = intent.getStringExtra("arg")!!
        }

        val eventListener = object : MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener {
            override fun onCompletion(mp: MediaPlayer?) {
                val intent = Intent(this@SplashScreenActivity, MainActivity::class.java)
                intent.putExtra("loginId", loginId)
                intent.putExtra("loginPw", loginPw)
                intent.putExtra("arg", arg)

                startActivity(intent)
                Log.d("Splash end","Splash end")
                finish()
            }

            override fun onError(mp: MediaPlayer?, what: Int, extra: Int): Boolean {
                val intent = Intent(this@SplashScreenActivity, MainActivity::class.java)
                intent.putExtra("loginId", loginId)
                intent.putExtra("loginPw", loginPw)
                intent.putExtra("arg", arg)

                startActivity(intent)
                Log.d("Splash end","Splash end")
                finish()
                return true
            }
        }
        videoView.setOnCompletionListener(eventListener)
        videoView.setOnErrorListener(eventListener)
    }

    //String to Json
    private fun loginDataToJson(loginId: String, loginPw: String): String {
        val jsonObject = JSONObject()
        jsonObject.put("loginId", loginId)
        jsonObject.put("loginPw", loginPw)
        return jsonObject.toString()
    }

    //Json to String
    private fun loginDataToString(jsonString: String): Pair<String?, String?> {
        val json = JSONObject(jsonString)
        val loginId = json.get("loginId") as String
        val loginPw = json.get("loginPw") as String
        return Pair(loginId, loginPw)
    }
}