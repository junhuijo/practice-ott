package com.homechoice.ott.vod.ui.screens.my.adultVerification

import android.app.Activity
import android.app.Dialog
import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.popup.TYPE
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AdultVerificationViewModel : ViewModel() {

    private val _inputPassword = mutableStateListOf<Char>()
    val inputPassword: List<Char> = _inputPassword

    private val _popupState = MutableStateFlow<PopupState>(PopupState.None)
    val popupState: StateFlow<PopupState> = _popupState.asStateFlow()

    private val _showLoginDialog = MutableStateFlow(true)
    val showLoginDialog: StateFlow<Boolean> = _showLoginDialog.asStateFlow()

    private val _instructionMessage = MutableStateFlow<PasswordInstructionMessage>(PasswordInstructionMessage.EnterExistingPassword)
    val instructionMessage: StateFlow<PasswordInstructionMessage> = _instructionMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<PasswordErrorMessage?>(null)
    val errorMessage: StateFlow<PasswordErrorMessage?> = _errorMessage.asStateFlow()

    private var oldPassword: String? = null

    private val _showAdultPasswordSuccessMessage = MutableStateFlow(false)
    val showAdultPasswordSuccessMessage: StateFlow<Boolean> = _showAdultPasswordSuccessMessage

    private val _isPasswordChecked = MutableStateFlow(false)
    val isPasswordChecked: StateFlow<Boolean> = _isPasswordChecked.asStateFlow()

    fun setPasswordChecked(checked: Boolean) {
        _isPasswordChecked.value = checked
    }

    fun showAdultPasswordSuccessMessage(value: Boolean) {
        _showAdultPasswordSuccessMessage.value = value
    }

    fun inputPassword(char: Char) {
        if (_inputPassword.size < 4) {
            _inputPassword.add(char)
        }
    }

    fun deletePassword() {
        if (_inputPassword.isNotEmpty()) {
            _inputPassword.removeLast()
        }
    }

    fun checkPassword() {
        if (_inputPassword.size == 4) {
            val enteredPassword = _inputPassword.joinToString("")
            if (_instructionMessage.value is PasswordInstructionMessage.EnterExistingPassword) {
                adultPwCheck(enteredPassword)
            } else if (_instructionMessage.value is PasswordInstructionMessage.EnterNewPassword) {
                adultPwModify(enteredPassword)
            }
        } else {
            updateErrorMessage(PasswordErrorMessage.InvalidPasswordFormat)
        }
        clearInputPassword()
    }

    private fun clearInputPassword() {
        _inputPassword.clear()
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    private fun adultPwCheck(password: String) {
        MBSAgent.adultPwCheck(
            password,
            callback = object : Callback<ResponseNoBody> {
                override fun onResponse(
                    call: Call<ResponseNoBody>,
                    response: Response<ResponseNoBody>
                ) {
                    if (response.isSuccessful && response.body() != null) {
                        oldPassword = password
                        updateInstructionMessage(PasswordInstructionMessage.EnterNewPassword)
                        clearErrorMessage()
                        setPasswordChecked(true)
                    } else {
                        when (response.code()) {
                            CODE.CONFLICT -> {
                                _popupState.value = PopupState.Conflict
                                STBAgent.isAuth = false
                            }
                            else -> updateErrorMessage(PasswordErrorMessage.PasswordMismatch)
                        }
                    }
                }

                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                    _popupState.value = PopupState.Error(
                        PopupType.getErrorType(TYPE.AUTH, CODE.NONE)
                    )
                }
            }
        )
    }

    private fun adultPwModify(newPassword: String) {
        oldPassword?.let { oldPw ->
            MBSAgent.adultPwModify(
                terminalKey = MBSAgent.terminalKey,
                type = "chg",
                oldPw = oldPw,
                newPw = newPassword,
                callback = object : Callback<ResponseNoBody> {
                    override fun onResponse(
                        call: Call<ResponseNoBody>,
                        response: Response<ResponseNoBody>
                    ) {
                        if (response.isSuccessful) {
                            _popupState.value = PopupState.Success("비밀번호가 성공적으로 변경되었습니다.")
                            clearOldPassword()
                            clearErrorMessage()
                            showAdultPasswordSuccessMessage(true)
                        } else {
                            when (response.code()) {
                                CODE.CONFLICT -> _popupState.value = PopupState.Conflict
                                else -> updateErrorMessage(PasswordErrorMessage.PasswordMismatch)
                            }
                        }
                    }
                    override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                        _popupState.value = PopupState.Error(
                            PopupType.getErrorType(TYPE.AUTH, CODE.NONE)
                        )
                    }
                }
            )
        } ?: run {
            updateErrorMessage(PasswordErrorMessage.PasswordMismatch)
        }
    }

    private fun clearOldPassword() {
        oldPassword = null
    }

    fun error() {
        _popupState.value = PopupState.Error(
            PopupType.getErrorType(TYPE.AUTH, CODE.NONE)
        )
    }

    fun dismissPopup() {
        _popupState.value = PopupState.None
    }

    fun onConflictLogin(context: Context, onDismiss: () -> Unit) {
        if (_showLoginDialog.value) {
            PopupAgent.showLoginPopup(context, object : LoginPopupEvent {
                override fun onLogin(loginDialog: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.SUCCESS -> {
                            loginDialog.dismiss()
                            _showLoginDialog.value = false
                            (context as? Activity)?.finish()
                            onDismiss()
                        }
                        BtnLabel.CANCEL -> {
                            loginDialog.dismiss()
                            _showLoginDialog.value = false
                            onDismiss()
                        }
                        BtnLabel.BACK -> {
                            _showLoginDialog.value = false
                            (context as? Activity)?.finish()
                            onDismiss()
                        }
                    }
                }
            })
        }
    }

    fun updateInstructionMessage(message: PasswordInstructionMessage) {
        _instructionMessage.value = message
    }

    fun updateErrorMessage(message: PasswordErrorMessage?) {
        _errorMessage.value = message
    }

    sealed class PopupState {
        object None : PopupState()
        data class Error(val type: PopupType.ErrorType) : PopupState()
        object Conflict : PopupState()
        data class Success(val message: String) : PopupState()
    }

    sealed class PasswordInstructionMessage {
        object EnterExistingPassword : PasswordInstructionMessage()
        object EnterNewPassword : PasswordInstructionMessage()
    }

    sealed class PasswordErrorMessage {
        object PasswordMismatch : PasswordErrorMessage()
        object InvalidPasswordFormat : PasswordErrorMessage()
    }
}