package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
class ResponsePoint(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val point : Int
) : Parcelable