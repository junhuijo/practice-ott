package com.homechoice.ott.vod.ui.popup.play

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.Window
import android.widget.TextView
import com.homechoice.ott.vod.R

class ErrorPopupView(
    ctx: Context,
    continueClickListener: View.OnClickListener,
    firstClickListener: View.OnClickListener
) : Dialog(ctx) {
    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setCancelable(false)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setContentView(R.layout.dialog_play_continue)

        findViewById<TextView>(R.id.btn_continue).setOnClickListener(continueClickListener)
        findViewById<TextView>(R.id.btn_first).setOnClickListener(firstClickListener)
        findViewById<TextView>(R.id.btn_cancel).setOnClickListener {
            dismiss()
        }
        show()
    }
}