package com.homechoice.ott.vod.popup

import android.app.Dialog
import android.content.Context
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.model.content.Content
import com.homechoice.ott.vod.model.content.OfferContent
import com.homechoice.ott.vod.model.event.Event
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.model.popup.Payment
import com.homechoice.ott.vod.model.popup.Purchase
import com.homechoice.ott.vod.popup.PopupType.ErrorType
import com.homechoice.ott.vod.popup.PopupType.NormalPopupType
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.PopupViewModel
import com.homechoice.ott.vod.ui.popup.adult.AdultPopupView
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupView
import com.homechoice.ott.vod.ui.popup.event.EventPopupView
import com.homechoice.ott.vod.ui.popup.member.ResignMemberPopupView
import com.homechoice.ott.vod.ui.popup.normal.NormalPopupView
import com.homechoice.ott.vod.ui.popup.normal.OneLinePopupView
import com.homechoice.ott.vod.ui.popup.normal.ThreeLinePopupView
import com.homechoice.ott.vod.ui.popup.pack.PackageDetailPopupView
import com.homechoice.ott.vod.ui.popup.play.ContinuePopupView
import com.homechoice.ott.vod.ui.popup.play.ExitPopupView
import com.homechoice.ott.vod.ui.popup.purchase.PurchasePopupView

object PopupAgent {

    fun showNormalPopup(context: Context, type: ErrorType, event: PopupEvent) {
        NormalPopupView(context, type, event).show()
    }

    fun showNormalPopup(context: Context, type: NormalPopupType, event: PopupEvent) {
        NormalPopupView(context, type, event).show()
    }

    fun showThreeLinePopup(context: Context, type: NormalPopupType, event: PopupEvent) {
        ThreeLinePopupView(context, type, event).show()
    }

    fun showResignMemberPopup(context: Context, event: PopupEvent) {
        ResignMemberPopupView(context, event).show()
    }

    fun showLoginPopup(context: Context, event: LoginPopupEvent) {
        LoginPopupView(context, Login(loginqr = null),
            object : PopupEvent {
                override fun onClick(d: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.BACK, // 재생중 로그인 팝업에서 이전키 입력만 사용
                        BtnLabel.SUCCESS -> {
                            d.dismiss()
                            event.onLogin(d, btn)
                        }
                        BtnLabel.CANCEL -> {
                            d.dismiss()
                        }
                    }
                }
            })
    }

    fun showLoginPopup(context: Context, login: Login, event: LoginPopupEvent) {
        LoginPopupView(context, login,
            object : PopupEvent {
                override fun onClick(d: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.BACK, // 재생중 로그인 팝업에서 이전키 입력만 사용
                        BtnLabel.SUCCESS -> {
                            d.dismiss()
                            event.onLogin(d, btn)
                        }
                        BtnLabel.CANCEL -> {
                            d.dismiss()
                        }
                    }
                }
            })
    }

    /**
     * 기존에 사용 중인 showLoginPopup에 영향을 주지 않기 위해 따로 만든 메소드
     * */
    fun appStartShowLoginPopup(context: Context, login: Login, event: LoginPopupEvent) {
        LoginPopupView(context, login,
            object : PopupEvent {
                override fun onClick(d: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.SUCCESS -> {
                            d.dismiss()
                            event.onLogin(d, btn)
                        }
                        else -> {
                            d.dismiss()
                            event.onLogin(d, btn)
                        }
                    }
                }
            })
    }

    fun showAdultPopup(context: Context, event: PopupEvent) {
        AdultPopupView(context, Login(loginqr = null), event).show()
    }

    fun showAdultPopup(context: Context, login: Login, event: PopupEvent) {
        AdultPopupView(context, login, event).show()
    }

    fun showOneLineNoBtn(context: Context, popupType: NormalPopupType, event: PopupEvent) {
        OneLinePopupView(context, PopupViewModel(popupType), event).show()
    }

    fun showPlayExitPopup(context: Context, event: PopupEvent) {
        ExitPopupView(context, event)
    }

    fun showContinuePopup(context: Context, event: PopupEvent) {
        ContinuePopupView(context, event).show()
    }

    fun showPackageDetailPopup(context: Context, content: Content, isPurchase: Boolean, event: PopupEvent) {
        PackageDetailPopupView(context, content, isPurchase, event).show()
    }

    fun showPackagePurchase(context: Context, offerContent: OfferContent, enterPath: String, event: PopupEvent) {
        val content = offerContent.contentList[0]
        var title = ""

        // 패키지는 이미 할인이 들어가 상품이므로, 적립을 하지 않음.
        val isExpand = false
        val expandText = "결제 금액의 5% 적립\n(카드 결제 금액만 적용)"
        var pointPolicyId = -1L

        for (item in offerContent.contentList) {
            title += "${item.title}\n"
        }

        PurchasePopupView(
            context, Purchase(
                offerId = offerContent.id,
                head = "결제하기",
                posterUrl = offerContent.posterUrl!!,
                rating = UIAgent.getRate(content.rating ?: ""),
                title = title,
                offerTitle = offerContent.title ?: "",
                contentInfo = "| ${UIAgent.getRentalText(offerContent.productType ?: "")} | ${
                    content.translationType?.let {
                        UIAgent.getTranslationText(
                            it
                        )
                    }
                }",
                viewablePeriod = UIAgent.createViewablePeriod(
                    productType = offerContent.productType ?: "",
                    viewablePeriod = offerContent.viewablePeriod ?: ""
                ),
                productHead = UIAgent.getProductHead(offerContent.productType ?: ""),
                price = offerContent.price ?: 0,
                discountPrice = offerContent.discountPrice ?: 0,
                contentType = "묶음상품 구매",
                payment = arrayListOf(
                    Payment(paymentType = "카드간편 결제", paymentName = STBAgent.cardName)
                ),
                isAuth = STBAgent.isAuth,
                targetType = "packageOffer",
                targetId = offerContent.id,
                maxLines = 4,
                isExpand = isExpand,
                expandText = expandText,
                enterPath = enterPath,
                pointPolicyId = pointPolicyId
            ), event
        ).show()
    }

    fun showEventPopupView(data: Event, isPush: Boolean, context: Context, event: PopupEvent) {
        EventPopupView(
            imgUrl = data.popupImgUrl,
            description = data.popupTxt,
            isPush = true,
            useLinkDetail = !(data.linkInfo.isNullOrEmpty() || data.linkType.isNullOrEmpty()),
            context = context, event = event
        )
    }
}