package com.homechoice.ott.vod.util

import android.util.Log
import com.homechoice.ott.vod.BuildConfig
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R

object Logger {

    var CastisTag: String = CMBApp.CTX.packageName ?: "com.homechoice.ott.vod"

    var logMode: Boolean = CMBApp.RES.getString(R.string.app_log_mode) == "on"

    fun init(mode: String) {
        logMode = (mode == "on")
    }

    fun isLogMode(): Boolean {
        return logMode
    }

    fun LogOnCreate(`object`: Any) {
        LogLifeCycle(`object`, "CREATE")
    }

    fun LogOnViewCreated(`object`: Any) {
        LogLifeCycle(`object`, "VIEW CREATED")
    }

    fun LogOnCreateView(`object`: Any) {
        LogLifeCycle(`object`, "CREATE VIEW")
    }

    fun LogOnAttach(`object`: Any) {
        LogLifeCycle(`object`, "ATTACH")
    }

    fun LogOnPaue(`object`: Any) {
        LogLifeCycle(`object`, "PAUSE")
    }

    fun LogOnResume(`object`: Any) {
        LogLifeCycle(`object`, "RESUME")
    }

    fun LogOnDetach(`object`: Any) {
        LogLifeCycle(`object`, "DETACH")
    }

    fun LogOnDestroy(`object`: Any) {
        LogLifeCycle(`object`, "DESTROY")
    }

    fun LogOnStop(`object`: Any) {
        LogLifeCycle(`object`, "STOP")
    }

    private fun LogLifeCycle(`object`: Any, message: String) {
        Log(Log.DEBUG, `object`, "***************** ON $message *****************")
    }

    fun Log(logType: Int, message: String) {
        if (logMode)
            when (logType) {
                Log.VERBOSE -> v(message)
                Log.DEBUG -> d(message)
                Log.INFO -> i(message)
                Log.WARN -> w(message)
                Log.ERROR -> e(message)
                Log.ASSERT -> a(message)
                else -> w("Not Type$message")
            }
    }

    fun Log(logType: Int, `object`: Any, message: String) {
        if (logMode)
            when (logType) {
                Log.VERBOSE -> v(`object`, message)
                Log.DEBUG -> d(`object`, message)
                Log.INFO -> i(`object`, message)
                Log.WARN -> w(`object`, message)
                Log.ERROR -> e(`object`, message)
                Log.ASSERT -> a(`object`, message)
                else -> w(`object`, "Not Type$message")
            }
    }

    fun BufferLog(`object`: Any, message: String) {
//        if (!Bom.LogInfo.isBufferLog()) return
        d(`object`, "BUFFER $message")
    }

    fun UploadLog(`object`: Any, message: String) {
//        if (!Bom.LogInfo.isUploadLog()) return
        i(`object`, "UPLOAD $message")
    }

    fun i(message: String?) {
        if (message != null) {
            Log.i(CastisTag, message)
        }
    }

    fun i(`object`: Any, message: String) {
        Log.i(CastisTag, getClassName(`object`) + message)
    }

    private fun d(message: String) {
        Log.d(CastisTag, message)
    }

    private fun d(`object`: Any, message: String) {
        Log.d(CastisTag, getClassName(`object`) + message)
    }

    fun e(message: String) {
        Log.e(CastisTag, message)
    }

    fun e(`object`: Any, message: String) {
        Log.e(CastisTag, getClassName(`object`) + message)
    }

    private fun w(message: String) {
        Log.w(CastisTag, message)
    }

    private fun w(`object`: Any, message: String) {
        Log.w(CastisTag, getClassName(`object`) + message)
    }

    fun v(message: String) {
        Log.v(CastisTag, message)
    }

    fun v(`object`: Any, message: String) {
        Log.v(CastisTag, getClassName(`object`) + message)
    }

    fun a(message: String) {
        Log.wtf(CastisTag, message)
    }

    fun a(`object`: Any, message: String) {
        Log.wtf(CastisTag, getClassName(`object`) + message)
    }

    fun buildLogMsg(message: String?): String? {
        val ste =
            Thread.currentThread().stackTrace[4]
        val sb = StringBuilder()
        sb.append("[")
        sb.append(ste.fileName.replace(".java", ""))
        sb.append(".")
        sb.append(ste.methodName)
        sb.append("] ")
        sb.append(message)
        return sb.toString()
    }

    fun heapLog() {
//        val allocated: Double = Debug.getNativeHeapAllocatedSize() / 1048576
//        val available: Double = Debug.getNativeHeapSize() / 1048576.0
//        val free: Double = Debug.getNativeHeapFreeSize() / 1048576.0
//        val df = DecimalFormat()
//        df.setMaximumFractionDigits(2)
//        df.setMinimumFractionDigits(2)
//        Log.w(
//            "Castis",
//            "[ks] heap native: allocated " + df.format(allocated)
//                .toString() + "MB of " + df.format(available).toString() + "MB (" + df.format(free)
//                .toString() + "MB free)" + " / [ks] memory: allocated: " + df.format(
//                Runtime.getRuntime().totalMemory() / 1048576
//            ).toString() + "MB of "
//                    + df.format(Runtime.getRuntime().maxMemory() / 1048576)
//                .toString() + "MB ("
//                    + df.format(Runtime.getRuntime().freeMemory() / 1048576)
//                .toString() + "MB free)"
//        )
    }

    /**
     * 클래스 파일이름 가져오기
     */
    private fun getClassName(obj: Any): String {
        val simpleName: String = if (obj is String) {
            obj
        } else {
            obj.javaClass.name
        }
        return "[${BuildConfig.VERSION_NAME}][$simpleName] "
    }

    fun logI(message: String) {
        Log.i(CastisTag, message)
    }

    fun logD(message: String) {
        Log.d(CastisTag, message)
    }

    fun logE(message: String) {
        Log.e(CastisTag, message)
    }

    fun playerLog(logType: Int, message: String) {
        when (logType) {
            Log.VERBOSE -> v("[PLAYER] $message")
            Log.DEBUG -> d("[PLAYER] $message")
            Log.INFO -> i("[PLAYER] $message")
            Log.WARN -> w("[PLAYER] $message")
            Log.ERROR -> e("[PLAYER] $message")
            Log.ASSERT -> a("[PLAYER] $message")
            else -> w("Not Type$message")
        }
    }

}