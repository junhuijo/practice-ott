package com.homechoice.ott.vod.ui.popup.event

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogEventPopBinding
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.ui.navigation.navigator.NavigatorModel
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.dialog_event_pop.*
import kotlinx.android.synthetic.main.dialog_notice_pop.notice_scroll

class EventPopupView : Dialog {
    private var binding: DialogEventPopBinding = DialogEventPopBinding.inflate(LayoutInflater.from(context))

    private lateinit var navigatorModel: NavigatorModel

    private var viewModel: EventPopupModel = EventPopupModel()

    constructor(
        imgUrl: String?,
        description: String?,
        isPush: Boolean,
        useLinkDetail: Boolean,
        context: Context,
        event: PopupEvent
    ) : super(context, R.style.Theme_Design_NoActionBar) {
        //DialogDeletePurchaseLogBinding.inflate(LayoutInflater.from(ctx))
        init()

        if (description.isNullOrBlank()) {
            Logger.Log(Log.DEBUG, this, "description is empty")
            viewModel.description.value = null
        } else {
            viewModel.description.value = description
        }

        if (imgUrl.isNullOrBlank()) {
            Logger.Log(Log.DEBUG, this, "imgUrl is empty")
            viewModel.imgUrl.value = null
        } else {
            viewModel.imgUrl.value = imgUrl
        }
        //notice_pop_title.text = title
        //notice_pop_description.text = description
        Logger.Log(Log.DEBUG, this, "showPopup : $imgUrl , $description ")
        val btns: ArrayList<String> = if (isPush) {
            today_button.visibility = View.VISIBLE
            if (useLinkDetail) {
                arrayListOf(BtnLabel.DETAIL, BtnLabel.TODAY, BtnLabel.CLOSE)
            } else {
                detail_button.visibility = View.GONE
                arrayListOf(BtnLabel.TODAY, BtnLabel.CLOSE)
            }
        } else {
            today_button.visibility = View.GONE
            if (useLinkDetail) {
                arrayListOf(BtnLabel.DETAIL, BtnLabel.CLOSE)
            } else {
                detail_button.visibility = View.GONE
                arrayListOf(BtnLabel.CLOSE)
            }
        }

        showNormalPopup(event, btns)
    }

    private fun init() {
        viewModel = EventPopupModel()
        binding.viewModel = viewModel
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        setContentView(binding.root)
    }

    private fun createButtons(buttons: List<String>, eventListener: PopupEvent) {
        navigatorModel = NavigatorModel(0, 0, buttons.size, 5, object : NavigatorModel.Callback {
            override fun init(index: Int) {
                when (buttons[index]) {
                    BtnLabel.DETAIL -> detail_button.isSelected = true
                    BtnLabel.TODAY -> today_button.isSelected = true
                    BtnLabel.CLOSE -> close_button.isSelected = true
                }
            }

            override fun pageStartIndexChanged() {

            }

            override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
                initButton();
                when (buttons[index]) {
                    BtnLabel.DETAIL -> detail_button.isSelected = true
                    BtnLabel.TODAY -> today_button.isSelected = true
                    BtnLabel.CLOSE -> close_button.isSelected = true
                }
            }
        })

    }

    private fun initButton() {
        detail_button.isSelected = false;
        today_button.isSelected = false;
        close_button.isSelected = false;
    }

    private fun showNormalPopup(event: PopupEvent, buttons: List<String>) {
        createButtons(buttons = buttons, eventListener = event)

        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {

                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        event.onClick(this, BtnLabel.BACK)
                        dismiss()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        notice_scroll.pageScroll(View.FOCUS_UP)
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        notice_scroll.pageScroll(View.FOCUS_DOWN)
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        navigatorModel.right()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        navigatorModel.left()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER, 96 -> {
                        event.onClick(this, buttons[navigatorModel.currentIndex])
                        result = true
                    }

                }
            }
            result
        }

        //      binding.btnDelete.requestFocus()
        show()
    }
}