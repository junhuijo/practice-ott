package com.homechoice.ott.vod.model.serviceLog

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ServiceLog (
    var serviceId : Long = 0,
    var title : String = "",
    var serviceStartDatetime : String? = "",
    var serviceEndDatetime : String? = "",
    var contentId : Long? = 0,
    var contentGroupId : Long? = 0,
    var episodeNo : Long? = 0,
    var seriesId : Long? = 0,
    var runTimeDisplay : String = "",
    var posterUrl: String = "",
    var rating: String? = "",
//    var genre: String? = ""
) : Parcelable {

}