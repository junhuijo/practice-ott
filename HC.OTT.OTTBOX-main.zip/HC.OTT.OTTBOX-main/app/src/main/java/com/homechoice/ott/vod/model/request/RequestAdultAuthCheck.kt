package com.homechoice.ott.vod.model.request

data class RequestAdultAuthCheck(
    val terminalKey: String = ""
)
