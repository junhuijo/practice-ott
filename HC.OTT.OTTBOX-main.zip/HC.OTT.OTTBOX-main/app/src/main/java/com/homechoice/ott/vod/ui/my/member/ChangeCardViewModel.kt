package com.homechoice.ott.vod.ui.my.member

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.ui.navigation.navigator.KeyPadNavigator
import com.homechoice.ott.vod.ui.navigation.navigator.PageNavigatorModel


class ChangeCardViewModel : ViewModel() {
    private lateinit var listener: ModelListener
    var invalidInfo: MutableLiveData<Boolean> = MutableLiveData()

    var keyPadNavigator = KeyPadNavigator(0, 0, 12, 3, object : PageNavigatorModel.Callback {
        override fun init(index: Int) {

        }

        override fun pageStartIndexChanged() {

        }

        override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
            if (::listener.isInitialized) {
                with(listener) {
                    focusChanged(
                        previousIndex = previousIndex,
                        index = index,
                        pageStartIndex = pageStartIndex
                    )
                }
            }
        }

    })

    fun up() {
        keyPadNavigator.up()

    }

    fun down() {
        keyPadNavigator.down()
    }

    fun left() {
        if (keyPadNavigator.currentIndex == keyPadNavigator.pageStartIndex) {
            listener.back()
        } else {
            keyPadNavigator.left()
        }
    }

    fun right() {
        keyPadNavigator.right()
    }

    fun enter() {
        this.listener.select(keyPadNavigator.currentIndex)
    }

    fun setListener(listener: ModelListener) {
        this.listener = listener
    }

    interface ModelListener {
        fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int)
        fun select(index: Int)
        fun back()
    }


}

