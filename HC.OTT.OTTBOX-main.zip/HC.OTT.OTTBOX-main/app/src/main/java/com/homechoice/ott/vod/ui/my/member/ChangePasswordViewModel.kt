package com.homechoice.ott.vod.ui.my.member

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.ui.navigation.navigator.KeyPadNavigator
import com.homechoice.ott.vod.ui.navigation.navigator.NavigatorModel
import com.homechoice.ott.vod.ui.navigation.navigator.PageNavigatorModel
import com.homechoice.ott.vod.util.Logger


class ChangePasswordViewModel : ViewModel() {
    val PURCHASE: Int = 0
    val ADULT: Int = 1
    val FOCUS_PURCHASE: Int = 2
    val FOCUS_ADULT: Int = 3

    var invalidInfo: MutableLiveData<Boolean> = MutableLiveData()

    private lateinit var listener: ModelListener

    var tabStatus: MutableLiveData<Int> = MutableLiveData()

    fun init(isTabActive: Boolean) {
        tabModel.currentIndex = 0
        tabModel.pageStartIndex = 0
        tabModel.isActive = isTabActive
        keyPadNavigator.currentIndex = 0
        keyPadNavigator.pageStartIndex = 0
        keyPadNavigator.isActive = false
    }

    fun setTabStatus(isActive: Boolean, index: Int) {
        Logger.Log(Log.ERROR, this, "setTabStatus:$isActive , $index")
        if (isActive) {
            if (index == 0) {
                tabStatus.value = FOCUS_PURCHASE
            } else {
                tabStatus.value = FOCUS_ADULT
            }
        } else {
            if (index == 0) {
                tabStatus.value = PURCHASE
            } else {
                tabStatus.value = ADULT
            }
        }
    }

    private var tabModel = NavigatorModel(0, 0, 2, 2, object : NavigatorModel.Callback {
        override fun init(index: Int) {
        }

        override fun pageStartIndexChanged() {
        }

        override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
            if (::listener.isInitialized) {
                listener.tabChanged(index)
                setTabStatus(true, index)
            }
        }

    }).also { it.isActive = true }

    private var keyPadNavigator = KeyPadNavigator(0, 0, 12, 3, object : PageNavigatorModel.Callback {
        override fun init(index: Int) {

        }

        override fun pageStartIndexChanged() {

        }

        override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
            if (::listener.isInitialized) {
                with(listener) {
                    focusChanged(
                        previousIndex = previousIndex,
                        index = index,
                        pageStartIndex = pageStartIndex
                    )
                }
            }
        }

    }).also { it.isActive = false }

    fun up() {
        if (tabModel.isActive) {

        } else {
            keyPadNavigator.up()
        }
    }

    fun down() {
        if (tabModel.isActive) {

        } else {
            keyPadNavigator.down()
        }
    }

    fun left() {
        if (tabModel.isActive) {
            if (tabModel.currentIndex == 0) {
                listener.back()
            } else {
                tabModel.left()
            }
        } else {
            if (keyPadNavigator.currentIndex == keyPadNavigator.pageStartIndex) {
                tabModel.isActive = true
                keyPadNavigator.isActive = false
                setTabStatus(tabModel.isActive, tabModel.currentIndex)
                listener.tabChanged(tabModel.currentIndex)
            } else {
                keyPadNavigator.left()
            }
        }
    }

    fun right() {
        if (tabModel.isActive) {
            if (tabModel.currentIndex == tabModel.totalSize - 1) {
                /*tabModel.isActive = false
                setTabStatus(tabModel.isActive , tabModel.currentIndex)

                keyPadNavigator.isActive = true
                val previousIndex = keyPadNavigator.currentIndex
                keyPadNavigator.currentIndex = 0
                keyPadNavigator.pageStartIndex = 0
                listener.focusChanged(previousIndex , 0 , 0)
*/
            } else
                tabModel.right()

        } else {
            keyPadNavigator.right()
        }
    }

    fun enter() {
        if (tabModel.isActive) {
            tabModel.isActive = false
            setTabStatus(tabModel.isActive, tabModel.currentIndex)

            keyPadNavigator.isActive = true
            val previousIndex = keyPadNavigator.currentIndex
            keyPadNavigator.currentIndex = 10
            keyPadNavigator.pageStartIndex = 9
            listener.focusChanged(previousIndex, keyPadNavigator.currentIndex, keyPadNavigator.pageStartIndex)
            //this.listener.selectTab(tabModel.currentIndex)
        } else {
            this.listener.select(keyPadNavigator.currentIndex)
        }

    }

    fun setListener(listener: ModelListener) {
        this.listener = listener
    }

    interface ModelListener {
        fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int)
        fun select(index: Int)
        fun tabChanged(index: Int)
        fun selectTab(index: Int)
        fun back()
    }


}

