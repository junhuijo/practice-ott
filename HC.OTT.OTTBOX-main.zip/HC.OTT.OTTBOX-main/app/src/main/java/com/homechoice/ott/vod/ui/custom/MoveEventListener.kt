package com.homechoice.ott.vod.ui.custom

interface MoveEventListener {
    fun onRight()
    fun onLeft()
    fun onUp(index: Int)
    fun onDown(index: Int)
}