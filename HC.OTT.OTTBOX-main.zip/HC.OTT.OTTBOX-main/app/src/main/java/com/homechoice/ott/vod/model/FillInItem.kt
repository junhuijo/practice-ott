package com.homechoice.ott.vod.model

import android.os.Parcel
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class FillInItem(
    val id: Long =  -1,
    val title: String = "",
    var type: String = "",
    var description: String = "",
    var posterUrl: String = "",
    val posterSizeLevel: Int = 0,
    var unselectedIconUrl: String = "",
    var selectedIconUrl: String = "",
    val isAdult: Boolean = false,
    var popupType: String = "",
    var popupImgUrl: String = "",
    var popupTxt: String = "",
    var linkType: String = "none",
    var linkInfo: String? = ""
) : Parcelable {
    fun build(): FillInItem {
        if (type == null) {
            type = ""
        }
        if (description == null) {
            description = ""
        }
        if (posterUrl == null) {
            posterUrl = ""
        }
        if (unselectedIconUrl == null) {
            unselectedIconUrl = ""
        }
        if (selectedIconUrl == null) {
            selectedIconUrl = ""
        }
        if (popupType == null) {
            popupType = ""
        }
        if (popupImgUrl == null) {
            popupImgUrl = ""
        }
        if (popupTxt == null) {
            popupTxt = ""
        }
        if (linkType == null) {
            linkType = ""
        }
        if (linkInfo == null) {
            linkInfo = ""
        }
        return this
    }
}