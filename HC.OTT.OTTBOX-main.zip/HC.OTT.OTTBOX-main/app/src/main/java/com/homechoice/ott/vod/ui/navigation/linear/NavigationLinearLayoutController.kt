package com.homechoice.ott.vod.ui.navigation.linear

import android.util.Log
import com.homechoice.ott.vod.agent.HomeContentFocusType
import com.homechoice.ott.vod.util.Logger
import kotlin.math.abs

class NavigationLinearLayoutController(
    var model: NavigationLinearLayoutModel,
    var event: NavigationLinearLayoutEvent
) {
    fun decrease(): Boolean {
        Logger.Log(
            Log.INFO,
            this,
            "==== before cData curIndex : ${model.cData.curIndex} / preIndex : ${model.cData.preIndex} / totalIndex : ${model.cData.totalIndex}"
        )
        Logger.Log(
            Log.INFO,
            this,
            "==== before data curIndex : ${model.data.curIndex} / preIndex : ${model.data.preIndex} / totalIndex : ${model.data.totalIndex}"
        )

        if (model.data.curIndex > 0) {
            model.data.preIndex = model.data.curIndex
            model.data.curIndex--
            if (model.cData.curIndex >= 0) {
                model.cData.preIndex = model.cData.curIndex  // pre : 8
                model.cData.curIndex =
                    model.cData.preIndex - model.cData[model.data.preIndex] // 5 = 8 - 3

                val count = model.cData.curIndex - model.cData[model.data.curIndex]
                Logger.Log(Log.INFO, this, "==== count : $count")

                if (count < -1) {
                    // Yes
                    Logger.Log(
                        Log.INFO,
                        this,
                        "==== model.cData.curIndex : ${model.cData.curIndex} / cData.visibleIndex : ${model.cData.visibleIndex} / is : ${(model.cData.curIndex == 0 && model.cData.visibleIndex == 0)}"
                    )

                    if (model.cData.visibleIndex == 0) {
                        Logger.Log(Log.DEBUG, this, "leftLineChange count: ${model.cData[model.data.curIndex]}")
                        event.leftLineChange(model.cData[model.data.curIndex])
                        model.cData.curIndex = model.cData[model.data.curIndex] - 1
                    } else {
                        if (model.data.curIndex == 0) {
                            Logger.Log(Log.DEBUG, this, "firstLineChange count: ${abs(count) - 1}")
                            event.firstLineChange(abs(count) - 1)
                            model.cData.curIndex = 0
                            model.cData.visibleIndex = 0
                        } else {
                            // -1 = 0
                            // -2 = 1
                            // -3 = 2
                            Logger.Log(Log.DEBUG, this, "leftLineChange count: ${abs(count) - 1}")
                            event.leftLineChange(abs(count) - 1)
                            model.cData.curIndex = model.cData[model.data.curIndex] - 1
                            model.cData.visibleIndex = 0
                        }
                    }
                    Logger.Log(Log.DEBUG, this, "focusChange focusType: ${HomeContentFocusType.LEFT}")
                    event.focusChange(HomeContentFocusType.LEFT)
                } else {
                    if (model.data.curIndex == 0 || count == -1) {
                        Logger.Log(Log.DEBUG, this, "focusChange focusType: ${HomeContentFocusType.LEFT}")
                        event.focusChange(HomeContentFocusType.LEFT)
                    } else {
                        Logger.Log(Log.DEBUG, this, "focusChange focusType: ${HomeContentFocusType.CENTER}")
                        event.focusChange(HomeContentFocusType.CENTER)
                    }

                }
            }

        } else {
            Logger.Log(Log.DEBUG, this, "exitChange")
            event.exitChange()
        }

        Logger.Log(
            Log.WARN,
            this,
            "==== after cData curIndex : ${model.cData.curIndex} / preIndex : ${model.cData.preIndex} / totalIndex : ${model.cData.totalIndex}"
        )

        Logger.Log(
            Log.WARN,
            this,
            "==== after data curIndex : ${model.data.curIndex} / preIndex : ${model.data.preIndex} / totalIndex : ${model.data.totalIndex}"
        )
        return false
    }

    fun increase(): Boolean {
        Logger.Log(
            Log.INFO,
            this,
            "==== before cData curIndex : ${model.cData.curIndex} / preIndex : ${model.cData.preIndex} / totalIndex : ${model.cData.totalIndex}"
        )
        Logger.Log(
            Log.INFO,
            this,
            "==== before data curIndex : ${model.data.curIndex} / preIndex : ${model.data.preIndex} / totalIndex : ${model.data.totalIndex}"
        )

        if (model.data.curIndex < (model.data.totalIndex)) {
            model.data.preIndex = model.data.curIndex
            model.data.curIndex++
            if (model.cData.curIndex < model.cData.totalIndex) {
                model.cData.preIndex = model.cData.curIndex

                model.cData.curIndex += model.cData[model.data.curIndex]

                Logger.Log(Log.ERROR, this, "${model.cData[model.data.preIndex]}")

                if (model.cData.preIndex == 0)
                    when (model.cData[model.data.preIndex]) {
                        2 -> {
                            model.cData.curIndex += 1
                        }
                        3 -> {
                            model.cData.curIndex += 2
                        }
                    }

                if (model.cData.curIndex > model.data.rightFixedIndex) {
                    val count = model.cData.curIndex - model.data.rightFixedIndex
                    model.cData.curIndex = model.cData.curIndex - count

                    if ((model.data.curIndex + 2) <= model.data.totalIndex) {
                        Logger.Log(Log.DEBUG, this, "rightLineChange position: ${model.data.curIndex + 2} / count: $count")
                        event.rightLineChange(
                            model.data.curIndex + 2,
                            count
                        )
                    } else {
                        if (model.data.curIndex == model.data.totalIndex) {
                            Logger.Log(Log.DEBUG, this, "lastLineChange")
                            event.lastLineChange()
                        } else {
                            Logger.Log(Log.DEBUG, this, "rightLineChange position: 9999 / count: 9999")
                            event.rightLineChange(9999, 9999)
                        }
                    }
                } else {
                    if ((model.data.curIndex + 2) > model.data.totalIndex) {
                        Logger.Log(Log.DEBUG, this, "rightLineChange position: 9999 / count: 10000")
                        event.rightLineChange(9999, 10000)
                    }
                }
            }
            Logger.Log(Log.DEBUG, this, "focusChange focusType: ${HomeContentFocusType.CENTER}")
            event.focusChange(HomeContentFocusType.CENTER)
            model.cData.visibleIndex = -1
        }

        Logger.Log(
            Log.WARN,
            this,
            "==== after cData curIndex : ${model.cData.curIndex} / preIndex : ${model.cData.preIndex} / totalIndex : ${model.cData.totalIndex}"
        )

        Logger.Log(
            Log.WARN,
            this,
            "==== after data curIndex : ${model.data.curIndex} / preIndex : ${model.data.preIndex} / totalIndex : ${model.data.totalIndex}"
        )

        return false
    }

    fun visibleThreshold(): Int {
        return model.data.visibleThreshold
    }

    fun getCurIndex(): Int {
        return model.data.curIndex
    }

    fun getPreIndex(): Int {
        return model.data.preIndex
    }

}