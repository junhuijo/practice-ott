package com.homechoice.ott.vod.ui.screens.home

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.view.KeyEvent
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.focus.FocusRequester
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.exoplayer2.util.Log
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.AdultContentState
import com.homechoice.ott.vod.agent.Categories
import com.homechoice.ott.vod.agent.CategoryWrapper
import com.homechoice.ott.vod.agent.ContentType
import com.homechoice.ott.vod.agent.ContentsProvider
import com.homechoice.ott.vod.agent.HomeScreens
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.SessionState
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.model.HomeCategoryList
import com.homechoice.ott.vod.model.home.CpItem
import com.homechoice.ott.vod.model.home.HomeUiState
import com.homechoice.ott.vod.model.response.ResponseAdultCheck
import com.homechoice.ott.vod.model.response.ResponseCategoryList
import com.homechoice.ott.vod.model.response.ResponseCpItemList
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.popup.TYPE
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.ui.screens.ContentFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.UUID
import java.util.concurrent.CancellationException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

class HomeViewModel : ViewModel() {

    // 데이터 필터
    private val _homeCategoryList = MutableStateFlow<HomeCategoryList?>(null)
    val homeCategoryList: StateFlow<HomeCategoryList?> = _homeCategoryList.asStateFlow()
    private val _filteredHomeCategoryList = MutableStateFlow<HomeCategoryList?>(null)
    val filteredHomeCategoryList: StateFlow<HomeCategoryList?> = _filteredHomeCategoryList.asStateFlow()

    private val _regularCategoryList = MutableStateFlow<Map<Categories, List<CategoryList>>>(emptyMap())
    private val regularCategoryList: StateFlow<Map<Categories, List<CategoryList>>> = _regularCategoryList.asStateFlow()
    private val _filteredRegularCategoryList = MutableStateFlow<Map<Categories, List<CategoryList>>>(emptyMap())
    val filteredRegularCategoryList: StateFlow<Map<Categories, List<CategoryList>>> = _filteredRegularCategoryList.asStateFlow()

    private val _allCpItems = MutableStateFlow<List<CategoryList>>(emptyList())
    private val allCpItems: StateFlow<List<CategoryList>> = _allCpItems.asStateFlow()
    private val _filteredAllCpItems = MutableStateFlow<HomeCategoryList?>(null)
    val filteredAllCpItems: StateFlow<HomeCategoryList?> = _filteredAllCpItems.asStateFlow()

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _adultContentState = MutableStateFlow(
        AdultContentState(
            isAdultAuth = STBAgent.isAdultAuth,
            includeRrated = STBAgent.includeRrated
        )
    )
    val adultContentState: StateFlow<AdultContentState> = _adultContentState

    private val _isKidsLockEnabled = MutableStateFlow(determineKidsLockEnabled())
    val isKidsLockEnabled: StateFlow<Boolean> = _isKidsLockEnabled.asStateFlow()
    private fun determineKidsLockEnabled(): Boolean {
        return !STBAgent.includeRrated && !STBAgent.isAdultAuth
    }

    private val _topFlag = MutableStateFlow(false)
    val topFlag: StateFlow<Boolean> = _topFlag.asStateFlow()

    private val _isCategoryDrawerVisible = MutableStateFlow(false)
    val isCategoryDrawerVisible: StateFlow<Boolean> = _isCategoryDrawerVisible.asStateFlow()

    private val _isMenuExpanded = MutableStateFlow(false)
    val isMenuExpanded: StateFlow<Boolean> = _isMenuExpanded.asStateFlow()

    private val _finishApp = MutableLiveData<Unit>()
    val finishApp: LiveData<Unit> = _finishApp

    private val _showQuitAppDialog = MutableStateFlow(false)
    val showQuitAppDialog: StateFlow<Boolean> = _showQuitAppDialog.asStateFlow()

    private val _showAdultVerificationDialog = MutableStateFlow(false)
    val showAdultVerificationDialog: StateFlow<Boolean> = _showAdultVerificationDialog.asStateFlow()

    private val _showAdultPasswordDialog = MutableStateFlow(false)
    val showAdultPasswordDialog: StateFlow<Boolean> = _showAdultPasswordDialog

    private val _selectedCategory = MutableStateFlow<CategoryWrapper?>(null)
    val selectedCategory: StateFlow<CategoryWrapper?> = _selectedCategory.asStateFlow()

    private val _currentBanner = MutableStateFlow<CategoryItem?>(null)
    val currentBanner: StateFlow<CategoryItem?> = _currentBanner.asStateFlow()

    private val _bannerIndex = MutableStateFlow(0)
    val bannerIndex: StateFlow<Int> = _bannerIndex.asStateFlow()

    val navCategoryFocusRequester = FocusRequester()
    val navHomeFocusRequester = FocusRequester()
    val navExpandFocusRequester = FocusRequester()

    private var randomCategoryItem: CategoryItem? = null
    private var isFetchingCpItems = false

    //패스 인증저장
    private val _isAdultVerified = MutableStateFlow<Boolean?>(false)
    val isAdultVerified: StateFlow<Boolean?> = _isAdultVerified

    //top10 임시
    private val _rankFlag = MutableStateFlow(false)
    val rankFlag: StateFlow<Boolean> = _rankFlag.asStateFlow()
    private val _isRankScrollComplete = MutableStateFlow(false)
    val isRankScrollComplete: StateFlow<Boolean> get() = _isRankScrollComplete
    val rankFocusRequester = FocusRequester()
    private val _homeScreenLaunchedEffectCompleted = MutableStateFlow(false)
    val homeScreenLaunchedEffectCompleted: StateFlow<Boolean> = _homeScreenLaunchedEffectCompleted
    fun setRankScrollComplete(complete: Boolean) {
        _isRankScrollComplete.value = complete
    }
    fun setHomeScreenLaunchedEffectCompleted(completed: Boolean) {
        _homeScreenLaunchedEffectCompleted.value = completed
    }
    fun rankFlagToggle(flag: Boolean = false) {
        _rankFlag.value = flag
//        Log.d("rankFlag","${rankFlag.value}")
    }

    init {
        fetchHomeCategoryList()
//        //패스인증
//        checkInitialAdultVerification()
    }

    fun checkAndShowAdultVerification() {
        showAdultPasswordDialog(true)
        _isCategoryDrawerVisible.value = false
    }

    private fun onAdultVerificationConfirmed() {
        viewModelScope.launch {
            fetchCategory(category = Categories.Adult)
            delay(500L)
            showAdultPasswordDialog(false)
            topFlagToggle(true)
            clearAlertMessage()
        }
    }
    //    //패스인증
//    private fun checkInitialAdultVerification() {
//        viewModelScope.launch {
//            val isVerified = checkAdultVerification()
//            _isAdultVerified.value = isVerified
//        }
//    }
    fun showAdultPasswordDialog(value: Boolean) {
        _showAdultPasswordDialog.value = value
    }
    fun updateQuitAppDialog(value: Boolean) {
        _showQuitAppDialog.value = value
    }

    fun finishAffinity() {
        viewModelScope.launch {
            _showQuitAppDialog.value = false
            delay(200L)
            _finishApp.value = Unit
        }
    }

    fun refreshAdultContentState() {
        _adultContentState.value = AdultContentState(
            isAdultAuth = STBAgent.isAdultAuth,
            includeRrated = STBAgent.includeRrated
        )
    }

    fun updateCurrentScreen(screen: HomeScreens) {
        _uiState.update { currentState ->
            currentState.copy(
                currentScreen = screen
            )
        }
    }

    fun navigateToAdultQrFail() {
        _uiState.update { currentState ->
            currentState.copy(currentScreen = HomeScreens.AdultQrFail)
        }
    }

    fun navigateFromHome() {
        _uiState.update { currentState ->
            currentState.copy(currentScreen = HomeScreens.Main)
        }
    }
    fun navigateFromAdultQr() {
        _uiState.update { currentState ->
            currentState.copy(currentScreen = HomeScreens.AdultQr)
        }
    }

    fun topFlagToggle(flag: Boolean = false) {
        _topFlag.value = flag
    }

    private fun toggleCategoryDrawer() {
        _isCategoryDrawerVisible.value = !_isCategoryDrawerVisible.value
    }

    fun closeCategoryDrawer() {
        _isCategoryDrawerVisible.value = false
    }

    fun getCategoryList(): List<CategoryList> {
        return if(uiState.value.currentScreen == HomeScreens.Main) {
            uiState.value.defaultCategoryList
        } else {
            uiState.value.specificCategoryList
        }
    }

    // API
    val cpList = listOf(
        CpItem("jtbc", 364),
        CpItem("tv_chosun", 365),
        CpItem("channel_a", 378),
        CpItem("mbn", 362),
        CpItem("ebs", 361)
    )

    private suspend fun fetchCpItemList(cpItem: CpItem): ResponseCpItemList? {
        return suspendCoroutine { continuation ->
            val transactionId = UUID.randomUUID().toString()
            MBSAgent.getCpItemList(
                terminalKey = MBSAgent.terminalKey,
                cpId = cpItem.id,
                includeAdult = false,
                includeRrated = true,
                startIdx = 1,
                pageSize = 0,
                callback = object : Callback<ResponseCpItemList> {
                    override fun onFailure(call: Call<ResponseCpItemList>, t: Throwable) {
                        Log.e("fetchCpItemList", "Failed to fetch CP item list for transaction ID: $transactionId", t)
                        viewModelScope.launch(Dispatchers.Main) {
                            _popupState.value = PopupState.Error(PopupType.ErrorType.ERROR)
                        }
                        continuation.resumeWith(Result.failure(t))
                    }

                    override fun onResponse(
                        call: Call<ResponseCpItemList>,
                        response: Response<ResponseCpItemList>
                    ) {
                        if (response.isSuccessful) {
                            response.body()?.let {
                                continuation.resume(it)
                            } ?: continuation.resumeWith(Result.failure(Exception("empty body")))
                        } else {
                            Log.e("fetchCpItemList", "Response not successful for transaction ID: $transactionId. Error code: ${response.code()}")
                            viewModelScope.launch(Dispatchers.Main) {
                                _popupState.value = PopupState.Error(PopupType.ErrorType.ERROR)
                            }
                            continuation.resumeWith(Result.failure(Exception("요청 실패")))
                        }
                    }
                }
            )
        }
    }

    fun fetchAllCpItems() {
        _selectedCategory.value = CategoryWrapper.CpCategory(ContentsProvider.Cp)

        if (isFetchingCpItems) {
            return
        }
        isFetchingCpItems = true

        viewModelScope.launch {
            try {
                if (_allCpItems.value.isEmpty()) {
                    val categoryList = mutableListOf<CategoryList>()

                    // 병렬로 API 호출
                    val responses = cpList.map { cpItem ->
                        async {
                            try {
                                fetchCpItemList(cpItem)
                            } catch (e: Exception) {
                                Log.e("fetchAllCpItems", "Failed to fetch for cpItem: ${cpItem.name}", e)
                                viewModelScope.launch(Dispatchers.Main) {
                                    _popupState.value = PopupState.Error(PopupType.ErrorType.ERROR)
                                }
                                null
                            }
                        }
                    }.awaitAll()

                    if (responses.any { it == null }) {
                        return@launch
                    }

                    responses.filterNotNull().forEachIndexed { index, response ->
                        categoryList.add(
                            CategoryList(
                                title = buildString {
                                    append(cpList[index].name.uppercase().replace("_", " "))
                                    append(" 모아보기")
                                },
                                categoryItemList = response.cpItemList
                            )
                        )
                    }
                    _allCpItems.value = categoryList
                }

                val filteredCpContent = ContentFilter.filterContentIfNeeded(
                    categories = _allCpItems.value,
                    isKidsLockEnabled = _isKidsLockEnabled.value
                )

                ContentFilter.updateFilteredContentAndState(
                    originalContent = filteredCpContent,
                    isKidsLockEnabled = _isKidsLockEnabled.value,
                    currentScreen = HomeScreens.Cp,
                    updateFilteredContent = { newFilteredContent ->
                        _filteredAllCpItems.value = HomeCategoryList(categoryList = newFilteredContent)
                    },
                    updateUiState = { newFilteredContent, screen ->
                        _uiState.update { state ->
                            state.copy(
                                currentScreen = screen,
                                specificCategoryList = newFilteredContent,
                                isCategoryVisible = false
                            )
                        }
                    }
                )
                topFlagToggle(true)
            } finally {
                isFetchingCpItems = false
            }
        }
        _isCategoryDrawerVisible.value = false
    }

    fun fetchHomeCategoryList() {
        MBSAgent.getHomeCategoryList(
            needItem = true,
            includeAdult = false,
            includeRrated = true,
            object : Callback<HomeCategoryList> {
                override fun onResponse(
                    call: Call<HomeCategoryList>,
                    response: Response<HomeCategoryList>
                ) {
                    if (response.isSuccessful) {
                        response.body()?.let { homeCategoryList ->
                            homeCategoryList.build()
                            _homeCategoryList.value = homeCategoryList

                            val filteredHomeContent = ContentFilter.filterContentIfNeeded(
                                categories = homeCategoryList.categoryList,
                                isKidsLockEnabled = _isKidsLockEnabled.value
                            )

                            ContentFilter.updateFilteredContentAndState(
                                originalContent = filteredHomeContent,
                                isKidsLockEnabled = _isKidsLockEnabled.value,
                                currentScreen = HomeScreens.Main,
                                updateFilteredContent = { newFilteredHomeContent ->
                                    _filteredHomeCategoryList.value = homeCategoryList.copy(categoryList = newFilteredHomeContent)
                                },
                                updateUiState = { newFilteredHomeContent, _ ->
                                    if (homeCategoryList.sessionState == SessionState.CONNECT || homeCategoryList.sessionState == SessionState.LOGIN) {
                                        _uiState.update { state ->
                                            state.copy(
                                                defaultCategoryList = newFilteredHomeContent
                                            )
                                        }
                                        updateBannerList()
                                    }
                                }
                            )
                            topFlagToggle(true)
                        }
                    } else {
                        // 실패 시
                    }
                }
                override fun onFailure(call: Call<HomeCategoryList>, t: Throwable) {
                    // 실패 시
                }
            }
        )
    }

    fun fetchCategory(category: Categories) {
        _selectedCategory.value = CategoryWrapper.RegularCategory(category)

        val categoryId = when (category) {
            Categories.Movie -> 982
            Categories.BroadCast -> 991
            Categories.OverseasDrama -> 996
            Categories.KidAnime -> 1001
            Categories.Documentary -> 1008
            Categories.Life -> 1012
            Categories.Adult -> 1573
        }

        viewModelScope.launch {
            if (_regularCategoryList.value[category] == null) {
                val result = suspendCoroutine<List<CategoryList>?> { continuation ->
                    val transactionCategoryId = UUID.randomUUID().toString()

                    MBSAgent.getCategoryList(
                        parentCategoryId = categoryId,
                        transactionId = transactionCategoryId,
                        includeAdult = true,
                        includeRrated = true,
                        callback = object : Callback<ResponseCategoryList> {
                            override fun onResponse(
                                call: Call<ResponseCategoryList>,
                                response: Response<ResponseCategoryList>
                            ) {
                                if (response.isSuccessful) {
                                    response.body()?.let {
                                        when (it.sessionState) {
                                            SessionState.CONNECT,
                                            SessionState.LOGIN -> {
                                                continuation.resume(it.categoryList)
                                            }
                                            SessionState.FORCE_LOGOUT -> {
                                                continuation.resume(null)
                                            }
                                            else -> {
//                                                continuation.resume(null)
                                                continuation.resume(it.categoryList)
                                            }
                                        }
                                    } ?: continuation.resume(null)
                                } else {
                                    Log.e("fetchCategory", "Response not successful for transaction ID: $transactionCategoryId. Error code: ${response.code()}")
                                    viewModelScope.launch(Dispatchers.Main) {
                                        _popupState.value = PopupState.Error(PopupType.ErrorType.ERROR)
                                    }
                                    continuation.resume(null)
                                }
                            }

                            override fun onFailure(call: Call<ResponseCategoryList>, t: Throwable) {
                                Log.e("fetchCategory", "Failed to fetch category list", t)
                                viewModelScope.launch(Dispatchers.Main) {
                                    _popupState.value = PopupState.Error(PopupType.ErrorType.ERROR)
                                }
                                continuation.resume(null)
                            }
                        }
                    )
                }

                result?.let { categoryList ->
                    _regularCategoryList.update { currentMap ->
                        currentMap.plus((category to categoryList))
                    }
                }
            }

            _regularCategoryList.value[category]?.let { categoryList ->
                val filteredCategoryContent = ContentFilter.filterContentIfNeeded(
                    categories = categoryList,
                    isKidsLockEnabled = _isKidsLockEnabled.value
                )

                ContentFilter.updateFilteredContentAndState(
                    originalContent = filteredCategoryContent,
                    isKidsLockEnabled = _isKidsLockEnabled.value,
                    currentScreen = if (category == Categories.Adult) HomeScreens.CategoryAdult else HomeScreens.Category,
                    updateFilteredContent = { newFilteredCategoryContent ->
                        _filteredRegularCategoryList.update { currentMap ->
                            currentMap.plus((category to newFilteredCategoryContent))
                        }
                    },
                    updateUiState = { newFilteredCategoryContent, screen ->
                        _uiState.update { state ->
                            state.copy(
                                currentScreen = screen,
                                specificCategoryList = newFilteredCategoryContent,
                                isCategoryVisible = false
                            )
                        }
                    }
                )
            }

            topFlagToggle(true)
        }
        _isCategoryDrawerVisible.value = false
    }

    fun updateAdultContentVisibility() {
        val newAdultContentState = AdultContentState(
            isAdultAuth = STBAgent.isAdultAuth,
            includeRrated = STBAgent.includeRrated
        )
        _adultContentState.value = newAdultContentState
        _isKidsLockEnabled.value = !newAdultContentState.includeRrated && !newAdultContentState.isAdultAuth

        when (_uiState.value.currentScreen) {
            HomeScreens.Main -> {
                _homeCategoryList.value?.let { homeCategoryList ->
                    val filteredHomeContent = ContentFilter.filterContentIfNeeded(
                        categories = homeCategoryList.categoryList,
                        isKidsLockEnabled = _isKidsLockEnabled.value
                    )

                    ContentFilter.updateFilteredContentAndState(
                        filteredHomeContent,
                        _isKidsLockEnabled.value,
                        HomeScreens.Main,
                        { newFilteredHomeContent ->
                            _filteredHomeCategoryList.value = homeCategoryList.copy(categoryList = newFilteredHomeContent)
                        },
                        {
                                newFilteredHomeContent, screen ->
                            _uiState.update { state ->
                                state.copy(
                                    defaultCategoryList = newFilteredHomeContent,
                                    currentScreen = screen
                                )
                            }
                        }
                    )
                    updateBannerList()
                }
            }

            HomeScreens.Category, HomeScreens.CategoryAdult -> {
                val selectedCategory = _selectedCategory.value as? CategoryWrapper.RegularCategory ?: return
                regularCategoryList.value[selectedCategory.category]?.let { categoryList ->
                    val filteredCategoryContent = ContentFilter.filterContentIfNeeded(
                        categories = categoryList,
                        isKidsLockEnabled = _isKidsLockEnabled.value
                    )

                    ContentFilter.updateFilteredContentAndState(
                        filteredCategoryContent,
                        _isKidsLockEnabled.value,
                        if (selectedCategory.category == Categories.Adult) HomeScreens.CategoryAdult else HomeScreens.Category,
                        { newFilteredCategoryContent ->
                            _filteredRegularCategoryList.update {  currentMap ->
                                currentMap.plus((selectedCategory.category to newFilteredCategoryContent))
                            }
                        },
                        { newFilteredCategoryContent, screen ->
                            _uiState.update { state ->
                                state.copy(
                                    currentScreen = screen,
                                    specificCategoryList = newFilteredCategoryContent,
                                    isCategoryVisible = false
                                )
                            }

                        }
                    )
                }
                topFlagToggle(true)
            }

            HomeScreens.Cp -> {
                val filteredCpContent = ContentFilter.filterContentIfNeeded(
                    categories = _allCpItems.value,
                    isKidsLockEnabled = _isKidsLockEnabled.value
                )

                ContentFilter.updateFilteredContentAndState(
                    filteredCpContent,
                    _isKidsLockEnabled.value,
                    HomeScreens.Cp,
                    { newFilteredCpContent ->
                        _filteredAllCpItems.value = HomeCategoryList(categoryList = newFilteredCpContent)
                    },
                    { newFilteredCpContent, screen ->
                        _uiState.update { state ->
                            state.copy(
                                currentScreen = screen,
                                specificCategoryList = newFilteredCpContent,
                                isCategoryVisible = false
                            )
                        }
                    }
                )
                topFlagToggle(true)
            }
        }
        _isCategoryDrawerVisible.value = false
    }

    fun onClickNavIcon(resource: Int) {
        viewModelScope.launch {
            when (resource) {
                R.drawable.icon_nav_home -> {
                    _isCategoryDrawerVisible.value = false
                    if (_uiState.value.currentScreen!= HomeScreens.Main) {
                        updateCurrentScreen(HomeScreens.Main)
                        topFlagToggle(true)
                    } else {
                        topFlagToggle(true)
                    }
                }
                R.drawable.icon_nav_vod -> {
                    toggleCategoryDrawer()
                }
                R.drawable.icon_nav_top10 -> {
                    _isCategoryDrawerVisible.value = false
                    if (_uiState.value.currentScreen == HomeScreens.Main) {
                        setHomeScreenLaunchedEffectCompleted(true)
                    } else {
                        updateCurrentScreen(HomeScreens.Main)
                        setHomeScreenLaunchedEffectCompleted(false)
                    }
                    topFlagToggle(true)
                    rankFlagToggle(true)
                }
            }
        }
    }

    fun completeAdultVerification(context: Context, onSuccess: () -> Unit, onFailure: () -> Unit) {
        viewModelScope.launch {
            val isVerified = checkAdultVerification(context)
            if (isVerified == true) {
                onSuccess()
            } else {
                onFailure()
            }
        }
    }


    private suspend fun checkAdultVerification(context: Context): Boolean? {
        return suspendCoroutine { continuation ->

            MBSAgent.adultCheckState(object : Callback<ResponseAdultCheck> {
                override fun onResponse(call: Call<ResponseAdultCheck>, response: Response<ResponseAdultCheck>) {
                    if (response.isSuccessful) {
                        val responseBody = response.body()
                        if (responseBody == null) {
                            continuation.resumeWithException(CancellationException("Invalid response body"))
                            return
                        }

                        when (responseBody.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                                UIAgent.showPopup(context, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                    }
                                    override fun cancel() {
                                    }
                                })
                            }
                            SessionState.LOGOUT -> {
                                UIAgent.showPopup(context, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                    }
                                    override fun cancel() {
                                    }
                                })
                            }
                            SessionState.CONNECT -> {
                                UIAgent.showPopup(context, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                    }
                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                // SessionState가 FORCE_LOGOUT이 아닌 경우 isCheck 확인
                                when (responseBody.isCheck) {
                                    true -> continuation.resume(true)
                                    false -> continuation.resume(false)
                                }
                            }
                        }
                    } else {
                        continuation.resumeWithException(CancellationException("Network request failed"))
                    }
                }

                override fun onFailure(call: Call<ResponseAdultCheck>, t: Throwable) {
                    continuation.resumeWithException(CancellationException("Network request failed"))
                }
            })
        }
    }



    private fun updateBannerList() {
        val bannerCategory = uiState.value.defaultCategoryList.find { it.type == "mainBanner" }
        bannerCategory?.let { category ->
            val updatedList = if (isKidsLockEnabled.value) {
                category.categoryItemList.filter { it.rating?.contains(ContentType.ADULT_RATING) != true }
            } else {
                category.categoryItemList
            }
            _uiState.update { state ->
                state.copy(
                    defaultCategoryList = state.defaultCategoryList.map {
                        if (it.type == "mainBanner") it.copy(categoryItemList = updatedList) else it
                    }
                )
            }

            //null
            if (updatedList.isNotEmpty()) {
                setRandomBanner()
            } else {
                _currentBanner.value = null
            }
        }
    }

    fun nextBanner(){
        val bannerItemList = uiState.value.defaultCategoryList.find { it.type == "mainBanner" }?.categoryItemList
        if (bannerItemList.isNullOrEmpty()) {
            //null
            _currentBanner.value = null
            return
        }
        val nextIndex = (bannerIndex.value + 1) % bannerItemList.size
        _bannerIndex.value = nextIndex
        _currentBanner.value = bannerItemList[nextIndex]
    }

    fun setRandomBanner() {
        val bannerItemList = uiState.value.defaultCategoryList.find { it.type == "mainBanner" }?.categoryItemList

        //null처리 수정
        if (bannerItemList.isNullOrEmpty()) {
            _bannerIndex.value = 0
            _currentBanner.value = null
            return
        }
        val randomItem = bannerItemList.randomOrNull()
        val randomIndex = bannerItemList.indexOf(randomItem)
        _bannerIndex.value = if (randomIndex != -1) randomIndex else 0
        _currentBanner.value = randomItem
        //test
//        _currentBanner.value = randomItem?.copy(rating = "19세")?.build()
    }

    fun onKeyBackEvent(keyCode: Int): Boolean {
        return when {
            keyCode == KeyEvent.KEYCODE_BACK && isCategoryDrawerVisible.value -> {
                _isCategoryDrawerVisible.value = false
                navCategoryFocusRequester.requestFocus()
                true
            }
            !isCategoryDrawerVisible.value && uiState.value.currentScreen == HomeScreens.Main -> {
                if (!navCategoryFocusRequester.freeFocus()) {
                    navCategoryFocusRequester.requestFocus()
                } else {
                    _showQuitAppDialog.value = true
                }
                true
            }
            else -> false
        }
    }

    // =============================================================================================================//
    // 성인 콘텐츠 다이얼로그 (분리 예정)

    private val _inputPassword = mutableStateListOf<Char>()
    val inputPassword: List<Char> = _inputPassword

    private val _alertMessage = MutableStateFlow<HomeAlertMessage?>(null)
    val alertMessage: StateFlow<HomeAlertMessage?> = _alertMessage.asStateFlow()

    private val _popupState = MutableStateFlow<PopupState>(PopupState.None)
    val popupState: StateFlow<PopupState> = _popupState.asStateFlow()

    private val _showLoginDialog = MutableStateFlow(true)
    val showLoginDialog: StateFlow<Boolean> = _showLoginDialog.asStateFlow()

    fun inputPassword(char: Char) {
        if (_inputPassword.size < 4) {
            _inputPassword.add(char)
        }
    }

    fun deletePassword() {
        if (_inputPassword.isNotEmpty()) {
            _inputPassword.removeLast()
        }
    }

    fun checkPassword() {
        if (_inputPassword.size == 4) {
            val enteredPassword = _inputPassword.joinToString("")
            adultPwCheck(enteredPassword)
        } else {
            _alertMessage.value = HomeAlertMessage.InvalidPasswordFormat
        }
        clearInputPassword()
    }

    fun clearInputPassword() {
        _inputPassword.clear()
    }

    fun clearAlertMessage() {
        _alertMessage.value = null
    }

    private fun adultPwCheck(password: String) {
        MBSAgent.adultPwCheck(
            password,
            callback = object : Callback<ResponseNoBody> {
                override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                    if (response.isSuccessful && response.body() != null) {
                        _alertMessage.value = HomeAlertMessage.IsAdultContentAccessible
                        onAdultVerificationConfirmed()
                    } else {
                        when (response.code()) {
                            // 409
                            CODE.CONFLICT -> {
                                _popupState.value = PopupState.Conflict
                                STBAgent.isAuth = false
                            }
                            // 401
                            else -> _alertMessage.value = HomeAlertMessage.PasswordMismatch
                        }
                    }
                }
                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                    _popupState.value = PopupState.Error(
                        PopupType.getErrorType(TYPE.AUTH, CODE.NONE)
                    )
                }
            }
        )
    }

    fun error() {
        _popupState.value = PopupState.Error(
            PopupType.getErrorType(TYPE.AUTH, CODE.NONE)
        )
    }

    fun dismissPopup() {
        _popupState.value = PopupState.None
    }

    fun onConflictLogin(context: Context, onDismiss: () -> Unit) {
        if (_showLoginDialog.value) {
            PopupAgent.showLoginPopup(context, object : LoginPopupEvent {
                override fun onLogin(loginDialog: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.SUCCESS -> {
                            loginDialog.dismiss()
                            _showLoginDialog.value = false
                            (context as? Activity)?.finish()
                            onDismiss()
                        }
                        BtnLabel.CANCEL -> {
                            loginDialog.dismiss()
                            _showLoginDialog.value = false
                            onDismiss()
                        }
                        BtnLabel.BACK -> {
                            _showLoginDialog.value = false
                            (context as? Activity)?.finish()
                            onDismiss()
                        }
                    }
                }
            })
        }
    }


    sealed class PopupState {
        object None : PopupState()
        data class Error(val type: PopupType.ErrorType) : PopupState()
        object Conflict : PopupState()
    }

    sealed class HomeAlertMessage {
        object IsAdultContentAccessible : HomeAlertMessage()
        object PasswordMismatch : HomeAlertMessage()
        object InvalidPasswordFormat : HomeAlertMessage()
    }
}