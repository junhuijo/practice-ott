package com.homechoice.ott.vod.model.content

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Series (
    val id : Long,
    val posterUrl: String?,
    val isAdult:Boolean?,
    val contentList : List<Content>,
    val episodeNoList : List<Int>
):Parcelable