package com.homechoice.ott.vod.ui.popup.point

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogPointPurchaseSuccessBinding
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.PopupType.NormalPopupType
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.PopupViewModel
import com.homechoice.ott.vod.ui.popup.component.PopupButtonView
import com.homechoice.ott.vod.util.Logger

class PurchasePointSuccessPopupView : Dialog {
    private var binding: DialogPointPurchaseSuccessBinding
    private var model: PopupViewModel
    private var btns: ArrayList<PopupButtonView> = arrayListOf()

    constructor(
        ctx: Context,
        type: NormalPopupType,
        balance: Int,
        event: PopupEvent
    ) : super(ctx, R.style.Theme_Design_NoActionBar) {
        binding = DialogPointPurchaseSuccessBinding.inflate(LayoutInflater.from(ctx))
        model = PopupViewModel(type)
        model.content.value?.sub = String.format("%,d", balance)
        init()
        showNormalPopup(ctx, type, event)
    }

    private fun init() {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        binding.apply {
            viewModel = model
        }
        setContentView(binding.root)

        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            Logger.Log(Log.DEBUG, this, "kCode:$kCode")
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                        result = true
                    }
                }
            }
            result
        }
    }

    private fun showNormalPopup(
        ctx: Context,
        type: NormalPopupType,
        event: PopupEvent
    ) {

        for (item in model.content.value?.buttons!!) {
            val btnView = PopupButtonView(
                ctx,
                binding.btnLayout,
                item.label
            )
            btns.add(btnView)
            btnView.btn.setOnClickListener {
                event.onClick(this, (it as TextView).text.toString())
            }
        }

        if (type.timer > 0)
            Handler().postDelayed({
                dismiss()
                event.onClick(this, BtnLabel.INIT)
            }, type.timer * 1000L)

        if (btns.isNotEmpty())
            btns.first().focus()

    }

}