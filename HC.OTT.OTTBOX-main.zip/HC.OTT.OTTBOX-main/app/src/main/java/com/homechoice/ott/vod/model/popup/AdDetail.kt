package com.homechoice.ott.vod.model.popup

data class AdDetail (
    var adTitle: String= "",
    var adText: String= ""
    )