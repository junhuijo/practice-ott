package com.homechoice.ott.vod.agent

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.util.Log
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.util.Logger
import java.util.concurrent.ConcurrentHashMap


object ImageAgent {

    private var categoryList: ConcurrentHashMap<Long, ConcurrentHashMap<String, Bitmap>> = ConcurrentHashMap()

    fun load(ctx: Context, url: String, imageView: ImageView) {
        // 캐시하지 않음
        Glide.with(ctx).load(url).thumbnail(0.3F)
            .override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height))
            .placeholder(R.drawable.main_poster_1_d)
            .into(imageView)
    }

    fun load(ctx: Context, categoryId: Long, url: String, imageView: ImageView) {
//        Logger.Log(Log.INFO, this, "categoryList.containsKey($categoryId) ${categoryList.containsKey(categoryId)}")
        if (categoryList.containsKey(categoryId)) {
//            Logger.Log(Log.ERROR, this, "categoryList[$categoryId]?.containsKey($url)!! ${categoryList[categoryId]?.containsKey(url)!!}")
            if (categoryList[categoryId]?.containsKey(url)!!) {
                imageView.setImageBitmap(categoryList[categoryId]?.get(url))
            } else {
                addImage(ctx, categoryId, url, imageView)
            }
        } else {
            categoryList[categoryId] = ConcurrentHashMap()
            addImage(ctx, categoryId, url, imageView)
        }
//        Logger.Log(Log.WARN, this, "이미지 캐쉬 수량 categoryList.size : ${categoryList.size} / $categoryId | size: ${categoryList[categoryId]?.size}")
    }

    fun clear() {
        categoryList.clear()
    }

    private fun addImage(ctx: Context, categoryId: Long, url: String, imageView: ImageView) {
        Glide.with(ctx)
            .asBitmap()
            .load(url)
            .thumbnail(0.3F)
            .override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height))
            .placeholder(R.drawable.main_poster_1_d)
            .into(object : CustomTarget<Bitmap?>() {
                override fun onLoadCleared(placeholder: Drawable?) {
                    Logger.Log(Log.WARN, this, "onLoadCleared")
                }

                override fun onLoadStarted(placeholder: Drawable?) {
                    super.onLoadStarted(placeholder)
                    Logger.Log(Log.WARN, this, "onLoadStarted")
                    imageView.setImageDrawable(placeholder)
                }

                override fun onLoadFailed(errorDrawable: Drawable?) {
                    super.onLoadFailed(errorDrawable)
                    Logger.Log(Log.ERROR, this, "onLoadFailed url $url")
                    categoryList[categoryId]?.remove(url)
                }

                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                    Logger.Log(Log.WARN, this, "onResourceReady byteCount ${resource.byteCount} / rowBytes ${resource.rowBytes}")
                    imageView.setImageBitmap(resource)
                    categoryList[categoryId]?.put(url, resource)
                }
            })
    }

}