package com.homechoice.ott.vod.ui

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.agent.STBAgent.init
import com.homechoice.ott.vod.databinding.ActivityDliveonBinding
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.model.response.ResponseAuth
import com.homechoice.ott.vod.model.response.ResponseUserInfo
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.popup.TYPE
import com.homechoice.ott.vod.ui.detail.DetailActivityManager
import com.homechoice.ott.vod.ui.home.HomeActivity2
import com.homechoice.ott.vod.ui.my.MyActivity2
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.HttpURLConnection

class MainActivity : AppCompatActivity() {
    var context = this
    lateinit var binding: ActivityDliveonBinding
    lateinit var prefs: PreferenceUtil

    @SuppressLint("HardwareIds")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDliveonBinding.inflate(layoutInflater)
        binding.on.startAnimation(AnimationUtils.loadAnimation(applicationContext, R.anim.anim_splash_on_fade_out))
        STBAgent.init()
        ImageAgent.clear()
        setContentView(binding.root)
        prefs = PreferenceUtil(this)


        DetailActivityManager.clearActivities()

        Logger.Log(Log.DEBUG, this, "loginId : ${intent.getStringExtra("loginId")}")
        Logger.Log(Log.DEBUG, this, "loginPw : ${intent.getStringExtra("loginPw")}")
        STBAgent.linkedHomeChoice = false
        if(intent.hasExtra("loginId") && intent.hasExtra("loginPw")){
            STBAgent.linkedHomeChoice = !intent.getStringExtra("loginId").isNullOrEmpty() && !intent.getStringExtra("loginPw").isNullOrEmpty()
        }
        Log.d("linkedHomeChoice", "${STBAgent.linkedHomeChoice}")

        val arg = intent.getStringExtra("arg")

        Log.d("arg", "${!arg.isNullOrEmpty()}")
        if (!arg.isNullOrEmpty()) {
            val enterPath = UIAgent.createEnterPath(EnterPath.EXTERNAL, 0)
            if (arg[0] == 'G' || arg[0] == 'g') {
                authenticate(object : AuthListener {
                    override fun next() {
                        val id = arg.substring(1)
                        ActivityChangeAgent.goToContent(context, id.toLong(), enterPath, null)
                    }
                })
            } else if (arg[0] == 'S' || arg[0] == 's') {
                authenticate(object : AuthListener {
                    override fun next() {
                        val id = arg.substring(1)
                        ActivityChangeAgent.goToSeriesContent(
                            id.toLong(),
                            0,
                            context,
                            enterPath,
                            null
                        )
                    }
                })
            }
        } else {
            if (STBAgent.linkedHomeChoice) {
                val loginId = intent.getStringExtra("loginId")
                val loginPw = intent.getStringExtra("loginPw")
                STBAgent.userId = loginId!!

                if (loginId != null && loginPw != null) {
                    simpleAuthenticate(loginId, loginPw, object : AuthListener {
                        override fun next() {
                            goToMenu()
                        }
                    }) { id, pw, listener ->
                        requestLogin(id, pw, listener)
                    }
                } else {
                    authenticate(object : AuthListener {
                        override fun next() {
                            goToMenu()
                        }
                    })
                }
            } else {
                if (Constant.devMode) {
                    val loginId = "cmb2"
                    val loginPw = "123456"
                    simpleAuthenticate(loginId, loginPw, object : AuthListener {
                        override fun next() {
                            goToMenu()
                        }
                    }) { id, pw, listener ->
                        requestLogin(id, pw, listener)
                    }

                } else {
                    val savedLoginId = prefs.getString2("loginId", "")
                    val savedLoginPw = prefs.getString2("loginPw", "")

                    if (savedLoginId.isNotEmpty() && savedLoginPw.isNotEmpty()) {
                        Log.d("autoLogin", "자동 로그인")
                        simpleAuthenticate(savedLoginId, savedLoginPw, object : AuthListener {
                            override fun next() {
                                goToHome()
                            }
                        }) { id, pw, listener ->
                            requestLogin2(id, pw, listener)
                        }
                    } else {
                        Log.d("Login", "일반 로그인 팝업으로 이동")
                        authenticate(object : AuthListener {
                            override fun next() {
                                goToMenu()
                            }
                        })
                    }
                }
            }
        }
    }

    interface AuthListener {
        fun next()
    }

    private fun requestLogin(loginId: String, loginPw: String, listener: AuthListener) {
        STBAgent.login(context, loginId, loginPw, true, true, object : LoginEvent {
            override fun onFailure() {
                listener.next()
            }

            override fun onAccount(isForce: Boolean) {
                listener.next()
            }

            override fun onContinue(code: Int) {
                listener.next()
            }
        })
    }

    private fun requestLogin2(loginId: String, loginPw: String, listener: AuthListener) {
        STBAgent.login2(context, loginId, loginPw, true, true, object : LoginEvent {
            override fun onFailure() {
                listener.next()
            }

            override fun onAccount(isForce: Boolean) {
                listener.next()
            }

            override fun onContinue(code: Int) {
                listener.next()
            }
        })
    }

    private fun simpleAuthenticate(loginId: String, loginPw: String, listener: AuthListener, requestLoginFunc: (String, String, AuthListener) -> Unit) {
        GlobalScope.launch(Dispatchers.Main) {
            MBSAgent.sessionAuth(
                Constant.appCode,
                resources.getString(R.string.device_type),
                STBAgent.getAndroidId(context),
                object : Callback<ResponseAuth> {
                    override fun onFailure(call: Call<ResponseAuth>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure")
                        UIAgent.showPopup(context, CODE.NONE, null)
                    }

                    override fun onResponse(call: Call<ResponseAuth>, response: Response<ResponseAuth>) {
                        when (response.code()) {
                            HttpURLConnection.HTTP_OK -> {
                                val res = response.body()
                                if (res != null) {
                                    MBSAgent.terminalKey = res.terminalKey
                                    STBAgent.backgroundImageUrl = res.bgImgUrl
                                    requestLoginFunc(loginId, loginPw, listener)
                                } else {
                                    // 장애 팝업
                                    UIAgent.showPopup(context, response.code(), null)
                                }
                            }
                            else -> {
                                // 장애 팝업
                                UIAgent.showPopup(context, response.code(), null)
                            }
                        }
                    }
                }
            )
        }
    }

    private fun authenticate(listener: AuthListener) {
        GlobalScope.launch(Dispatchers.Main) {
            Log.d("MBSAgent.sessionAuth","${Constant.appCode} ${resources.getString(R.string.device_type)} ${STBAgent.getAndroidId(context)}")
            MBSAgent.sessionAuth(
                Constant.appCode,
                resources.getString(R.string.device_type),
                STBAgent.getAndroidId(context),
                object : Callback<ResponseAuth> {
                    override fun onFailure(call: Call<ResponseAuth>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure")
                        if (!context.isFinishing)
                            UIAgent.showPopup(context, CODE.NONE, null)
                    }

                    override fun onResponse(call: Call<ResponseAuth>, response: Response<ResponseAuth>) {
                        when (response.code()) {
                            HttpURLConnection.HTTP_OK -> {
                                val res = response.body()
                                if (res != null) {
                                    MBSAgent.terminalKey = res.terminalKey
                                    STBAgent.backgroundImageUrl = res.bgImgUrl

                                    // 자동 로그인 체크 시 ID/PW 확인
                                    // 자동 로그인은 우선순위가 높음. 강제 로그인 시도 처리
//                                    STBAgent.userId = ""
//                                    STBAgent.userName = ""

                                    PopupAgent.appStartShowLoginPopup(context = context, login = Login(forceLogin = true, terminalKey = res.terminalKey, loginqr = null), event = object : LoginPopupEvent {
                                        override fun onLogin(loginDialog: Dialog, btn: String) {
                                            when (btn) {
                                                BtnLabel.SUCCESS -> {
                                                    listener.next()
                                                }
                                                else -> {
                                                    goToHome()
                                                }
                                            }
                                        }
                                    })
                                }
//                                    }
                                else {
                                    // 장애 팝업
                                    UIAgent.showPopup(context, response.code(), null)
                                }
                            }
                            else -> {
                                // 장애 팝업
                                UIAgent.showPopup(context, response.code(), null)
                            }
                        }
                    }
                }
            )
        }
    }

    private fun goToMenu() {
        if (Constant.isLiveMode()) {
            MBSAgent.userInfo(MBSAgent.terminalKey, object : Callback<ResponseUserInfo> {
                override fun onResponse(call: Call<ResponseUserInfo>, response: Response<ResponseUserInfo>) {
                    Logger.Log(Log.DEBUG, this, "response " + response.message().toString())
                    when (response.code()) {
                        HttpURLConnection.HTTP_OK -> {
                            STBAgent.userName = response.body()?.userName.toString()
                            goToHome()
                        }
                        else -> {
                            goToHome()
                        }
                    }
                }
                override fun onFailure(call: Call<ResponseUserInfo>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, "onFailure")
                    goToHome()
                }
            })
        }
        else {
            when ("home") {
                "home" -> goToHome()
                "my" -> goToMyMenu()
                "search" -> goToSearch()
            }
        }
    }

    private fun showPopup(code: Int) {
        PopupAgent.showNormalPopup(
            context,
            PopupType.getErrorType(
                TYPE.AUTH,
                code
            ),
            object : PopupEvent {
                override fun onClick(d: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.OK -> {
                            init()
                            d.dismiss()
                        }
                    }
                }
            })
    }

    private fun goToSearch() {
        ActivityChangeAgent.goToSearchMenu(this)
        finish()
    }

    private fun goToHome() {
        val intent = Intent(this, HomeActivity2::class.java)
        intent.putExtra("TARGET_INFO", CategoryTarget.HOME)
        startActivity(intent)
        finish()
    }

    private fun goToMyMenu() {
        val intent = Intent(context, MyActivity2::class.java)
        intent.putExtra("TARGET_INFO", CategoryTarget.ROOT)
        startActivity(intent)
        finish()
    }

//    private fun authenticateUser(username: String, password: String): Boolean {
//        // 이 부분에서 실제 사용자 검증 로직을 구현합니다.
//        // 예제를 위해 단순화된 검증 로직을 사용합니다.
//        val secureLoginStorage = SecureLoginStorage(context)
//
//        // 로그인 정보 검색
//        val loginCredentials = secureLoginStorage.getLoginCredentials()
//        loginCredentials?.let {
//            val username = it.first
//            val password = it.second
//            // 이제 username과 password를 사용하여 로그인 로직을 수행할 수 있습니다.
//        }
//
//        // 로그인 정보 저장
//        secureLoginStorage.saveLoginCredentials("user123", "password456")
//
//        return username == "user123" && password == "password456"
//    }

}