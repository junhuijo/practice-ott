package com.homechoice.ott.vod.ui.search.result

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.TableRow
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentSearchResultBinding
import com.homechoice.ott.vod.databinding.ItemSearchContentListBinding
import com.homechoice.ott.vod.model.response.ResponseSearchList
import com.homechoice.ott.vod.model.search.SearchItem
import com.homechoice.ott.vod.ui.navigation.grid.NavigationGridData
import com.homechoice.ott.vod.ui.navigation.grid.NavigationGridEvent
import com.homechoice.ott.vod.ui.navigation.grid.NavigationGridModel
import com.homechoice.ott.vod.ui.navigation.grid.NavigationGridView
import com.homechoice.ott.vod.ui.search.SearchActivity
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.CONTENT_LOADED
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.INPUT_FOCUS
import com.homechoice.ott.vod.ui.sub.SubCategoryActivity
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.math.ceil

class SearchResultFragment(private val keyword: String, private val includeAdult: Boolean, val eventHandler: Handler) : NavigationGridView() {
    private lateinit var binding: FragmentSearchResultBinding
    private var contentViewList: ArrayList<ItemSearchContentListBinding> = arrayListOf()
    private lateinit var imm: InputMethodManager

    var isLoading = true

    val event: NavigationGridEvent = object : NavigationGridEvent {
        override fun upRowChange() {
            Logger.Log(Log.INFO, this, "upRowChange")
            UIAgent.smoothScrollDxBy(binding.searchResultListScrollView, R.dimen.search_content_height, false)
        }

        override fun downRowChange() {
            Logger.Log(Log.INFO, this, "downRowChange")
            isLoading = true
            UIAgent.smoothScrollDxBy(binding.searchResultListScrollView, R.dimen.search_content_height, true)
//            requestSearch(UUID.randomUUID().toString(), controller?.data?.totalIndex!!.plus(2), controller?.data?.pageSize!!, false)
        }

        override fun lastRowChange() {
            Logger.Log(Log.INFO, this, "lastRowChange")
            UIAgent.smoothScrollDxBy(binding.searchResultListScrollView, R.dimen.search_content_height, true)
        }

        override fun firstRowChange() {
            Logger.Log(Log.INFO, this, "firstRowChange")
            unfocus(controller?.getCurIndex()!!)
            eventHandler.obtainMessage(INPUT_FOCUS).sendToTarget()
        }

        override fun firstColChange() {
            Logger.Log(Log.INFO, this, "firstColChange")
            controller?.decreaseForce()
        }

        override fun focusChange() {
            val preIndex = controller?.getPreIndex()
            val curIndex = controller?.getCurIndex()

            preIndex?.let { unfocus(it) }
            curIndex?.let { focus(it) }
        }

        override fun addEmptyRow() {
            Logger.Log(Log.INFO, this, "addEmptyRow")
            val tableRow = TableRow(context)
            val itemBinding = ItemSearchContentListBinding.inflate(
                LayoutInflater.from(context),
                tableRow,
                false
            )

            tableRow.addView(itemBinding.root)

            binding.searchResultListTableLayout.addView(tableRow)
            UIAgent.smoothScrollDxBy(
                binding.searchResultListScrollView,
                R.dimen.sub_content_layout_row_height, true
            )
            UIAgent.smoothScrollDxBy(binding.searchResultListScrollView, R.dimen.search_content_height, true)
        }
    }

    @SuppressLint("InflateParams", "SetTextI18n")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        binding = FragmentSearchResultBinding.inflate(inflater)
        binding.apply {
        }

        binding.searchName.text = "검색결과 : $keyword"
        imm = context!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        requestSearch(UUID.randomUUID().toString(), 1, 46, true)

        binding.searchResultListTableLayout.setOnKeyListener { _, keyCode, event ->

            if (event.action == KeyEvent.ACTION_DOWN) {
                val input = STBAgent.enableKeyInput(300L)
                Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode / input : $input / isLoading $isLoading / event.action ${event.action}")
                if (input && !isLoading) {
//                if (true) {
                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            controller?.increase()
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_LEFT -> {
                            controller?.decrease()
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_UP -> {
                            controller?.decreaseRow()
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            controller?.increaseRow()
                            true
                        }
                        KeyEvent.KEYCODE_BACK, 97  -> {
                            eventHandler.obtainMessage(SearchActivity.ActionType.SEARCH_EXIT).sendToTarget()
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_CENTER, 96,
                        KeyEvent.KEYCODE_ENTER -> {
                            val item = controller?.getCurItem() as SearchItem
                            val enterPath = UIAgent.createEnterPath(EnterPath.SEARCH, 0)
                            when (item.searchItemTargetList[0].targetType) {
                                CategoryItemType.CONTENTGROUP -> {
                                    ActivityChangeAgent.goToContent(context!!, item.searchItemTargetList[0].targetId, enterPath, null)
                                }
                                CategoryItemType.SERIES -> {
                                    ActivityChangeAgent.goToSeriesContent(item.searchItemTargetList[0].targetId, 0, context!!, enterPath, null)
                                }
                                CategoryItemType.CATEGORY -> {
                                    ActivityChangeAgent.goToSubCategoryList(
                                        context!!,
                                        item.searchItemTargetList[0].targetId.toInt(),
                                        SubCategoryActivity.ActionType.CONTENTS_FOCUS
                                    )
                                }
                                CategoryItemType.PACKAGE_OFFER -> {
                                    ActivityChangeAgent.goToPackage(
                                        context!!,
                                        UUID.randomUUID().toString(),
                                        item.searchItemTargetList[0].targetId,
                                        enterPath,
                                        null
                                    )
                                }
                            }
                            true
                        }
                        else -> true
                    }
                } else
                    true
            } else {
                false
            }
        }

        return binding.root
    }

//    override fun onResume() {
//        super.onResume()
//        // 사용자가 화면으로 돌아왔을 때, CustomEditTextView에 포커스를 다시 설정
//        bind.searchEditTextView.requestFocus()
//    }


    private fun requestSearch(transactionId: String, startIdx: Int, pageSize: Int, init: Boolean) {

        MBSAgent.search(
            transactionId = transactionId,
            searchWord = keyword,
            includeAdult = false,
            includeRrated = STBAgent.includeRrated,
            startIdx = startIdx,
            pageSize = pageSize,
            callback = object : Callback<ResponseSearchList> {
                override fun onFailure(call: Call<ResponseSearchList>, t: Throwable) {
                    binding.searchResultListScrollView.visibility = View.INVISIBLE
                    binding.searchResultEmptyLayout.visibility = View.VISIBLE
                    eventHandler.obtainMessage(INPUT_FOCUS).sendToTarget()
                    eventHandler.obtainMessage(CONTENT_LOADED).sendToTarget()
                }

                override fun onResponse(call: Call<ResponseSearchList>, response: Response<ResponseSearchList>) {
                    if (response.isSuccessful) {
                        val res = response.body()


                        if (transactionId == res!!.transactionId) {
                            val list = res.searchItemList
                            val totalCount = res.totalCount.toDouble()
                            val itemCount = list.size.toDouble()
                            val defaultCount = 3.toDouble()

                            if (res.totalCount > 0) {
                                if (init) {
                                    val rows = if ((itemCount / defaultCount) > 1) ceil(itemCount / defaultCount) else (1).toDouble()
                                    Logger.Log(Log.DEBUG, this, "defaultCount $defaultCount / rows $rows")

                                    for (rowIndex in 0 until rows.toInt()) {
                                        Logger.Log(Log.DEBUG, this, "rowIndex $rowIndex")
                                        val tableRow = TableRow(context)
                                        for (colIndex in (rowIndex * defaultCount.toInt()) until ((rowIndex * defaultCount.toInt()) + defaultCount.toInt())) {
                                            if (colIndex > list.size - 1) {
                                                break
                                            }

                                            val itemBinding = ItemSearchContentListBinding.inflate(
                                                LayoutInflater.from(context),
                                                tableRow,
                                                false
                                            )

                                            if (list[colIndex].posterUrl != "") {

                                                Glide.with(context!!).load(list[colIndex].posterUrl).thumbnail(0.3F)
                                                    .override(
                                                        CMBApp.getPixelSize(R.dimen.home_sub_content_poster_width),
                                                        CMBApp.getPixelSize(R.dimen.home_sub_content_poster_height)
                                                    )
                                                    .placeholder(R.drawable.main_poster_1_d)
                                                    .into(itemBinding.subContentListPoster)
                                            }

                                            tableRow.addView(itemBinding.root)
                                            contentViewList.add(itemBinding)
                                        }
                                        binding.searchResultListTableLayout.addView(tableRow)
                                    }

                                    setModel(
                                        NavigationGridModel(
                                            NavigationGridData(
                                                rightFixedIndex = 0,
                                                totalCount = res.totalCount + 1,
                                                colCount = defaultCount.toInt(),
                                                startIndex = 0,
                                                visibleThreshold = 1,
                                                pageSize = 60
                                            ).build(list)
                                        ), event
                                    )

                                    focus(0)

                                    binding.searchResultListTableLayout.requestFocus()

                                    GlobalScope.launch(Dispatchers.Main) {
                                        delay(300L)
                                        isLoading = false
                                    }
                                } else {

                                    val arrayList: ArrayList<Any> = arrayListOf()
                                    for (item in list) {
                                        arrayList.add(item)
                                    }
                                    controller?.appendData(arrayList)

                                    val rows = if ((arrayList.size / defaultCount) > 1) ceil(arrayList.size / defaultCount) else (1).toDouble()
                                    for (rowIndex in 0 until rows.toInt()) {
                                        val tableRow = TableRow(context)
                                        for (colIndex in (rowIndex * defaultCount.toInt()) until ((rowIndex * defaultCount.toInt()) + defaultCount.toInt())) {
                                            if (colIndex > arrayList.size - 1) {
                                                break
                                            }
                                            val itemBinding = ItemSearchContentListBinding.inflate(
                                                LayoutInflater.from(context),
                                                tableRow,
                                                false
                                            )

                                            if (list[colIndex].posterUrl != "") {

                                                Glide.with(context!!).load(list[colIndex].posterUrl).thumbnail(0.3F)
                                                    .override(
                                                        CMBApp.getPixelSize(R.dimen.home_sub_content_poster_width),
                                                        CMBApp.getPixelSize(R.dimen.home_sub_content_poster_height)
                                                    )
                                                    .placeholder(R.drawable.main_poster_1_d)
                                                    .into(itemBinding.subContentListPoster)
                                            }

                                            tableRow.addView(itemBinding.root)
                                            contentViewList.add(itemBinding)
                                        }
                                        binding.searchResultListTableLayout.addView(tableRow)
                                    }
                                    GlobalScope.launch(Dispatchers.Main) {
                                        delay(300L)
                                        isLoading = false

                                    }
                                }
                            } else {
                                // 검색 결과가 없음.
                                binding.searchResultListScrollView.visibility = View.INVISIBLE
                                binding.searchResultEmptyLayout.visibility = View.VISIBLE
                                isLoading = false
                                eventHandler.obtainMessage(INPUT_FOCUS).sendToTarget()
                            }

                        }
                    } else {
                        // 검색 결과가 없음.
                        // -> 목록이 없는 경우 404 리
                        binding.searchResultListScrollView.visibility = View.INVISIBLE
                        binding.searchResultEmptyLayout.visibility = View.VISIBLE
                        isLoading = false
                        eventHandler.obtainMessage(INPUT_FOCUS).sendToTarget()
                    }
                    eventHandler.obtainMessage(CONTENT_LOADED).sendToTarget()
                }
            })
    }


    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
        return false
    }

    fun focus(index: Int) {
        if (index in contentViewList.indices) {
            contentViewList[index].mainCategoryLayout.background =
                ContextCompat.getDrawable(CMBApp.CTX, R.drawable.border_red)
        }
    }

    fun unfocus(index: Int) {
        if (index in contentViewList.indices) {
            contentViewList[index].mainCategoryLayout.background =
                ContextCompat.getDrawable(CMBApp.CTX, R.drawable.border_black)
            imm.hideSoftInputFromWindow(binding.searchResultListTableLayout.windowToken, 0)
        }
    }


    fun select() {
    }

    fun back() {
    }

    fun active() {
        if (controller?.hasData() == true) {
            binding.searchResultListTableLayout.requestFocus()
            controller?.init()
            focus(0)
        }
    }
}