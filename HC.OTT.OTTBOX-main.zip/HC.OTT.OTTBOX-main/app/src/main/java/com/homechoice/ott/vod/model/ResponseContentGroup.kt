package com.homechoice.ott.vod.model

import android.os.Parcelable
import com.homechoice.ott.vod.model.content.ContentGroup
import kotlinx.android.parcel.Parcelize

@Parcelize
class ResponseContentGroup(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    var contentGroup: ContentGroup
) : Parcelable