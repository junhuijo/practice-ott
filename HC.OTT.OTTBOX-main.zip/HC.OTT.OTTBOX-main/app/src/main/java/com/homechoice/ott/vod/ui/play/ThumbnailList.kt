//package com.homechoice.ott.vod.ui.play
//
//import androidx.compose.foundation.BorderStroke
//import androidx.compose.foundation.border
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.lazy.LazyRow
//import androidx.compose.foundation.lazy.items
//import androidx.compose.material3.Surface
//import androidx.compose.runtime.*
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.platform.LocalContext
//import androidx.compose.ui.unit.dp
//import coil.compose.AsyncImage
//import com.homechoice.ott.vod.io.RetrofitXmlClient
//import com.homechoice.ott.vod.model.play.Frame
//import com.homechoice.ott.vod.model.play.Thumbnail
//import kotlinx.coroutines.launch
//import retrofit2.Call
//import retrofit2.Callback
//import retrofit2.Response
//
//@Composable
//fun ThumbnailList(
//    thumbnailServerInfo: String,
//    thumbnailUrl: String,
//    currentPosition: Int,
//    onThumbnailLoaded: (List<Frame>) -> Unit
//) {
//    val coroutineScope = rememberCoroutineScope()
//    var frames by remember { mutableStateOf(emptyList<Frame>()) }
//    val context = LocalContext.current
//
//    LaunchedEffect(thumbnailUrl) {
//        coroutineScope.launch {
//            try {
//                RetrofitXmlClient.getInstance().setService(thumbnailServerInfo + "/")
//                RetrofitXmlClient.getInstance()
//                    .getThumbnail(thumbnailUrl, object : Callback<Thumbnail> {
//                        override fun onFailure(call: Call<Thumbnail>, t: Throwable) {
//                            frames = emptyList()
//                        }
//
//                        override fun onResponse(call: Call<Thumbnail>, response: Response<Thumbnail>) {
//                            val thumbnail = response.body()
//                            frames = thumbnail?.frames ?: emptyList()
//                            onThumbnailLoaded(frames)
//                        }
//                    })
//            } catch (e: Exception) {
//                frames = emptyList()
//            }
//        }
//    }
//
//    Surface(
//        modifier = Modifier.fillMaxWidth(),
//        tonalElevation = 8.dp
//    ) {
//        LazyRow(
//            modifier = Modifier.fillMaxWidth(),
//            contentPadding = PaddingValues(horizontal = 16.dp),
//            horizontalArrangement = Arrangement.spacedBy(8.dp)
//        ) {
//            items(frames) { frame ->
//                ThumbnailItem(
//                    thumbnailServerInfo = thumbnailServerInfo,
//                    frame = frame,
//                    isSelected = frame.startPositionSec <= currentPosition && currentPosition < frame.endPositionSec
//                )
//            }
//        }
//    }
//}
//
//@Composable
//fun ThumbnailItem(
//    thumbnailServerInfo: String,
//    frame: Frame,
//    isSelected: Boolean
//) {
//    Box(
//        modifier = Modifier
//            .width(160.dp)
//            .height(90.dp)
//            .border(
//                border = if (isSelected) {
//                    BorderStroke(2.dp, Color.Red)
//                } else {
//                    BorderStroke(1.dp, Color.Gray)
//                }
//            )
//    ) {
//        AsyncImage(
//            model = "$thumbnailServerInfo/${frame.url}",
//            contentDescription = null,
//            modifier = Modifier.fillMaxSize()
//        )
//    }
//}