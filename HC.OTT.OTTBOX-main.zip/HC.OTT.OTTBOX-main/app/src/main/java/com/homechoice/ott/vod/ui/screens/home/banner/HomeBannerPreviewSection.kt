package com.homechoice.ott.vod.ui.screens.home.banner

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.ui.screens.VideoContent
import kotlinx.coroutines.delay

@Composable
fun BannerPreviewSection(banner: CategoryItem, nextBanner: () -> Unit) {

    var isTrailerReady by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.CenterEnd
    ){
        Box(
            modifier = Modifier
                .width(480.dp)
                .fillMaxHeight()
        ){
            if(isTrailerReady){
                BannerVideo(
                    movieUrl = banner.trailer ?: "",
                    onEnded = {
                        isTrailerReady = false
                        nextBanner()
                    }
                )
            }
            BannerLeftGradient()
        }
    }

    LaunchedEffect(banner) {
        delay(3000)
        if(banner.trailer.isNullOrEmpty()){
            delay(10000)
            nextBanner()
        }else{
            isTrailerReady = true
        }
    }
}

@Composable
fun BannerLeftGradient(){
    val leftBrush = Brush.horizontalGradient(colorStops = arrayOf(0.0f to Color.Black,0.2f to Color.Transparent, 1f to Color.Transparent))
    Canvas(modifier = Modifier
        .fillMaxSize()
        .background(leftBrush)) {}
}

@Composable
fun BannerVideo(movieUrl: String,onEnded: ()->Unit = {}) {
    VideoContent(
        movieUrl = movieUrl,
        onEnded = onEnded
    )
}