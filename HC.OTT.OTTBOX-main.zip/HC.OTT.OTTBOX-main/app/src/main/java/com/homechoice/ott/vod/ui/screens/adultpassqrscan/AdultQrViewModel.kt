package com.homechoice.ott.vod.ui.screens.adultpassqrscan

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.exoplayer2.util.Log
import com.homechoice.ott.vod.agent.Constant
import com.homechoice.ott.vod.agent.HomeScreens
import com.homechoice.ott.vod.agent.LoginEvent
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.model.response.ResponseAdultCheck
import com.homechoice.ott.vod.model.response.ResponseAuth
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.ui.MainActivity.AuthListener
import com.homechoice.ott.vod.util.AdultQrScanner
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.HttpURLConnection
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine


class AdultQrViewModel : ViewModel() {

    fun initializeAuthentication(context: Context, onSuccess: () -> Unit, onFailure: () -> Unit) {

        viewModelScope.launch {
            val prefs = context.getSharedPreferences("user_info", Context.MODE_PRIVATE)
            val loginId = prefs.getString("loginId", "") ?: ""
            val loginPw = prefs.getString("loginPw", "") ?: ""

            simpleAuthenticate(context, loginId, loginPw, object : AuthListener {
                override fun next() {
                    completeAdultVerification(onSuccess, onFailure)
                }
            })
        }
    }

    private fun simpleAuthenticate(context: Context, loginId: String, loginPw: String, listener: AuthListener) {
        viewModelScope.launch {
            MBSAgent.sessionAuth( Constant.appCode,"OTTBOX.android.cmb", STBAgent.getAndroidId(context), object : Callback<ResponseAuth> {
                override fun onFailure(call: Call<ResponseAuth>, t: Throwable) {
                    UIAgent.showPopup(context, CODE.NONE, null)
                }

                override fun onResponse(call: Call<ResponseAuth>, response: Response<ResponseAuth>) {
                    when (response.code()) {
                        HttpURLConnection.HTTP_OK -> {
                            val res = response.body()
                            if (res != null) {
                                MBSAgent.terminalKey = res.terminalKey
                                STBAgent.backgroundImageUrl = res.bgImgUrl
                                requestLogin2(context, loginId, loginPw, listener)
                            } else {
                                UIAgent.showPopup(context, response.code(), null)
                            }
                        }
                        else -> {
                            UIAgent.showPopup(context, response.code(), null)
                        }
                    }
                }
            }
            )
        }
    }

    private fun requestLogin2(context: Context, loginId: String, loginPw: String, listener: AuthListener) {
        STBAgent.login2(
            context,
            loginId,
            loginPw,
            isChecked = true,
            forceLogin = true,
            event = object : LoginEvent {
                override fun onFailure() {
                    listener.next()
                }

                override fun onAccount(isForce: Boolean) {
                    listener.next()
                }

                override fun onContinue(code: Int) {
                    listener.next()
                }
            })
    }

    private fun completeAdultVerification(onSuccess: () -> Unit, onFailure: () -> Unit) {
        viewModelScope.launch {
            val isVerified = checkAdultVerification()
            if (isVerified) {
                onSuccess()
            } else {
                onFailure()
            }
        }
    }

    private suspend fun checkAdultVerification(): Boolean {
        return suspendCoroutine { continuation ->
            MBSAgent.adultCheckState(object : Callback<ResponseAdultCheck> {
                override fun onResponse(call: Call<ResponseAdultCheck>, response: Response<ResponseAdultCheck>) {
                    if (response.isSuccessful) {
                        val isVerified = response.body()?.isCheck == true
                        continuation.resume(isVerified)
                    } else {
                        continuation.resume(false)
                    }
                }

                override fun onFailure(call: Call<ResponseAdultCheck>, t: Throwable) {
                    continuation.resume(false)
                }
            })
        }
    }
}