package com.homechoice.ott.vod.model.content

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
class Offer(
    val id : Long,
    val title : String?,
    val packageType : String?,
    val productType : String?,
    val price : Int?,
    val discountPrice : Int?,
    val rentalPeriod : String?,
    val eventType : String?,
    val isPurchase: Boolean?,
    val viewablePeriod : String?,
    val pointPolicyId: Long? = 0,
    val pointPolicyType: String? = "",
    val pointPolicyValue: Int? = 0
) : Parcelable
