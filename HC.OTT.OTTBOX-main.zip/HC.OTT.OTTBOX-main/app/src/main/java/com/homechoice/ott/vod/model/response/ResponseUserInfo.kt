package com.homechoice.ott.vod.model.response

import android.os.Parcel
import android.os.Parcelable

data class ResponseUserInfo(
    val transactionId: String? = null,
    val errorString: String = "",
    val sessionState: String = "",
    val dliveterminalKey: String = "",
    val accountId: String = "",
    val userName: String = "",
    val socialNumber: String = "",
    val phoneNumber: String = "",
    val zipcode: String = "",
    val adultCert: String = "",
    val msoName: String = ""
) : Parcelable {

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(transactionId)
        parcel.writeString(errorString)
        parcel.writeString(sessionState)
        parcel.writeString(dliveterminalKey)
        parcel.writeString(accountId)
        parcel.writeString(userName)
        parcel.writeString(socialNumber)
        parcel.writeString(phoneNumber)
        parcel.writeString(zipcode)
        parcel.writeString(adultCert)
        parcel.writeString(msoName)
    }

    companion object CREATOR : Parcelable.Creator<ResponseUserInfo> {
        override fun createFromParcel(parcel: Parcel): ResponseUserInfo {
            return ResponseUserInfo(
                transactionId = parcel.readString(),
                errorString = parcel.readString() ?: "",
                sessionState = parcel.readString() ?: "",
                dliveterminalKey = parcel.readString() ?: "",
                accountId = parcel.readString() ?: "",
                userName = parcel.readString() ?: "",
                socialNumber = parcel.readString() ?: "",
                phoneNumber = parcel.readString() ?: "",
                zipcode = parcel.readString() ?: "",
                adultCert = parcel.readString() ?: "",
                msoName = parcel.readString() ?: ""
            )
        }

        override fun newArray(size: Int): Array<ResponseUserInfo?> {
            return arrayOfNulls(size)
        }
    }
}