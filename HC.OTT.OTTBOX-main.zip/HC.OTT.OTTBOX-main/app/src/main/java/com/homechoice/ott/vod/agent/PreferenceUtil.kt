package com.homechoice.ott.vod.agent

import android.content.Context
import android.content.SharedPreferences

class PreferenceUtil(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("prefs_name", Context.MODE_PRIVATE)

    private val prefs2: SharedPreferences =
        context.getSharedPreferences("user_info", Context.MODE_PRIVATE)

    fun getString(key: String, defValue: String): String {
        return prefs.getString(key, defValue).toString()
    }

    fun setString(key: String, str: String) {
        prefs.edit().putString(key, str).apply()
    }

    fun isBoolean(key: String, defValue: Boolean): Boolean {
        return prefs.getBoolean(key, defValue)
    }

    fun setBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    fun getString2(key: String, defValue: String): String {
        return prefs2.getString(key, defValue) ?: defValue
    }

    fun setString2(key: String, str: String) {
        prefs2.edit().putString(key, str).apply()
    }
}