package com.homechoice.ott.vod.ui.my.member

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.ui.navigation.navigator.NavigatorModel


class MemberLoginViewModel : ViewModel() {
    enum class FocusType {
        NONE, ID, PASSWORD, KEEP_LOGGED_IN, JOIN, BUTTON
    }

    interface ModelListener {
        fun focused(focusType: FocusType)
        fun buttonFocused(index: Int)
        fun select(focusType: FocusType, currentIndex: Int)
        fun back(focusType: FocusType)
        fun hideIME()
    }

    var invalidInfo: MutableLiveData<Boolean> = MutableLiveData()

    var focusType: FocusType = FocusType.NONE
    private lateinit var listener: ModelListener

    var buttonListModel: NavigatorModel = NavigatorModel(1, 0, 1, 1, object : NavigatorModel.Callback {
        override fun init(index: Int) {

        }

        override fun pageStartIndexChanged() {

        }

        override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
            listener.buttonFocused(index)
        }

    })


    fun init() {
        focusType = FocusType.ID
    }

    fun up() {
        when (this.focusType) {
            FocusType.PASSWORD -> {
                this.focusType = FocusType.ID
                listener.focused(this.focusType)
            }
            FocusType.KEEP_LOGGED_IN -> {
                this.focusType = FocusType.PASSWORD
                listener.focused(this.focusType)
            }
            FocusType.JOIN -> {
                this.focusType = FocusType.PASSWORD
                listener.focused(this.focusType)
            }
            FocusType.BUTTON -> {
                this.focusType = FocusType.PASSWORD
                listener.focused(this.focusType)
            }
        }
    }

    fun setModelListener(listener: ModelListener) {
        this.listener = listener
    }

    fun getModelListener(): ModelListener {
        return this.listener
    }

    fun down() {
        when (this.focusType) {
            FocusType.ID -> {
                this.focusType = FocusType.PASSWORD
                listener.focused(this.focusType)
            }
            FocusType.PASSWORD -> {
                this.focusType = FocusType.BUTTON
                buttonListModel.currentIndex = 0
                listener.buttonFocused(buttonListModel.currentIndex)
            }
            FocusType.KEEP_LOGGED_IN -> {
                this.focusType = FocusType.BUTTON
                buttonListModel.currentIndex = 0
                listener.buttonFocused(buttonListModel.currentIndex)
            }
            FocusType.JOIN -> {
                this.focusType = FocusType.BUTTON
                buttonListModel.currentIndex = 0
                listener.buttonFocused(buttonListModel.currentIndex)
            }
        }
    }

    fun right() {
        when (this.focusType) {
            FocusType.KEEP_LOGGED_IN -> {
                this.focusType = FocusType.JOIN
                listener.focused(this.focusType)
            }
            FocusType.BUTTON -> {
                buttonListModel.right()
            }
        }
    }

    fun left() {
        when (this.focusType) {
            FocusType.ID -> {
                back()
            }
            FocusType.PASSWORD -> {
                back()
            }
            FocusType.JOIN -> {
                this.focusType = FocusType.KEEP_LOGGED_IN
                listener.focused(this.focusType)
            }
            FocusType.KEEP_LOGGED_IN -> {
                back()
            }
            FocusType.BUTTON -> {
                if (buttonListModel.currentIndex > 0) {
                    buttonListModel.left()
                } else {
                    back()
                }
            }
        }
    }

    fun back() {
        listener.back(this.focusType)
    }

    fun enter() {
        when (this.focusType) {
            FocusType.BUTTON -> {
                listener.select(this.focusType, buttonListModel.currentIndex)
            }
            else -> {
                listener.select(this.focusType, 0)
            }
        }
    }

}

