package com.homechoice.ott.vod.model.request

data class RequestPointPinNo(
    val terminalKey: String,
    val pointPinNo: String
)
