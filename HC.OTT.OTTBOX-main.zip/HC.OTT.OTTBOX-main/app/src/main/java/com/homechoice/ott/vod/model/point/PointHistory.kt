package com.homechoice.ott.vod.model.point

import android.os.Parcelable
import com.homechoice.ott.vod.agent.PointType
import com.homechoice.ott.vod.util.StringUtil
import kotlinx.android.parcel.Parcelize

@Parcelize
class PointHistory (
    var id: String,
    var type: String,
    var date : String,
    var price : Int,
    var point : Int,
    var description : String,
    var titleForPay : String,
    var priceStr : String,
    var pointStr : String,
    var validDate : String,
    var typeStr : String,
    var dateStr : String

) : Parcelable {
    init {
        build()
    }

    fun build(): PointHistory {
        priceStr = String.format("%,d", price)
        pointStr = String.format("%,d", point)
        typeStr = getTypeStr(type)
        dateStr = StringUtil.getInstance().getPointHistoryDate(date)
        return this
    }

    private fun getTypeStr(type : String): String {
        var typeStr = ""
        when (type) {
            PointType.PAYMENT_VOD -> {
                typeStr = "사용"
            }

            PointType.PRODUCT_MILEAGE,
            PointType.VOD_MILEAGE -> {
                typeStr = "적립"
            }
            PointType.EXPIRED_POINT -> {
                typeStr = "소멸"
            }
            PointType.POINT_PRODUCT -> {
                typeStr = "구매"
            }
            PointType.CANCEL_POINT_PRODUCT ->{
                typeStr = "충전취소"
            }
            PointType.CANCEL_VOD_MILEAGE,
            PointType.CANCEL_PRODUCT_MILEAGE ->{
                typeStr = "적립회수"
            }

            PointType.CANCEL_PAYMENT_VOD->{
                typeStr = "환불"
            }

            PointType.ISSUE->{
                typeStr = "발급"
            }

            PointType.PUBLISH->{
                typeStr = "등록"
            }

        }


        return typeStr
    }
}