package com.homechoice.ott.vod.model.request

data class RequestAdultPwModify (
    val terminalKey: String,
    val type: String,
    val oldPw: String,
    val newPw: String
)