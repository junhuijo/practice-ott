package com.homechoice.ott.vod.model.search

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class SearchItemTarget(
    var appCode: String = "",
    var targetType: String = "",
    var targetId: Long = 0
): Parcelable
