package com.homechoice.ott.vod.model.request

data class RequestUserInfo(
    val user_id: String,
    val app_code: String
)
