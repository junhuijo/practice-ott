package com.homechoice.ott.vod.model.response

data class ResponsePlayOffset(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    var offset: Int = 0
)