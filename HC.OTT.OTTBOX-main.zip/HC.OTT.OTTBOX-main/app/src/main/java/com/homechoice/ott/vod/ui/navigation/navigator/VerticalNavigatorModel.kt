package com.homechoice.ott.vod.ui.navigation.navigator

class VerticalNavigatorModel {
    var isActive: Boolean = false
    var currentIndex: Int = 0
    val totalSize: Int
    val callback: Callback

    constructor(currentIndex: Int, totalSize: Int, callback: Callback) {
        this.currentIndex = currentIndex
        this.totalSize = totalSize
        this.callback = callback

        // 초기 설정 콜백 호출
        callback.init(currentIndex)
    }

    fun moveUp() {
        val previousIndex = this.currentIndex

        if (currentIndex > 0) {
            this.currentIndex--
        } else {
            this.currentIndex = totalSize - 1 // 리스트의 끝으로 순환
        }

        callback.focusChanged(previousIndex, this.currentIndex)
    }

    fun moveDown() {
        val previousIndex = this.currentIndex

        if (currentIndex < totalSize - 1) {
            this.currentIndex++
        } else {
            this.currentIndex = 0 // 리스트의 시작으로 순환
        }

        callback.focusChanged(previousIndex, this.currentIndex)
    }

    interface Callback {
        fun init(index: Int)
        fun focusChanged(previousIndex: Int, index: Int)
    }
}
