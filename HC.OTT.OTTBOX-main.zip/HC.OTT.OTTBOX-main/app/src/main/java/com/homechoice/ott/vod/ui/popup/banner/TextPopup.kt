package com.homechoice.ott.vod.ui.popup.banner

import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogBannerTextBinding
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.event.Event
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.ui.popup.PopupEvent

class TextPopup : Dialog {
    private var binding: DialogBannerTextBinding

    constructor(ctx: Context, item: CategoryItem, event: PopupEvent) : super(ctx, R.style.Theme_Design_NoActionBar) {
        this.binding = DialogBannerTextBinding.inflate(LayoutInflater.from(ctx))
        val dialog = this
        setContentView(binding.root)
        if (item.linkType == "none") {
            binding.btnDetail.visibility = View.GONE
        } else {
            binding.btnDetail.setOnClickListener {
                event.onClick(dialog, BtnLabel.OK)
            }
        }
        binding.btnClose.setOnClickListener {
            dismiss()
        }
        if (item.popupTxt != "") {
            binding.text.text = item.popupTxt
        }
        show()
    }

    constructor(ctx: Context, item: Event, event: PopupEvent) : super(ctx, R.style.Theme_Design_NoActionBar) {
        this.binding = DialogBannerTextBinding.inflate(LayoutInflater.from(ctx))
        val dialog = this
        setContentView(binding.root)
        if (item.linkType == "none") {
            binding.btnDetail.visibility = View.GONE
        } else {
            binding.btnDetail.setOnClickListener {
                event.onClick(dialog, BtnLabel.OK)
            }
        }
        binding.btnClose.setOnClickListener {
            dismiss()
        }
        if (item.popupTxt != "") {
            binding.text.text = item.popupTxt
        }
        show()
    }

}