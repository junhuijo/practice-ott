package com.homechoice.ott.vod.ui.my.category

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.Category
import com.homechoice.ott.vod.agent.CustomColor
import com.homechoice.ott.vod.agent.STBAgent
import kotlinx.android.synthetic.main.my_category_list_item.view.*

class MyCategoryView(ctx: Context, parent: ViewGroup, val category: Category, var index: Int, private val actionHandler: Handler) {
    private var isBack = false
    var view: View = LayoutInflater.from(parent.context).inflate(R.layout.my_category_list_item, parent, false)

    init {
        if (category.name == "로그아웃") {
            category.name = if (STBAgent.isAuth) "로그아웃" else "로그인"
        }
        view.category_name.text = category.name
        parent.addView(view)

        view.category_list_indicator.setImageResource(category.iconResourceId)
    }

    fun update() {
        if (view.category_name.text == "로그인" || view.category_name.text == "로그아웃") {
            if (STBAgent.isAuth) {
                view.category_name.text = "로그아웃"
            } else {
                view.category_name.text = "로그인"
            }
        }
    }

    fun focus(isBack: Boolean) {
        view.main_category_layout.setBackgroundResource(R.drawable.my_category_list_item_background)
        view.category_name.requestFocus()
        if (!isBack)
            if (category.leaf) {
                actionHandler.obtainMessage(0, index, 0, this).sendToTarget()
            } else {
                actionHandler.obtainMessage(1, index, 0, this).sendToTarget()
            }
    }

    fun unfocus() {
        view.main_category_layout.setBackgroundColor(Color.TRANSPARENT)
    }

    fun select() {
//        view.category_list_indicator.visibility = View.VISIBLE
    }

    fun back() {
        // 포커스가 목록에 되 돌아 올때 onFocusChangeListener 호출 로 인해 목록을 다시 불러오는 이슈가 있음.
        view.category_name.isSelected = false
        isBack = true
    }

}