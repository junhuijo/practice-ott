package com.homechoice.ott.vod.model.request

data class RequestCardReplace(
    val terminalKey: String = "",
    val mobileNumber: String = ""
)
