package com.homechoice.ott.vod.ui.home;

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.homechoice.ott.vod.agent.CategoryTarget
import com.homechoice.ott.vod.agent.HomeScreens
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.popup.TYPE
import com.homechoice.ott.vod.ui.my.MyActivity2
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.screens.home.HomeScreen
import com.homechoice.ott.vod.ui.screens.home.HomeViewModel
import kotlin.system.exitProcess


class HomeActivity2 : AppCompatActivity() {
    private val viewModel: HomeViewModel by viewModels()
    private var target: String = "none"
    var ctx = this

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        target = intent?.getStringExtra("TARGET_INFO").toString()

        viewModel.finishApp.observe(this) {
            finishAffinity()
            exitProcess(0)
        }

        createHomeMenu()
        setContent {
            HomeScreen()
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshAdultContentState()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
//        Log.d("KeyEvent", "키 코드: ${event.keyCode}")

        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE, 97 -> {
                    if (viewModel.isCategoryDrawerVisible.value) {
                        viewModel.onKeyBackEvent(KeyEvent.KEYCODE_BACK)
                        return true
                    } else if (viewModel.uiState.value.currentScreen != HomeScreens.Main) {
                        viewModel.updateCurrentScreen(HomeScreens.Main)
                        viewModel.updateAdultContentVisibility()
                        viewModel.topFlagToggle(true)
                        viewModel.navCategoryFocusRequester.requestFocus()
                        return true
                    } else {
                        viewModel.onKeyBackEvent(KeyEvent.KEYCODE_BACK)
                    }
                }

                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
//                    Log.d("Input", "enter")
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun createHomeMenu() {}

    private fun showPopup(code: Int) {
        PopupAgent.showNormalPopup(
            ctx,
            PopupType.getErrorType(
                TYPE.DEFAULT,
                code
            ),
            object : PopupEvent {
                override fun onClick(d: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.OK -> {
                            d.dismiss()
                            finish()
                        }
                    }
                }
             }
        )
    }
}