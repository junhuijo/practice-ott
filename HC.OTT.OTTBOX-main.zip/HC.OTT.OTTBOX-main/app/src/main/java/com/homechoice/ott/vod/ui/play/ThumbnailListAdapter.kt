package com.homechoice.ott.vod.ui.play

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.internal.ViewUtils.dpToPx
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.ThumbnailListItemBinding
import com.homechoice.ott.vod.model.play.CustomThumbnail
import com.homechoice.ott.vod.model.play.Frame
import com.homechoice.ott.vod.util.Logger
import kotlin.math.floor

class ThumbnailListAdapter(var serverInfo: String, frames: List<Frame>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var controller: ThumbnailController

    private var item: List<CustomThumbnail>? = null

    init {
        controller = ThumbnailController(frames)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ThumbnailListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CellViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return if (item == null) 0 else item!!.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is CellViewHolder) {
            holder.bindViews(item!![position], position)
        }
    }

    private interface UpdateViewHolder {
        fun bindViews(data: CustomThumbnail, position: Int)
    }

    fun updateList(positionSec: Int) {
        Logger.playerLog(Log.INFO, "updateList positionSec : $positionSec")
        item = controller.getFrames(positionSec)
        notifyDataSetChanged()
    }

    inner class CellViewHolder(val binding: ThumbnailListItemBinding) : RecyclerView.ViewHolder(binding.root), UpdateViewHolder {
        override fun bindViews(data: CustomThumbnail, position: Int) {
            if (data.img != "") {
                if (position == 2) {
                    binding.thumbnailItemBg.isSelected = true
                }

                Glide.with(binding.thumbnailItem.context)
                    .load("$serverInfo${data.img}")
                    .apply(RequestOptions.bitmapTransform(RoundedCorners(16))
                        .placeholder(R.drawable.play_cut_default))
                    .into(binding.thumbnailItem)
            }
            binding.root.visibility = if (data.visible) View.VISIBLE else View.INVISIBLE
        }
    }

    inner class ThumbnailController(frames: List<Frame>) {

        var frameList = mutableMapOf<Int, CustomThumbnail>()

        init {
            for (index in frames.indices) {
                frameList[frames[index].tc] =
                    CustomThumbnail(framecnt = frames[index].framecnt, img = frames[index].img, tc = frames[index].tc, visible = true)
            }
        }

        /**
         * 현재 시간 기준의 썸네일 5장을 가져옴
         * 10초단위 처리
         * 10초 미만인 경우 예외처리
         * 현재 시간 기준 다음 썸네일이 없는 경우 예외처리
         * */
        fun getFrames(value: Int): List<CustomThumbnail> {
            val result: List<CustomThumbnail>
            var standard: Int = floor((value.toDouble() / 10)).toInt() * 10
            val total = frameList.size
            var count = 4
            result = mutableListOf(
                CustomThumbnail(0, "", 0, visible = false),
                CustomThumbnail(0, "", 0, visible = false),
                CustomThumbnail(0, "", 0, visible = false),
                CustomThumbnail(0, "", 0, visible = false),
                CustomThumbnail(0, "", 0, visible = false)
            )
            if (total > 0) {
                var i = 0
                when (standard) {
                    0 -> {
                        i = 2
                    }
                    10 -> {
                        i = 1
                        standard -= 10
                    }
                    frameList[total - 1]?.tc -> {
                        standard -= 20
                        count = 3
                    }
                    frameList[total - 2]?.tc -> {
                        standard -= 20
                        count = 2
                    }
                    else -> {
                        standard -= 20
                    }
                }
                for (index in standard..(standard + 50) step 10) {
                    frameList[index]?.let {
                        it.visible = true
                        result.add(i, it)
                    }
                    i++
                    if (i > count)
                        break
                }
            }
            return result
        }
    }

}

