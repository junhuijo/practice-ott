package com.homechoice.ott.vod.model.request

data class RequestPlayStart(
    val terminalKey: String,
    val contentId: Long,
    val offerId: Long,
    val enterPath: String
)