package com.homechoice.ott.vod.ui.navigation.navigator

class CircleLinkedList {
    var current: ListNode

    lateinit var head: ListNode

    constructor(size : Int) {
        this.current = ListNode(0)
        this.head = this.current
        list.add(current)
         for (e in 1 until size){
             append(e)
         }

    }

    var list: MutableList<ListNode> = mutableListOf()

    fun append(data: Int) {
        var listNode = ListNode(data)
        this.current.next = listNode
        listNode.previous = this.current
        listNode.next = head
        this.current = listNode
        this.head.previous = listNode

        list.add(listNode)
    }

}