package com.homechoice.ott.vod.ui.popup.component

import android.animation.ObjectAnimator
import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.dialog_login.view.login_pw_input
import java.security.Key

class PopupEditTextView :
    androidx.appcompat.widget.AppCompatEditText {

    private lateinit var container: View

    constructor(ctx: Context) : super(ctx) {
    }

    constructor(ctx: Context, attrs: AttributeSet) : super(ctx, attrs) {
    }

    fun setContainer(view: View) {
        container = view
    }

    fun move(value: Float) {
//        Logger.Log(Log.DEBUG, this, "move: $value")
        ObjectAnimator.ofFloat(container, "translationY", value).apply {
            duration = 100
            start()
        }
    }

    override fun onKeyPreIme(keyCode: Int, event: KeyEvent?): Boolean {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
//        Logger.Log(Log.DEBUG, this, "PopupEditTextView keyCode $keyCode / event : ${event?.action} / view.id ${this.id}")
        if (event?.action == KeyEvent.ACTION_DOWN) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_BUTTON_B ) {
                move(0F)
            } else if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_BUTTON_A  || keyCode == KeyEvent.KEYCODE_ENTER) {
//                    move(-50F)
            }
//                else if (imm.isAcceptingText && keyCode == KeyEvent.KEYCODE_DPAD_UP) {
////                    Logger.Log(Log.DEBUG, this, "PopupEditTextView keyCode $keyCode / event : ${event?.action} / view.id ${this.id}")
//                }
        }
        return super.onKeyPreIme(keyCode, event)
    }
}