package com.homechoice.ott.vod.ui.detail.series

import android.app.Dialog
import android.content.Context
import android.content.Intent
import com.google.android.exoplayer2.util.Log
import com.homechoice.ott.vod.agent.ActivityChangeAgent
import com.homechoice.ott.vod.agent.ActivityChangeAgent.goToKidsLockMenu
import com.homechoice.ott.vod.agent.EnterPath
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.SessionState
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.content.Content
import com.homechoice.ott.vod.model.content.Offer
import com.homechoice.ott.vod.model.play.PlayContent
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.model.response.ResponseContent
import com.homechoice.ott.vod.model.response.ResponseDrmToken
import com.homechoice.ott.vod.model.response.ResponsePlayOffset
import com.homechoice.ott.vod.model.response.ResponseSeries
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.ui.detail.series.utils.Utils
import com.homechoice.ott.vod.ui.play.PlayerActivity
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.adult.AdultPopupView
import com.homechoice.ott.vod.ui.popup.play.SeriesExitPopupView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PlayerManager(private val context: Context, private val viewModel: SeriesViewModel) {

    private var seriesId: Long = 0
    private var episodeNo: Int = 0


    fun processPlay(content: Content, skipOffset: Boolean = false) {
        val seriesId = content.seriesId
        if (seriesId == null) {
            Log.e("ProcessPlay", "Content does not have a valid seriesId")
            return
        }

        MBSAgent.getSeries(seriesId, object : Callback<ResponseSeries> {
            override fun onResponse(call: Call<ResponseSeries>, res: Response<ResponseSeries>) {
                if (!res.isSuccessful) {
                    Log.e("ProcessPlay", "Failed to fetch series data: HTTP ${res.code()}")
                    return
                }

                val response = res.body()
                if (response == null) {
                    Log.e("ProcessPlay", "No series data available: HTTP ${res.code()}")
                    return
                }

                if (response.sessionState == SessionState.FORCE_LOGOUT) {
                    UIAgent.showPopup(context, res.code(), object : RetryCallback {
                        override fun call() { }
                        override fun cancel() { }
                    })
                    return
                }

                val offer = content.offerList.getOrNull(0) ?: return
                if (!offer.isPurchase!! && offer.price != 0) {
                    // 구매가 필요한 경우에 대한 처리
                    return
                }

                fun playContent() {
                    if (skipOffset) {
                        play(content, offer, 0, offer.isPurchase!!)
                    } else {
                        requestPlayOffset(content, offer, offer.isPurchase!!)
                    }
                }

                if (isAdultContent(content.rating ?: "")) {
                    if (STBAgent.includeRrated) {
                        playContent()
                    } else {
                        goToKidsLockMenu(context)
//                        AdultPopupView(context, Login(loginqr = null), object : PopupEvent {
//                            override fun onClick(d: Dialog, btn: String) {
//                                d.dismiss()
//                                playContent()
//                            }
//                        }).show()
                    }
                } else {
                    playContent()
                }
            }

            override fun onFailure(call: Call<ResponseSeries>, t: Throwable) {
                Log.e("ProcessPlay", "Network error while fetching series data: ${t.message}")
            }
        })
    }

    private fun requestPlayOffset(content: Content, offer: Offer, isPurchase: Boolean) {
        MBSAgent.playOffset(content.id,
            object : Callback<ResponsePlayOffset> {
                override fun onFailure(call: Call<ResponsePlayOffset>, t: Throwable) {
                    UIAgent.showPopup(context, CODE.NONE, null)
                }
                override fun onResponse(call: Call<ResponsePlayOffset>, response: Response<ResponsePlayOffset>) {
                    if (response.isSuccessful && response.body() != null) {
                        val offset = response.body()?.offset ?: 0
                        if (offset > 0) {
                            PopupAgent.showContinuePopup(context, object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    when (btn) {
                                        "이어보기" -> {
                                            d.dismiss()
                                            play(content, offer, offset, isPurchase)
                                        }

                                        "처음부터 보기" -> {
                                            d.dismiss()
                                            play(content, offer, 0, isPurchase)
                                        }

                                        else -> {
                                            d.dismiss()
                                        }
                                    }
                                }
                            })
                        } else {
                            play(content, offer, 0, isPurchase)
                        }
                    } else {
                        UIAgent.showPopup(context, response.code(), object: RetryCallback {
                            override  fun call() {
                                requestPlayOffset(content, offer, isPurchase)
                            }

                            override fun cancel() {

                            }
                        })
                    }
                }
            })
    }

    private fun play(
        content: Content,
        offer: Offer,
        offset: Int,
        isPurchase: Boolean
    ) {
        val contentIdStr = Utils.parseContentId(content.movieUrl)
        MBSAgent.getDrmToken(
            MBSAgent.terminalKey,
            contentIdStr,
            object : Callback<ResponseDrmToken> {
                override fun onResponse(
                    call: Call<ResponseDrmToken>,
                    response: Response<ResponseDrmToken>
                ) {
                    val drmToken = response.body()
                    val intent = Intent(context, PlayerActivity::class.java)
                    val seriesId = content.seriesId!!
                    val enterPath = UIAgent.createEnterPath(EnterPath.UNDEFINED, seriesId)
                    val content2 = PlayContent(
                        id = content.id,
                        title = content.title ?: "",
                        movieUrl = content.movieUrl ?: "",
                        genre = content.genre ?: "",
                        thumbnailUrl = content.thumbnailUrl ?: "",
                        thumbnailServerInfo = content.thumbnailServerInfo ?: "",
                        offset = offset,
                        advUrl = content.advUrl ?: "",
                        offerId = offer.id,
                        rating = content.rating!!,
                        isPurchase = isPurchase,
                        enterPath = enterPath,
                        drmToken = drmToken?.drmToken!!
                    )
                    intent.putExtra("content", content2)

                    if (context is SeriesActivity) {
                        context.resultLauncher.launch(intent) // 변경된 부분
                    }
                }

                override fun onFailure(call: Call<ResponseDrmToken>, t: Throwable) {
                }
            })
    }

    fun getContent(seriesId: Long, episodeNo: Int, callback: Callback<ResponseContent>) {
        this.seriesId = seriesId
        this.episodeNo = episodeNo
        MBSAgent.getContent(
            seriesId = seriesId,
            transcodingType = "dash",
            episodeNo = episodeNo,
            drmType = "widevine",
            callback = callback
        )
    }

    fun nextSeriesPlay(seriesId: Long, episodeNo: Int) {
        getContent(seriesId = seriesId, episodeNo = episodeNo, callback = object : Callback<ResponseContent> {
            override fun onResponse(call: Call<ResponseContent>, res: Response<ResponseContent>) {
                if (res.isSuccessful && res.body() != null) {
                    val response = res.body()
                    if (response != null) {
                        var content = response.content
                        val offerList = content.offerList.sortedBy { it.isPurchase != true }
                        Content(
                            id = content.id,
                            contentGroupId = content.contentGroupId,
                            seriesId = content.seriesId,
                            title = content.title,
                            posterUrl = content.posterUrl,
                            synopsis = content.synopsis,
                            actor = content.actor,
                            writer = content.writer,
                            director = content.director,
                            producer = content.producer,
                            releaseYear = content.releaseYear,
                            genre = content.genre,
                            rating = content.rating,
                            episodeNo = content.episodeNo,
                            isWish = content.isWish,
                            reviewRating = content.reviewRating,
                            runTimeDisplay = content.runTimeDisplay,
                            runTime = content.runTime,
                            movieUrl = content.movieUrl,
                            thumbnailUrl = content.thumbnailUrl,
                            thumbnailServerInfo = content.thumbnailServerInfo,
                            trailerUrl = content.trailerUrl,
                            previewDurationInSec = content.previewDurationInSec,
                            isHot = content.isHot,
                            isNew = content.isNew,
                            isAdult = content.isAdult,
                            translationType = content.translationType,
                            isAudioVisual = content.isAudioVisual,
                            advUrl = content.advUrl,
                            offerList = offerList
                        ).also {
                            content = it
                            content.title?.let { it1 ->
                                content.posterUrl?.let { it2 ->
                                    SeriesExitPopupView(it1, it2, context, object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            if (btn == "다음 회 시청") {
                                                processPlay(content, skipOffset = true)
                                                d.dismiss()
                                            } else {
                                                d.dismiss()
                                            }
                                        }
                                    }).show()
                                }
                            }
                        }
                    }
                } else {
                    UIAgent.showPopup(context, res.code(), object : RetryCallback {
                        override fun call() {
                            nextSeriesPlay(seriesId, episodeNo)
                        }
                        override fun cancel() {
                        }
                    })
                }
            }
            override fun onFailure(call: Call<ResponseContent>, t: Throwable) {
                UIAgent.showPopup(context, CODE.NONE, null)
            }
        })
    }

    fun isAdultContent(rating: String): Boolean {
        return rating.contains("19")
    }

    fun playEnd() {
        val currentIndex = viewModel.currentEpisodeIndex.value
        Log.d("PlayerManager", "Current index: $currentIndex")

        val nextIndex = currentIndex + 1
        val contents = viewModel.contents.value
        Log.d("PlayerManager", "Contents size: ${contents.size}")

        if (nextIndex >= contents.size) {
            Log.d("다음화종료","다음화종료")
        } else {
            viewModel.series.value?.let { series ->
                val nextEpisodeNo = contents[nextIndex].episodeNo ?: 0
                nextSeriesPlay(
                    seriesId = series.id,
                    episodeNo = nextEpisodeNo
                )
            }
            viewModel.updateCurrentEpisodeIndex(nextIndex)
        }
    }
}