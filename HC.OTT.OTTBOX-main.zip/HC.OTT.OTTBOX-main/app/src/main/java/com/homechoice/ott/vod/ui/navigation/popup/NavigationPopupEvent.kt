package com.homechoice.ott.vod.ui.navigation.popup

interface NavigationPopupEvent {
    fun focusChange(pos: Int)
    fun unfocusChange(pos: Int)
}