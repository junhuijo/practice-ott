package com.homechoice.ott.vod.model.home

import com.homechoice.ott.vod.agent.CategoryWrapper
import com.homechoice.ott.vod.agent.HomeScreens
import com.homechoice.ott.vod.model.CategoryList

data class HomeUiState(
    val currentScreen: HomeScreens = HomeScreens.Main,
    val defaultCategoryList: List<CategoryList> = listOf(),
    val specificCategoryList: List<CategoryList> = listOf(),
    val isCategoryVisible: Boolean = false,
    val selectedCategory: CategoryWrapper? = null
//    val selectedNavIcon: Int? = null
)