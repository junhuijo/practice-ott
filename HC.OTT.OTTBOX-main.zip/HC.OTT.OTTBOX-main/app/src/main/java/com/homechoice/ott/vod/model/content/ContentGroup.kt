package com.homechoice.ott.vod.model.content

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ContentGroup(
    val id: Long,
    val title: String?,
    val isAdult: Boolean?,
    val trailerUrl: String?,
    val previewUrl: String?,
    val previewDurationInSec: Int?,
    val offerContentList: List<OfferContent>,
    val advUrl: String?

) : Parcelable