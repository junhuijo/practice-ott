package com.homechoice.ott.vod.ui.navigation.grid

import android.util.Log
import com.homechoice.ott.vod.util.Logger
import kotlin.math.ceil

class NavigationGridModel(
    var data: NavigationGridData
) {
    init {
        Logger.Log(Log.INFO, this, " ${data.toString()}")
    }

    fun addModel(addList: List<Any>) {
        for (item in addList) {
            data.list.add(item)
        }
        data.totalIndex = data.totalIndex + addList.size

        val itemCount = addList.size.toDouble()
        val defaultCount = (7).toDouble()
        val rows = if ((itemCount / defaultCount) > 1) ceil(itemCount / defaultCount) else (1).toDouble()

        data.rows += rows.toInt()

        Logger.Log(Log.INFO, this, "new data.rows ${data.rows} / rows $rows")
    }

}

