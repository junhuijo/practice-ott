package com.homechoice.ott.vod.ui.popup.point

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.PointType
import com.homechoice.ott.vod.databinding.DialogPointPurchaseBinding

import com.homechoice.ott.vod.databinding.DialogPointSaveBinding
import com.homechoice.ott.vod.model.point.PointHistory
import com.homechoice.ott.vod.util.Logger

class PointPopupView(context: Context, pointHistory: PointHistory) : Dialog(context, R.style.Theme_Design_NoActionBar) {
    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        when (val type = pointHistory.type) {
            PointType.PAYMENT_VOD -> {
                val binding = DialogPointPurchaseBinding.inflate(LayoutInflater.from(context))
                binding.apply {
                    viewModel = PointPopupViewModel(getTitle(type), getDesc(type), getLabel(type), pointHistory)
                }
                setContentView(binding.root)
            }
            else -> {
                val binding = DialogPointSaveBinding.inflate(LayoutInflater.from(context))
                binding.apply {
                    viewModel = PointPopupViewModel(getTitle(type), getDesc(type), getLabel(type), pointHistory)
                }
                setContentView(binding.root)
            }
        }

        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            Logger.Log(Log.DEBUG, this, "kCode:$kCode")
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER, 96 -> {
                        dismiss()
                        result = true
                    }
                }
            }
            result
        }
    }

    fun getTitle(type: String): String {
        return when (type) {
            PointType.PAYMENT_VOD -> "콘텐츠 구매"
            PointType.PRODUCT_MILEAGE ->
                "포인트 구매 포인트 적립"
            PointType.VOD_MILEAGE ->
                "콘텐츠 구매 포인트 적립"
            PointType.EXPIRED_POINT ->
                "포인트 유효기간 만료"
            PointType.POINT_PRODUCT ->
                "포인트 구매 내역"
            PointType.CANCEL_POINT_PRODUCT ->
                "포인트 충전 취소"
            PointType.CANCEL_VOD_MILEAGE,
            PointType.CANCEL_PRODUCT_MILEAGE ->
                "포인트 적립 취소"
            PointType.CANCEL_PAYMENT_VOD ->
                "포인트 환불"
            PointType.ISSUE ->
                "포인트 발급"
            PointType.PUBLISH ->
                "포인트 등록"
            else -> ""
        }
    }

    private fun getDesc(type: String): String {
        return when (type) {
            PointType.PRODUCT_MILEAGE,
            PointType.VOD_MILEAGE ->
                "유효기간 내 사용하지 않을 경우, 자동 소멸됩니다."
            PointType.EXPIRED_POINT ->
                "유효기간이 경과되어 포인트가 소멸되었습니다. \n소멸된 포인트는 복구되지 않습니다."
            PointType.POINT_PRODUCT ->
                "유효기간 내 사용하지 않을 경우, 자동 소멸됩니다."
            PointType.CANCEL_POINT_PRODUCT ->
                "포인트 충전이 취소되었습니다."
            PointType.CANCEL_VOD_MILEAGE ->
                "콘텐츠 구매 취소로 인해 적립된 포인트가 회수되었습니다."
            PointType.CANCEL_PRODUCT_MILEAGE ->
                "포인트 충전 취소로 인해 적립된 포인트가 회수되었습니다."
            PointType.CANCEL_PAYMENT_VOD ->
                "콘텐츠 구매 취소로 인해 포인트가 환불되었습니다."
            PointType.PUBLISH,
            PointType.ISSUE ->
                "유효기간 내 사용하지 않을 경우, 자동 소멸됩니다."
            else -> ""
        }
    }

    private fun getLabel(type: String): List<String> {
        return when (type) {
            PointType.PAYMENT_VOD -> listOf("", "", "")
            PointType.PRODUCT_MILEAGE,
            PointType.VOD_MILEAGE -> listOf("적립포인트", "잔여포인트", "유효기간")
            PointType.EXPIRED_POINT -> listOf("소멸포인트", "잔여포인트", "소멸날짜")
            PointType.POINT_PRODUCT -> listOf("구매포인트", "잔여포인트", "유효기간")
            PointType.CANCEL_POINT_PRODUCT -> listOf("충전 취소된 포인트", "잔여포인트", "취소일자")
            PointType.CANCEL_PRODUCT_MILEAGE,
            PointType.CANCEL_VOD_MILEAGE -> listOf("포인트 적립 회수", "잔여포인트", "회수일자")
            PointType.CANCEL_PAYMENT_VOD -> listOf("환불 포인트", "잔여금액", "환불날짜")
            PointType.PUBLISH,
            PointType.ISSUE -> listOf("적립포인트", "잔여포인트", "유효기간")
            else -> listOf("적립포인트", "잔여포인트", "유효기간")
        }
    }

}