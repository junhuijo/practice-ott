package com.homechoice.ott.vod.ui.qrscreen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import android.util.Log
import com.homechoice.ott.vod.model.content.Display
import com.homechoice.ott.vod.ui.screens.adultqrscan.QrScreen

class QrActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val display = intent.getParcelableExtra<Display>("display")
        val contentGroupId = intent.getLongExtra("contentGroupId", -1L)
        val enterPath = intent.getStringExtra("enterPath") ?: ""

        Log.d("QrActivity", "contentGroupId: $contentGroupId")
        Log.d("QrActivity", "enterPath: $enterPath")

        setContent {
            MaterialTheme {
                if (display != null) {
                    QrScreen(display, contentGroupId, enterPath)
                }
            }
        }
    }
}