package com.homechoice.ott.vod.agent

import com.homechoice.ott.vod.io.RetrofitClient
import com.homechoice.ott.vod.io.RetrofitService
import com.homechoice.ott.vod.model.HomeCategoryList
import com.homechoice.ott.vod.model.ResponseContentGroup
import com.homechoice.ott.vod.model.request.*
import com.homechoice.ott.vod.model.response.*
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

object MBSAgent {

    private var mbs = mbsService()

    var terminalKey: String = ""

    fun init() {
        mbs = mbsService()
    }

    private fun mbsService(): RetrofitService {
        return RetrofitClient.retrofit().create(RetrofitService::class.java)
    }

    fun error(errorBody: ResponseBody): ResponseError? {
        return RetrofitClient.retrofit()
            .responseBodyConverter<ResponseError>(
                ResponseError::class.java,
                ResponseError::class.java.annotations
            )
            .convert(errorBody)
    }

    fun getHomeCategoryList(
        needItem: Boolean,
        includeAdult: Boolean,
        includeRrated: Boolean,
        callback: Callback<HomeCategoryList>
    ) {
        val call: Call<HomeCategoryList> = mbs.homeCategoryList(
            terminalKey = terminalKey,
            includeAdult = includeAdult,
            includeRrated = includeRrated,
            needItem = needItem
        )
        call.enqueue(callback)
    }

    fun getCategoryList(
        transactionId: String,
        parentCategoryId: Int = 0,
        needItem: Boolean = true,
        includeAdult: Boolean,
        includeRrated: Boolean,
        startIdx: Int = 1,
        pageSize: Int = 0,
        callback: Callback<ResponseCategoryList>
    ): Call<ResponseCategoryList> {
        val call: Call<ResponseCategoryList> =
            mbs.getCategoryList(
                transactionId,
                terminalKey,
                parentCategoryId,
                needItem,
                includeAdult,
                includeRrated,
                startIdx,
                pageSize
            )
        call.enqueue(callback)
        return call
    }

    fun getSiblingCategoryList(
        transactionId: String,
        categoryId: Int,
        needItem: Boolean,
        startIdx: Int,
        pageSize: Int,
        callback: Callback<ResponseSiblingCategoryList>
    ): Call<ResponseSiblingCategoryList> {
        val call: Call<ResponseSiblingCategoryList> =
            mbs.getSiblingCategoryList(
                transactionId,
                terminalKey,
                categoryId,
                needItem,
                startIdx,
                pageSize
            )
        call.enqueue(callback)
        return call
    }

    fun getCategoryItemList(
        parentCategoryId: Int,
        includeAdult: Boolean,
        includeRrated: Boolean,
        needItem: Boolean = true,
        startIdx: Int = 1,
        pageSize: Int = 0,
        transactionId: String,
        callback: Callback<ResponseCategoryItemList>
    ): Call<ResponseCategoryItemList> {
        val call: Call<ResponseCategoryItemList> =
            mbs.getCategoryItemList(
                terminalKey,
                transactionId,
                parentCategoryId,
                needItem,
                includeAdult,
                includeRrated,
                startIdx,
                pageSize
            )
        call.enqueue(callback)
        return call
    }

    fun getContentGroup(
        contentGroupId: Long,
        transcodingType: String,
        drmType: String,
        callback: Callback<ResponseContentGroup>
    ) {
        val call: Call<ResponseContentGroup> = mbs.getContentGroup(
            terminalKey = terminalKey,
            contentGroupId = contentGroupId,
            transcodingType = transcodingType,
            drmType = drmType
        )
        call.enqueue(callback)
    }

    fun playOffset(contentId: Long, callback: Callback<ResponsePlayOffset>) {
        val df: DateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
        val cal = Calendar.getInstance();
        cal.time = Date();
        cal.add(Calendar.MONTH, -6);
        val startDate = cal.time
        val endDate = Date()

        val call: Call<ResponsePlayOffset> =
            mbs.playOffset(
                terminalKey = terminalKey,
                contentId = contentId,
                startDatetime = df.format(startDate),
                endDatetime = df.format(endDate)
            )
        call.enqueue(callback)
    }

    fun reviewRating(contentId: Long, reviewRating: Int, callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> =
            mbs.reviewRating(
                RequestReviewRating(
                    terminalKey = terminalKey,
                    contentId = contentId,
                    reviewRating = reviewRating
                )
            )
        call.enqueue(callback)
    }

    fun getSeries(
        seriesId: Long,
        callback: Callback<ResponseSeries>
    ) {
        val call: Call<ResponseSeries> = mbs.getSeries(
            terminalKey = terminalKey, seriesId = seriesId
        )
        call.enqueue(callback)
    }

    fun sessionAuth(
        appCode: String,
        deviceType: String,
        deviceId: String,
        callback: Callback<ResponseAuth>
    ) {
        val call: Call<ResponseAuth> = mbs.sessionAuth(RequestAuth(appCode, deviceType, deviceId))
        call.enqueue(callback)
    }

    fun login(
        memberId: String,
        memberPw: String,
        forceLogin: Boolean,
        callback: Callback<ResponseLogin>
    ) {
        val call: Call<ResponseLogin> =
            mbs.loginV2(
                RequestLogin(
                    terminalKey = terminalKey,
                    memberId = memberId,
                    forceLogin = forceLogin,
                    memberPw = memberPw
                )
            )
        call.enqueue(callback)
    }

    fun logout(callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> = mbs.logout(RequestLogout(terminalKey = terminalKey))
        call.enqueue(callback)
    }

    fun easyPayment(
        offerId: Long,
        paymentPw: String,
        price: Int,
        discountPrice: Int,
        normalPrice: Int,
        pointPrice: Int,
        targetType: String,
        targetId: Long,
        episodeNo: Int,
        contentId: Long,
        enterPath: String,
        pointPolicyId: Long,
        callback: Callback<ResponsePurchase>
    ) {
        val call: Call<ResponsePurchase> = mbs.easyPayment(
            RequestEasyPayment(
                terminalKey = terminalKey,
                offerId = offerId,
                paymentPw = paymentPw,
                price = price,
                discountPrice = discountPrice,
                normalPrice = normalPrice,
                pointPrice = pointPrice,
                targetType = targetType,
                targetId = targetId,
                episodeNo = episodeNo,
                contentId = contentId,
                enterPath = enterPath,
                pointPolicyId = pointPolicyId
            )
        )
        call.enqueue(callback)
    }

    fun getContent(
        seriesId: Long,
        episodeNo: Int,
        transcodingType: String,
        drmType: String,
        callback: Callback<ResponseContent>
    ) {
        val call: Call<ResponseContent> = mbs.getContent(
            terminalKey = terminalKey,
            seriesId = seriesId,
            episodeNo = episodeNo,
            transcodingType = transcodingType,
            drmType = drmType
        )
        call.enqueue(callback)
    }

    fun recommend(
        srcType: String,
        srcId: Long,
        includeAdult: Boolean,
        includeRrated: Boolean,
        startIdx: Int,
        pageSize: Int,
        callback: Callback<ResponseCategoryItemList>
    ) {
        val call: Call<ResponseCategoryItemList> =
            mbs.recommend(
                terminalKey = terminalKey,
                srcType = srcType,
                srcId = srcId,
                startIdx = startIdx,
                pageSize = pageSize,
                includeAdult = includeAdult,
                includeRrated = includeRrated
            )
        call.enqueue(callback)
    }

    fun navigation(
        assetType: String,
        assetId: Long,
        enterPath: String,
        callback: Callback<ResponseNoBody>
    ) {
        val call: Call<ResponseNoBody> =
            mbs.navigation(
                RequestNavigation(
                    terminalKey = terminalKey,
                    assetType = assetType,
                    assetId = assetId,
                    enterPath = enterPath
                )
            )
        call.enqueue(callback)
    }

    fun wishItem(
        contentId: Long,
        actionType: String,
        targetType: String,
        targetId: Long,
        episodeNo: Int,
        callback: Callback<ResponseNoBody>
    ) {
        val call: Call<ResponseNoBody> = mbs.wishItem(
            ResponseWishItem(
                terminalKey = terminalKey,
                contentId = contentId,
                actionType = actionType,
                targetType = targetType,
                targetId = targetId,
                episodeNo = episodeNo
            )
        )
        call.enqueue(callback)
    }

    fun wishItem(
        contentId: Long,
        actionType: String,
        targetType: String,
        targetId: Long,
        callback: Callback<ResponseNoBody>
    ) {
        val call: Call<ResponseNoBody> = mbs.wishItem(
            ResponseWishItem(
                terminalKey = terminalKey,
                contentId = contentId,
                actionType = actionType,
                targetType = targetType,
                targetId = targetId
            )
        )
        call.enqueue(callback)
    }

    fun postMemberRegister(mobileNumber: String, callback: Callback<ResponseRegister>) {
        val call: Call<ResponseRegister> =
            mbs.postMemberRegister(
                RequestMobile(
                    terminalKey = terminalKey,
                    mobileNumber = mobileNumber
                )
            )
        call.enqueue(callback)
    }

    fun postMemberTermination(callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> =
            mbs.memberTermination(RequestMemberTermination(terminalKey = terminalKey))
        call.enqueue(callback)
    }

    fun putMemberRegister(mobileNumber: String, callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> =
            mbs.putMemberRegister(
                RequestMobile(
                    terminalKey = terminalKey,
                    mobileNumber = mobileNumber
                )
            )
        call.enqueue(callback)
    }

    fun pwReplace(mobileNumber: String, type: String, callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> =
            mbs.pwReplace(
                RequestPwReplace(
                    terminalKey = terminalKey,
                    mobileNumber = mobileNumber,
                    type = type
                )
            )
        call.enqueue(callback)
    }

    fun memberAccountFind(mobileNumber: String, callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> =
            mbs.memberAccountFind(
                RequestMobile(
                    terminalKey = terminalKey,
                    mobileNumber = mobileNumber
                )
            )
        call.enqueue(callback)
    }

    fun purchaseLogList(
        startDatetime: String,
        endDatetime: String,
        isAdult: Boolean,
        groupType: String,
        startIdx: Int,
        pageSize: Int,
        callback: Callback<ResponsePurchaseLogList>
    ) {
        val call: Call<ResponsePurchaseLogList> = mbs.purchaseLogList(
            terminalKey = terminalKey,
            startDatetime = startDatetime,
            endDatetime = endDatetime,
            isAdult = isAdult,
            groupType = groupType,
            startIdx = startIdx,
            pageSize = pageSize
        )
        call.enqueue(callback)
    }

    fun purchaseLogList(
        startDatetime: String,
        endDatetime: String,
        isAdult: Boolean,
        groupTypes: ArrayList<String>,
        startIdx: Int,
        pageSize: Int,
        callback: Callback<ResponsePurchaseLogList>
    ) {
        val call: Call<ResponsePurchaseLogList> = mbs.purchaseLogList(
            terminalKey = terminalKey,
            startDatetime = startDatetime,
            endDatetime = endDatetime,
            isAdult = isAdult,
            groupTypes = groupTypes,
            startIdx = startIdx,
            pageSize = pageSize
        )
        call.enqueue(callback)
    }

    fun purchaseLog(purchaseId: Long, isVisible: Boolean, callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> = mbs.purchaseLog(
            RequestPurchaseLog(
                terminalKey = terminalKey,
                purchaseId = purchaseId,
                isVisible = isVisible
            )
        )
        call.enqueue(callback)
    }

    fun serviceLog(contentId: Long, isVisible: Boolean, callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> = mbs.serviceLog(
            RequestServiceLog(
                terminalKey = terminalKey,
                contentId = contentId,
                isVisible = isVisible
            )
        )
        call.enqueue(callback)
    }

    fun postCardReplace(mobileNumber: String, callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> =
            mbs.postCardReplace(
                RequestCardReplace(
                    terminalKey = terminalKey,
                    mobileNumber = mobileNumber
                )
            )
        call.enqueue(callback)
    }

    fun getCard(callback: Callback<ResponseCardName>) {
        val call: Call<ResponseCardName> = mbs.getCard(terminalKey = terminalKey)
        call.enqueue(callback)
    }

    fun adultPwCheck(adultPw: String, callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> =
            mbs.adultPwCheck(RequestAdultPwCheck(terminalKey = terminalKey, adultPw = adultPw))
        call.enqueue(callback)
    }

    fun adultPwModify(
        terminalKey: String,
        type: String,
        oldPw: String,
        newPw: String,
        callback: Callback<ResponseNoBody>
    ) {
        val call: Call<ResponseNoBody> =
            mbs.adultPwModify(RequestAdultPwModify(terminalKey, type, oldPw, newPw))
        call.enqueue(callback)
    }

    fun paymentCancel(
        purchaseId: Long,
        paymentPw: String,
        state: String,
        callback: Callback<ResponseNoBody>
    ) {
        val call: Call<ResponseNoBody> =
            mbs.paymentCancel(
                RequestPaymentCancel(
                    terminalKey = terminalKey,
                    purchaseId = purchaseId,
                    paymentPw = paymentPw,
                    state = state
                )
            )
        call.enqueue(callback)
    }

    fun playStart(
        contentId: Long,
        offerId: Long,
        enterPath: String,
        callback: Callback<ResponsePlayStart>
    ) {
        val call: Call<ResponsePlayStart> =
            mbs.playStart(
                RequestPlayStart(
                    terminalKey = terminalKey,
                    contentId = contentId,
                    offerId = offerId,
                    enterPath = enterPath
                )
            )
        call.enqueue(callback)
    }

    fun playStop(serviceId: Long, offset: Int, callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> =
            mbs.playStop(
                RequestPlayStop(
                    terminalKey = terminalKey,
                    serviceId = serviceId,
                    offset = offset
                )
            )
        call.enqueue(callback)
    }

    fun serviceLogList(
        isAdult: Boolean,
        startDatetime: String,
        endDatetime: String,
        startIdx: Int,
        pageSize: Int,
        callback: Callback<ResponseServiceLogList>
    ) {
        val call: Call<ResponseServiceLogList> = mbs.serviceLogList(
            terminalKey = terminalKey,
            isAdult = isAdult,
            startDatetime = startDatetime,
            endDatetime = endDatetime,
            startIdx = startIdx,
            pageSize = pageSize
        )
        call.enqueue(callback)
    }

    fun wishItemList(
        isAdult: Boolean,
        transactionId: String,
        callback: Callback<ResponseWishItemList>
    ) {
        val call: Call<ResponseWishItemList> = mbs.getWishItemList(
            terminalKey = terminalKey,
            isAdult = isAdult,
            transactionId = transactionId,
            pageSize = 0
        )
        call.enqueue(callback)
    }

    fun faqList(startIdx: Int, pageSize: Int, callback: Callback<ResponseFaqList>) {
        val call: Call<ResponseFaqList> =
            mbs.faqList(terminalKey = terminalKey, startIdx = startIdx, pageSize = pageSize)
        call.enqueue(callback)
    }

    fun pointFaqList(startIdx: Int, pageSize: Int, callback: Callback<ResponseFaqList>) {
        val call: Call<ResponseFaqList> =
            mbs.pointFaqList(terminalKey = terminalKey, startIdx = startIdx, pageSize = pageSize)
        call.enqueue(callback)
    }

    fun noticeList(startIdx: Int, pageSize: Int, callback: Callback<ResponseNoticeList>) {
        val call: Call<ResponseNoticeList> =
            mbs.noticeList(terminalKey = terminalKey, startIdx = startIdx, pageSize = pageSize)
        call.enqueue(callback)
    }

    fun offerContent(
        transactionId: String,
        offerId: Long,
        callback: Callback<ResponseOfferContent>
    ) {
        val call: Call<ResponseOfferContent> =
            mbs.offerContent(
                transactionId = transactionId,
                terminalKey = terminalKey,
                offerId = offerId
            )
        call.enqueue(callback)
    }

    fun recommendListForSearch(
        transactionId: String,
        startIdx: Int,
        pageSize: Int,
        callback: Callback<ResponseCategoryItemList>
    ) {
        val call: Call<ResponseCategoryItemList> =
            mbs.recommendListForSearch(transactionId, terminalKey, startIdx, pageSize)
        call.enqueue(callback)
    }

    fun search(
        transactionId: String,
        searchWord: String,
        includeAdult: Boolean,
        includeRrated: Boolean,
        startIdx: Int,
        pageSize: Int,
        callback: Callback<ResponseSearchList>
    ) {
        val call: Call<ResponseSearchList> =
            mbs.search(
                transactionId,
                terminalKey,
                searchWord,
                includeAdult,
                includeRrated,
                startIdx,
                pageSize
            )
        call.enqueue(callback)
    }

    fun keywordForSearch(
        transactionId: String,
        searchWord: String,
        includeAdult: Boolean,
        count: Int,
        callback: Callback<ResponseKeyWord>
    ) {
        val call: Call<ResponseKeyWord> =
            mbs.keywordForSearch(transactionId, terminalKey, searchWord, includeAdult, count)
        call.enqueue(callback)
    }

    fun eventList(
        usePushPopup: Boolean,
        startIdx: Int,
        pageSize: Int,
        transactionId: String,
        callback: Callback<ResponseEventList>
    ) {
        val call: Call<ResponseEventList> =
            mbs.eventList(
                usePushPopup = usePushPopup,
                transactionId = transactionId,
                terminalKey = terminalKey,
                startIdx = startIdx,
                pageSize = pageSize
            )
        call.enqueue(callback)
    }

    fun pointProductList(
        startIdx: Int,
        pageSize: Int,
        transactionId: String,
        callback: Callback<ResponsePointProductList>
    ) {
        val call: Call<ResponsePointProductList> =
            mbs.pointProductList(
                terminalKey = terminalKey,
                startIdx = startIdx,
                pageSize = pageSize,
                transactionId = transactionId
            )
        call.enqueue(callback)
    }

    fun purchasePointProduct(
        productId: Long,
        productTitle: String,
        price: Int,
        paymentPw: String,
        transactionId: String,
        callback: Callback<ResponsePoint>
    ) {
        val call: Call<ResponsePoint> =
            mbs.purchasePointProduct(
                RequestPurchasePointProduct(
                    terminalKey = terminalKey,
                    productId = productId,
                    productTitle = productTitle,
                    paymentPw = paymentPw,
                    price = price
                )
            )
        call.enqueue(callback)
    }

    fun pointBalance(callback: Callback<ResponsePoint>) {
        val call: Call<ResponsePoint> =
            mbs.pointBalance(
                terminalKey = terminalKey
            )
        call.enqueue(callback)
    }

    fun pointPinNo(pointPinNo: String, callback: Callback<ResponsePointPinNo>) {
        val call: Call<ResponsePointPinNo> =
            mbs.pointPinNo(RequestPointPinNo(terminalKey = terminalKey, pointPinNo = pointPinNo))
        call.enqueue(callback)
    }

    fun pointHistoryList(
        startIdx: Int,
        pageSize: Int,
        transactionId: String,
        callback: Callback<ResponsePointHistoryList>
    ) {
        val call: Call<ResponsePointHistoryList> =
            mbs.pointHistoryList(
                terminalKey = terminalKey,
                startIdx = startIdx,
                pageSize = pageSize,
                transactionId = transactionId
            )
        call.enqueue(callback)
    }

    fun pointNotiList(
        startIdx: Int,
        pageSize: Int,
        transactionId: String,
        callback: Callback<ResponsePointProductList>
    ) {
        val call: Call<ResponsePointProductList> =
            mbs.pointNotiList(
                terminalKey = terminalKey,
                startIdx = startIdx,
                pageSize = pageSize,
                transactionId = transactionId
            )
        call.enqueue(callback)
    }

    fun pointNotiConfirm(callback: Callback<ResponseNoBody>) {
        val call: Call<ResponseNoBody> =
            mbs.pointNotiConfirm(RequestPointNoticeConfirm(terminalKey = terminalKey))
        call.enqueue(callback)
    }

    fun getDrmToken(terminalKey: String, contentId: String, callback: Callback<ResponseDrmToken>) {
        val call: Call<ResponseDrmToken> = mbs.drmToken(terminalKey, contentId, "widevine")
        call.enqueue(callback)
    }

    fun getCpItemList(
        terminalKey: String,
        cpId: Int,
        includeAdult: Boolean,
        includeRrated: Boolean,
        startIdx: Int,
        pageSize: Int,
        callback: Callback<ResponseCpItemList>
    ) {
        val call: Call<ResponseCpItemList> =
            mbs.cpItemList(
                terminalKey = terminalKey,
                cpId = cpId,
                includeAdult = includeAdult,
                includeRrated = includeRrated,
                startIdx = startIdx,
                pageSize = pageSize,
            )
        call.enqueue(callback)
    }

    fun fetchAdUrl(callback: (String?) -> Unit) {
        val apiUrl = "https://triplead.homechoice.co.kr/v2/api/ad/get_advd.php"

        val request = Request.Builder()
            .url(apiUrl)
            .build()

        val client = OkHttpClient()
        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                callback(null)
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                val responseData = response.body?.string()
                if (response.isSuccessful && !responseData.isNullOrEmpty()) {
                    try {
                        val json = JSONObject(responseData)
                        val status = json.optString("status")
                        if (status == "success") {
                            val dataArray = json.optJSONArray("data")
                            if (dataArray != null && dataArray.length() > 0) {
                                val adUrl = dataArray.optJSONObject(0)?.optString("videoUrl", null)
                                callback(adUrl)
                            } else {
                                callback(null)
                            }
                        } else {
                            callback(null)
                        }
                    } catch (e: Exception) {
                        callback(null)
                    }
                } else {
                    callback(null)
                }
            }
        })
    }

    fun checkPermission(
        contentId: Long,
        offerId: Long,
        callback: Callback<CheckPermissionResponse>
    ) {
        val call: Call<CheckPermissionResponse> = mbs.checkPermission(
            terminalKey = terminalKey,
            contentId = contentId,
            offerList = offerId
        )
        call.enqueue(callback)
    }

    fun adultCheckState(
        callback: Callback<ResponseAdultCheck>
    ) {
        val call: Call<ResponseAdultCheck> = mbs.adultCheckState(
            terminalKey = terminalKey
        )
        call.enqueue(callback)
    }

    fun userInfo(
        terminalKey: String,
        callback: Callback<ResponseUserInfo>
    ) {
        val call: Call<ResponseUserInfo> = mbs.userInfo(terminalKey = terminalKey)
        call.enqueue(callback)
    }
}

//fun adultCheckState(
//    callback: Callback<ResponseAdultCheck>
//) {
//    val call: Call<ResponseAdultCheck> = mbs.adultCheckState(
//        terminalKey = terminalKey
//    )
//
//        Handler(Looper.getMainLooper()).postDelayed({
//            callback.onFailure(call, RuntimeException("Forced error for testing"))
//        }, 1000)
//    }
//}