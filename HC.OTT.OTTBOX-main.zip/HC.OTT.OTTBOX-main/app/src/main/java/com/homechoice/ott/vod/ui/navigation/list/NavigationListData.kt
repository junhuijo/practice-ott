package com.homechoice.ott.vod.ui.navigation.list

data class NavigationListData(
    var curIndex: Int = 0, // 전체 모델중 데이터 현재 인덱스
    var preIndex: Int = -1, // 전체 모델중 데이터 이전 인덱스
    var totalIndex: Int = 0, // 전체 모델 중 저장된 데이터의 마지막 인덱스
    var totalCount: Int = 0, // 전체 모델 데이터 갯수
    var visibleIndex: Int = 0, // 노출 중 현재 인덱스
    var visibleThreshold: Int = 0, // 화면에 노출 할 갯수
    var startIndex: Int = 0, // 화면에 노출중인 첫 인덱스
    var list: ArrayList<Any> = arrayListOf()
) {
    fun build(itemList: List<Any>): NavigationListData {
        val arrayList: ArrayList<Any> = arrayListOf()
        for (item in itemList) {
            arrayList.add(item)
        }
        list = arrayList
        totalCount = itemList.size
        totalIndex = itemList.size - 1
        toString()
        return this
    }

    override fun toString() =
        "cur:$curIndex / preIndex: $preIndex / totalIndex: $totalIndex / totalCount : $totalCount / startIndex:$startIndex / visibleIndex: $visibleIndex"
}