package com.homechoice.ott.vod.model.content

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class Content(
    val id: Long,
    val contentGroupId: Long?,
    val seriesId: Long?,
    val title: String?,
    val posterUrl: String?,
    val synopsis: String?,
    val actor: String?,
    val writer: String?,
    val director: String?,
    val producer: String?,
    val releaseYear: String?,
    val genre: String?,
    val rating: String?,
    val episodeNo: Int?,
    var isWish: Boolean?,
    val reviewRating: Int?,
    val runTimeDisplay: String?,
    val runTime: String?,
    val movieUrl: String?,
    val thumbnailUrl: String?,
    val thumbnailServerInfo: String?,
    val trailerUrl: String?,
    val previewDurationInSec: Int?,
    val isHot: Boolean?,
    val isNew: Boolean?,
    val isAdult: Boolean?,
    val translationType: String?,
    val isAudioVisual: Boolean?,
    val advUrl: String?,
    val offerList: List<Offer>
) : Parcelable
