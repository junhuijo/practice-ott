package com.homechoice.ott.vod.ui.navigation.list

import androidx.fragment.app.Fragment

abstract class NavigationListView : Fragment() {

    var isActive = false

    lateinit var controller: NavigationListController

    fun setModel(navigationData: NavigationListData, event: NavigationListEvent) {
        controller = NavigationListController(
            navigationData,
            event
        )
    }

    fun setData(newData: NavigationListData) {
        controller.setNavigationData(newData)
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    abstract fun onKeyDown(keyCode: Int): Boolean
    abstract fun active()
    abstract fun lateActive()
    abstract fun setVisible(visible: Int)
}