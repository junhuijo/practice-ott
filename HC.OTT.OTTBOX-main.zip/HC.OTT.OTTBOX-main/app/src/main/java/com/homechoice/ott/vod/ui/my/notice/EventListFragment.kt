package com.homechoice.ott.vod.ui.my.notice

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentEventListBinding
import com.homechoice.ott.vod.event.MBSCallback
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.event.Event
import com.homechoice.ott.vod.model.response.ResponseEventList
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.ui.navigation.list.NavigationListData
import com.homechoice.ott.vod.ui.navigation.list.NavigationListEvent
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.banner.ImagePopup
import com.homechoice.ott.vod.ui.popup.banner.ImageWithTextPopup
import com.homechoice.ott.vod.ui.popup.banner.TextPopup
import com.homechoice.ott.vod.ui.popup.event.EventPopupView
import com.homechoice.ott.vod.ui.sub.SubCategoryActivity
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_event_list.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class EventListFragment(private val activityHandler: Handler, val categoryTarget: String) : NavigationListView() {

    private lateinit var adapter: EventListAdapter
    private lateinit var viewHolder: EventListAdapter.ViewHolder
    private lateinit var bind: FragmentEventListBinding
    private var logList: ArrayList<Event> = arrayListOf()

    var head = UIAgent.createLoginHead(categoryTarget)
    var isAdult: Boolean = categoryTarget == CategoryTarget.FAV_ADULT
    var description: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_event_list, container, false)
        bind.frg = this
        bind.lifecycleOwner = this

        description = "\n홈초이스의 다양한 신작 소식과 진행 중인 이벤트에 참여해 보세요."
        requestEventList()
        return bind.root
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume")
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "ServiceLogListFragment onKeyDown keyCode $keyCode")
        if (!::viewHolder.isInitialized) {
            return false
        }
        if (!STBAgent.enableKeyInput(150L)) {
            return true
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {

                controller.decrease()
                true

            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {

                controller.increase()
                true

            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {

                adapter.unfocus(controller.getCurIndex())
                activityHandler.obtainMessage(2).sendToTarget()
                true

            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                context?.let {
                    val log = logList[controller.getCurIndex()]
                    if (log.isPushPopup == true) {
                        EventPopupView(
                            imgUrl = log.popupImgUrl,
                            description = log.popupTxt,
                            isPush = false,
                            useLinkDetail = !(log.linkInfo.isNullOrEmpty() || log.linkType.isNullOrEmpty()),
                            context = it, event = object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    if (btn == BtnLabel.DETAIL) {
                                        goToLink(log, it)
                                    } else if (btn == BtnLabel.CLOSE) {
                                        d.dismiss()
                                    }
                                }

                            })

                    } else {
                        showBanner(log, it)
                    }
                }
                true
            }

            KeyEvent.KEYCODE_BACK, 97 -> {

                adapter.unfocus(controller.getCurIndex())
                activityHandler.obtainMessage(2).sendToTarget()

                true
            }
            else -> false
        }
    }

    private fun showBanner(item: Event, context: Context) {
        when (item.popupType) {
            "img" -> {
                ImagePopup(context, item, object : PopupEvent {
                    override fun onClick(d: Dialog, btn: String) {
                        goToLink(item, context)
                        d.dismiss()
                    }
                })
            }
            "img_txt" -> {

                ImageWithTextPopup(context, item, object : PopupEvent {
                    override fun onClick(d: Dialog, btn: String) {
                        Logger.Log(Log.DEBUG, this, "item.linkType : ${item.linkType} / id : ${item.id}")
                        goToLink(item, context)
                        d.dismiss()
                    }
                })

            }
            "txt" -> {
                TextPopup(context, item, object : PopupEvent {
                    override fun onClick(d: Dialog, btn: String) {
                        goToLink(item, context)
                        d.dismiss()
                    }
                })
            }
            else -> {
                goToLink(item, context)
            }
        }
    }

    private fun goToLink(item: Event, context: Context) {
        val enterPath = UIAgent.createEnterPath(EnterPath.EVENT, item.id)
        when (item.linkType) {
            CategoryItemType.CATEGORY -> showSubCategoryList(item.linkInfo?.toInt()!!, SubCategoryActivity.ActionType.CONTENTS_FOCUS, context)
            CategoryItemType.CONTENTGROUP -> item.linkInfo?.let { goToContent(it.toLong(), enterPath, context) }
            CategoryItemType.SERIES -> item.linkInfo?.let { goToSeriesContent(it.toLong(), enterPath, context) }
            CategoryItemType.PACKAGE_OFFER -> item.linkInfo?.let {
                ActivityChangeAgent.goToPackage(
                    context,
                    UUID.randomUUID().toString(),
                    item.linkInfo?.toLong()!!,
                    EnterPath.EVENT,
                    null
                )
            }
        }
    }

    private fun showSubCategoryList(id: Int, focusType: Int, context: Context) {
        ActivityChangeAgent.goToSubCategoryList(context, id, focusType)
    }

    private fun goToContent(id: Long, enterPath: String, context: Context) {
        ActivityChangeAgent.goToContent(context, id, enterPath, object : MBSCallback {
            override fun success() {
                viewHolder.unSelect()
                focus()
            }

            override fun error(responseCode: Int) {
            }

            override fun failure(responseCode: Int) {
            }
        })
    }

    private fun goToSeriesContent(id: Long, enterPath: String, context: Context) {
        ActivityChangeAgent.goToSeriesContent(id, 0, context, enterPath, object : MBSCallback {
            override fun success() {
                viewHolder.unSelect()
                focus()
            }

            override fun error(responseCode: Int) {
            }

            override fun failure(responseCode: Int) {
            }
        })
    }

    override fun active() {
        focus()
    }

    private fun requestEventList() {
        GlobalScope.launch(Dispatchers.Main) {
            /**
             * 409 return api
             * */
            MBSAgent.eventList(usePushPopup = false,
                startIdx = 1,
                pageSize = 0,
                transactionId = UUID.randomUUID().toString(),
                callback = object : Callback<ResponseEventList> {
                    override fun onFailure(call: Call<ResponseEventList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
                    }

                    override fun onResponse(call: Call<ResponseEventList>, res: Response<ResponseEventList>) {
                        if (res.isSuccessful && res.body() != null) {
                            val response = res.body()
                            if (response != null) {
                                val eventItemList = response.eventList
                                val totalCount = response.totalCount

                                if (totalCount > 0) {
                                    val actionHandler = Handler {
                                        Logger.Log(Log.DEBUG, this, "actionHandler ${it.what}")
                                        when (it.what) {
                                            0 -> {
                                                viewHolder = it.obj as EventListAdapter.ViewHolder
                                            }
                                        }
                                        true
                                    }

                                    logList.clear()
                                    for (item in eventItemList) {
                                        logList.add(item)
                                    }
                                    adapter = EventListAdapter(bind.logList!!, logList, actionHandler)

                                    setModel(
                                        NavigationListData(
                                            curIndex = 0,
                                            visibleThreshold = 4
                                        ).build(eventItemList), object : NavigationListEvent {
                                            override fun focusChange() {
                                                Logger.Log(Log.DEBUG, this, "focusChange")
                                                adapter.focus(controller.getCurIndex(), controller.getPreIndex())
                                                checkArrow()
                                            }

                                            override fun plusLineChange() {
                                                Logger.Log(Log.DEBUG, this, "plusLineChange")
                                                log_list_scroll_view.smoothScrollBy(0, CMBApp.getPixelSize(R.dimen.event_log_height))
                                            }

                                            override fun minusLineChange() {
                                                Logger.Log(Log.DEBUG, this, "minusLineChange")
                                                log_list_scroll_view.smoothScrollBy(0, -CMBApp.getPixelSize(R.dimen.event_log_height))
                                            }
                                        })

                                    if (log_list_layout != null)
                                        log_list_layout.visibility = View.VISIBLE
                                    checkArrow()
                                    activityHandler.obtainMessage(11).sendToTarget()
                                    if (isLateActive) {
                                        active()
                                    }
                                } else {
                                    login_line?.visibility = View.VISIBLE
                                    log_list_empty_layout?.visibility = View.VISIBLE
                                    activityHandler.obtainMessage(2).sendToTarget()
                                }
                            } else {
                                login_line?.visibility = View.VISIBLE
                                log_list_empty_layout?.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()

                            }
                        } else {
                            UIAgent.showPopupForMyMenu(context!!, res.code(), object : RetryCallback {
                                override fun call() {
                                    activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                    activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                }

                                override fun cancel() {
                                    activityHandler.obtainMessage(12).sendToTarget()
                                }
                            })
                        }
                    }
                })
        }
    }

    private fun checkArrow() {
        if (controller.getTotalCount() > controller.getVisibleThreshold()) {
            if (controller.isLastItem()) {
                if (table_arrow != null)
                    table_arrow.visibility = View.INVISIBLE

            } else {
                if (table_arrow != null)
                    table_arrow.visibility = View.VISIBLE
            }
        }
    }

    private fun isEnable(): Boolean {
        return bind.logListLayout.isVisible
    }

    fun focus() {
        if (isEnable()) {
            adapter.focus(controller.getCurIndex(), controller.getPreIndex())
        } else {
            activityHandler.obtainMessage(2).sendToTarget()
        }
    }

    var isLateActive: Boolean = false

    override fun lateActive() {
        isLateActive = true
    }

    override fun setVisible(visible: Int) {
        bind.root.visibility = visible
    }
}