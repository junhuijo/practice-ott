package com.homechoice.ott.vod.ui.navigation.grid

import kotlin.math.ceil

data class NavigationGridData(
    var curIndex: Int = 0, // 전체 모델중 데이터 현재 인덱스
    var preIndex: Int = -1, // 전체 모델중 데이터 이전 인덱스
    var totalIndex: Int = 0, // 전체 모델 중 설정된 데이터의 마지막 인덱스
    var totalCount: Int = 0, // 전체 모델 데이터 갯수
    var leftFixedIndex: Int = 0, // 이전 고정 인덱스
    var rightFixedIndex: Int = 0, // 다음 고정 인덱스
    var visibleThreshold: Int = 0, // 노출 인덱스
    var visibleIndex: Int = 0, // 노출 중 현재 인덱스
    var rows: Int = 0, // 현재까지 가져온 ROW 갯수
    var totalRows: Int = 0, // 전체 ROW 갯수
    var colCount: Int = 0, // 한 라인 중 노출 아이템 갯수
    var startIndex: Int = 0, // MBS 요청 시 시작 인덱스
    var pageSize: Int = 0, // MBS 요청 시 갯수,
    var isLoaded: Boolean = false,
    var list: ArrayList<Any> = arrayListOf()
) {
    fun build(itemList: List<Any>): NavigationGridData {
        val arrayList: ArrayList<Any> = arrayListOf()
        for (item in itemList) {
            arrayList.add(item)
        }
        list = arrayList
        totalCount = itemList.size
        totalIndex = totalCount - 1 // 인덱스는 0부터 시작하므로
        rows = getRows(itemList.size.toDouble())
        totalRows = getRows(totalCount.toDouble())
        return this
    }

    private fun getRows(itemCount: Double): Int {
        val rows =
            if ((itemCount / colCount.toDouble()) > 1) ceil(itemCount / colCount.toDouble()) else (1).toDouble()
        return rows.toInt()
    }

    fun getCurRows(): Int {
        val rows =
            if (((curIndex + 1).toDouble() / colCount.toDouble()) > 1) ceil((curIndex + 1).toDouble() / colCount.toDouble()) else (1).toDouble()
        return rows.toInt()
    }

    fun getCurRows(index: Int): Int {
        val rows =
            if (((index + 1).toDouble() / colCount.toDouble()) > 1) ceil((index + 1).toDouble() / colCount.toDouble()) else (1).toDouble()
        return rows.toInt()
    }

    fun getPreRows(): Int {
        val rows =
            if (((preIndex + 1).toDouble() / colCount.toDouble()) > 1) ceil((preIndex + 1).toDouble() / colCount.toDouble()) else (1).toDouble()
        return rows.toInt()
    }

    override fun toString() =
        "cur:$curIndex / pre:$preIndex / totalIndex:$totalIndex / totalCount:$totalCount / left:$leftFixedIndex / right$rightFixedIndex / threshold:$visibleThreshold" +
                " / visible:$visibleIndex / rows:$rows / totalRows:$totalRows / colCount:$colCount / start:$startIndex / page:$pageSize / getCurRows:${getCurRows()} / getPreRows:${getPreRows()}"
}