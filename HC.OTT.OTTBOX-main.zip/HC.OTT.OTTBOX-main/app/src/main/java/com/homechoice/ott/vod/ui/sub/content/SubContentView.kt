package com.homechoice.ott.vod.ui.sub.content

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.LinearLayout
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.ImageAgent

@SuppressLint("ViewConstructor")
class SubContentView : LinearLayout {

    private var posterView: ImageView

    constructor(ctx: Context, posterUrl: String, categoryId: Long) : super(ctx) {
        val view = LayoutInflater.from(ctx).inflate(R.layout.sub_content_list_item, this, false)
        posterView = view.findViewById(R.id.sub_content_list_poster)
        if (posterUrl != "")
            ImageAgent.load(ctx, categoryId, posterUrl, posterView)
        addView(view)
    }

    constructor(ctx: Context, posterUrl: String) : super(ctx) {
        val view = LayoutInflater.from(ctx).inflate(R.layout.sub_content_list_item, this, false)
        posterView = view.findViewById(R.id.sub_content_list_poster)
        if (posterUrl != "")
            Glide.with(ctx).load(posterUrl).thumbnail(0.3F)
                .override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height))
                .placeholder(R.drawable.main_poster_1_d)
                .into(view.findViewById(R.id.sub_content_list_poster))
        addView(view)
    }

    fun focus() {
        val anim: Animation
        val animRes: Int = R.anim.anim_sub_content_scale_up
        anim = AnimationUtils.loadAnimation(CMBApp.CTX, animRes).also { it.fillAfter = true }
        posterView.startAnimation(anim)
    }

    fun unfocus() {
        val anim: Animation
        val animRes: Int = R.anim.anim_sub_content_scale_down
        anim = AnimationUtils.loadAnimation(CMBApp.CTX, animRes).also { it.fillAfter = true }
        posterView.startAnimation(anim)
    }
}