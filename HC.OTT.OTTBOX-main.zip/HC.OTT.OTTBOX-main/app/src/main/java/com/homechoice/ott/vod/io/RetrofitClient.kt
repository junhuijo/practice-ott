package com.homechoice.ott.vod.io;

import android.content.Context
import android.util.Log
import com.homechoice.ott.vod.model.purchaseLog.ResponsePurchaseLogListAdapter
import com.homechoice.ott.vod.util.Logger
import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory
import com.squareup.moshi.Moshi
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.IOException
import java.io.InputStream
import java.lang.reflect.Type
import java.security.*
import java.security.cert.Certificate
import java.security.cert.CertificateException
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import javax.net.ssl.*


object RetrofitClient {
//    var BASE_URL = "http://172.17.12.103:9001/"
      var BASE_URL = "https://prod-mbs.ochoice.co.kr/"
//      var BASE_URL = "https://dev-mbs.ochoice.co.kr/"
    var client: OkHttpClient? = null

    fun init(url: String) {
        BASE_URL = url

        Logger.Log(Log.ERROR, this, "RetrofitClient BASE_URL: $BASE_URL / Logger.isLogMode() ${Logger.isLogMode()}")

        val loggingInterceptor: HttpLoggingInterceptor

        if (Logger.isLogMode()) {
            loggingInterceptor = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
        } else {
            loggingInterceptor = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.NONE
            }
        }

        client = getUnsafeOkHttpClient()?.addInterceptor(loggingInterceptor)?.addInterceptor { chain ->
            val request: Request = chain.request().newBuilder().addHeader("Content-Type", "application/json").build()
            chain.proceed(request)
        }?.hostnameVerifier(NullHostNameVerifier())?.build()
    }

    private fun withNullSerialization(): Moshi {
        return Moshi.Builder().add { _: Type?, annotations: Set<Annotation>, _: Moshi? ->
            for (annotation in annotations) {
                Logger.Log(Log.INFO, this, "annotation $annotation")
            }
            null
        }.add(ResponsePurchaseLogListAdapter()).build()
    }

    fun retrofit(): Retrofit = Retrofit.Builder()
        .client(client)
        .baseUrl(BASE_URL)
        .addConverterFactory(MoshiConverterFactory.create(withNullSerialization()))
        .addCallAdapterFactory(CoroutineCallAdapterFactory())
        .build()

    fun retrofitHttps(context: Context, rawId: Int): Retrofit = Retrofit.Builder()
        .client(
            OkHttpClient.Builder().sslSocketFactory(getPinnedCertSslSocketFactory(context, rawId)!!,
                getTrustManager()
            )
                .hostnameVerifier(NullHostNameVerifier())
                .addInterceptor { chain ->
                    val request: Request = chain.request().newBuilder().addHeader("Accept", "application/json").build()
                    chain.proceed(request)
                }.build()
        )
        .baseUrl(BASE_URL)
        .addConverterFactory(MoshiConverterFactory.create())
        .addCallAdapterFactory(CoroutineCallAdapterFactory())
        .build()

    private fun getTrustManager(): X509TrustManager {
        return object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {
                // 클라이언트 인증서 확인 로직
            }

            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
                // 모든 서버 인증서를 허용
            }

            override fun getAcceptedIssuers(): Array<X509Certificate> {
                // 수락된 발행자 인증서 반환
                return emptyArray()
            }
        }
    }

    private fun getPinnedCertSslSocketFactory(context: Context, rawId: Int): SSLSocketFactory? {

        try {
            val cf: CertificateFactory = CertificateFactory.getInstance("X.509")
            val caInput: InputStream = context.resources.openRawResource(rawId)
            var ca: Certificate? = null
            try {
                ca = cf.generateCertificate(caInput)

                Logger.Log(Log.INFO, this, "subjectDN ${(ca as X509Certificate).subjectDN}")
            } catch (e: CertificateException) {
                e.printStackTrace()
            } finally {
                caInput.close()
            }
            val keyStoreType: String = KeyStore.getDefaultType()
            val keyStore: KeyStore = KeyStore.getInstance(keyStoreType)
            keyStore.load(null, null)
            if (ca == null) {
                return null
            }
            keyStore.setCertificateEntry("ca", ca)
            val tmfAlgorithm: String = TrustManagerFactory.getDefaultAlgorithm()
            val tmf: TrustManagerFactory = TrustManagerFactory.getInstance(tmfAlgorithm)
            tmf.init(keyStore)
            val sslContext: SSLContext = SSLContext.getInstance("TLS")
            sslContext.init(null, tmf.trustManagers, null)
            return sslContext.socketFactory
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        } catch (e: KeyStoreException) {
            e.printStackTrace()
        } catch (e: KeyManagementException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private fun getUnsafeOkHttpClient(): OkHttpClient.Builder? {
        return try {
            // Create a trust manager that does not validate certificate chains
            val trustAllCerts: Array<TrustManager> = arrayOf<TrustManager>(
                object : X509TrustManager {
                    @Throws(CertificateException::class)
                    override fun checkClientTrusted(chain: Array<X509Certificate?>?, authType: String?) {
                    }

                    @Throws(CertificateException::class)
                    override fun checkServerTrusted(chain: Array<X509Certificate?>?, authType: String?) {
                    }

                    override fun getAcceptedIssuers(): Array<X509Certificate> {
                        return arrayOf()
                    }
                }
            )

            // Install the all-trusting trust manager
            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, SecureRandom())

            // Create an ssl socket factory with our all-trusting manager
            val sslSocketFactory = sslContext.socketFactory
            val builder = OkHttpClient.Builder()
            builder.sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
            builder.hostnameVerifier { _, _ -> true }
            builder
        } catch (e: java.lang.Exception) {
            throw RuntimeException(e)
        }
    }
}

class NullHostNameVerifier : HostnameVerifier {
    override fun verify(hostname: String?, session: SSLSession?): Boolean {
        return true
    }
}
