package com.homechoice.ott.vod.model.purchaseLog

import com.homechoice.ott.vod.model.response.ResponsePurchaseLogList
import com.squareup.moshi.FromJson
import com.squareup.moshi.JsonReader

class ResponsePurchaseLogListAdapter {
    @FromJson
    fun fromJson(reader: JsonReader): ResponsePurchaseLogList {
        var transactionId = ""
        var errorString = ""
        var totalCount = 0
        var purchaseLogList: List<PurchaseLog> = arrayListOf()
        reader.beginObject()
        while (reader.hasNext()) {
            val name = reader.nextName()
            if (name == "transactionId") {
                transactionId = reader.nextString()
            } else if (name == "errorString") {
                errorString = reader.nextString()
            } else if (name == "purchaseLogList") {
                purchaseLogList = readPurchaseLog(reader)
            } else if (name == "totalCount") {
                totalCount = reader.nextInt()
            } else {
                reader.skipValue()
            }
        }
        reader.endObject()

        return ResponsePurchaseLogList(
            transactionId = transactionId,
            errorString = errorString,
            totalCount = totalCount,
            purchaseLogList = purchaseLogList
        )
    }

    private fun readPurchaseLog(reader: JsonReader): List<PurchaseLog> {
        val purchaseLogList: ArrayList<PurchaseLog> = arrayListOf()
        reader.beginArray()
        while (reader.hasNext()) {
            reader.beginObject()
            val log = PurchaseLog()
            while (reader.hasNext()) {
                when (reader.nextName()) {
                    "purchaseId" -> log.purchaseId = reader.nextLong()
                    "title" -> log.title = reader.nextString()
                    "viewablePeriod" -> log.viewablePeriod = reader.nextString()
                    "packageType" -> log.packageType = reader.nextString()
                    "productType" -> log.productType = reader.nextString()
                    "paymentType" -> log.paymentType = reader.nextString()
                    "price" -> log.price = reader.nextInt()
                    "purchasedDatetime" -> log.purchasedDatetime = reader.nextString()
                    "targetType" -> log.targetType = reader.nextString()
                    "targetId" -> log.targetId = reader.nextLong()
                    "episodeNo" -> {
                        if (reader.peek() == JsonReader.Token.NULL) {
                            reader.nextNull<Long>()
                        } else {
                            log.episodeNo = reader.nextLong()
                        }
                    }
                    else -> reader.skipValue()
                }
            }
            reader.endObject()
            purchaseLogList.add(log)
        }
        reader.endArray()
        return purchaseLogList
    }
}