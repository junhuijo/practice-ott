package com.homechoice.ott.vod.ui.navigation.navigator

open class PageNavigatorModel {
    var isActive : Boolean = false
    var currentIndex: Int = 0
        get() = field
    var pageStartIndex: Int
    val totalSize: Int
    val pageSize : Int
    val callback: Callback

    constructor(currentIndex: Int, pageStartIndex: Int, totalSize: Int, pageSize : Int, callback: Callback) {
        this.currentIndex = currentIndex
        this.pageStartIndex = pageStartIndex
        this.totalSize = totalSize
        this.pageSize = pageSize
        this.callback = callback
        callback.init(currentIndex)
    }

    open fun left(){
        val previousIndex = this.currentIndex

        if(currentIndex > 0) {
            this.currentIndex--
            if(currentIndex < pageStartIndex){
                pageStartIndex -= pageSize
            }
        }else{
            this.currentIndex = totalSize - 1
            this.pageStartIndex = totalSize -1 - (pageSize-1)
        }

        callback.focusChanged(previousIndex , this.currentIndex , this.pageStartIndex)
    }

    open fun right(){
        val previousIndex = this.currentIndex

        if(currentIndex < totalSize-1) {
            this.currentIndex++
            if( this.currentIndex > pageStartIndex + (pageSize -1) ){
                this.pageStartIndex += pageSize
            }
        }else{
            this.currentIndex = 0
            this.pageStartIndex = 0
        }

        callback.focusChanged(previousIndex , this.currentIndex , this.pageStartIndex)
    }

    interface Callback{
        fun init(index: Int)
        fun pageStartIndexChanged()
        fun focusChanged(previousIndex: Int , index : Int , pageStartIndex : Int)
    }
}