package com.homechoice.ott.vod.ui.popup.ad

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.DialogFragment
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.Constant
import com.homechoice.ott.vod.databinding.DialogAdDetailBinding
import com.homechoice.ott.vod.model.popup.AdDetail

class AdDetailView(private var adDetail: AdDetail) : DialogFragment() {
    private var binding: DialogAdDetailBinding? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val inflater = LayoutInflater.from(requireContext())
        binding = DataBindingUtil.inflate(inflater, R.layout.dialog_ad_detail,null,false)

        binding?.viewModel = AdDetailViewModel()
        binding?.adPopupTitle?.text = adDetail.adTitle
        binding?.adPopupText?.text = adDetail.adText
        binding?.btnCancel?.setOnClickListener {
            dismiss()
        }
        val dialog = Dialog(requireContext())
        dialog.setContentView(binding!!.root)
        dialog.window?.setLayout(
            resources.getDimension(R.dimen.ad_popup_width).toInt(),
            resources.getDimension(R.dimen.ad_popup_height).toInt())
        return dialog
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }

}