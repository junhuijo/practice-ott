package com.homechoice.ott.vod.ui.popup.purchase

import android.content.Context
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.homechoice.ott.vod.databinding.ItemPopupPointProductListBinding
import com.homechoice.ott.vod.model.point.PointProduct
import com.homechoice.ott.vod.ui.popup.purchase.PurchasePopupView.ActionType.DROP_BTN_FOCUS
import com.homechoice.ott.vod.ui.popup.purchase.PurchasePopupView.ActionType.DROP_BTN_SELECT
import com.homechoice.ott.vod.util.Logger

class PurchasePointProductListAdapter(private var items: List<PointProduct>, private val actionHandler: Handler) :
    RecyclerView.Adapter<PurchasePointProductListAdapter.ViewHolder>() {

    private var viewHolderList: ArrayList<ViewHolder> = arrayListOf()

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        viewHolderList.add(position, holder)
        holder.bindViews(items[position], position)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPopupPointProductListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        binding.itemWishListLayout.setOnKeyListener { v, keyCode, event ->
            var result = false
            if (event.action == KeyEvent.ACTION_DOWN) {
                Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode / ${v.tag as Int}")
                val index = v.tag as Int
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        if (index == 0) {
                            // 버튼 포커스 이등 필요
                            actionHandler.obtainMessage(DROP_BTN_FOCUS).sendToTarget()
                            result = true
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        result = (index >= itemCount - 1)
                    }
                    KeyEvent.KEYCODE_ENTER, 96,
                    KeyEvent.KEYCODE_DPAD_CENTER -> {
                        actionHandler.obtainMessage(DROP_BTN_SELECT, items[index]).sendToTarget()
                        result = true
                    }
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        actionHandler.obtainMessage(DROP_BTN_FOCUS).sendToTarget()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT,
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        result = true
                    }
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        actionHandler.obtainMessage(DROP_BTN_FOCUS).sendToTarget()
                        result = true
                    }
                }
            }

            Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode / result $result / itemCount $itemCount")
            result
        }
        return ViewHolder(binding, parent.context)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    private interface UpdateViewHolder {
        fun bindViews(data: PointProduct, position: Int)
    }

    fun init() {
        viewHolderList[0].binding.itemWishListLayout.requestFocus()
    }

    class ViewHolder(val binding: ItemPopupPointProductListBinding, val ctx: Context) : RecyclerView.ViewHolder(binding.root), UpdateViewHolder {
        override fun bindViews(data: PointProduct, position: Int) {
            Logger.Log(Log.DEBUG, this, "data ${data.displayPriceStr}")
            binding.apply {
                item = PurchasePopupPointItemModel(data.build())
            }
            binding.root.tag = position
            binding.executePendingBindings()

//            if (data.posterUrl != "")
//                Glide.with(ctx).load(data.posterUrl).placeholder(R.drawable.poster).into(binding.contentPoster)
//
//            binding.rating.setImageResource(UIAgent.getRatingImageResource(data.rating!!))
//            binding.contentPoster.tag = data
//            binding.contentPoster.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
//                var animationId = R.anim.anim_package_scale_down
//                if (hasFocus)
//                    animationId = R.anim.anim_package_scale_up
//
//                AnimationUtils.loadAnimation(ctx, animationId).also {
//                    it.fillAfter = true
//                    v.startAnimation(it)
//                }
//            }
        }
    }

}