package com.homechoice.ott.vod.ui.screens.adultqrscan

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.model.content.Display
import com.homechoice.ott.vod.util.AdultQrScanner
import kotlinx.coroutines.delay


@Composable
fun QrScreen(
    display: Display,
    contentGroupId: Long,
    enterPath: String
) {
    val viewModel: QrViewModel = viewModel()
    val focusRequester = remember { FocusRequester() }
    val qrCodeBitmap = remember { AdultQrScanner.generateQRCode("https://ochoice.page.link/KjC6") }

    LaunchedEffect(Unit) {
        delay(500)
        focusRequester.requestFocus()
        delay(200)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(60.dp)
    ) {
        QrScreenHeader()
        ProductInfo(display)
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 30.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            QrCodeImage(qrCodeBitmap)
            Column(
                modifier = Modifier
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Instructions()
                CompleteButton(contentGroupId, viewModel, enterPath, focusRequester)
            }
        }
    }
}

@Composable
fun QrCodeImage(bitmap: Bitmap?){
    Column {
        Text(
            text = "모바일앱으로 이동하기",
            modifier = Modifier.padding(top = 8.dp, bottom = 14.dp),
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        bitmap?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = "QR 코드",
                modifier = Modifier
                    .size(200.dp)
                    .background(Color.White)
            )
        }
    }
}

@Composable
fun Instructions() {
    val instructions = listOf(
        "TV에서는 콘텐츠 구매가 어렵습니다.",
        "오초이스 모바일에서 구매 후 TV에서 시청해주세요.",
        "모바일 앱 > {VOD} 메뉴 > {19+} > 콘텐츠 결제"
    )

    Column {
        instructions.forEachIndexed { index, instruction ->
            val parts = instruction.split("{", "}")

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        top = when (index) {
                            0 -> 24.dp
                            2 -> 22.dp
                            else -> 4.dp
                        }
                    ),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                parts.forEachIndexed { partIndex, part ->
                    when {
                        part == "VOD" -> Image(
                            painter = painterResource(id = R.drawable.icon_adult_vod),
                            contentDescription = "VOD 아이콘",
                            modifier = Modifier
                                .height(26.dp)
                                .align(Alignment.Bottom)
                                .padding(bottom = 2.dp)
                        )
                        part == "19+" -> Image(
                            painter = painterResource(id = R.drawable.icon_adult_19plus),
                            contentDescription = "19+ 아이콘",
                            modifier = Modifier
                                .height(28.dp)
                                .align(Alignment.Bottom)
                                .padding(bottom = 2.dp)
                        )
                        else -> Text(
                            text = part,
                            color = Color.White,
                            fontSize = 20.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CompleteButton(
    contentGroupId: Long,
    viewModel: QrViewModel,
    enterPath: String,
    focusRequester: FocusRequester
)
{
    val context = LocalContext.current
    val interactionSource = remember { MutableInteractionSource() }
    var containerColor by remember {mutableStateOf(Color.Black)  }

    Button(
        onClick = {
                viewModel.initializeAuthentication(context, contentGroupId, enterPath)
        },
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = Color.White
        ),
        interactionSource = interactionSource,
        border = BorderStroke(1.dp, Color.White),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .height(52.dp)
            .width(226.dp)
            .focusRequester(focusRequester)
            .onFocusChanged { focusState ->
                containerColor = if (focusState.isFocused) Color.Red else Color.Black
            }
            .focusable()
    ) {
        Text(
            "결제 확인",
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,)
    }
}

@Composable
fun QrScreenHeader() {
    Column {
        Row{
            Image(
                painter = painterResource(id = R.drawable.property_1_default),
                contentDescription = "오초이스 로고",
                modifier = Modifier.width(180.dp)
            )
            Text(
                text = " 상품 구매",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 25.sp,
                modifier = Modifier.offset(y = (-4).dp)
            )
        }
        Spacer(modifier = Modifier.height(36.dp))
    }
}

@Composable
fun ProductInfo(display: Display) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(66.dp)
            .background(Color.LightGray)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = display.title,
            color = Color.Black,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .weight(6f)
        )
        Text(
            text = buildAnnotatedString {
                withStyle(style = SpanStyle(fontSize = 16.sp)) {
                    append(display.price)
                    append(" / ")
                    append(display.viewablePeriod)
                }
                withStyle(style = SpanStyle(fontSize = 14.sp)) {
                    append("(VAT 포함)")
                }
            },
            color = Color.Black,
            fontWeight = FontWeight.Medium,
            fontSize = 20.sp,
            modifier = Modifier
                .weight(3f)
                .padding(start = 8.dp, end = 8.dp)
        )
        Text(
            text = "구매하기",
            color = Color.Black,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            modifier = Modifier
                .weight(1f)
        )
    }
}