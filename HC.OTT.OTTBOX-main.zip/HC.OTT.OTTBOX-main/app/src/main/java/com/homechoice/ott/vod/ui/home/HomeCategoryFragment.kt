package com.homechoice.ott.vod.ui.home;

import android.annotation.SuppressLint;
import android.app.Dialog
import android.content.Intent
import android.os.Bundle;
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.view.isVisible
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.CategoryTarget
import com.homechoice.ott.vod.agent.Constant
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.SessionState
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.model.response.ResponseAuth
import com.homechoice.ott.vod.model.response.ResponseCategoryList
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.ui.MainActivity
import com.homechoice.ott.vod.ui.my.MyActivity2
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.ui.search.SearchActivity
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.HttpURLConnection
import java.util.UUID

class HomeCategoryFragment(val ctx: HomeActivity2) : NavigationView2(){

    private lateinit var searchIcon: FrameLayout
    private lateinit var myIcon: FrameLayout
    private lateinit var homeIcon: FrameLayout
    private lateinit var categoryIcon: FrameLayout
    private lateinit var topIcon: FrameLayout

    private lateinit var extendMenu: LinearLayout
    private lateinit var extendMovie: TextView
    private lateinit var extendBroadcast: TextView
    private lateinit var extendGlobal: TextView
    private lateinit var extendKidAni: TextView
    private lateinit var extendLife: TextView
    private lateinit var extendDocu: TextView

    val contentScrollView = ctx.findViewById<ScrollView>(R.id.home_content_main_scrollview)
    val bannerLayoutView = ctx.findViewById<FrameLayout>(R.id.home_banner_layout)
    val categoryScrollBody = ctx.findViewById<LinearLayout>(R.id.home_category_scrollbody)
    val categoryScrollView = ctx.findViewById<ScrollView>(R.id.home_category_scrollview)

//    override fun onAttach(context: Context) {
//        super.onAttach(context)
//    }

    @SuppressLint("InflateParams")
    override fun onCreateView(inflater:LayoutInflater, container:ViewGroup?, savedInstanceState:Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_home_category, null)

        searchIcon = view.findViewById(R.id.nav_search)
        myIcon = view.findViewById(R.id.nav_my)
        homeIcon = view.findViewById(R.id.nav_home)
        categoryIcon = view.findViewById(R.id.nav_category)
        topIcon = view.findViewById(R.id.nav_top10)

        extendMenu = view.findViewById(R.id.nav_extend)
        extendMovie = view.findViewById(R.id.textView_movie)
        extendBroadcast = view.findViewById(R.id.textView_broadcast)
        extendGlobal = view.findViewById(R.id.textView_global)
        extendKidAni = view.findViewById(R.id.textView_kid_ani)
        extendLife = view.findViewById(R.id.textView_life)
        extendDocu = view.findViewById(R.id.textView_docu)

//        val categoryScroll = ctx.findViewById<LinearLayout>(R.id.home_category_scrollbody)
        val contentScrollView = ctx.findViewById<ScrollView>(R.id.home_content_main_scrollview)

        extendMenu.visibility = View.GONE

        //프로필 아이콘 클릭 이벤트
        myIcon.setOnClickListener {
            val intent = Intent(requireContext(), MyActivity2::class.java)
            intent.putExtra("TARGET_INFO", CategoryTarget.ROOT)

            if (STBAgent.isAuth) {
                startActivity(intent)
            } else {
                authenticate(object : AuthListener {
                    override fun next() {
                        homeIconClickEvent(contentScrollView)
                    }
                })
            }
        }

        //검색 아이콘 클릭 이벤트
        searchIcon.setOnClickListener {
            val intent = Intent(requireContext(),SearchActivity::class.java)
            startActivity(intent)
        }

        //홈 아이콘 클릭 이벤트
        homeIcon.setOnClickListener {
            homeIconClickEvent(contentScrollView)
        }

        //카테고리 아이콘 클릭 이벤트
        categoryIcon.setOnClickListener {
            when(extendMenu.isVisible){
                true -> extendMenu.visibility = View.GONE
                false -> {
                    extendMenu.visibility = View.VISIBLE
                    extendMovie.requestFocus()
                }
            }
        }


        extendMovie.setOnClickListener {
            selectCategory("영화")
        }

        extendBroadcast.setOnClickListener {
            selectCategory("방송")
        }

        extendGlobal.setOnClickListener {
            selectCategory("해외드라마")
        }

        extendKidAni.setOnClickListener {
            selectCategory("키즈·애니")
        }

        extendLife.setOnClickListener {
            selectCategory("라이프")
        }

        extendDocu.setOnClickListener {
            selectCategory("다큐")
        }

        topIcon.setOnClickListener {
            rollbackCategoryResult()

            //"주간 종편 시청률 TOP으로 이동"
            val handler = Handler()
            handler.postDelayed({
                goTop10LocationY(contentScrollView)
            },300)
//            goTop10LocationY(contentScrollView)
        }


        // View 초기화
        initializeViews(view)

        //아이콘 포커스 방향 설정
        setIconsNextFoucs()
        setExtendNextFocus()
//        // 포커스 리스너 설정
//        setupFocusListeners()
//
//        setupFocusLimitations()


        return view
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        TODO("Not yet implemented")
    }

    override fun active() {
        TODO("Not yet implemented")

    }

    override fun lateActive() {
        TODO("Not yet implemented")
    }

    override fun setVisible(visible: Int) {
        TODO("Not yet implemented")
    }

    //"주간 종편 시청률 TOP으로 이동"
    private fun goTop10LocationY(targetView: ScrollView){
        val fragments = ctx.supportFragmentManager.fragments
        val top10Fragment = ctx.supportFragmentManager.findFragmentByTag("top10")
        val location = IntArray(2)
        top10Fragment?.view?.findViewById<FrameLayout>(R.id.content_poster_border3)?.requestFocus()
        fragments.forEach{fragment ->
            val textView = fragment.view?.findViewById<TextView>(R.id.home_category_list_title)
            if(textView != null && textView.text.contains("주간 종편 시청률 TOP")){
                textView.getLocationInWindow(location)
                val childY = location[1]
                targetView.post {
                    targetView.scrollBy(0, childY)
                }
            }
        }

    }

    private fun selectCategory(targetText: String) {
        categoryScrollView.visibility = View.VISIBLE
        extendMenu.visibility = View.GONE
        contentScrollView.visibility = View.GONE
        categoryScrollBody.removeAllViews()
        var categoryId = 0
        when(targetText){
            "영화"->categoryId=982
            "방송"->categoryId=991
            "해외드라마"->categoryId=996
            "키즈·애니"->categoryId=1001
            "라이프"->categoryId=1012
            "다큐"->categoryId=1008
        }
        val transactionCategoryId = UUID.randomUUID().toString()

        MBSAgent.getCategoryList(
            transactionCategoryId,
            categoryId,
            true,
            STBAgent.isAdultAuth,
            STBAgent.includeRrated,
            1,
            10,

            object : Callback<ResponseCategoryList> {
                override fun onFailure(call: Call<ResponseCategoryList>, t: Throwable) {
                    Log.e("getCategoryList Error","${call}")
                }

                override fun onResponse(
                    call: Call<ResponseCategoryList>,
                    response: Response<ResponseCategoryList>
                ) {
                    if (response.isSuccessful && response.body() != null) {
                        val categoryList: ResponseCategoryList = response.body()!!
                        when (categoryList.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                                UIAgent.showPopup(ctx, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
//                                        createCategory()
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                if (transactionCategoryId == categoryList.transactionId) {
                                    var firstFlag = true
                                    categoryList.categoryList.forEach { category ->
                                        val homeContentGroupV2ListFragment = HomeContentGroupV2ListFragment(category.title,category.categoryItemList,firstFlag)
                                        if(firstFlag) firstFlag=false
                                        val transaction = parentFragmentManager
                                        transaction.beginTransaction().add(R.id.home_category_scrollbody,homeContentGroupV2ListFragment!!).commit()
                                    }

                                }
                                else {
                                    // 무시
                                }
                            }
                        }

                    }
                    else {
                        // 장애팝업
                        Log.e("error","HomeCategoryFragment 227")
                    }
                }
            })
    }

    private fun rollbackCategoryResult(){
        categoryScrollView.visibility = View.GONE
        categoryScrollBody.removeAllViews()
        extendMenu.visibility = View.GONE
        contentScrollView.visibility = View.VISIBLE
    }
    private fun initializeViews(view: View) {
        // 여기서 모든 view.findViewById 호출을 수행
    }
    
    private fun setIconsNextFoucs(){
        val focusableIcons = listOf(myIcon, searchIcon, homeIcon, categoryIcon, topIcon)
        focusableIcons.forEach { icon ->
//            Log.d("${icon} icon","index: ${focusableIcons.indexOf(icon)} ")
            if(focusableIcons.indexOf(icon)==0) icon.nextFocusUpId = icon.id
            else icon.nextFocusUpId = focusableIcons[focusableIcons.indexOf(icon)-1].id

            icon.nextFocusLeftId = icon.id

            if(focusableIcons.indexOf(icon)==focusableIcons.lastIndex) icon.nextFocusDownId = icon.id
            else icon.nextFocusDownId = focusableIcons[focusableIcons.indexOf(icon)+1].id

        }
    }

    private fun setExtendNextFocus(){
        val focusableExtend = listOf(extendMovie,extendBroadcast,extendGlobal,extendKidAni,extendLife,extendDocu)
        extendMovie.nextFocusUpId = extendMovie.id
        extendDocu.nextFocusDownId = extendDocu.id
        focusableExtend.forEach { extend ->
            extend.nextFocusLeftId = categoryIcon.id
            extend.setOnKeyListener { view, i, keyEvent ->
                if(keyEvent.action == KeyEvent.ACTION_DOWN)
                    when(i){
                        KeyEvent.KEYCODE_DPAD_UP->{

                        }
                        KeyEvent.KEYCODE_DPAD_LEFT->{
                            extendMenu.visibility = View.GONE
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_RIGHT->{
                            extendMenu.visibility = View.GONE
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_DOWN->{

                        }
//                        KeyEvent.KEYCODE_BACK, 97->{
//                            extendMenu.visibility = View.GONE
//                            categoryIcon.requestFocus()
//                            true
//                        }
                    }
                false
            }
        }
    }

    private fun homeIconClickEvent(contentScrollView: ScrollView) {
        rollbackCategoryResult()

        contentScrollView.post {
            contentScrollView.findViewById<FrameLayout>(R.id.banner_button_frame).requestFocus()
            contentScrollView.scrollTo(0, 0)
        }

        Log.d("next right focus", "${homeIcon.focusSearch(View.FOCUS_RIGHT)}")
    }

    private fun authenticate(listener: AuthListener) {
        GlobalScope.launch {
            MBSAgent.sessionAuth(
                Constant.appCode,
                requireContext().getString(R.string.device_type),
                STBAgent.getAndroidId(requireContext()),
                object : Callback<ResponseAuth> {
                    override fun onFailure(call: Call<ResponseAuth>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure")
                        if (!requireActivity().isFinishing)
                            UIAgent.showPopup(requireContext(), CODE.NONE, null)
                    }

                    override fun onResponse(call: Call<ResponseAuth>, response: Response<ResponseAuth>) {
                        when (response.code()) {
                            HttpURLConnection.HTTP_OK -> {
                                val res = response.body()
                                if (res != null) {
                                    MBSAgent.terminalKey = res.terminalKey
                                    STBAgent.backgroundImageUrl = res.bgImgUrl

                                    PopupAgent.appStartShowLoginPopup(context = requireContext(), login = Login(forceLogin = true, terminalKey = res.terminalKey, loginqr = null), event = object : LoginPopupEvent {
                                        override fun onLogin(loginDialog: Dialog, btn: String) {
                                            when (btn) {
                                                BtnLabel.SUCCESS -> {
                                                    listener.next()
                                                }
                                                else -> {
//                                                    goToHome()
                                                }
                                            }
                                        }
                                    })
                                }
                                else {
                                    UIAgent.showPopup(requireContext(), response.code(), null)
                                }
                            }
                            else -> {
                                UIAgent.showPopup(requireContext(), response.code(), null)
                            }
                        }
                    }
                }
            )
        }
    }

    private interface AuthListener {
        fun next()
    }
}