package com.homechoice.ott.vod.ui.popup.purchase

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.popup.PopupType.NormalPopupType
import com.homechoice.ott.vod.databinding.DialogPurchaseFailBinding
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.PopupViewModel

class PurchaseFailPopupView(
    ctx: Context,
    code: Int,
    popupType: NormalPopupType,
    event: PopupEvent
) : Dialog(
    ctx,
    R.style.Theme_Design_NoActionBar
) {
    private var binding: DialogPurchaseFailBinding
    private var model: PopupViewModel = PopupViewModel(popupType)

    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        model.content.value?.code = code.toString()
        binding = DialogPurchaseFailBinding.inflate(LayoutInflater.from(ctx))
        binding.apply {
            viewModel = model
        }
        setContentView(binding.root)

        binding.btnOk.setOnClickListener {
            event.onClick(this, (it as TextView).text.toString())
        }
        show()
    }

}