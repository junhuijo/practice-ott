package com.homechoice.ott.vod.event

interface AdultRetryCallback {
    fun call()
    fun cancel()
    fun navigateToHome()
}