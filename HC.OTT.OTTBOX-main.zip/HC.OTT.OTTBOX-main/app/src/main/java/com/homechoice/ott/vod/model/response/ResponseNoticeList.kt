package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.notice.Notice
import kotlinx.android.parcel.Parcelize


@Parcelize
class ResponseNoticeList(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val totalCount : Int,
    val noticeList : List<Notice>
) : Parcelable