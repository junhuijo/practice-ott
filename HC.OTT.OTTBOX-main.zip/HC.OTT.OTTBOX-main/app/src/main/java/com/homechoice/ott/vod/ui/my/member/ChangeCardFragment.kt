package com.homechoice.ott.vod.ui.my.member

import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.get
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.CategoryTarget
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentMyChangeCardBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.my.member.ChangeCardViewModel.ModelListener
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_my_change_card.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ChangeCardFragment(val activityHandler: Handler) : NavigationView2() {

    private lateinit var bind: FragmentMyChangeCardBinding
    private lateinit var viewModel: ChangeCardViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_my_change_card, container, false)
        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this).get(ChangeCardViewModel::class.java)

        with(viewModel) {
            this.setListener(listener = object : ModelListener {
                override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
                    Logger.Log(Log.ERROR, this, "focusChanged:$index")
                    keypad_layout[index].requestFocus()
                }

                override fun select(index: Int) {
                    Logger.Log(Log.ERROR, this, "select:$index")
                    enter(keypad_layout[index])
                }

                override fun back() {
                    activityHandler.obtainMessage(2).sendToTarget()
                }

            })
        }

        bind.viewModel = viewModel
        bind.lifecycleOwner = this
    }


    fun enter(view: View) {
        when (view) {
            keypad_num_0 -> {
                keypad_inputbox.append("0")
            }
            keypad_num_1 -> {
                keypad_inputbox.append("1")
            }
            keypad_num_2 -> {
                keypad_inputbox.append("2")
            }
            keypad_num_3 -> {
                keypad_inputbox.append("3")
            }
            keypad_num_4 -> {
                keypad_inputbox.append("4")
            }
            keypad_num_5 -> {
                keypad_inputbox.append("5")
            }
            keypad_num_6 -> {
                keypad_inputbox.append("6")
            }
            keypad_num_7 -> {
                keypad_inputbox.append("7")
            }
            keypad_num_8 -> {
                keypad_inputbox.append("8")
            }
            keypad_num_9 -> {
                keypad_inputbox.append("9")
            }
            keypad_num_del -> {
                var numbers = keypad_inputbox.text
                if (numbers.isNotEmpty()) {
                    numbers.substring(0, numbers.length - 1).also { numbers = it }
                }
                keypad_inputbox.text = numbers
            }
            keypad_num_ok -> {
                okNumber(keypad_inputbox.text.toString())
            }
            else -> {
                Logger.Log(Log.ERROR, this, "not exist key")
            }

        }
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        var result = false
        when (keyCode) {

            KeyEvent.KEYCODE_BACK, 97 -> {
                activityHandler.obtainMessage(2).sendToTarget()
                result = true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                viewModel.up()
                result = true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                viewModel.down()
                result = true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                viewModel.right()
                result = true

            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                //activityHandler.obtainMessage(2).sendToTarget()
                viewModel.left()
                result = true

            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                viewModel.enter()
                result = true
            }
        }

        return result
    }

    override fun active() {
    }

    private fun okNumber(numbers: String) {
        val numbers =
            if (UIAgent.isValidCellPhoneNumber(numbers)) {
                Logger.Log(Log.DEBUG, this, "전화번호 형식 맞음")

                MBSAgent.postCardReplace(numbers, object : Callback<ResponseNoBody> {
                    override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                        context?.let {
                            PopupAgent.showNormalPopup(
                                it,
                                PopupType.getErrorType(
                                    TYPE.AUTH,
                                    CODE.NONE
                                ),
                                object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        when (btn) {
                                            BtnLabel.OK -> {
                                                d.dismiss()
                                            }
                                        }
                                    }
                                })
                        }

                    }

                    override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                        if (response.isSuccessful && response.body() != null) {
                            viewModel.invalidInfo.value = false
                            context?.let {
                                PopupAgent.showNormalPopup(
                                    it,
                                    PopupType.NormalPopupType.CARD_ADD,
                                    object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            d.dismiss()

                                        }
                                    })
                            }

                        } else {
                            context?.let {
                                when (response.code()) {
                                    CODE.CONFLICT -> {
                                        UIAgent.showPopupForMyMenu(it, response.code(), object : RetryCallback {
                                            override fun call() {
                                                activityHandler.obtainMessage(12).sendToTarget()
                                                activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                            }
                                            override fun cancel() {
                                                activityHandler.obtainMessage(12).sendToTarget()
                                            }
                                        })
                                    }
                                    else -> {
                                        viewModel.invalidInfo.value = true
                                        val error = response.errorBody()?.let { MBSAgent.error(it) }
                                        PopupAgent.showNormalPopup(
                                            it,
                                            PopupType.getErrorType(
                                                TYPE.AUTH,
                                                response.code(),
                                                error?.errorString!!
                                            ),
                                            object : PopupEvent {
                                                override fun onClick(d: Dialog, btn: String) {
                                                    when (btn) {
                                                        BtnLabel.OK -> {
                                                            d.dismiss()
                                                        }
                                                    }
                                                }
                                            })
                                    }
                                }
                            }
                        }
                    }

                })


            } else {
                viewModel.invalidInfo.value = true
                Logger.Log(Log.DEBUG, this, "전화번호 형식 아님")
            }
    }

    fun focus() {
        viewModel.keyPadNavigator.currentIndex = 10
        viewModel.keyPadNavigator.pageStartIndex = 9
        keypad_num_0.requestFocus()
    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        TODO("Not yet implemented")
    }

}