package com.homechoice.ott.vod.model.point

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class PointProduct(
    var id: Long,
    var name: String,
    var msg: String,
    var price: Int,
    var mileagePrice: Int = 0,
    var priceStr: String,
    var validDate: String,
    var msgStr: String,
    var displayPriceStr: String = "0원 (VAT 포함)",
    var mileagePriceStr: String = "0"
) : Parcelable {
    init {
        build()
    }

    fun build(): PointProduct {
        priceStr = String.format("%,d", price)
        displayPriceStr = "${priceStr}원 (VAT 포함)"
        mileagePriceStr = String.format("%,d", mileagePrice)
        return this
    }
}