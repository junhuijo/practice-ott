package com.homechoice.ott.vod.ui.screens.home.banner

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.homechoice.ott.vod.model.CategoryItem

@Composable
fun BannerBackground(banner: CategoryItem) {
    val imageUrl = banner.posterUrl
    Box(
        modifier = Modifier.fillMaxSize()
    ){
        AsyncImage(
            model = imageUrl,
            contentDescription = null,
            contentScale = ContentScale.FillHeight,
            alignment = Alignment.CenterEnd,
            modifier = Modifier.fillMaxSize())
    }
}