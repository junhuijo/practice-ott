package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.content.Content
import kotlinx.android.parcel.Parcelize

@Parcelize
class ResponseContent (
    //TODO: Transaction Id관련 추가 필요한지?
    val errorString: String,
    val sessionState: String = "",
    var content: Content
):Parcelable
