package com.homechoice.ott.vod.ui.detail

class LikeModel {
    var isActive: Boolean = false
    var isLike: Boolean = false
}