package com.homechoice.ott.vod.ui.my.point

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.ui.navigation.navigator.NavigatorModel


class PointRegisterViewModel : ViewModel() {
    enum class FocusType {
        NONE, FIRST_EDIT, SECOND_EDIT,THIRD_EDIT, BUTTON
    }

    interface ModelListener {
        fun focused(focusType: FocusType)
        fun buttonFocused(index: Int)
        fun select(focusType: FocusType, currentIndex: Int)
        fun back(focusType: FocusType)
        fun hideIME()
    }

    var invalidInfo: MutableLiveData<Boolean> = MutableLiveData()

    var focusType: FocusType = FocusType.NONE
    private lateinit var listener: ModelListener

    var buttonListModel: NavigatorModel = NavigatorModel(1, 0, 2, 2, object : NavigatorModel.Callback {
        override fun init(index: Int) {

        }

        override fun pageStartIndexChanged() {

        }

        override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
            listener.buttonFocused(index)
        }

    })


    fun init() {
        focusType = FocusType.FIRST_EDIT
    }

    fun up() {
        when (this.focusType) {
            FocusType.BUTTON -> {
                this.focusType = FocusType.FIRST_EDIT
                listener.focused(this.focusType)
            }
        }
    }

    fun setModelListener(listener: ModelListener) {
        this.listener = listener
    }

    fun getModelListener(): ModelListener {
        return this.listener
    }

    fun down() {
        when (this.focusType) {
            FocusType.THIRD_EDIT,
            FocusType.SECOND_EDIT,
            FocusType.FIRST_EDIT -> {
                this.focusType = FocusType.BUTTON
                buttonListModel.currentIndex = 0
                listener.buttonFocused(buttonListModel.currentIndex)
            }
        }
    }

    fun right() {
        when (this.focusType) {
            FocusType.FIRST_EDIT -> {
                this.focusType = FocusType.SECOND_EDIT
                listener.focused(this.focusType)
            }
            FocusType.SECOND_EDIT -> {
                this.focusType = FocusType.THIRD_EDIT
                listener.focused(this.focusType)
            }

            FocusType.BUTTON -> {
                buttonListModel.right()
            }
        }
    }

    fun left() {
        when (this.focusType) {
            FocusType.FIRST_EDIT -> {
                back()
            }

            FocusType.SECOND_EDIT -> {
                this.focusType = FocusType.FIRST_EDIT
                listener.focused(this.focusType)
            }

            FocusType.THIRD_EDIT -> {
                this.focusType = FocusType.SECOND_EDIT
                listener.focused(this.focusType)
            }

            FocusType.BUTTON -> {
                if (buttonListModel.currentIndex > 0) {
                    buttonListModel.left()
                } else {
                    back()
                }
            }
        }
    }

    fun back() {
        listener.back(this.focusType)
    }

    fun enter() {
        when (this.focusType) {
            FocusType.BUTTON -> {
                listener.select(this.focusType, buttonListModel.currentIndex)
            }
            else -> {
                listener.select(this.focusType, 0)
            }
        }
    }

}

