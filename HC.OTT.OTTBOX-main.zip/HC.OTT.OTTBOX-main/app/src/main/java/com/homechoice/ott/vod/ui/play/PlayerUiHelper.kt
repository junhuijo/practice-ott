package com.homechoice.ott.vod.ui.play

import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.ActivityPlayerBinding


class PlayerUiHelper(private val binding: ActivityPlayerBinding) {

    fun showProgressBar() {
        if (!isShowPlayView()) {
            val animation = AnimationUtils.loadAnimation(binding.root.context, R.anim.play_view_fadein)
            animation.fillAfter = true
            setVisible(binding.playerLayout, View.VISIBLE)
            binding.playerLayout.startAnimation(animation)
        }
    }

    fun hideProgressBar() {
        hideProgressBar(R.anim.play_view_fadeout)
    }

    fun hideProgressBar(animationId: Int) {
        val animation = AnimationUtils.loadAnimation(binding.root.context, animationId)
        animation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(animation: Animation?) {
                setVisible(binding.playerLayout, View.INVISIBLE)
            }

            override fun onAnimationStart(animation: Animation?) {

            }
        })
        animation.fillAfter = true
        binding.playerLayout.startAnimation(animation)
    }

    fun isShowPlayView(): Boolean {

        return binding.playerLayout.visibility == View.VISIBLE
    }

    fun isShowThumbnailView(): Boolean {

        return binding.thumbnailList.visibility == View.VISIBLE
    }

    fun setVisible(view: View, visibility: Int) {
        view.visibility = visibility
    }
}