package com.homechoice.ott.vod.ui.popup.pack

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.model.content.Content
import java.text.DecimalFormat

class PackageDetailViewModel(detailContent: Content) : ViewModel() {
    var content: MutableLiveData<Content> = MutableLiveData()
    var priceStr: MutableLiveData<String> = MutableLiveData()
    var viewablePeriod: MutableLiveData<String> = MutableLiveData()

    init {
        val offer = detailContent.offerList[0]
        val price: String = DecimalFormat("#,###").format(UIAgent.getProductPrice("single", detailContent.offerList))
        content.value = detailContent
        priceStr.value = when (price) {
            "0" -> "무료"
            else -> price + "원"
        }
        viewablePeriod.value = UIAgent.getViewablePeriod(offer.productType ?: "", offer.rentalPeriod ?: "")
    }
}