package com.homechoice.ott.vod.ui.screens.home.banner

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.homechoice.ott.vod.R

@Composable
fun BannerButtons(playNowOnClick: () -> Unit, nextBanner: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        PlayNowButton(playNowOnClick, nextBanner)
        NextButton(nextBanner)
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun PlayNowButton(
    playNowOnClick: () -> Unit,
    nextBanner: () -> Unit) {
    var borderColor by remember{ mutableStateOf(Color.Red) }
    var isFirstKeyEventAfterFocus by remember { mutableStateOf(true) }
    Box(
        modifier = Modifier
            .padding(start = 33.dp)
            .fillMaxHeight()
            .width(164.dp)
            .onFocusChanged {
                borderColor = if(it.hasFocus) Color.White else Color.Red
                if (it.hasFocus) {
                    isFirstKeyEventAfterFocus = true
                }
            }
            .focusable()
            .onKeyEvent { keyEvent ->
                if (keyEvent.key == Key.DirectionRight && keyEvent.type == KeyEventType.KeyUp) {
                    if (isFirstKeyEventAfterFocus) {
                        isFirstKeyEventAfterFocus = false
                        true
                    } else {
                        nextBanner()
                        true
                    }
                } else {
                    false
                }
            }
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() },) {
                playNowOnClick()
            }
    ){
        Box(
            modifier = Modifier
                .padding(top = 224.dp)
                .width(164.dp)
                .height(37.dp)
                .background(color = Color.Red, shape = RoundedCornerShape(4.dp))
                .border(width = 2.dp, color = borderColor, shape = RoundedCornerShape(4.dp)),
            contentAlignment = Alignment.Center
        ){
            Text(text = "지금 재생하기", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun NextButton(nextBanner: () -> Unit) {
    var resourceId by remember {
        mutableStateOf(R.drawable.next_arrow_unfocused)
    }
    Box(
        modifier = Modifier
            .padding(start = 780.dp)
            .fillMaxHeight()
            .width(20.dp),
        contentAlignment = Alignment.Center
    ){
        Box(
            modifier = Modifier
                .width(20.dp)
        ){
            Image(painter = painterResource(id = resourceId),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                alpha = 0.6f
            )
        }
    }
}