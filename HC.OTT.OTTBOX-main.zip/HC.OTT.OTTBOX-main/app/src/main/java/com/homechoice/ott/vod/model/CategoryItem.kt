package com.homechoice.ott.vod.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CategoryItem(
    val id: Long = -1,
    val title: String = "",
    var subtitle: String = "",
    var type: String = "",
    var description: String = "",
    var posterUrl: String = "",
    val posterSizeLevel: Int = 0,
    var unselectedIconUrl: String = "",
    var selectedIconUrl: String = "",
    val isAdult: Boolean = false,
    var popupType: String = "",
    var popupImgUrl: String = "",
    var popupTxt: String = "",
    var linkType: String = "none",
    var linkInfo: String? = "",
    var titleImage: String? = "",
    //adult content block test
//    private val _rating: String? = null,
    var rating : String? = "",
    var releaseYear: String? = "",
    var runTime: String? = "",
    var trailer: String? = ""
) : Parcelable {

    fun build(): CategoryItem {
        if (subtitle == null) {
            subtitle = ""
        }
        if (type == null) {
            type = ""
        }
        if (description == null) {
            description = ""
        }
        if (posterUrl == null) {
            posterUrl = ""
        }
        if (unselectedIconUrl == null) {
            unselectedIconUrl = ""
        }
        if (selectedIconUrl == null) {
            selectedIconUrl = ""
        }
        if (popupType == null) {
            popupType = ""
        }
        if (popupImgUrl == null) {
            popupImgUrl = ""
        }
        if (popupTxt == null) {
            popupTxt = ""
        }
        if (linkType == null) {
            linkType = ""
        }
        if (linkInfo == null) {
            linkInfo = ""
        }
        if (rating == null) {
            rating = ""
        }
        if (trailer == null) {
            trailer = ""
        }
        if (releaseYear == null) {
            releaseYear = ""
        }
        if (runTime == null) {
            runTime = ""
        }
        if (titleImage == null) {
            titleImage = ""
        }
        return this
    }
//    val rating: String
//        get() = "19세"

}