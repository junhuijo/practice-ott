package com.homechoice.ott.vod.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.homechoice.ott.vod.model.CategoryList
import androidx.recyclerview.widget.RecyclerView

//class CategoryAdapter(private val categoryList: List<CategoryList>) : RecyclerView.Adapter<CategoryAdapter.ViewHolder>(){
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
//        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_vertical_recyclerview, parent, false)
//        return ViewHolder(view)
//    }
//
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        val horizontalLayoutManager = LinearLayoutManager(holder.itemView.context, LinearLayoutManager.HORIZONTAL, false)
//        holder.horizontalRecyclerView.layoutManager = horizontalLayoutManager
//        val horizontalAdapter = HorizontalAdapter(categoryList[position])
//        holder.horizontalRecyclerView.adapter = horizontalAdapter
//    }
//
//    override fun getItemCount() = categoryList.size
//
//    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        val horizontalRecyclerView: RecyclerView = itemView.findViewById(R.id.horizontalRecyclerView)
//    }
//}