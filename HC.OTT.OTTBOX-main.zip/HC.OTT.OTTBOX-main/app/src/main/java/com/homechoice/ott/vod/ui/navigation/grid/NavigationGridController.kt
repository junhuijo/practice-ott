package com.homechoice.ott.vod.ui.navigation.grid

import android.util.Log
import com.homechoice.ott.vod.util.Logger

class NavigationGridController(var model: NavigationGridModel, var event: NavigationGridEvent) {
    var data = model.data

    fun init() {
        data.curIndex = 0
        data.preIndex = -1
        data.visibleIndex = 0
    }

    fun hasData(): Boolean {
        return (data.totalCount > 0)
    }

    fun decreaseForce(): Boolean {
        return if (data.curIndex > 0) {
            data.preIndex = data.curIndex
            data.curIndex--
            if (data.getCurRows() < data.getPreRows()) {
                if (data.visibleIndex > data.leftFixedIndex) {
                    data.visibleIndex--
                    Logger.Log(Log.WARN, this, "라인이 넘어 갔지만 1번 줄을 넘지 않음")
                } else {
                    Logger.Log(Log.WARN, this, "보이는 라인 중 첫번째")
                    event.upRowChange()
                }
            }
            event.focusChange()
            false
        } else {
            true
        }
    }

    fun decrease(): Boolean {
        return if (data.curIndex % data.colCount == 0) {
            event.firstColChange()
            false
        } else {
            // 라인이 바뀌는 상황이 없음. -> 상/하/우키로만 라인이 바뀜
            data.preIndex = data.curIndex
            data.curIndex--
            event.focusChange()
            true
        }
    }

    fun increase(): Boolean {
        return if (data.curIndex < (data.totalCount - 1)) {
            data.preIndex = data.curIndex
            data.curIndex++
            if (data.getCurRows() > data.getPreRows()) {
                // 라인이 넘어갈 때
                Logger.Log(Log.WARN, this, "라인이 넘어갔음")
                if (data.visibleIndex < data.rightFixedIndex) {
                    data.visibleIndex++
                    Logger.Log(Log.WARN, this, "라인이 넘어 갔지만 3번 줄을 넘지 않음")
                } else {
                    if (data.rows < data.totalRows) {
                        Logger.Log(Log.WARN, this, "라인이 모두 로드 안 되었음 -> 다음 라인 불러오기 오른쪽")
                        data.startIndex = data.startIndex + (data.pageSize)
//                        data.pageSize = data.colCount
                        Logger.Log(Log.INFO,"1, ${data.rows}")
                        Logger.Log(Log.INFO,"2, ${data.rows}")
                        event.downRowChange()
                    } else {
                        Logger.Log(Log.WARN, this, "더 불러올 라인이 없음")
                        if (!data.isLoaded) {
                            if (data.rows == data.totalRows) {
                                data.isLoaded = true
                            }
                            if (data.getCurRows() == data.rows) {
                                Logger.Log(Log.WARN, this, "빈 라인 안만들기 1")
                                event.lastRowChange()
                            } else {
                                Logger.Log(Log.WARN, this, "빈 라인 만들기")
                                event.addEmptyRow()
                            }
                        } else {
                            Logger.Log(Log.WARN, this, "빈 라인 안만들기 2")
                            event.lastRowChange()
                        }
                    }
                }
            }
            event.focusChange()
            printString()
            true
        } else {
            printString()
            false
        }
    }

    fun increaseRow(): Boolean {
        return if (data.curIndex < (data.totalCount - 1)) {
            data.preIndex = data.curIndex
            if (data.curIndex + data.colCount < data.totalCount - 1) {
                data.curIndex += data.colCount
            } else {
                data.curIndex = data.totalCount - 1
            }

            if (data.getCurRows() > data.getPreRows()) {
                // 라인이 넘어갈 때
                Logger.Log(Log.WARN, this, "라인이 넘어갔음")
                if (data.visibleIndex < data.rightFixedIndex) {
                    data.visibleIndex++
                    Logger.Log(Log.WARN, this, "라인이 넘어 갔지만 3번 줄을 넘지 않음")
                } else {
                    if (data.rows < data.totalRows) {

                        data.startIndex = data.startIndex + (data.pageSize)

                        // 현재 라인이 몇 row인지 판단이 필요.
                        Logger.Log(Log.WARN, this, "data.getCurRows(): ${data.getCurRows(data.curIndex + data.colCount)} / ${data.rows}")
                        if (data.getCurRows(data.curIndex + data.colCount - 1) < data.rows) {
                            Logger.Log(Log.WARN, this, "다음 라인 넘어가기 3")
                            event.lastRowChange()
                        } else {
                            Logger.Log(Log.WARN, this, "라인이 모두 로드 안 되었음 -> 다음 라인 불러오기 하이")
                            event.downRowChange()
                        }


                    } else {
                        Logger.Log(Log.WARN, this, "더 불러올 라인이 없음")
                        if (!data.isLoaded) {
                            if (data.rows == data.totalRows) {
                                data.isLoaded = true
                            }
                            if (data.getCurRows() == data.rows) {
                                Logger.Log(Log.WARN, this, "빈 라인 안만들기 4")
                                event.lastRowChange()
                            } else {
                                Logger.Log(Log.WARN, this, "빈 라인 만들기")
                                event.addEmptyRow()
                            }
                        } else {
                            Logger.Log(Log.WARN, this, "빈 라인 안만들기 5")
                            event.lastRowChange()
                        }
                    }
                }
            }
            event.focusChange()
            printString()
            true
        } else {
            printString()
            false
        }
    }

    fun decreaseRow(): Boolean {
        return if (data.getCurRows() == 1) {
            event.firstRowChange()
            true
        } else {
            data.preIndex = data.curIndex

            if (data.curIndex - data.colCount >= 0) {
                data.curIndex -= data.colCount
                // 라인이 바뀌었음 -> 라이이 바뀌는 케이스만 존재
                if (data.getCurRows() < data.getPreRows()) {
                    if (data.visibleIndex > data.leftFixedIndex) {
                        data.visibleIndex--
                        Logger.Log(Log.WARN, this, "라인이 넘어 갔지만 1번 줄을 넘지 않음")
                    } else {
                        Logger.Log(Log.WARN, this, "보이는 라인 중 첫번째")
                        event.upRowChange()
                    }
                }
                event.focusChange()
            }
            printString()
            true
        }
    }

    fun appendData(list: ArrayList<Any>) {
        model.addModel(list)

        Logger.Log(
            Log.DEBUG,
            this,
            "NavigationView ${data.toString()}"
        )
    }

    private fun printString() {
        Logger.Log(
            Log.DEBUG,
            this,
            "NavigationView ${data.toString()}"
        )
//        Logger.Log(
//            Log.DEBUG,
//            this,
//            "NavigationView curIndex: ${data.curIndex} / preIndex: ${data.preIndex} / totalIndex: ${data.totalIndex} / totalCount : ${data.totalCount} / visibleIndex: ${data.visibleIndex} / visibleThreshold: ${data.visibleThreshold}" +
//                    "/ rightFixedIndex : ${model.data.rightFixedIndex} / leftFixedIndex : ${model.data.leftFixedIndex} / rows : ${data.rows} / colCount :${data.colCount} / startIndex:${data.startIndex} / pageSize:${data.pageSize}"
//        )
//
//        Logger.Log(
//            Log.DEBUG,
//            this,
//            "NavigationView rows : ${data.rows} / colCount :${data.colCount} / startIndex:${data.startIndex} / pageSize:${data.pageSize}"
//        )
    }

    fun visibleThreshold(): Int {
        return model.data.visibleThreshold
    }

    fun getCurItem(): Any? {
        return model.data.list?.get(model.data.curIndex)
    }

    fun getItem(position: Int): Any? {
        return model.data.list?.get(position)
    }

    fun getCurIndex(): Int {
        return model.data.curIndex
    }

    fun getPreIndex(): Int {
        return model.data.preIndex
    }

}