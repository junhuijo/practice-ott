package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.content.OfferContent
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseOfferContent(
    val transactionId: String = "",
    val errorString: String = "",
    val sessionState: String = "",
    val offerContent: OfferContent
) : Parcelable