package com.homechoice.ott.vod.agent

import android.app.Dialog
import android.content.Context
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.ToastLayoutBinding
import com.homechoice.ott.vod.event.AdultRetryCallback
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.content.*
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.util.Logger
import java.text.DecimalFormat
import java.util.regex.Matcher
import java.util.regex.Pattern

object UIAgent {

    var focusAnims = hashMapOf<String, ArrayList<Int>>()
    var unfocusAnims = hashMapOf<String, ArrayList<Int>>()

    init {
        focusAnims[HomeCategoryType.MAINBANNER.name] = arrayListOf(R.drawable.anim_main_top_banner_scale_up)
        focusAnims[HomeCategoryType.ADULT.name] = arrayListOf(R.drawable.anim_main_full_banner_scale_up)
        focusAnims[HomeCategoryType.MIDBANNER.name] = arrayListOf(R.drawable.anim_main_full_banner_scale_up)
        focusAnims[HomeCategoryType.QUICKMENUGROUP.name] = arrayListOf(R.drawable.anim_main_quick_menu_scale_up)
        focusAnims[HomeCategoryType.CATEGORY.name] = arrayListOf(
            R.drawable.anim_main_content_scale_up,
            R.drawable.anim_main_content_scale_up,
            R.drawable.anim_main_content_two_size_scale_up,
            R.drawable.anim_main_content_three_size_scale_up
        )
        focusAnims[HomeCategoryType.ASSET.name] = arrayListOf(
            R.drawable.anim_main_content_scale_up,
            R.drawable.anim_main_content_scale_up,
            R.drawable.anim_main_content_two_size_scale_up,
            R.drawable.anim_main_content_three_size_scale_up
        )

        unfocusAnims[HomeCategoryType.MAINBANNER.name] = arrayListOf(R.anim.anim_main_top_banner_scale_down)
        unfocusAnims[HomeCategoryType.ADULT.name] = arrayListOf(R.anim.anim_main_full_banner_scale_down)
        unfocusAnims[HomeCategoryType.MIDBANNER.name] = arrayListOf(R.anim.anim_main_full_banner_scale_down)
        unfocusAnims[HomeCategoryType.QUICKMENUGROUP.name] = arrayListOf(R.anim.anim_main_quick_menu_scale_down)
        unfocusAnims[HomeCategoryType.CATEGORY.name] = arrayListOf(
            R.anim.anim_main_content_scale_down,
            R.anim.anim_main_content_scale_down,
            R.anim.anim_main_content_two_size_scale_down,
            R.anim.anim_main_content_three_size_scale_down
        )
        unfocusAnims[HomeCategoryType.ASSET.name] = arrayListOf(
            R.anim.anim_main_content_scale_down,
            R.anim.anim_main_content_scale_down,
            R.anim.anim_main_content_two_size_scale_down,
            R.anim.anim_main_content_three_size_scale_down
        )
    }

    fun smoothScrollDxBy(scrollView: ScrollView, dimenId: Int, isPlus: Boolean) {
        Logger.Log(Log.INFO, this, "smoothScrollDxBy dimenId : $dimenId / isPlus : $isPlus ")
        // by 현재 기준으로 이동
        // to 절대값 기준으로 이동
        if (isPlus)
            scrollView.smoothScrollBy(0, CMBApp.RES.getDimensionPixelOffset(dimenId))
        else
            scrollView.smoothScrollBy(0, -CMBApp.RES.getDimensionPixelOffset(dimenId))
    }

    fun getRatingImageResource(rating: String): Int {
        val resourceId: Int = when (rating) { //TODO : 연령아이콘 추가해야함
            "전체" -> R.drawable.icon_s_age_all
            "7세" -> R.drawable.icon_s_age_7
            "12세" -> R.drawable.icon_s_age_12
            "15세" -> R.drawable.icon_s_age_15
            "19세" -> R.drawable.icon_s_age_19
            // "18세" -> R.drawable.age_18
            else -> R.drawable.icon_s_age_all
        }
        Logger.Log(Log.WARN, this, "rating: $rating / resourceId $resourceId")
        return resourceId
    }

    private fun getSecondStickerType(content: Content): String {
        return if (content.isAudioVisual == true) {
            StickerType.AUDIO_VISUAL
        }
        else {
            if (content.offerList[0].discountPrice!! > 0)
                StickerType.DISCOUNT
            else
                ""
        }
    }

    private fun getSecondStickerType(offContent: OfferContent, content: Content): String {
        return if (content.isAudioVisual == true) {
            StickerType.AUDIO_VISUAL
        }
        else {
            if (offContent.discountPrice > 0)
                StickerType.DISCOUNT
            else
                ""
        }
    }

    private fun getSecondStickerType(offContent: Offer, content: Content): String {
        return if (content.isAudioVisual == true) {
            StickerType.AUDIO_VISUAL
        }
        else {
            if (offContent.discountPrice!! > 0)
                StickerType.DISCOUNT
            else
                ""
        }
    }

    fun createDisplay(content: Content, offer: Offer): Display {
        val price = if (offer.price == 0) {
            "무료"
        }
        else {
            "${DecimalFormat("#,###").format(offer.price)}원"
        }

        // 포인트 발급 시 -> 결제 시 n 포인트 즉시 발급 (카드 결제 금액만 적용)
        // 포인트 적립 시 -> 결제 금액의 n% 즉시 적립 (카드 결제 금액만 적용)
        var isDiscount = offer.discountPrice!! > 0
        if (offer.packageType == PackageType.PACKAGE)
            isDiscount = false

        var isExpand = false
        var expandText = ""
        if (!isDiscount && price != "무료") {
            when (offer.pointPolicyType) {
                "rate" -> {
                    expandText = "결제 금액의 ${offer.pointPolicyValue}% 적립 (카드 결제 금액만 적용)"
                    isExpand = true
                }
                "price" -> {
                    expandText = "${offer.pointPolicyValue}P 적립 (포인트만 결제 시 적립 불가)"
                    isExpand = true
                }
            }
        }

        return Display(
            title = content.title ?: "",
            ratingImageResource = getRatingImageResource(content.rating ?: "전체"),
            genre = content.genre ?: "",
            runningTime = content.runTimeDisplay ?: "",
            runTime = content.runTime ?: "",
            price = price,
            disPrice = DecimalFormat("#,###").format(offer.discountPrice),
            director = content.director ?: "",
            actor = content.actor ?: "",
            synopsys = content.synopsis ?: "",
            reviewRating = content.reviewRating ?: 0,
            isWish = content.isWish == true,
            imageUrl = content.posterUrl ?: "",
            eventType = offer.eventType ?: "",
            secondStickerType = getSecondStickerType(offer, content),
            stickerType = when {
                content.isHot == true -> {
                    "hot"
                }
                content.isNew == true -> {
                    "new"
                }
                else -> {
                    ""
                }
            },
            translationType = content.translationType ?: "",
            viewablePeriod = getViewablePeriod(offer.productType ?: "", offer.rentalPeriod ?: ""),
            isExpand = isExpand,
            expandText = expandText,
            isDiscount = isDiscount,
            releaseYesar = "${content.releaseYear}년"
        )
    }

    fun getProductHead(productType: String): String {
        return when (productType) {
            ProductType.RENT -> ""
            ProductType.BUY -> ""
            ProductType.SUBSCRIPTION -> "월"
            else -> ""
        }
    }

    fun getRentalText(productType: String): String {
        return when (productType) {
            ProductType.RENT -> "단편"
            ProductType.BUY -> "소장"
            ProductType.SUBSCRIPTION -> "월정액"
            else -> ""
        }
    }

    fun getTranslationText(translationType: String): String {
        return when (translationType) {
            TranslationType.NOR -> "일반"
            TranslationType.SUB -> "자막"
            TranslationType.DUB -> "더빙"
            TranslationType.ENSUB -> "자막"  //TODO: 영문자막 확인
            else -> ""
        }
    }

    fun getViewableText(productType: String, viewablePeriod: String): String {
        return when (productType) {
            ProductType.BUY -> {
                viewablePeriod
            }
            else -> {
                ""
            }
        }
    }

    fun createRecommendDisplay(categoryItemList: List<CategoryItem>): RecommendDisplay {
        val urlList = categoryItemList
            .map { it.posterUrl }
        return RecommendDisplay(posterUrlList = urlList)
    }

    fun getViewablePeriod(productType: String, viewablePeriod: String): String {
        lateinit var description: String
        when (productType) {
            ProductType.SUBSCRIPTION -> {
                description = "월정액"
            }
            ProductType.BUY -> {
                description = "소장"
            }
            ProductType.RENT -> {
                description = viewablePeriod
            }
        }
        Logger.Log(Log.DEBUG, this, "description $description / viewablePeriod $viewablePeriod")
        return description
    }

    fun getRate(rating: String): Int {
        return when (rating) {
            "전체" -> 0
            "12세" -> 12
            "15세" -> 15
            "19세" -> 19
            else -> 19
        }
    }

    fun createDisplay(offerContent: OfferContent): Display {
        Logger.Log(Log.DEBUG, this, "createDisplay $offerContent")

        val contentList = offerContent.contentList
        val display: Display

        val price = if (offerContent.price == 0) {
            "무료"
        }
        else {
            "${DecimalFormat("#,###").format(offerContent.price)}원"
        }

        if (contentList.isNotEmpty()) {
            val content: Content = contentList[0]
            // 포인트 발급 시 -> 결제 시 n 포인트 즉시 발급 (카드 결제 금액만 적용)
            // 포인트 적립 시 -> 결제 금액의 n% 즉시 적립 (카드 결제 금액만 적용)

            var isDiscount = offerContent.discountPrice > 0
            if (offerContent.packageType == PackageType.PACKAGE)
                isDiscount = false

            var isExpand = false
            var expandText = ""
            if (!isDiscount && price != "무료") {
                when (offerContent.pointPolicyType) {
                    "rate" -> {
                        expandText = "결제 금액의 ${offerContent.pointPolicyValue}% 적립 (카드 결제 금액만 적용)"
                        isExpand = true
                    }
                    "price" -> {
                        expandText = "${offerContent.pointPolicyValue}P 적립 (포인트만 결제 시 적립 불가)"
                        isExpand = true
                    }
                }
            }

            display = Display(
                title = content.title ?: offerContent.title ?: "",
                ratingImageResource = getRatingImageResource(content.rating ?: "전체"),
                genre = content.genre ?: "",
                runningTime = content.runTimeDisplay ?: "",
                runTime = content.runTime ?: "",
                price = price,
                disPrice = DecimalFormat("#,###").format(offerContent.discountPrice),
                director = content.director ?: "",
                actor = content.actor ?: "",
                synopsys = content.synopsis ?: "",
                reviewRating = content.reviewRating ?: 0,
                isWish = content.isWish == true,
                imageUrl = content.posterUrl ?: "",
                eventType = offerContent.eventType ?: "",
                secondStickerType = getSecondStickerType(offerContent, content),
                stickerType = when {
                    content.isHot == true -> {
                        "hot"
                    }
                    content.isNew == true -> {
                        "new"
                    }
                    else -> {
                        ""
                    }
                },
                translationType = content.translationType ?: "",
                viewablePeriod = getViewablePeriod(offerContent.productType ?: "", offerContent.rentalPeriod ?: ""),
                isExpand = isExpand,
                expandText = expandText,
                isDiscount = isDiscount,
                releaseYesar = "${content.releaseYear}년"
            )
        }
        else {
            display = Display(
                title = offerContent.title ?: "",
                ratingImageResource = R.drawable.age_15,
                genre = "GENRE",
                runningTime = "RUNNING_TIME",
                runTime = "RUNTIME",
                price = "${DecimalFormat("#,###").format(offerContent.price)}원",
                disPrice = DecimalFormat("#,###").format(offerContent.discountPrice),
                director = "DIRECTOR",
                actor = "ACTOR",
                synopsys = "SYNOPSYS",
                reviewRating = 0,
                isWish = true,
                imageUrl = "",
                eventType = "",
                stickerType = "",
                secondStickerType = "",
                translationType = "",
                viewablePeriod = "",
                isExpand = false,
                expandText = "",
                isDiscount = false,
                releaseYesar = "RELEASEYEAR"
            )
        }
        Logger.Log(Log.DEBUG, this, "display $display")

        return display
    }

    fun isValidCellPhoneNumber(cellphoneNumber: String): Boolean {
        var returnValue = false;
        try {
            val regex = "^\\s*(010|011|016|017|018|019)(-|\\)|\\s)*(\\d{3,4})(-|\\s)*(\\d{4})\\s*$";
            val p = Pattern.compile(regex);
            val m: Matcher = p.matcher(cellphoneNumber);
            if (m.matches()) {
                returnValue = true;
            }
            if (returnValue && cellphoneNumber.isNotEmpty() && cellphoneNumber.startsWith("010")) {
                val phoneNumber = cellphoneNumber.replace("-", "");
                if (phoneNumber.length != 11) {
                    returnValue = false;
                }
            }
            Logger.Log(Log.DEBUG, this, "isValidCellPhoneNumber returnValue: $returnValue")
            return returnValue;
        }
        catch (e: Exception) {
            return false;
        }
    }

    fun createLayoutParamsWithMargin(lId: Int, tId: Int, rId: Int, bId: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
        var lValue = 0
        var rValue = 0
        var tValue = 0
        var bValue = 0
        if (lId != R.dimen.none)
            lValue = CMBApp.getPixelSize(lId)
        if (rId != R.dimen.none)
            rValue = CMBApp.getPixelSize(rId)
        if (tId != R.dimen.none)
            tValue = CMBApp.getPixelSize(tId)
        if (bId != R.dimen.none)
            bValue = CMBApp.getPixelSize(bId)
        Logger.Log(Log.DEBUG, this, "tValue! : $tValue")
        Logger.Log(Log.DEBUG, this, "bValue! : $bValue")

        lp.setMargins(lValue, tValue, rValue, bValue)
        return lp
    }

    fun createLayoutParamsWithMargin(w: Int, h: Int, l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(w, h)
        lp.setMargins(l, t, r, b)
        return lp
    }

    fun createLoginHead(target: String): String {
        Logger.Log(Log.ERROR, this, "createLoginHead target $target");

        return when (target) {
            CategoryTarget.PAY_NORMAL -> "일반"
            CategoryTarget.PAY_SERIES -> "시리즈"
            CategoryTarget.PAY_MONTH -> "월정액"
            CategoryTarget.PAY_BUNDLE -> "묶음상품"
            CategoryTarget.PAY_ADULT -> "성인"
            CategoryTarget.WAT_ADULT -> "성인"
//            CategoryTarget.WAT_NORMAL -> "일반"
            CategoryTarget.WAT_NORMAL -> "시청 목록"
            CategoryTarget.FAV_ADULT -> "성인"
//            CategoryTarget.FAV_NORMAL -> "일반"
            CategoryTarget.FAV_NORMAL -> "찜 목록"
            CategoryTarget.EVENT -> "소식지"
            CategoryTarget.POINT_PURCHASE -> "포인트 구매"
            CategoryTarget.POINT_REGISTER -> "포인트 등록"
            CategoryTarget.POINT_HISTORY -> "포인트 내역"
            CategoryTarget.POINT_FAQ -> "이용안내"
            CategoryTarget.PIN_ADULT -> "성인 비밀번호 변경"
            else -> {
                "일반"
            }
        }
    }

    fun createLoginTitle(target: String): String {
        return when (target) {
            CategoryTarget.PAY_NORMAL,
            CategoryTarget.PAY_SERIES,
            CategoryTarget.PAY_BUNDLE -> "최근 콘텐츠 구매내역으로 최대 60일간 노출됩니다. \n구매 콘텐츠를 선택하여 OK 버튼을 누르면 시청, 구매, 삭제 하실 수 있습니다."
            CategoryTarget.PAY_ADULT -> "최근 구매한 성인 콘텐츠 목록으로 월정액을 제외한 모든 콘텐츠는 최대 60일간 노출됩니다.\n구매한 콘텐츠를 선택하여 OK 버튼을 누르면 시청, 구매, 삭제, 및 (월정액) 해지 하실 수 있습니다."
            CategoryTarget.PAY_MONTH -> "가입한 월정액 상품목록입니다.\n월정액 명을 선택하여 OK 버튼을 누르면 해지하실 수 있습니다."
            CategoryTarget.WAT_NORMAL -> "최근 콘텐츠 시청내역으로 최대 7일간 노출됩니다. \n시청 콘텐츠를 선택하여 OK 버튼을 누르면 시청, 구매, 삭제 하실 수 있습니다."
            CategoryTarget.WAT_ADULT -> "최근 성인 콘텐츠 시청내역으로 최대 7일간 노출됩니다. \n시청 콘텐츠를 선택하여 OK 버튼을 누르면 시청, 구매, 삭제 하실 수 있습니다."
            CategoryTarget.FAV_NORMAL,
            CategoryTarget.FAV_ADULT -> "관심있는 콘텐츠를 찜한 목록입니다.\n무제한으로 찜하기가 가능하며, 홈초이스에서 찜한 모든 콘텐츠를 한번에 확인하실 수 있습니다."
            CategoryTarget.POINT_PURCHASE -> "포인트를 구매하시면 보너스 포인트를 추가로 제공해 드립니다.\n포인트와 함께 콘텐츠를 더욱 편하게 즐겨 보세요!"
            CategoryTarget.POINT_REGISTER -> "수령하신 쿠폰의 인증번호를 입력하시면 포인트를 이용하실 수 있습니다."
            CategoryTarget.POINT_HISTORY -> "포인트 내역입니다. \n" + "항목 선택 시 상세한 내용을 확인하실 수 있습니다"
            CategoryTarget.PIN_ADULT -> "\n성인 비밀번호 변경을 위해 현재 성인 비밀번호를 입력해 주세요"
            else -> {
                "최근 콘텐츠 구매내역으로 최대 60일간 노출됩니다. \n구매 콘텐츠를 선택하여 OK 버튼을 누르면 시청, 구매, 삭제 하실 수 있습니다."
            }
        }
    }

    fun createEmptyDesc(target: String): String {
        return when (target) {
            CategoryTarget.PAY_MONTH -> "가입한 VOD가 없습니다.\n홈초이스에서 다양한 유료 VOD들을 즐겨 보세요!"
            else -> "구매한 VOD가 없습니다.\n홈초이스에서 다양한 유료 VOD들을 즐겨 보세요!"
        }
    }

    fun createLoginBody(target: String): String {
        return when (target) {
            CategoryTarget.PAY_NORMAL,
            CategoryTarget.PAY_SERIES,
            CategoryTarget.PAY_BUNDLE,
            CategoryTarget.PAY_ADULT -> "구매목록은 로그인 후 확인하실 수 있습니다."
            CategoryTarget.PAY_MONTH -> "가입목록은 로그인 후 확인하실 수 있습니다."
            CategoryTarget.WAT_ADULT -> "시청목록은 로그인 후 확인하실 수 있습니다."
            CategoryTarget.WAT_NORMAL -> "시청목록은 로그인 후 확인하실 수 있습니다."
            CategoryTarget.POINT_PURCHASE -> "포인트 구매는 로그인 후 이용하실 수 있습니다."
            CategoryTarget.POINT_REGISTER -> "포인트 등록은 로그인 후 이용하실 수 있습니다."
            CategoryTarget.POINT_HISTORY -> "포인트 내역은 로그인 후 이용하실 수 있습니다."
            CategoryTarget.FAV_NORMAL,
            CategoryTarget.FAV_ADULT -> "찜목록은 로그인 후 확인하실 수 있습니다."
            CategoryTarget.PIN_ADULT -> "성인 비밀번호 변경은 로그인 후 이용하실 수 있습니다."
            else -> {
                "구매목록은 로그인 후 확인하실 수 있습니다."
            }
        }
    }

    fun getGroupType(target: String): String {
        return when (target) {
            CategoryTarget.PAY_NORMAL -> "normal"
            CategoryTarget.PAY_SERIES -> "series"
            CategoryTarget.PAY_BUNDLE -> "package"
            CategoryTarget.PAY_MONTH -> "subscribe"
            else -> "normal"
        }
    }

    fun createPaymentTypeStr(paymentType: String): String {
        return when (paymentType) {
            "easy" -> "간편결제"
            "app" -> "앱카드"
            "phone" -> "휴대폰"
            "complex" -> "복합결제"
            "point" -> "포인트결제"
            else -> ""
        }
    }

    fun createProductTypeStr(productType: String, packageType: String): String {
        return when (productType) {
            "subscription" -> "월정액"
            "rent" -> {
                when (packageType) {
                    "package" -> "묶음상품"
                    "series" -> "시리즈"
                    else -> "일반"
                }
            }
            "buy" -> "소장"
            else -> ""
        }
    }

    fun createPurchaseLogBtnName(productType: String): String {
        Logger.Log(Log.DEBUG, this, "createPurchaseLogBtnName productType $productType")
        return when (productType) {
            "subscription" -> "해지"
            else -> {
                "삭제"
            }
        }
    }

    fun createViewablePeriod(productType: String, viewablePeriod: String): String {
        lateinit var description: String
        when (productType) {
            ProductType.SUBSCRIPTION -> {
                description = "해지 시까지 시청"
            }
            ProductType.BUY -> {
                description = "무제한 시청"
            }
            ProductType.RENT -> {
                description = "${viewablePeriod}간 시청"
            }
        }
        return description
    }

    fun createToast(context: Context, message: String): Toast {
        val inflater = LayoutInflater.from(context)
        val binding: ToastLayoutBinding = ToastLayoutBinding.inflate(inflater, null, false)

        binding.tvSample.text = message

        return Toast(context).apply {
            setGravity(Gravity.BOTTOM or Gravity.CENTER, 0, 20)
            duration = Toast.LENGTH_SHORT
            view = binding.root
        }
    }

    fun createProductHead(offerContent: OfferContent): String {
        return if (offerContent.productType == ProductType.SUBSCRIPTION) {
            val translationType = when (offerContent.contentList[0].translationType) {
                TranslationType.NOR -> "(일반)"
                TranslationType.SUB -> "(자막)"
                TranslationType.DUB -> "(더빙)"
                TranslationType.ENSUB -> "(자막)"
                else -> ""
            }
            "${offerContent.title}${translationType}"
        }
        else {
            val rentalType = when (offerContent.productType) {
                ProductType.RENT -> "단편"
                ProductType.BUY -> "소장"
                else -> ""
            }
            val translationType = when (offerContent.contentList[0].translationType) {
                TranslationType.NOR -> "(일반)"
                TranslationType.SUB -> "(자막)"
                TranslationType.DUB -> "(더빙)"
                TranslationType.ENSUB -> "(자막)"
                else -> ""
            }
            if (offerContent.packageType == PackageType.SERIES) {
                "시리즈${translationType}"
            }
            else {
                "$rentalType${translationType}"
            }
        }
    }

    fun createProductHead(offer: Offer): String {
        return if (offer.productType == ProductType.SUBSCRIPTION) {
            "${offer.title}"
        }
        else {
            val rentalType = when (offer.productType) {
                ProductType.RENT -> "단편"
                ProductType.BUY -> "소장"
                else -> ""
            }
            if (offer.packageType == PackageType.SERIES) {
                "시리즈"
            }
            else {
                "$rentalType"
            }
        }
    }

    fun fragmentTransaction(activity: AppCompatActivity, layoutId: Int, fragment: Fragment, tag: String) {
        activity.supportFragmentManager.beginTransaction().replace(layoutId, fragment, tag).commit()
    }

    fun showPopup(ctx: Context, code: Int, retryCallback: RetryCallback?) {
        if (code == CODE.CONFLICT) {

            PopupAgent.showLoginPopup(context = ctx, login = Login(forceLogin = true, loginqr = null), event = object : LoginPopupEvent {
                override fun onLogin(loginDialog: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.SUCCESS -> {
                            retryCallback?.call()
                        }
                    }
                }
            })
        } else {

            PopupAgent.showNormalPopup(
                ctx,
                PopupType.getErrorType(TYPE.DEFAULT, code),
                object : PopupEvent {
                    override fun onClick(errorDialog: Dialog, btn: String) {
                        when (btn) {
                            BtnLabel.OK -> {
                                errorDialog.dismiss()
                            }
                        }
                    }
                })
        }
    }

//    fun showPopupGoToHome(ctx: Context, code: Int, isAdultContent: Boolean, retryCallback: AdultRetryCallback?) {
//        if (code == CODE.CONFLICT) {
//
//            PopupAgent.showLoginPopup(context = ctx, login = Login(forceLogin = true, loginqr = null), event = object : LoginPopupEvent {
//                override fun onLogin(loginDialog: Dialog, btn: String) {
//                    when (btn) {
//                        BtnLabel.SUCCESS -> {
//                            if(isAdultContent){
//                                retryCallback?.navigateToHome()
//                            }
//                            retryCallback?.call()
//                        }
//                    }
//                }
//            })
//        } else {
//
//            PopupAgent.showNormalPopup(
//                ctx,
//                PopupType.getErrorType(TYPE.DEFAULT, code),
//                object : PopupEvent {
//                    override fun onClick(errorDialog: Dialog, btn: String) {
//                        when (btn) {
//                            BtnLabel.OK -> {
//                                errorDialog.dismiss()
//                            }
//                        }
//                    }
//                })
//        }
//    }

    fun showPopupForMyMenu(ctx: Context, code: Int, retryCallback: RetryCallback?) {
        if (code == CODE.CONFLICT) {
            STBAgent.init()
        }
        PopupAgent.showNormalPopup(
            ctx,
            PopupType.getErrorType(TYPE.DEFAULT, code),
            object : PopupEvent {
                override fun onClick(errorDialog: Dialog, btn: String) {
                    if (code == CODE.CONFLICT) {
                        when (btn) {
                            BtnLabel.OK -> {
                                // MY 메뉴 로그인 메뉴로 이동
                                retryCallback?.call()
                                errorDialog.dismiss()
                            }
                            BtnLabel.CANCEL -> {
                                retryCallback?.cancel()
                                errorDialog.dismiss()
                            }
                        }
                    }
                    else {
                        when (btn) {
                            BtnLabel.OK -> {
                                errorDialog.dismiss()
                            }
                        }
                    }
                }
            })
    }

    fun createViewablePeriodStr(productType: String, viewablePeriod: String): String {
        return when (productType) {
            ProductType.SUBSCRIPTION -> {
                "해지시까지"
            }
            else -> viewablePeriod
        }
    }

    fun getProductPrice(productType: String, offerList: List<Offer>): Int {
        var price = 0
        for (item in offerList) {
            if (item.packageType == productType) {
                price = item.price!!
                break
            }
        }
        if (price == 0 && offerList.isNotEmpty())
            offerList[0].price

        return price
    }

    fun hasSpecialText(s: String): Boolean {
        val pattern = "^[ㄱ-ㅎ가-힣a-zA-Z0-9]*$"
        val result: String = s.trim().replace(" ", "")
        return !Pattern.matches(pattern, result)
    }

    fun createEnterPath(type: String, id: Long): String {
        return "$type,$id"
    }

}