package com.homechoice.ott.vod.ui.popup.play

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.KeyEvent
import android.view.LayoutInflater
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogPlayContinueBinding
import com.homechoice.ott.vod.ui.popup.PopupEvent

class ContinuePopupView(ctx: Context, event: PopupEvent) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {

    private var binding: DialogPlayContinueBinding

    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        binding = DialogPlayContinueBinding.inflate(LayoutInflater.from(ctx))

        setContentView(binding.root)

        binding.btnContinue.setOnClickListener {
            event.onClick(this, (it as TextView).text.toString())
        }

        binding.btnFirst.setOnClickListener {
            event.onClick(this, (it as TextView).text.toString())
        }

        binding.btnCancel.setOnClickListener {
            event.onClick(this, (it as TextView).text.toString())
        }

        setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                    }
                }
            }
            false
        }

        binding.btnContinue.requestFocus()
    }
}