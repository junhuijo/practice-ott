package com.homechoice.ott.vod.ui.screens.home.dialogs

import KeypadLayout
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.ActivityChangeAgent
import com.homechoice.ott.vod.ui.screens.home.HomeViewModel

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun HomeAdultVerificationDialog(
    viewModel: HomeViewModel = viewModel()
) {
    val alertMessage by viewModel.alertMessage.collectAsState()
    val popupState by viewModel.popupState.collectAsState()
    val context = LocalContext.current

    Dialog(
        onDismissRequest = {
            viewModel.clearInputPassword()
            viewModel.clearAlertMessage()
            viewModel.showAdultPasswordDialog(false) },
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    color = colorResource(R.color.dialog_background),
                )
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    HomeAdultVerificationTitleBar()
                    Spacer(modifier = Modifier.height(50.dp))
                    Row {
                        KeypadLayout(
                            onInputClick = { char -> viewModel.inputPassword(char) },
                            onDeleteClick = { viewModel.deletePassword() },
                            onConfirmClick = { viewModel.checkPassword() })
                        Spacer(modifier = Modifier.width(80.dp))
                        PasswordInputLayout(alertMessage = alertMessage, viewModel = viewModel)
                    }
            }
        }
    }

    PopupHandler(
        popupState = popupState,
        onDismiss = {
            viewModel.dismissPopup()
            viewModel.showAdultPasswordDialog(false)
        },
        onConflictLogin = {
            viewModel.onConflictLogin(
                context,
                onDismiss = { viewModel.dismissPopup() }
        ) },
    )
}

@Composable
private fun HomeAdultVerificationTitleBar() {
    Box(
        modifier = Modifier
            .width(dimensionResource(R.dimen.screen_title_bar_width))
            .height(dimensionResource(R.dimen.screen_title_bar_height))
            .background(
                color = colorResource(R.color.kids_lock_notification_text),
                shape = RoundedCornerShape(dimensionResource(R.dimen.corner_radius))
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = stringResource(R.string.adult_verification_title),
            style = TextStyle(
                fontSize = 26.sp,
                color = colorResource(R.color.kids_lock_text)
            )
        )
    }
}

@Composable
private fun PasswordInputLayout(
    alertMessage: HomeViewModel.HomeAlertMessage?,
    viewModel: HomeViewModel,
) {
    val passwordInputSpacing = 10.dp
    var isFocused by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .width(360.dp)
            .padding(top = 10.dp)
            .onFocusChanged {
                isFocused = it.isFocused
            }
            .focusable(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.adult_verification_content1),
            modifier = Modifier.padding(bottom = 12.dp),
            style = TextStyle(
                fontSize = 20.sp,
                color = colorResource(R.color.kids_lock_text),
                textAlign = TextAlign.Center,
            )
        )
        Text(
            text = buildAnnotatedString{
                val fullText = stringResource(R.string.adult_verification_content2)
                val underlineText = "성인 확인 비밀번호"
                val startIndex = fullText.indexOf(underlineText)
                val endIndex = startIndex + underlineText.length

                append(fullText.substring(0, startIndex))
                withStyle(style = SpanStyle(textDecoration = TextDecoration.Underline)) {
                    append(underlineText)
                }
                append(fullText.substring(endIndex))
            },
            modifier = Modifier.padding(bottom = 14.dp),
            style = TextStyle(
                fontSize = 16.sp,
                color = colorResource(R.color.kids_lock_text),
                textAlign = TextAlign.Center,
            )
        )
        Text(
            text = stringResource(R.string.adult_password_setting_content4),
            modifier = Modifier
                .padding(top = 6.dp),
            style = TextStyle(
                fontSize = 14.sp,
                color = colorResource(R.color.kids_lock_text),
                textAlign = TextAlign.Center,
                lineHeight = 36.sp
            )
        )
        Column(
            modifier = Modifier
                .padding(top = 20.dp, bottom = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            PasswordInputFields(passwordInputSpacing, viewModel)
            AlertHomeMessageDisplay(alertMessage)
            ResetHomeAdultPassword(viewModel = viewModel, isFocused = isFocused)
        }
    }
}

@Composable
fun ResetHomeAdultPassword(
    viewModel: HomeViewModel,
    modifier: Modifier = Modifier,
    isFocused: Boolean
) {
    val context = LocalContext.current

    Box(
        modifier = modifier
            .border(
                width = 1.dp,
                color = if (isFocused) Color.Red else Color.Transparent,
                shape = RoundedCornerShape(4.dp)
            )
            .padding(8.dp)
            .focusable()
            .clickable {
                ActivityChangeAgent.goToAdultPasswordSettingMenu(context)
                viewModel.clearInputPassword()
                viewModel.clearAlertMessage()
            }
    ) {
        Text(
            text = stringResource(R.string.adult_password_setting_button),
            color = Color.White,
            fontSize = 14.sp,
            textDecoration = TextDecoration.Underline,
            textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.Center)
        )
    }
}

@Composable
private fun PasswordInputFields(
    spacing: Dp,
    viewModel: HomeViewModel
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(spacing)
    ) {
        repeat(4) {index ->
            PasswordInputField(
                index = index,
                viewModel = viewModel
            )
        }
    }
}

@Composable
private fun PasswordInputField(
    index: Int,
    viewModel: HomeViewModel
) {
    val inputText = if (index < viewModel.inputPassword.size) "*" else ""

    Box(
        modifier = Modifier
            .width(56.dp)
            .height(56.dp)
            .background(
                color = Color.White,
                shape = RoundedCornerShape(dimensionResource(R.dimen.icon_corner_radius))
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = inputText,
            style = TextStyle(
                fontSize = 30.sp,
                color = Color.Black
            )
        )
    }
}

@Composable
fun AlertHomeMessageDisplay(message: HomeViewModel.HomeAlertMessage?) {
    val context = LocalContext.current
    val messageText = when (message) {
        HomeViewModel.HomeAlertMessage.IsAdultContentAccessible -> stringResource(R.string.adult_verification_message_on)
        HomeViewModel.HomeAlertMessage.PasswordMismatch -> stringResource(R.string.kids_lock_message_pw_mismatch)
        HomeViewModel.HomeAlertMessage.InvalidPasswordFormat -> stringResource(R.string.kids_lock_message_pw_invalid_format)
        null -> ""
    }

    val text = messageText.ifEmpty { stringResource(R.string.adult_verification_instruction) }

    Text(
        text = text,
        modifier = Modifier
            .width(300.dp)
            .padding(top = 28.dp, bottom = 18.dp)
            .background(Color.Transparent),
        style = TextStyle(
            fontSize = 18.sp,
            color = if (messageText.isNotEmpty()) colorResource(R.color.kids_lock_notification_text) else Color.White,
            textAlign = TextAlign.Center
        )
    )
}

@Composable
fun PopupHandler(
    popupState: HomeViewModel.PopupState,
    onDismiss: () -> Unit,
    onConflictLogin: () -> Unit
) {
    when (popupState) {
        is HomeViewModel.PopupState.Error -> {
            CustomAlertDialog(
                onDismissRequest = onDismiss,
                title = popupState.type.head,
                message = popupState.type.body.ifEmpty { popupState.type.defaultBody },
                confirmButtonText = popupState.type.btns.firstOrNull()?.label ?: "확인",
                onConfirmClick = onDismiss
            )
        }
        HomeViewModel.PopupState.Conflict -> {
            CustomAlertDialog(
                onDismissRequest = onDismiss,
                title = "로그아웃 안내",
                message = "다른 기기에서 로그인 되어 연결이 종료되었습니다.\n재 로그인 하시겠습니까?",
                confirmButtonText = "로그인",
                onConfirmClick = onConflictLogin,
                dismissButtonText = "취소",
                onDismissClick = onDismiss
            )
        }
        HomeViewModel.PopupState.None -> {
            // 팝업 생략
        }
    }
}

@Composable
fun CustomAlertDialog(
    onDismissRequest: () -> Unit,
    title: String,
    message: String,
    confirmButtonText: String,
    onConfirmClick: () -> Unit,
    dismissButtonText: String? = null,
    onDismissClick: (() -> Unit)? = null
) {
    var cancelBtnBorderColor by remember { mutableStateOf(Color.DarkGray) }
    var confirmBtnBorderColor by remember { mutableStateOf(Color.DarkGray) }
    val cancelBtnFocusRequester = remember { FocusRequester() }
    val confirmBtnFocusRequester = remember { FocusRequester() }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Card(
            modifier = Modifier
                .width(360.dp)
                .height(220.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(dimensionResource(R.dimen.dialog_radius)),
            colors = CardDefaults.cardColors(
                containerColor = colorResource(R.color.quit_app_dialog_bg)
            ),
            border = BorderStroke(dimensionResource(R.dimen.border_width), colorResource(R.color.dialog_border3))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = title,
                    modifier = Modifier.padding(top = 12.dp, bottom = 22.dp),
                    style = TextStyle(
                        fontSize = 16.sp,
                        color = Color.White
                    )
                )
                Text(
                    text = message,
                    modifier = Modifier.padding(bottom = 26.dp),
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = if (onDismissClick != null) Arrangement.SpaceBetween else Arrangement.Center,
                ) {
                    TextButton(
                        onClick = onConfirmClick,
                        shape = RoundedCornerShape(dimensionResource(R.dimen.dialog_radius)),
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(confirmBtnFocusRequester)
                            .onFocusChanged {
                                confirmBtnBorderColor =
                                    if (it.hasFocus) Color.Red else Color.DarkGray
                            }
                            .focusable(),
                        contentPadding = PaddingValues(0.dp),
                        border = BorderStroke(dimensionResource(R.dimen.border_width), confirmBtnBorderColor)
                    ) {
                        Text(
                            text = confirmButtonText,
                            style = TextStyle(fontSize = 14.sp, color = Color.White)
                        )
                    }
                    if (onDismissClick != null) {
                        Spacer(modifier = Modifier.width(16.dp))
                        TextButton(
                            onClick = onDismissClick,
                            shape = RoundedCornerShape(dimensionResource(R.dimen.dialog_radius)),
                            modifier = Modifier
                                .weight(1f)
                                .focusRequester(cancelBtnFocusRequester)
                                .onFocusChanged {
                                    cancelBtnBorderColor =
                                        if (it.hasFocus) Color.Red else Color.DarkGray
                                }
                                .focusable(),
                            colors = ButtonDefaults.textButtonColors(contentColor = Color.Transparent),
                            contentPadding = PaddingValues(0.dp),
                            border = BorderStroke(dimensionResource(R.dimen.border_width), cancelBtnBorderColor)
                        ) {
                            Text(
                                text = dismissButtonText ?: "취소",
                                style = TextStyle(fontSize = 14.sp, color = Color.White)
                            )
                        }
                    }
                }
            }
            LaunchedEffect(Unit) {
                confirmBtnFocusRequester.requestFocus()
            }
        }
    }
}