package com.homechoice.ott.vod.ui.custom

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.KeyEvent
import com.homechoice.ott.vod.ui.my.member.MemberLoginViewModel
import com.homechoice.ott.vod.util.Logger

class CustomEditTextView : androidx.appcompat.widget.AppCompatEditText {

    private var listener: MemberLoginViewModel.ModelListener? = null

    constructor(ctx: Context) : super(ctx) {
    }

    constructor(ctx: Context, attrs: AttributeSet) : super(ctx, attrs) {
    }

    fun setModelListener(listener: MemberLoginViewModel.ModelListener) {
        this.listener = listener
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
//        Logger.Log(Log.DEBUG, this, "CustomEditTextView onKeyDown keyCode $keyCode / event : ${event?.action} / view.id ${this.id}")
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyPreIme(keyCode: Int, event: KeyEvent?): Boolean {
        Logger.Log(Log.DEBUG, this, "CustomEditTextView keyCode $keyCode / event : ${event?.action} / view.id ${this.id}")
        if (event?.action == KeyEvent.ACTION_DOWN) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_BUTTON_B) {
                this.listener?.hideIME()
            }
        }
        return super.onKeyPreIme(keyCode, event)
    }
}