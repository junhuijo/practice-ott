package com.homechoice.ott.vod.util

import android.annotation.SuppressLint
import android.util.Log
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class StringUtil private constructor() {
    companion object {
        @Volatile
        private var instance: StringUtil? = null

        @JvmStatic
        fun getInstance(): StringUtil =
            instance ?: synchronized(this) {
                instance ?: StringUtil().also {
                    instance = it
                }
            }
    }

    fun getSecondStr(value: String?): Int? {
        // 00:00:10:00
        val stars = value?.split(":")
        val ss = stars?.get(2)?.let { Integer.parseInt(it) }
        val mm = stars?.get(1)?.let { Integer.parseInt(it) }?.times(60)
        val hh = stars?.get(0)?.let { Integer.parseInt(it) }?.times(3600)
        return ss?.plus(mm!!)?.plus(hh!!)
    }

    fun getTimeStr(value: Int): String {
        var min = (value / 60)
        val hourStr = if ((min / 60) < 10) "0${(min / 60)}" else "${(min / 60)}"
        val secStr = if ((value % 60) < 10) "0${(value % 60)}" else "${(value % 60)}"
        min %= 60
        val minStr = if (min < 10) "0${min}" else "$min"
        return "$hourStr:$minStr:$secStr"
    }

    @SuppressLint("SimpleDateFormat")
    fun getStartDate(): String {
        val cal = Calendar.getInstance()
        cal.time = Date()
        val df: DateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
        Logger.Log(Log.DEBUG, this, "getStartDate ${df.format(cal.time)}")
        return df.format(cal.time)
    }

    @SuppressLint("SimpleDateFormat")
    fun getStartDate(pattern: String): String {
        val cal = Calendar.getInstance()
        cal.time = Date()
        val df: DateFormat = SimpleDateFormat(pattern)
        Logger.Log(Log.DEBUG, this, "getStartDate ${df.format(cal.time)}")
        return df.format(cal.time)
    }

    @SuppressLint("SimpleDateFormat")
    fun getEndDate(month: Int, date: Int): String {
        val cal = Calendar.getInstance()
        cal.time = Date()
        val df: DateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
        cal.add(Calendar.MONTH, month)
        cal.add(Calendar.DATE, date)
        Logger.Log(Log.DEBUG, this, "getEndDate ${df.format(cal.time)}")
        return df.format(cal.time)
    }

    @SuppressLint("SimpleDateFormat")
    fun getPurchaseDate(source: String): String {
        Logger.Log(Log.DEBUG, this, "getPurchaseDate : $source")
        val newDf: DateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val date = newDf.parse(source)

        val df: DateFormat = SimpleDateFormat("MM'월' dd'일('E')' HH:mm")
        return df.format(date.time)
    }

    @SuppressLint("SimpleDateFormat")
    fun getPointHistoryDate(source: String): String {
        Logger.Log(Log.DEBUG, this, "getPointHistoryDate : $source")
        val newDf: DateFormat = SimpleDateFormat("yyyy-MM-dd")
        val date = newDf.parse(source)

        val df: DateFormat = SimpleDateFormat("MM'월' dd'일('E')'")
        return df.format(date.time)
    }

    @SuppressLint("SimpleDateFormat")
    fun getPointPopupDate(source: String): String {
        Logger.Log(Log.DEBUG, this, "getPointHistoryDate : $source")
        val newDf: DateFormat = SimpleDateFormat("yyyy-MM-dd")
        val date = newDf.parse(source)

        val df: DateFormat = SimpleDateFormat("yyyy-MM-dd")
        return df.format(date.time)
    }

}