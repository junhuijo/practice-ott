package com.homechoice.ott.vod.ui.navigation.navigator

class KeyPadNavigator(currentIndex: Int, pageStartIndex: Int, totalSize: Int, pageSize: Int, callback: Callback) :
    PageNavigatorModel(currentIndex, pageStartIndex, totalSize, pageSize, callback) {

    fun up() {
        if(this.currentIndex - this.pageSize >= 0) {
            val previousIndex = this.currentIndex
            this.currentIndex = this.currentIndex - this.pageSize
            this.pageStartIndex -= this.pageSize
            callback.focusChanged(previousIndex , this.currentIndex , this.pageStartIndex)
        }
    }

    fun down(){
        if(this.currentIndex + this.pageSize < this.totalSize){
            val previousIndex = this.currentIndex
            this.currentIndex = this.currentIndex + this.pageSize
            this.pageStartIndex += this.pageSize
            callback.focusChanged(previousIndex , this.currentIndex , this.pageStartIndex)
        }
    }

    override fun right() {
        if(this.currentIndex < this.pageStartIndex + this.pageSize) {
            super.right()
        }
    }

    override fun left() {
        if(this.currentIndex > this.pageStartIndex) {
            super.left()
        }
    }

}