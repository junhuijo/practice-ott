package com.homechoice.ott.vod.model.request

data class RequestPointNoticeConfirm(
    val terminalKey: String
)
