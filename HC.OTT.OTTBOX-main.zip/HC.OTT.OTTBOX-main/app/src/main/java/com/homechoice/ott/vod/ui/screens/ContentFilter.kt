package com.homechoice.ott.vod.ui.screens

import com.homechoice.ott.vod.agent.ContentType
import com.homechoice.ott.vod.agent.HomeScreens
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.model.CategoryList

object ContentFilter {
    fun isAdultUser(): Boolean {
        val isAdult = STBAgent.userAge >= 19
        if (STBAgent.userAge != 0 && !isAdult) {
            STBAgent.isAdultAuth = false
            STBAgent.includeRrated = false
        }
        return isAdult
    }

    fun isSpecificMsoName(): Boolean {
        return STBAgent.msoName == "서경방송" || STBAgent.msoName == "JCN울산중앙방송"
    }

    // 콘텐츠 필터링
    private fun filterAdultContent(categories: List<CategoryList>): List<CategoryList> {
        return categories.map { category ->
            category.copy(
                categoryItemList = category.categoryItemList.filter { item ->
                    item.rating?.contains(ContentType.ADULT_RATING) != true
                }
            )
        }
    }

    fun filterContentIfNeeded(
        categories: List<CategoryList>,
        isKidsLockEnabled: Boolean
    ): List<CategoryList> {
        // 미성년자
        if (STBAgent.userAge != 0 && !isAdultUser()) {
            return filterAdultContent(categories)
        }

        // 성인
        return if (isKidsLockEnabled) {
            filterAdultContent(categories)
        } else {
            categories
        }
    }

    // 업데이트
    fun updateFilteredContentAndState(
        originalContent: List<CategoryList>,
        isKidsLockEnabled: Boolean,
        currentScreen: HomeScreens,
        updateFilteredContent: (List<CategoryList>) -> Unit,
        updateUiState: (List<CategoryList>, HomeScreens) -> Unit
    ) {
        val filteredContent = filterContentIfNeeded(originalContent, isKidsLockEnabled)
        updateFilteredContent(filteredContent)
        updateUiState(filteredContent, currentScreen)
    }
}

//interface Filterable {
//    val rating: String?
//    val categoryItemList: List<Filterable>
//}