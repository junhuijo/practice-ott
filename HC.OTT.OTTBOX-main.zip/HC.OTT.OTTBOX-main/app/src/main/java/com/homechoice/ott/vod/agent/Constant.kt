package com.homechoice.ott.vod.agent

import android.content.Context
import android.graphics.Color
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.io.PVSClient
import com.homechoice.ott.vod.io.RetrofitClient

object Home {
    var CATEGORY_ID: String = "HOME_CATEGORY_ID"
    var CATEGORY_FOCUS: String = "HOME_CATEGORY_FOCUS"
    var CATEGORY_LIST: String = "HOME_CATEGORY_LIST"
    var CONTENT_LIST: String = "HOME_CONTENT_LIST"
    var TOP_CATEGORY_LIST: String = "HOME_TOP_CATEGORY_LIST"
    var CURRENT_CATEGORY_INDEX: String = "CURRENT_CATEGORY_INDEX"
    var CURRENT_CATEGORY_START_INDEX: String = "CURRENT_CATEGORY_START_INDEX"
    var CURRENT_CATEGORY_VISIBLE_INDEX: String = "CURRENT_CATEGORY_VISIBLE_INDEX"
    var CURRENT_CATEGORY_IS_EMPTY: String = "CURRENT_CATEGORY_IS_EMPTY"
    var OFFER_ID: String = "OFFER_ID"
    var OFFER_CONTENT: String = "OFFER_CONTENT"
    var ENTER_PATH: String = "enterPath"
}

object Name {
    const val CONTENT_GROUP = "contentGroup"
    const val ENTER_PATH = "enterPath"
}

object TagName {
    var HOME_CATEGORY_LIST: String = "HomeCategoryList"
    var HOME_CATEGORY: String = "HomeCategory"
    var HOME_BANNER: String = "HomeBanner"
    var HOME_CONTENT_GROUP_LIST: String = "HomeContentGroupListFragment"
    var SUB_MAIN_CATEGORY: String = "SubMainCategoryListFragment"
    var SUB_TOP_CATEGORY: String = "SubTopCategoryListFragment"
    var SUB_CONTENT: String = "SubContentListFragment"
    var SUB_LOGIN: String = "MemberLoginFragment"
}

object Constant {
    var ACTION_EVENT_TYPE: ActionEventType = ActionEventType()

    var appMode = ""
    var appCode = CMBApp.RES.getString(R.string.app_code)
    var pvsAppCode = CMBApp.RES.getString(R.string.pvs_app_code)
    var userCategoryId = CMBApp.RES.getString(R.string.user_category_id)
    var devMode = false
    //필요없는 url제거
    fun init(context: Context, mode: String, code: String) {
        appMode = mode
        appCode = code
        val res = context.resources
        var resourceId: Int = 0
        when (appMode) {
            "local" -> {
                resourceId = R.array.local
            }
            "debug" -> {
                resourceId = R.array.debug
            }
            "dev" -> {
                resourceId = R.array.dev
            }
            "prod" -> {
                resourceId = R.array.prod
            }
        }
        val infos = res.getStringArray(resourceId)
        RetrofitClient.init(infos[0]) //mbs
        PVSClient.init(infos[1]) //pvs
        STBAgent.macAddress = infos[2] //mac address

//        devMode = (appMode == "dev")
    }

    fun isLiveMode(): Boolean {
        return appMode.indexOf("live") > -1
    }
}

enum class HomeCategoryType(type: String) {
    ASSET("ASSET"),
    CATEGORY("CATEGORY"),
    MAINBANNER("MAINBANNER"),
    MIDBANNER("MIDBANNER"),
    QUICKMENUGROUP("QUICKMENUGROUP"),
    ADULT("ADULT"),
    NONE("NONE")
}

enum class HomeContentFocusType {
    LEFT, CENTER, RIGHT
}

data class ActionEventType(
    var HOME: HomeActionType = HomeActionType()
)

data class HomeActionType(
    var CATEGORY: Int = 0,
    var CONTENT: Int = 1,
    var CATEGORY_UP: Int = 2,
    var CATEGORY_DOWN: Int = 3,
    var CONTENT_UP: Int = 4,
    var CONTENT_DOWN: Int = 5,
    var INIT: Int = 6
)

object StickerType {
    const val NEW = "new"
    const val HOT = "hot"
    const val AUDIO_VISUAL = "audioVisual"
    const val DISCOUNT = "discount"
}

object PwReplace {
    const val PURCHASE = "payment"
    const val ADULT = "adult"
}

object EventType {
    const val NOWING: String = "nowing"
    const val FIRST: String = "1st"
    const val SALE: String = "sale"
    const val MONOFOLY: String = "monopoly"
}

object TranslationType {
    const val DUB = "dub"
    const val SUB = "sub"
    const val NOR = "nor"
    const val ENSUB = "enSub"
}

object PackageType {
    const val SERIES = "series"
    const val SINGLE = "single"
    const val PACKAGE = "package"
}

object SessionState {
    const val CONNECT = "connect"
    const val LOGIN = "login"
    const val LOGOUT = "logout"
    const val FORCE_LOGOUT = "forceLogout"
}

object EnterPath {
    const val BANNER = "banner"
    const val PUSH_POPUP = "push_popup"
    const val NOTICE = "notice"
    const val EVENT = "event"
    const val RECOMMEND = "recommend"
    const val PACKAGE_OFFER = "package_offer"
    const val RECOMMEND_FOR_SEARCH = "recommend_for_search"
    const val SEARCH = "search"
    const val PURCHASE_LOG = "purchase_log"
    const val SERVICE_LOG = "service_log"
    const val WISH_ITEM = "wish_item"
    const val EXTERNAL = "external"
    const val MAIN_CATEGORY = "main_category"
    const val SUB_CATEGORY = "sub_category"
    const val UNDEFINED = "undefined"
    const val POINT_LOG = "point_log"
}

object ProductType {
    const val RENT = "rent"
    const val BUY = "buy"
    const val SUBSCRIPTION = "subscription"
}

object CategoryItemType {
    const val CATEGORY = "category"
    const val CONTENTGROUP = "contentGroup"
    const val SERIES = "series"
    const val BANNER = "banner"
    const val QUICKMENU = "quickMenu"
    const val PACKAGE_OFFER = "packageOffer"
    const val PACKAGE = "package"
}

object PointType {
    const val ISSUE = "issue" //발급
    const val PUBLISH = "publish" //발행
    const val POINT_PRODUCT = "point_product" //충전
    const val VOD_MILEAGE = "vod_mileage" //적립(VOD 구매)
    const val PRODUCT_MILEAGE = "product_mileage" //적립(포인트 상품 구매)
    const val EXPIRED_POINT = "expired_point" //유효기간 만료
    const val PAYMENT_VOD = "payment_vod" //사용
    const val CANCEL_POINT_PRODUCT = "cancel_point_product" //충전 취소
    const val CANCEL_VOD_MILEAGE = "cancel_vod_mileage" //적립취소 (VOD 구매)
    const val CANCEL_PRODUCT_MILEAGE = "cancel_product_mileage" // 적립 취소(포인트 상품)
    const val CANCEL_PAYMENT_VOD = "cancel_payment_vod" //사용 취소
}

object ContentType {
    const val ADULT_RATING = "19"
    const val ADULT_PLUS_GENRE = "성인"
}

enum class CustomColor(private val r: Int, private val g: Int, private val b: Int) {
    BTN_TEXT_FOCUS(180, 192, 47),
    BTN_TEXT_UNFOCUS(169, 169, 169),
    CATEGORY_TEXT_FOCUS(184, 188, 236),
    CATEGORY_TEXT_UNFOCUS(166, 166, 166),
    CATEGORY_CONTENT_FOCUS(117, 117, 117),
    CATEGORY_TEXT_SELECT(135, 139, 179);

    fun rgb(): Int {
        return Color.rgb(r, g, b)
    }


}

object Auth {

    const val  AuthLocalDevServerUri : String = "ws://192.168.45.202:5926/ws"
//    const val  AuthLocalDevServerUri : String = "ws://172.17.12.51:5926/ws"
    const val  AuthServerUri : String = "wss://prod-auth.homechoice.co.kr/ws"
}

enum class HomeScreens {
    Main, Cp, Category, CategoryAdult, AdultQr, AdultQrFail
}

enum class Categories {
    Movie, BroadCast, OverseasDrama, KidAnime, Life, Documentary, Adult
}

enum class ContentsProvider {
    Cp,
//    Adult
}

sealed class CategoryWrapper {
    data class RegularCategory(val category: Categories) : CategoryWrapper()
    data class CpCategory(val contentsProvider: ContentsProvider) : CategoryWrapper()

//    data class AdultCategory(val contentsProvider: ContentsProvider) : CategoryWrapper()
}
