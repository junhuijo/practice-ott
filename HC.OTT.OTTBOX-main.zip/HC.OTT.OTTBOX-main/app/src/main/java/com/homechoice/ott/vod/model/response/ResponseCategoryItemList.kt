package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.CategoryItem
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseCategoryItemList(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val totalCount: Int,
    var categoryItemList: List<CategoryItem>
) : Parcelable