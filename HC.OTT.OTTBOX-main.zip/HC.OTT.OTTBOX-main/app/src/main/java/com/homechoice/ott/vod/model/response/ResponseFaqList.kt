package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.notice.FAQ
import kotlinx.android.parcel.Parcelize

@Parcelize
class ResponseFaqList (
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val totalCount : Int,
    val faqList : List<FAQ>
): Parcelable
