package com.homechoice.ott.vod.ui.screens.home.myList

class MyListViewModel {
}