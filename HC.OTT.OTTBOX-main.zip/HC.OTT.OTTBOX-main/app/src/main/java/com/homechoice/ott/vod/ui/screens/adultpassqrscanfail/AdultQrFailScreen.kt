package com.homechoice.ott.vod.ui.screens.adultpassqrscanfail


import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp


@Composable
fun AdultQrFailScreen(onConfirm: () -> Unit) {
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(100.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(100.dp))
        Instructions()
        Spacer(modifier = Modifier.height(30.dp))
        ConfirmButton(onClick = onConfirm, focusRequester)
    }
}


@Composable
fun Instructions() {
    val instructions = listOf(
        "성인 인증에 실패하였습니다",
        "오초이스 모바일앱에서 재시도해 주세요",
    )

    Column(
        modifier = Modifier.wrapContentSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        instructions.forEachIndexed { index, instruction ->
            Text(
                text = instruction,
                color = Color.White,
                fontSize = 40.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun ConfirmButton(
    onClick: () -> Unit,
    focusRequester: FocusRequester
) {
    val interactionSource = remember { MutableInteractionSource() }
    var containerColor by remember {mutableStateOf(Color.Black)  }

    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = Color.White
        ),
        interactionSource = interactionSource,
        border = BorderStroke(1.dp, Color.White),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier
            .height(35.dp)
            .width(200.dp)
            .focusRequester(focusRequester)
            .onFocusChanged { focusState ->
                containerColor = if (focusState.isFocused) Color.Red else Color.Black
            }
            .focusable()
    ) {
        Text("확인")
    }
}