package com.homechoice.ott.vod.model.content

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class OfferContent(
    val id: Long,
    var title: String?,
    val posterUrl: String?,
    val packageType: String?,
    val productType: String?,
    var price: Int?,
    val discountPrice: Int = 0,
    val rentalPeriod: String?,
    val eventType: String?,
    var isPurchase: Boolean?,
    val viewablePeriod: String?,
    val pointPolicyId: Long? = 0,
    val pointPolicyType: String? = "",
    val pointPolicyValue: Int? = 0,
    var contentList: List<Content>
) : Parcelable
