package com.homechoice.ott.vod.ui.popup.point

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.agent.PointType

import com.homechoice.ott.vod.model.point.PointHistory
import com.homechoice.ott.vod.util.StringUtil

class PointPopupViewModel(title: String, desc: String, textList: List<String>, data: PointHistory) : ViewModel() {
    val pointProduct = data
    var price: MutableLiveData<String> = MutableLiveData()
    var title: MutableLiveData<String> = MutableLiveData()
    var contentName: MutableLiveData<String> = MutableLiveData()
    var point: MutableLiveData<String> = MutableLiveData()
    var date: MutableLiveData<String> = MutableLiveData()
    var issueDate: MutableLiveData<String> = MutableLiveData()
    var firstText: MutableLiveData<String> = MutableLiveData()
    var secondText: MutableLiveData<String> = MutableLiveData()
    var thirdText: MutableLiveData<String> = MutableLiveData()
    var desc: MutableLiveData<String> = MutableLiveData()

    init {
        this.title.value = title
        this.price.value = data.priceStr
        this.contentName.value = data.titleForPay
        this.point.value = data.pointStr
        this.price.value = data.priceStr
        when (data.type) {
            PointType.CANCEL_VOD_MILEAGE,
            PointType.CANCEL_PRODUCT_MILEAGE,
            PointType.CANCEL_PAYMENT_VOD,
            PointType.CANCEL_POINT_PRODUCT,
            PointType.EXPIRED_POINT
            -> {
                if(!data.date.isNullOrEmpty()) {
                    this.date.value = StringUtil.getInstance().getPointPopupDate(data.date)
                }
            }
            else -> {
                if(!data.validDate.isNullOrEmpty()) {
                    this.date.value = StringUtil.getInstance().getPointPopupDate(data.validDate)
                }
            }
        }

        if(!data.date.isNullOrEmpty()) {
            this.issueDate.value = StringUtil.getInstance().getPointPopupDate(data.date)
        }
        this.firstText.value = textList[0]
        this.secondText.value = textList[1]
        this.thirdText.value = textList[2]
        this.desc.value = desc
    }
}