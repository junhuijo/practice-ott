package com.homechoice.ott.vod.ui.screens.adultpassqrscan

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.ui.screens.home.HomeViewModel
import com.homechoice.ott.vod.util.AdultQrScanner

@Composable
fun AdultQrScreen(
    onNavigateBack: () -> Unit,
) {

    val homeViewModel: HomeViewModel = viewModel()
    val adultQrViewModel: AdultQrViewModel = viewModel()
    val focusRequester = remember { FocusRequester() }
    val customPadding = PaddingValues(
        start = 60.dp,
        top = 94.dp,
        end = 80.dp,
        bottom = 84.dp
    )

    var showDialog by remember { mutableStateOf(false) }


    // 사용자 정보 로깅
    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.CenterVertically)
            ) {
                QRLayout()
            }
            VerticalDivider()
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(customPadding),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                QRInstructions()
                Row {
                    BackButton(onNavigateBack)
                    Spacer(modifier = Modifier.width(20.dp))
                    CompleteButton(
                        homeViewModel,
                        adultQrViewModel,
                        focusRequester,
                        onShowDialog = { showDialog = true})
                }
            }
        }
    }

    if (showDialog) {
        AdultQrDialog(
            onDismiss = {
                showDialog = false
                onNavigateBack()  // 다이얼로그 닫을 때 뒤로 가기
            },
            homeViewModel
        )
    }
}

@Composable
fun QRLayout(
    modifier: Modifier = Modifier
) {
    val qrCodeBitmap = remember { AdultQrScanner.generateQRCode("https://ochoice.page.link/k1ue") }
    val customPadding = PaddingValues(
        start = 70.dp,
        top = 90.dp,
        end = 60.dp,
        bottom = 90.dp
    )

    Column (
        modifier = modifier
            .width(360.dp)
            .fillMaxHeight()
            .padding(customPadding),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        QRCodeTitle()
        QRCodeImage(qrCodeBitmap)
        AgeRestrictionNotice()
    }
}

@Composable
fun QRCodeTitle() {
    Text (
        text = "모바일앱으로 이동하기",
        modifier = Modifier.padding(top = 10.dp),
        color = Color.White,
        fontSize = 22.sp,
        textAlign = TextAlign.Center,
        fontWeight = FontWeight.ExtraBold,
    )
}

@Composable
fun QRCodeImage(bitmap: Bitmap?){

    Box (
        modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
    ) {
        bitmap?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = "QR 코드",
                modifier = Modifier
                    .size(224.dp)
                    .background(Color.White)
            )
        }
    }
}

@Composable
fun AgeRestrictionNotice() {
    val instructions = listOf(
        "연령 제한 콘텐츠",
        "이 정보 내용은 청소년 유해물로서 '정보통신망 이용촉진 및 정보보호 등에 관한 법률' 및'청소년 보호법'에 따라 19세 미만의 청소년이 이용할 수 없습니다."
    )
    Column(
        modifier = Modifier
            .width(224.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        instructions.forEachIndexed { index, instruction ->
            Text(
                text = instruction,
                color = Color.White,
                fontSize = if (index == 0) 14.sp else 10.sp,
            )
        }
    }
}

@Composable
fun QRInstructions() {
    val instructions = listOf(
        "[성인인증방법]",
        "1. QR을 스캔해서 모바일로 이동하세요.",
        "2. 앱 하단의 {VOD}를 클릭하세요.",
        "3. 상단의 {19+}를 클릭하세요.",
        "4. 설명에 따라 성인 인증을 진행하세요.",
        "5. 오초이스 TV에서 인증완료를 클릭하세요",
    )

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        instructions.forEachIndexed { index, instruction ->
            when (index) {
                0 -> Text(
                    text = instruction,
                    color = Color.White,
                    fontSize = 30.sp,
                    modifier = Modifier.padding(bottom = 30.dp)
                )
                else -> {
                    val parts = instruction.split("{", "}")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        parts.forEachIndexed { _, part ->
                            when (part) {
                                "VOD" -> Image(
                                    painter = painterResource(id = R.drawable.icon_adult_vod),
                                    contentDescription = "VOD 아이콘",
                                    modifier = Modifier.height(35.dp).align(Alignment.Bottom).padding(bottom = 12.dp)
                                )
                                "19+" -> Image(
                                    painter = painterResource(id = R.drawable.icon_adult_19plus),
                                    contentDescription = "19+ 아이콘",
                                    modifier = Modifier.height(35.dp).align(Alignment.Bottom).padding(bottom = 12.dp)
                                )
                                else -> Text(
                                    text = part,
                                    color = Color.White,
                                    fontSize = 22.sp,
                                    lineHeight = 2.sp,
                                    modifier = Modifier.padding(bottom = 10.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompleteButton(
    homeViewModel: HomeViewModel,
    adultQrViewModel: AdultQrViewModel,
    focusRequester: FocusRequester,
    onShowDialog: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val context = LocalContext.current
    var containerColor by remember {mutableStateOf(Color.Black)  }


    Button(
        onClick = {
            adultQrViewModel.initializeAuthentication(
                context,
                onSuccess = {
//                    homeViewModel.checkAndShowAdultVerification()
                    onShowDialog()  // 인증 성공 시 다이얼로그 표시

                },
                onFailure = {
                    homeViewModel.navigateToAdultQrFail()
                }
            )
        },
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = Color.White
        ),
        interactionSource = interactionSource,
        border = BorderStroke(1.dp, Color.White),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .width(220.dp)
            .height(54.dp)
            .focusRequester(focusRequester)
            .onFocusChanged { focusState ->
                containerColor = if (focusState.isFocused) Color.Red else Color.Black
            }
            .focusable()
    ) {
        Text(
            text = "인증완료",
            fontSize = 20.sp)
    }
}

@Composable
fun BackButton(onNavigateBack: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    Button(
        onClick = { onNavigateBack() },
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isFocused) Color.Red else Color.Black,
            contentColor = Color.White
        ),
        interactionSource = interactionSource,
        border = BorderStroke(1.dp, Color.White),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .width(220.dp)
            .height(54.dp)
    ) {
        Text(
            text = "뒤로가기",
            fontSize = 20.sp
        )
    }
}

@Composable
fun VerticalDivider() {
    Box(
        modifier = Modifier
            .padding(vertical = 80.dp)
            .fillMaxHeight()
            .width(1.dp)
            .background(Color.White)
    )
}