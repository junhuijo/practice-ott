package com.homechoice.ott.vod.io;

import com.homechoice.ott.vod.model.request.*
import com.homechoice.ott.vod.model.response.*
import retrofit2.Call
import retrofit2.http.*

interface PVSService {
    @POST("/PVS/api/passwordCheck")
    fun passwordCheck(
        @Body passwordCheck: RequestPasswordCheck
    ): Call<ResponsePasswordCheck>

    @POST("/PVS/api/passwordSet")
    fun passwordSet(
        @Body requestPasswordSet: RequestPasswordSet
    ): Call<ResponsePasswordSet>
}