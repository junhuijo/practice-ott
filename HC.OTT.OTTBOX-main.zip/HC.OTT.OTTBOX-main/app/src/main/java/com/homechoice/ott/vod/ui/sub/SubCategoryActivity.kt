package com.homechoice.ott.vod.ui.sub

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.ActivitySubCategoryBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.model.HomeCategoryList
import com.homechoice.ott.vod.model.response.ResponseCategoryItemList
import com.homechoice.ott.vod.model.response.ResponseCategoryList
import com.homechoice.ott.vod.model.response.ResponsePointProductList
import com.homechoice.ott.vod.model.response.ResponseSiblingCategoryList
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.popup.TYPE
import com.homechoice.ott.vod.ui.my.MyActivity2
import com.homechoice.ott.vod.ui.navigation.grid.NavigationGridView
import com.homechoice.ott.vod.ui.navigation.view.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.sub.auth.LoginFragment
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class SubCategoryActivity : AppCompatActivity() {

    private var subMainCategoryListFragment: SubCategoryListFragment? = null
    private var subTopCategoryListFragment: SubTopCategoryListFragment? = null
    private var subContentListFragment: SubContentListFragment? = null
    private var loginFragment: LoginFragment? = null
    private var adultAuthFragment: SubAdultAuthFragment? = null

    private var ctx = this
    private var homeCategoryList: HomeCategoryList? = null
    private var activityHandler: Handler? = null

    private var keyTag = ""

    private var transactionCategoryId: String = ""
    private var transactionContentId: String = ""
    private var requestCategory: Call<ResponseCategoryList>? = null
    private var requestSiblingCategory: Call<ResponseSiblingCategoryList>? = null
    private var requestContent: Call<ResponseCategoryItemList>? = null

    private var isMyMenuBack = false

    private lateinit var binding: ActivitySubCategoryBinding

    object ActionType {
        const val MAIN_CATEGORY_FOCUS = 0
        const val TOP_CATEGORY_FOCUS = 1
        const val CONTENTS_FOCUS = 2
        const val LOGIN_FOCUS = 3
        const val ADULT_FOCUS = 4
        const val MAIN_CATEGORY_UPDATE = 5
        const val TOP_CATEGORY_UPDATE = 6
        const val CONTENTS_UPDATE = 7
        const val LOGIN_UPDATE = 8
        const val ADULT_UPDATE = 9
        const val CONTESTS_LOADED = 10
        const val TOP_CATEGORY_LOADED = 11
        const val LOADING = 12
        const val REQUEST_CANCEL = 13
        const val GO_MY_MENU = 14
        const val FOCUS = 15
        const val UNFOCUS = 16
        const val ADULT_UPDATE_FOCUS = 17
        const val DOWN_FOCUS = 18
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySubCategoryBinding.inflate(layoutInflater)
        binding.apply {
            lifecycleOwner = this@SubCategoryActivity
        }
        setContentView(binding.root)
        homeCategoryList = intent.getParcelableExtra(Home.CATEGORY_LIST)
        activityHandler = createHandler()
        createCategory()
    }

    override fun onResume() {
        super.onResume()
        if (!isShowSubContentListLayout() && isMyMenuBack) {
            val currentHomeCategory = homeCategoryList?.categoryList!![0]
            activityHandler?.obtainMessage(ActionType.TOP_CATEGORY_UPDATE, currentHomeCategory.id, ActionType.UNFOCUS)?.sendToTarget()
        }
        isMyMenuBack = false

        if (STBAgent.isAuth && !STBAgent.hasPointNoti) {
            //requestPointNoti()
        }
        else {
            if (subMainCategoryListFragment != null) {
                if (STBAgent.hasPointNoti) {
                    subMainCategoryListFragment!!.showPointNotiIcon()
                }
                else {
                    subMainCategoryListFragment!!.hidePointNotiIcon()
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        hideLoadingView()
        requestCancel()
    }

    private fun createCategory() {
        // 카테고리 캐시 초기화
        CategoryAgent.clearCategoryList()

        hideTopCategoryListLayout()
        showLoadingView()

        if (homeCategoryList == null) {
            // 카테고리 점프로 온 경우
            val categoryId = intent.getIntExtra(Home.CATEGORY_ID, 0)
            val focusType = intent.getIntExtra(Home.CATEGORY_FOCUS, ActionType.MAIN_CATEGORY_FOCUS)

            // 서브 카테고리 요청
            transactionCategoryId = UUID.randomUUID().toString()
            requestSiblingCategoryList(categoryId, transactionCategoryId, object : Callback<ResponseSiblingCategoryList> {
                override fun onFailure(call: Call<ResponseSiblingCategoryList>, t: Throwable) {
                    // 장애팝업
                    showErrorPopup()
                }

                override fun onResponse(call: Call<ResponseSiblingCategoryList>, response: Response<ResponseSiblingCategoryList>) {
                    // 메인 카테고리 요청
                    if (response.isSuccessful && response.body() != null) {
                        val subCategoryList: ResponseSiblingCategoryList = response.body()!!

                        when (subCategoryList.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                                UIAgent.showPopup(ctx, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                        createCategory()
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                if (transactionCategoryId == subCategoryList.transactionId) {

                                    if (subCategoryList.parentCategoryId > -1) {

                                        CategoryAgent.setCategoryList(subCategoryList.categoryList[0].parentId, subCategoryList.categoryList)

                                        transactionCategoryId = UUID.randomUUID().toString()

                                        requestSiblingCategoryList(
                                            subCategoryList.parentCategoryId,
                                            transactionCategoryId,
                                            object : Callback<ResponseSiblingCategoryList> {
                                                override fun onFailure(call: Call<ResponseSiblingCategoryList>, t: Throwable) {
                                                    // 장애팝업
                                                    showErrorPopup()
                                                }

                                                override fun onResponse(
                                                    call: Call<ResponseSiblingCategoryList>,
                                                    response: Response<ResponseSiblingCategoryList>
                                                ) {
                                                    if (response.isSuccessful && response.body() != null) {
                                                        val mainCategoryList: ResponseSiblingCategoryList = response.body()!!
                                                        if (transactionCategoryId == mainCategoryList.transactionId) {
                                                            initCategoryData(
                                                                categoryId,
                                                                subCategoryList.parentCategoryId,
                                                                mainCategoryList.categoryList,
                                                                subCategoryList.categoryList,
                                                                ActionType.CONTENTS_FOCUS
                                                            )
                                                        }
                                                        else {
                                                            // 무시
                                                        }
                                                    }
                                                    else {
                                                        // 장애팝업
                                                        showErrorPopup(response.code())
                                                    }
                                                }
                                            })

                                    }
                                    else {
                                        // ROOT 카테고리 인경우 처리 -> 포커스는 카테고리 리스트
                                        transactionCategoryId = UUID.randomUUID().toString()
                                        MBSAgent.getCategoryList(
                                            transactionCategoryId,
                                            categoryId,
                                            false,
                                            STBAgent.isAdultAuth,
                                            STBAgent.includeRrated,
                                            1,
                                            0,

                                            object : Callback<ResponseCategoryList> {
                                                override fun onFailure(call: Call<ResponseCategoryList>, t: Throwable) {
                                                    showErrorPopup()
                                                }

                                                override fun onResponse(
                                                    call: Call<ResponseCategoryList>,
                                                    response: Response<ResponseCategoryList>
                                                ) {
                                                    if (response.isSuccessful && response.body() != null) {
                                                        val categoryList: ResponseCategoryList = response.body()!!
                                                        when (categoryList.sessionState) {
                                                            SessionState.FORCE_LOGOUT -> {
                                                                UIAgent.showPopup(ctx, CODE.CONFLICT, object : RetryCallback {
                                                                    override fun call() {
                                                                        createCategory()
                                                                    }

                                                                    override fun cancel() {
                                                                    }
                                                                })
                                                            }
                                                            else -> {
                                                                if (transactionCategoryId == categoryList.transactionId) {
                                                                    initCategoryData(
                                                                        categoryList.categoryList[0].id,
                                                                        categoryId,
                                                                        subCategoryList.categoryList,
                                                                        categoryList.categoryList,
                                                                        focusType
                                                                    )
                                                                }
                                                                else {
                                                                    // 무시
                                                                }
                                                            }
                                                        }

                                                    }
                                                    else {
                                                        // 장애팝업
                                                        showErrorPopup(response.code())
                                                    }
                                                }
                                            })
                                    }

                                }
                                else {
                                    // 무시
                                }
                            }
                        }
                    }
                    else {
                        // 장애팝업
                        showErrorPopup(response.code())
                    }
                }
            })
        }
        else {
            val categoryStartIndex = intent.getIntExtra(Home.CURRENT_CATEGORY_START_INDEX, 0)
            val categoryCurIndex = intent.getIntExtra(Home.CURRENT_CATEGORY_INDEX, 0)
            val visibleIndex = intent.getIntExtra(Home.CURRENT_CATEGORY_VISIBLE_INDEX, 7)
            val isEmpty = intent.getBooleanExtra(Home.CURRENT_CATEGORY_IS_EMPTY, false)

            val currentHomeCategory = homeCategoryList?.categoryList!![categoryCurIndex]

            createFragment(
                createController(
                    categoryList = homeCategoryList?.categoryList!!,
                    curIndex = categoryCurIndex,
                    startIndex = categoryStartIndex,
                    leftFixedIndex = 1,
                    rightFixedIndex = 5,
                    visibleIndex = visibleIndex,
                    visibleThreshold = 7,
                    isEmpty = isEmpty
                )
            )

            requestCategory = requestTopCategoryList(currentHomeCategory.id, ActionType.CONTENTS_FOCUS)
        }
    }

    private fun initCategoryData(
        categoryId: Int,
        parentCategoryId: Int,
        mainCategoryList: List<CategoryList>,
        subCategoryList: List<CategoryList>,
        focusType: Int
    ) {

        val con = createController(
            categoryId = parentCategoryId,
            categoryList = mainCategoryList,
            leftFixedIndex = 1,
            rightFixedIndex = 5,
            visibleThreshold = 7
        )
        createFragment(con)

        // 성인카테고리 확인 필요
        var isShowContentView = true
        val category = con.getCurItem() as CategoryList
        if (category.isAdult) {
            if (STBAgent.isAuth) {
                if (STBAgent.isAdultAuth) {
                    // 성인컨텐츠 노출
                }
                else {
                    // 성인인증 뷰
                    activityHandler?.obtainMessage(ActionType.ADULT_UPDATE, category.id, ActionType.FOCUS)
                        ?.sendToTarget()
                    isShowContentView = false
                    keyTag = SubAdultAuthFragment::class.simpleName!!
                }
            }
            else {
                // 로그인 뷰
                activityHandler?.obtainMessage(ActionType.LOGIN_UPDATE, category.id, ActionType.FOCUS)
                    ?.sendToTarget()
                isShowContentView = false
                keyTag = LoginFragment::class.simpleName!!
            }
        }

        if (isShowContentView) {
            var hasTopCategory = true
            if (subCategoryList.size > 1) {
                subTopCategoryListFragment = SubTopCategoryListFragment(
                    createController(
                        categoryId = categoryId,
                        categoryList = subCategoryList,
                        leftFixedIndex = 1,
                        rightFixedIndex = 4,
                        visibleThreshold = 7
                    ),
                    activityHandler!!
                )

                UIAgent.fragmentTransaction(
                    ctx,
                    R.id.sub_category_list_body,
                    subTopCategoryListFragment!!,
                    subTopCategoryListFragment!!::class.simpleName!!
                )

                showSubCategoryListLayout()
            }
            else {
                hideSubCategoryListLayout()
                hasTopCategory = false
            }

            if (subCategoryList.isNotEmpty()) {
                subContentListFragment =
                    SubContentListFragment(
                        categoryId,
                        hasTopCategory,
                        focusType,
                        activityHandler = activityHandler!!
                    )
                UIAgent.fragmentTransaction(
                    ctx,
                    binding.subContentListBody.id,
                    subContentListFragment!!,
                    subContentListFragment!!::class.simpleName!!
                )

            }
        }

    }

    private fun createController(
        categoryId: Int, categoryList: List<CategoryList>, leftFixedIndex: Int, rightFixedIndex: Int, visibleThreshold: Int
    ): NavigationController {
        Logger.Log(Log.DEBUG, this, "categoryId= $categoryId")

        var curIndex = 0
        val list = mutableListOf<CategoryList>()

        for (item in categoryList) {
            if (item.isVisible) {
                list.add(item)
            }
        }

        for (index in list.indices) {
            if (categoryId == list[index].id) {
                curIndex = index
            }
        }

        Logger.Log(Log.DEBUG, this, "curIndex= $curIndex")

        val con = NavigationController(NavigationModel(
            NavigationData(
                leftFixedIndex = leftFixedIndex,
                rightFixedIndex = rightFixedIndex,
                visibleThreshold = visibleThreshold,
                totalCount = list.size
            ).build(
                list
            )
        ), object : NavigationEvent {
            override fun rightLineChange(position: Int) {
            }

            override fun leftLineChange() {
            }

            override fun lastLineChange() {
            }

            override fun firstLineChange() {
            }

            override fun focusChange() {
            }

            override fun addEmptyRow() {

            }

            override fun lineChange(isDown: Boolean) {
            }
        })

        for (i in 0 until curIndex) {
            con.increase()
        }
        Logger.Log(Log.DEBUG, this, "con.getCurIndex= ${con.getCurIndex()}")

        return con
    }

    private fun createController(
        categoryList: List<CategoryList>,
        curIndex: Int,
        startIndex: Int,
        leftFixedIndex: Int,
        rightFixedIndex: Int,
        visibleIndex: Int,
        visibleThreshold: Int,
        isEmpty: Boolean
    ): NavigationController {
        val list = mutableListOf<CategoryList>()
        for (item in categoryList) {
            if (item.isVisible) {
                list.add(item)
            }
        }

        return NavigationController(NavigationModel(
            NavigationData(
                curIndex = curIndex,
                startIndex = startIndex,
                leftFixedIndex = leftFixedIndex,
                rightFixedIndex = rightFixedIndex,
                visibleThreshold = visibleThreshold,
                visibleIndex = visibleIndex,
                totalCount = list.size,
                isEmpty = isEmpty
            ).build(
                list
            )
        ), object : NavigationEvent {
            override fun rightLineChange(position: Int) {
            }

            override fun leftLineChange() {
            }

            override fun lastLineChange() {
            }

            override fun firstLineChange() {
            }

            override fun focusChange() {
            }

            override fun addEmptyRow() {

            }

            override fun lineChange(isDown: Boolean) {
            }
        })
    }

    private fun createHandler(): Handler {
        return Handler(Looper.getMainLooper()) {
            Logger.Log(
                Log.DEBUG,
                this,
                "activityHandler : what ${it.what} / arg1 ${it.arg1}/ arg2 ${it.arg2}"
            )
            when (it.what) {
                ActionType.MAIN_CATEGORY_FOCUS -> {

                    // 컨텐츠 리스트 -> 메인 카테고리로 이동
                    keyTag = SubCategoryListFragment::class.simpleName!!
                    subMainCategoryListFragment!!.focus()
                }
                ActionType.CONTENTS_FOCUS -> {
                    // 메인 카테고리 -> 컨텐츠 리스트 이동
                    if (!isLoading()) {
                        subMainCategoryListFragment?.selected()
                        subTopCategoryListFragment?.selected()
                        subContentListFragment!!.focus()
                        keyTag = SubContentListFragment::class.simpleName!!
                    }
                }
                ActionType.TOP_CATEGORY_FOCUS -> {
                    // 컨텐츠 리스트 -> 서브 카테고리 이동
                    keyTag = SubTopCategoryListFragment::class.simpleName!!
                    subTopCategoryListFragment!!.focus()
                }
                ActionType.TOP_CATEGORY_UPDATE -> {
                    Logger.Log(Log.DEBUG, this, "subMainCategoryListFragment!!.isFirstCategory() ${subMainCategoryListFragment!!.isFirstCategory()}")
                    if (subContentListFragment != null)
                        Logger.Log(Log.DEBUG, this, "subContentListFragment!!.isLoading ${subContentListFragment!!.isLoading}")
                    if (subMainCategoryListFragment!!.isFirstCategory() && subContentListFragment != null && !subContentListFragment!!.isLoading) {

                    }
                    else {
                        requestCancel()
                        hideTopCategoryListLayout()
                        showLoadingView()
                        val id = it.arg1
                        val focusType = it.arg2
                        val list = CategoryAgent.getCategoryList(id)

                        Logger.Log(Log.DEBUG, this, "id:$id / list:${list.isNullOrEmpty()}")

                        if (list.isNullOrEmpty()) {
                            requestCategory = requestTopCategoryList(id, focusType)
                        }
                        else {
                            if (list.size > 1) {
                                binding.subCategoryListBody.removeAllViews()
                                subTopCategoryListFragment = SubTopCategoryListFragment(
                                    createController(
                                        categoryId = id,
                                        categoryList = list,
                                        leftFixedIndex = 1,
                                        rightFixedIndex = 4,
                                        visibleThreshold = 7
                                    ),
                                    activityHandler!!
                                )

                                UIAgent.fragmentTransaction(
                                    ctx,
                                    R.id.sub_category_list_body,
                                    subTopCategoryListFragment!!,
                                    subTopCategoryListFragment!!::class.simpleName!!
                                )
                                showSubCategoryListLayout()
                            }
                            else {
                                hideSubCategoryListLayout()
                            }

                            subContentListFragment =
                                SubContentListFragment(
                                    list[0].id,
                                    (list.size > 1),
                                    focusType,
                                    activityHandler = activityHandler!!
                                )
                            UIAgent.fragmentTransaction(
                                ctx,
                                binding.subContentListBody.id,
                                subContentListFragment!!,
                                subContentListFragment!!::class.simpleName!!
                            )
                        }
                    }
                }
                ActionType.CONTENTS_UPDATE -> {
                    requestCancel()
                    showLoadingView()
                    subContentListFragment!!.update(it.obj as CategoryList)
                }
                ActionType.LOGIN_UPDATE -> {
                    val id = it.arg1
                    val focus = it.arg2
                    requestCancel()
                    hideLoadingView()
                    showLoginLayout(id, (focus == ActionType.FOCUS))
                    hideSubCategoryListLayout()
                    showSubContentListLayout()
                }

                ActionType.ADULT_UPDATE_FOCUS -> {
                    val id = it.obj as Int
                    requestCancel()
                    hideLoadingView()
                    showAdultAuthLayout(id, true)
                    showSubContentListLayout()
                    keyTag = adultAuthFragment!!::class.simpleName!!
                    subMainCategoryListFragment?.selected()
                }

                ActionType.ADULT_UPDATE -> {
                    val id = it.arg1
                    val focus = it.arg2
                    requestCancel()
                    hideLoadingView()
                    showAdultAuthLayout(id, (focus == ActionType.FOCUS))
                    showSubContentListLayout()
                }
                ActionType.LOGIN_FOCUS -> {
                    keyTag = loginFragment!!::class.simpleName!!
                    subMainCategoryListFragment?.selected()
                    loginFragment?.focus()
                }
                ActionType.ADULT_FOCUS -> {
                    keyTag = adultAuthFragment!!::class.simpleName!!
                    subMainCategoryListFragment?.selected()
                    adultAuthFragment?.focus()
                }
                ActionType.CONTESTS_LOADED -> {
                    val focusType = it.arg1
                    Logger.Log(Log.ERROR, this, "focusType:$focusType / keyTag : $keyTag")

                    when (focusType) {
                        ActionType.MAIN_CATEGORY_FOCUS -> {
                            Handler().postDelayed({
                                activityHandler?.obtainMessage(focusType)?.sendToTarget()
                            }, 250L)
                        }
                        ActionType.CONTENTS_FOCUS -> activityHandler?.obtainMessage(focusType)?.sendToTarget()
                    }
                    hideLoadingView()
                    showSubContentListLayout()
                }
                ActionType.GO_MY_MENU -> {
                    hideLoadingView()
                    requestCancel()
                    if (it.obj != null) {
                        goToMyMenu(it.obj as String)
                    }
                    else {
                        goToMyMenu()
                    }
                }
            }
            true
        }
    }

    private fun createFragment(con: NavigationController) {
        subMainCategoryListFragment = SubCategoryListFragment(con, actionEventHandler = activityHandler!!)

        // 한번 생성 후 바뀌지 않음
        showMainCategoryList()
    }

    private fun showMainCategoryList() {
        UIAgent.fragmentTransaction(
            this,
            binding.subHomeCategoryListBody.id,
            subMainCategoryListFragment!!,
            subMainCategoryListFragment!!::class.simpleName!!
        )
    }

    private fun showLoginLayout(categoryId: Int, isFocus: Boolean) {
        loginFragment = LoginFragment(activityHandler = activityHandler!!, categoryId = categoryId, isFocus = isFocus)
        UIAgent.fragmentTransaction(
            this,
            binding.subContentListBody.id,
            loginFragment!!,
            loginFragment!!::class.simpleName!!
        )
        binding.subCategoryListBody.visibility = View.INVISIBLE
    }

    private fun showAdultAuthLayout(categoryId: Int, isFocus: Boolean) {
        adultAuthFragment = SubAdultAuthFragment(categoryId = categoryId, activityHandler = activityHandler!!, isFocus = isFocus)
        UIAgent.fragmentTransaction(
            this,
            binding.subContentListBody.id,
            adultAuthFragment!!,
            adultAuthFragment!!::class.simpleName!!
        )
        if (isFocus) {
            keyTag = SubAdultAuthFragment::class.simpleName!!
        }
        binding.subCategoryListBody.visibility = View.INVISIBLE
    }

    private fun showLoadingView() {
        if (!isLoading()) {
            binding.subContentListBody.visibility = View.INVISIBLE
            binding.loading.visibility = View.VISIBLE
            val animation = AnimationUtils.loadAnimation(this, R.anim.play_loading_rotate)
            binding.loading.startAnimation(animation)
        }
    }

    private fun hideLoadingView() {
        binding.loading.visibility = View.INVISIBLE
        binding.loading.clearAnimation()
    }

    private fun hideTopCategoryListLayout() {
        binding.subCategoryListBody.visibility = View.INVISIBLE
    }

    private fun hideSubCategoryListLayout() {
        binding.subCategoryListBody.visibility = View.INVISIBLE
        binding.subContentListBody.layoutParams = createMargins(R.dimen.sub_content_list_empty_margin_top)
    }

    private fun showSubCategoryListLayout() {
        binding.subCategoryListBody.visibility = View.VISIBLE
        binding.subContentListBody.layoutParams = createMargins(R.dimen.sub_content_list_margin_top)
    }

    private fun showSubContentListLayout() {
        Logger.Log(
            Log.DEBUG,
            this,
            "showSubContentListLayout !!!!!"
        )
        binding.subContentListBody.visibility = View.VISIBLE
    }

    private fun hideSubContentListLayout() {
        binding.subContentListBody.visibility = View.INVISIBLE
    }

    private fun isShowSubContentListLayout(): Boolean {
        return binding.subContentListBody.visibility == View.VISIBLE
    }

    private fun goToMyMenu() {
        val intent = Intent(ctx, MyActivity2::class.java)
        isMyMenuBack = true
        intent.putExtra("TARGET_INFO", CategoryTarget.ROOT)
        startActivity(intent)
    }

    private fun goToMyMenu(linkInfo: String) {
        val intent = Intent(ctx, MyActivity2::class.java)
        isMyMenuBack = true
        intent.putExtra("TARGET_INFO", linkInfo)
        startActivity(intent)
    }

    private fun createMargins(id: Int): FrameLayout.LayoutParams {
        val lp = FrameLayout.LayoutParams(
            CMBApp.getPixelSize(R.dimen.sub_content_list_width),
            LinearLayout.LayoutParams.MATCH_PARENT
        )

        lp.setMargins(
            CMBApp.getPixelSize(R.dimen.sub_content_list_margin_start),
            CMBApp.getPixelSize(id),
            0,
            0
        )
        return lp
    }

    private fun requestCancel() {
        if (requestCategory != null)
            requestCategory?.cancel()
        if (requestContent != null)
            requestContent?.cancel()
        transactionCategoryId = ""
        transactionContentId = ""
    }

    private fun requestSiblingCategoryList(categoryId: Int, transactionCategoryId: String, callback: Callback<ResponseSiblingCategoryList>) {
        MBSAgent.getSiblingCategoryList(transactionCategoryId, categoryId, false, 1, 0, callback)
    }

    private fun requestTopCategoryList(id: Int, focusType: Int): Call<ResponseCategoryList> {
        transactionCategoryId = UUID.randomUUID().toString()

        return MBSAgent.getCategoryList(
            transactionCategoryId,
            id,
            false,
            true,
            true,
            0,
            0,
            object : Callback<ResponseCategoryList> {
                override fun onResponse(call: Call<ResponseCategoryList>, response: Response<ResponseCategoryList>) {
                    if (response.isSuccessful && response.body() != null) {
                        val responseCategoryList: ResponseCategoryList = response.body()!!

                        when (responseCategoryList.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                                UIAgent.showPopup(ctx, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                        requestTopCategoryList(id, focusType)
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                if (transactionCategoryId == responseCategoryList.transactionId) {
                                    var hasTopCategory = true
                                    CategoryAgent.setCategoryList(id, responseCategoryList.categoryList)

                                    if (responseCategoryList.categoryList.size > 1) {
                                        binding.subCategoryListBody.removeAllViews()
                                        subTopCategoryListFragment = SubTopCategoryListFragment(
                                            createController(
                                                categoryId = id,
                                                categoryList = responseCategoryList.categoryList,
                                                leftFixedIndex = 1,
                                                rightFixedIndex = 4,
                                                visibleThreshold = 7
                                            ),
                                            activityHandler!!
                                        )

                                        UIAgent.fragmentTransaction(
                                            ctx,
                                            R.id.sub_category_list_body,
                                            subTopCategoryListFragment!!,
                                            subTopCategoryListFragment!!::class.simpleName!!
                                        )
                                        showSubCategoryListLayout()
                                    }
                                    else {
                                        hideSubCategoryListLayout()
                                        hasTopCategory = false
                                    }

                                    if (responseCategoryList.categoryList.isNotEmpty()) {
                                        subContentListFragment =
                                            SubContentListFragment(
                                                responseCategoryList.categoryList[0].id,
                                                hasTopCategory,
                                                focusType,
                                                activityHandler = activityHandler!!
                                            )
                                        UIAgent.fragmentTransaction(
                                            ctx,
                                            binding.subContentListBody.id,
                                            subContentListFragment!!,
                                            subContentListFragment!!::class.simpleName!!
                                        )
                                    }
                                }
                            }
                        }

                    }
                    else {
                        Logger.Log(Log.ERROR, this, "실패2");
                        showErrorPopup(response.code())
                    }
                }

                override fun onFailure(call: Call<ResponseCategoryList>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, "onFailure 실패 ${call.isCanceled}")
                    if (call.isCanceled) {
                        keyTag = subMainCategoryListFragment!!::class.simpleName!!
                    }
                    else {
                        showErrorPopup()
                    }
                }
            })

    }

    private fun showErrorPopup() {
        PopupAgent.showNormalPopup(ctx, PopupType.ErrorType.ERROR, object : PopupEvent {
            override fun onClick(d: Dialog, btn: String) {
                d.dismiss()
                ctx.finish()
            }
        })
    }

    private fun showErrorPopup(code: Int) {
        PopupAgent.showNormalPopup(ctx, PopupType.getErrorType(
            TYPE.DEFAULT,
            code
        ), object : PopupEvent {
            override fun onClick(d: Dialog, btn: String) {
                d.dismiss()
                ctx.finish()
            }
        })
    }

    private fun isLoading(): Boolean {
        return binding.loading.visibility == View.VISIBLE
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        Logger.Log(Log.INFO, this, "dispatchKeyEvent keyTag : $keyTag")
        return if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.keyCode == KeyEvent.KEYCODE_BACK || event.keyCode == KeyEvent.KEYCODE_BUTTON_B) {
                Logger.Log(Log.INFO, this, "subMainCategoryListFragment != null : ${(subMainCategoryListFragment != null)}")
                if (subMainCategoryListFragment != null)
                    Logger.Log(Log.INFO, this, "isLoading != null : ${subMainCategoryListFragment!!.isLoading}")

                if (isLoading() && keyTag == "" && subMainCategoryListFragment != null && !subMainCategoryListFragment!!.isLoading) {
                    keyTag = subMainCategoryListFragment!!::class.simpleName!!
                    subMainCategoryListFragment?.focus()
                    if (subContentListFragment != null)
                        subContentListFragment!!.setFocusType(ActionType.MAIN_CATEGORY_FOCUS)
                }
                else
                    finish()
                true
            }
            else {
                when (keyTag) {
                    "LoginFragment",
                    "SubAdultAuthFragment",
                    SubCategoryListFragment::class.simpleName!!,
                    SubTopCategoryListFragment::class.simpleName!!,
                    TagName.SUB_MAIN_CATEGORY,
                    TagName.SUB_TOP_CATEGORY -> {
                        val fr = supportFragmentManager.findFragmentByTag(keyTag)
                        if (fr != null) {
                            if ((supportFragmentManager.findFragmentByTag(keyTag) as NavigationView2).onKeyDown(
                                    event.keyCode
                                )
                            ) {
                                true
                            }
                            else {
                                return super.dispatchKeyEvent(event)
                            }
                        }
                        else {
                            true
                        }
                    }
                    SubContentListFragment::class.simpleName!! -> {
                        (supportFragmentManager.findFragmentByTag(keyTag) as NavigationGridView).onKeyDown(
                            event.keyCode
                        )
                    }
                    else -> {
                        return super.dispatchKeyEvent(event)
                    }
                }

            }
        }
        else {
            when (event.keyCode) {
                KeyEvent.KEYCODE_ENTER,
                        KeyEvent.KEYCODE_DPAD_CENTER, 96-> {
                    true
                }
                else -> {
                    super.dispatchKeyEvent(event)
                }
            }
        }
    }

    private fun requestPointNoti() {
        GlobalScope.launch(Dispatchers.Main) {
            MBSAgent.pointNotiList(1, 0, UUID.randomUUID().toString(), object : Callback<ResponsePointProductList> {
                override fun onResponse(call: Call<ResponsePointProductList>, res: Response<ResponsePointProductList>) {
                    STBAgent.hasPointNoti = if (res.isSuccessful && res.body() != null) {
                        val response = res.body()
                        if (response != null) {
                            response.totalCount > 0
                        }
                        else
                            false
                    }
                    else
                        false

                    if (subMainCategoryListFragment != null) {
                        if (STBAgent.hasPointNoti)
                            subMainCategoryListFragment!!.showPointNotiIcon()
                        else
                            subMainCategoryListFragment!!.hidePointNotiIcon()
                    }
                }

                override fun onFailure(call: Call<ResponsePointProductList>, t: Throwable) {
                    STBAgent.hasPointNoti = false
                    if (subMainCategoryListFragment != null)
                        subMainCategoryListFragment!!.hidePointNotiIcon()
                }
            })
        }
    }
}