package com.homechoice.ott.vod.ui.popup.point

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.model.popup.Popup

class PurchasePointSuccessViewModel : ViewModel {
    var content: MutableLiveData<Popup> = MutableLiveData()

    constructor(
        popupType: PopupType.NormalPopupType
    ) {
        content.value =
            Popup(head = popupType.head, body = popupType.body, buttons = popupType.btns)
    }

    constructor(
        popupType: PopupType.ErrorType
    ) {
        content.value =
            Popup(head = popupType.head, body = popupType.body, buttons = popupType.btns)
    }

}