package com.homechoice.ott.vod.ui.my.serviceLog

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.serviceLog.ServiceLog

class ServiceLogViewModel(value: ServiceLog) : ViewModel() {
    var serviceLog: MutableLiveData<ServiceLog> = MutableLiveData()

    init {
        serviceLog.value = value
    }
}