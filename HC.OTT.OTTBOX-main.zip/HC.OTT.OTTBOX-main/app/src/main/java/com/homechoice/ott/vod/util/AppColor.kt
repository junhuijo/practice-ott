package com.homechoice.ott.vod.util

import androidx.compose.ui.graphics.Color

class AppColors {
    companion object {
        val selectedColor = Color.Red
        val unselectedColor = Color.Black
    }
}
