package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseKeyWord(
    val transactionId: String = "",
    val errorString: String = "",
    val sessionState: String = "",
    val keywordList: List<String>
) : Parcelable