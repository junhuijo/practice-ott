package com.homechoice.ott.vod.ui.my.member

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel


class MemberLogoutViewModel : ViewModel() {
}

