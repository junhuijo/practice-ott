package com.homechoice.ott.vod.ui.popup.adult

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.DialogAdultAuthBinding
import com.homechoice.ott.vod.model.popup.Phone
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.PhonePopupViewModel
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class AdultAuthPopupView(
    ctx: Context,
    phone: Phone,
    val event: PopupEvent
) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {
    private var binding: DialogAdultAuthBinding = DialogAdultAuthBinding.inflate(LayoutInflater.from(ctx))
    private var model: PhonePopupViewModel = PhonePopupViewModel(phone)
    private val dialog = this

    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding.apply {
            viewModel = model
        }

        setContentView(binding.root)

        val keyPadList: ArrayList<LinearLayout> =
            arrayListOf(
                binding.numDel, // 0 <-
                binding.num0, // 1
                binding.numOk, // 2
                binding.num1, // 3 <-
                binding.num2, // 4
                binding.num3, // 5
                binding.num4, // 6 <-
                binding.num5, // 7
                binding.num6, // 8
                binding.num7, // 9 <-
                binding.num8, // 10
                binding.num9  // 11
            )

        for (item in keyPadList) {
            item.setOnClickListener {
                pushKey(it)
            }
        }

        setOnKeyListener { _, kCode, kEvent ->
            val result = false
            Logger.Log(Log.DEBUG, this, "kCode:$kCode")
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                    }
                }
            }
            result
        }
        binding.num0.requestFocus()
    }

    private fun pushKey(view: View) {
        when (view.id) {
            binding.numOk.id -> okNumber()
            binding.numDel.id -> removeNumber()
            else ->
                appendNumber(view.tag as String)
        }
    }

    private fun appendNumber(num: String) {
        Logger.Log(Log.DEBUG, this, "appendNumber $num")
        var number = binding.regJoinNumber.text.toString()
        number += num
        binding.regJoinNumber.text = number
        binding.warnText.visibility = View.INVISIBLE
    }

    private fun removeNumber() {
        var numbers = binding.regJoinNumber.text
        if (numbers.isNotEmpty())
            numbers = numbers.substring(0, numbers.length - 1)
        binding.regJoinNumber.text = numbers
        binding.warnText.visibility = View.INVISIBLE
    }

    private fun okNumber() {
        val numbers = binding.regJoinNumber.text.toString()
        if (UIAgent.isValidCellPhoneNumber(numbers)) {
            MBSAgent.putMemberRegister(numbers, object : Callback<ResponseNoBody> {
                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                    context.let {
                        PopupAgent.showNormalPopup(
                            it,
                            PopupType.getErrorType(
                                TYPE.AUTH,
                                CODE.NONE
                            ),
                            object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    when (btn) {
                                        BtnLabel.OK -> {
                                            d.dismiss()
                                        }
                                    }
                                }
                            })
                    }
                }

                override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                    if (response.isSuccessful && response.body() != null) {
                        PopupAgent.showNormalPopup(context, PopupType.NormalPopupType.ADULT_AUTH, object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                Logger.Log(Log.DEBUG, this, "showNormalPopup btn:$btn")
                                d.dismiss()
                                event.onClick(dialog, btn)
                            }
                        })
                    } else {
                        val error = response.errorBody()?.let { MBSAgent.error(it) }
                        when (response.code()) {
                            401 -> binding.warnText?.visibility = View.VISIBLE
                        }
                        context.let {
                            PopupAgent.showNormalPopup(
                                it,
                                PopupType.getErrorType(
                                    TYPE.AUTH,
                                    response.code(),
                                    error?.errorString!!
                                ),
                                object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        when (btn) {
                                            BtnLabel.OK -> {
                                                d.dismiss()
                                            }
                                        }
                                    }
                                })
                        }
                    }
                }
            })
        } else {
            binding.warnText?.visibility = View.VISIBLE
        }
    }

}