package com.homechoice.ott.vod.ui.screens.home

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.foundation.PivotOffsets
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.TvLazyListState
import androidx.tv.foundation.lazy.list.TvLazyRow
import androidx.tv.foundation.lazy.list.items
import androidx.tv.foundation.lazy.list.itemsIndexed
import androidx.tv.foundation.lazy.list.rememberTvLazyListState
import coil.compose.AsyncImage
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.ActivityChangeAgent
import com.homechoice.ott.vod.agent.CategoryItemType
import com.homechoice.ott.vod.agent.EnterPath
import com.homechoice.ott.vod.agent.HomeScreens
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.model.home.CpItem

@SuppressLint("StateFlowValueCalledInComposition")
@Composable
fun MainCategories(
    categoryLists: List<CategoryList>,
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel,
    topFlag: Boolean,
    listState: TvLazyListState,
) {
    val rankIds = listOf(1266)
    val rankFlag by viewModel.rankFlag.collectAsState()

    TvLazyColumn(state = listState, pivotOffsets = PivotOffsets(0.07778f), contentPadding = PaddingValues(bottom = 18.dp)) {
//    TvLazyColumn(state = listState, pivotOffsets = PivotOffsets(0.1f), contentPadding = PaddingValues(bottom = 18.dp)) {
        categoryLists.forEachIndexed { index, categoryList ->
            if (categoryList.type.contains("banner", true)) {
                item { BannerSection(viewModel = viewModel) }
            } else if (categoryList.id in rankIds) {
                item { RankingCategory(categoryList = categoryList, columnIndex = index, viewModel = viewModel) }
            }
            else if (categoryList.title.contains("좋아할만한 콘텐츠")) {
                // 추천 컨텐츠 제외
            } else {
                item { CommonCategory(categoryList = categoryList, columnIndex = index  , viewModel = viewModel) }
            }
        }
    }
    if(topFlag){
        LaunchedEffect(Unit) {
            listState.scrollToItem(0)
            viewModel.topFlagToggle(false)
        }
    }

    if(rankFlag && viewModel.homeScreenLaunchedEffectCompleted.value){
        LaunchedEffect(Unit) {
            val rankIndex = categoryLists.indexOfFirst { it.id in rankIds }
            listState.scrollToItem(rankIndex)
        }
    }
}

@Composable
fun CommonCategory(
    categoryList: CategoryList? = null,
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel,
    columnIndex: Int = -1
) {
    val focusRequester = remember { FocusRequester() }
    Column(modifier = Modifier.height(270.dp)) {
        if (categoryList != null) {
            CategoryTitle(
                title = categoryList.title,
                viewModel = viewModel,
                categoryList = categoryList
            )
            TvLazyRow(
                horizontalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.home_category_poster_gap)),
                pivotOffsets = PivotOffsets(0f)
//                pivotOffsets = PivotOffsets(0.36f)
            ) {
                itemsIndexed(categoryList.categoryItemList) { index,item ->
                    CategoryItemImage(categoryItem = item,
                        enterPath = EnterPath.MAIN_CATEGORY,
                        focusRequester = focusRequester,
                        colIndex = columnIndex,
                        rowIndex = index,
                        viewModel = viewModel,
                        modifier = modifier.let { modifier ->
                            if (columnIndex==0 && index==0){
                                modifier.focusRequester(focusRequester)
                            } else {
                                modifier
                            }
                        })
                }
                item {
                    Spacer(modifier = Modifier.padding(end = 130.dp))
                }
            }
        }
    }
}

@Composable
fun CategoryIcon(
    viewModel: HomeViewModel,
    categoryList: CategoryList
) {
    val cpList = viewModel.cpList
    val cpIconMap = mapOf(
        364 to R.drawable.cp_jtbc,
        365 to R.drawable.cp_tvchosun_new2,
        378 to R.drawable.cp_channel_a_new,
        362 to R.drawable.cp_mbn_new,
        361 to R.drawable.cp_ebs_new
    )

    val cpId = cpList.find { cp ->
        val titleWithoutSuffix = categoryList.title
            .removeSuffix(" 모아보기")
            .replace(" ", "_")
        cp.name.equals(titleWithoutSuffix, ignoreCase = true)
    }?.id
//    val cpId = cpList.find { it.name == categoryList.title.lowercase().replace(" ", "_") }?.id
    if (cpId != null && cpIconMap.containsKey(cpId)) {
        Box(
            modifier = Modifier
                .width(20.dp)
                .height(22.dp)
                .padding(bottom = 2.dp)
        ) {
            Image(
                painter = painterResource(cpIconMap[cpId]!!),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        color = Color(0xFFEBEBEB),
                        shape = RoundedCornerShape(dimensionResource(R.dimen.icon_corner_radius))
                    )
                    .clip(shape = RoundedCornerShape(dimensionResource(R.dimen.icon_corner_radius)))
                    .then(if (cpId == 378 || cpId == 361) Modifier.padding(1.dp) else Modifier)
            )
        }
    }
}

@Composable
fun CategoryTitle(
    title: String = "",
    viewModel: HomeViewModel,
    categoryList: CategoryList,
) {
    Row(
        modifier = Modifier.padding(
            top = 20.dp,
//            top = dimensionResource(R.dimen.home_category_gap),
            start = dimensionResource(R.dimen.home_category_title_margin_start),
//            bottom = dimensionResource(R.dimen.home_category_title_margin_bottom)
            bottom = 8.dp
        ),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.home_category_icon_title_spacing))
    ) {
        CategoryIcon(viewModel, categoryList)
        BasicText(
            text = title,
            style = TextStyle(
                fontSize = 20.sp,
                color = Color(0xFFEBEBEB),
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif
            ),
        )
    }
}

@Composable
fun RankingCategory(
    categoryList: CategoryList? = null,
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel,
    columnIndex: Int = -1
) {
    val focusRequester = remember { FocusRequester() }

    val rankFlag by viewModel.rankFlag.collectAsState()
    val homeScreenLaunchedEffectCompleted by viewModel.homeScreenLaunchedEffectCompleted.collectAsState()
    Column(
        modifier = Modifier.height(270.dp)
    ) {
        if (categoryList != null) {
            CategoryTitle(
                categoryList.title,
                viewModel = viewModel,
                categoryList = categoryList
            )
            TvLazyRow(
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                pivotOffsets = PivotOffsets(0.055f)
//                pivotOffsets = PivotOffsets(0.300f)
            ) {
                itemsIndexed(categoryList.categoryItemList.take(10)) {index, item ->
                    Box {
                        val context = LocalContext.current
                        val paddingValue = if (index == 0) 34.dp else 10.dp
                        val resourceId = context.resources.getIdentifier("_${index + 1}","drawable", context.packageName)
                        CategoryItemImage(
                            categoryItem = item,
                            enterPath = EnterPath.MAIN_CATEGORY,
                            colIndex = columnIndex,
                            rowIndex = index,
//                            focusRequester = focusRequester,
                            focusRequester = viewModel.rankFocusRequester,
                            viewModel = viewModel,
                            modifier = Modifier
                                .padding(start = dimensionResource(R.dimen.home_category_rank_poster_margin_start))
                                .let { modifier ->
                                    if (index == 0) {
                                        modifier.focusRequester(viewModel.rankFocusRequester)
                                    } else {
                                        modifier
                                    }
                                }
                        )
                        Box(
                            modifier
                                .height(68.dp)
                                .align(Alignment.BottomStart)
                                .padding(start = paddingValue)) {
                            Image(
                                painter = painterResource(resourceId),
                                contentDescription = null,
                            )
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.padding(end = 52.dp))
                }
            }
        }
    }
    if (rankFlag){
        LaunchedEffect(Unit) {
            if (homeScreenLaunchedEffectCompleted) {
                viewModel.rankFocusRequester.requestFocus()
                viewModel.rankFlagToggle()
                viewModel.setHomeScreenLaunchedEffectCompleted(false)
                viewModel.setRankScrollComplete(true)
            }
        }
    }
}

@Composable
fun CategoryItemImage(
    categoryItem: CategoryItem,
    enterPath: String,
    colIndex: Int = -1,
    rowIndex: Int = -1,
    viewModel: HomeViewModel,
    focusRequester: FocusRequester,
    modifier: Modifier = Modifier
) {
    var borderColor by remember { mutableStateOf(Color.Transparent) }
    val context = LocalContext.current
    val topFlag by viewModel.topFlag.collectAsState()

    AsyncImage(
        model = categoryItem.posterUrl,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier
            .onFocusChanged { borderColor = if (it.hasFocus) Color.Red else Color.Transparent }
            .clickable {
                when (categoryItem.type) {
                    CategoryItemType.CONTENTGROUP -> {
                        ActivityChangeAgent.goToContent(
                            ctx = context,
                            contentGroupId = categoryItem.id,
                            enterPath = enterPath,
                            callback = null
                        )
                    }

                    CategoryItemType.SERIES -> {
                        ActivityChangeAgent.goToSeriesContent(
                            context = context,
                            id = categoryItem.id,
                            episodeNo = 0,
                            enterPath = enterPath,
                            callback = null
                        )
                    }
                }
            }
            .focusable()
            .size(
                width = 142.dp,
                height = 204.dp
            )
            .border(
                BorderStroke(dimensionResource(R.dimen.border_width), color = borderColor),
                RoundedCornerShape(dimensionResource(R.dimen.corner_radius))
            )
            .clip(RoundedCornerShape(dimensionResource(R.dimen.corner_radius)))
    )

    if (colIndex == 0 && rowIndex == 0 && topFlag){
        LaunchedEffect(Unit) {
            focusRequester.requestFocus()
            viewModel.topFlagToggle()
        }
    }
}