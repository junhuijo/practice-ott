package com.homechoice.ott.vod.ui.my.member

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.ui.navigation.navigator.KeyPadNavigator
import com.homechoice.ott.vod.ui.navigation.navigator.PageNavigatorModel


class ChangeUserInfoViewModel : ViewModel() {
    enum class FocusType {
        KEYPAD, RESIGN
    }

    private lateinit var listener: ModelListener

    private var focusType = FocusType.KEYPAD

    var invalidInfo: MutableLiveData<Boolean> = MutableLiveData()

    var keyPadNavigator = KeyPadNavigator(0, 0, 12, 3, object : PageNavigatorModel.Callback {
        override fun init(index: Int) {

        }

        override fun pageStartIndexChanged() {

        }

        override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
            if (::listener.isInitialized) {
                with(listener) {
                    focusChanged(
                        previousIndex = previousIndex,
                        index = index,
                        pageStartIndex = pageStartIndex
                    )
                }
            }
        }

    })

    fun up() {
        if (focusType == FocusType.KEYPAD) {
            keyPadNavigator.up()
        } else if (focusType == FocusType.RESIGN) {
            this.focusType = FocusType.KEYPAD
            with(listener) {
                focusChanged(
                    previousIndex = keyPadNavigator.currentIndex,
                    index = keyPadNavigator.currentIndex,
                    pageStartIndex = keyPadNavigator.pageStartIndex
                )
            }
        }

    }

    fun down() {
        if (focusType == FocusType.KEYPAD) {
            if (keyPadNavigator.currentIndex + keyPadNavigator.pageSize < keyPadNavigator.totalSize) {
                keyPadNavigator.down()
            } else {
                this.focusType = FocusType.RESIGN
                listener.focusResign()
            }
        }
    }

    fun left() {
        if (focusType == FocusType.KEYPAD) {
            if (keyPadNavigator.currentIndex == keyPadNavigator.pageStartIndex) {
                listener.back()
            } else {
                keyPadNavigator.left()
            }
        } else {
            listener.back()
        }
    }

    fun right() {
        if (focusType == FocusType.KEYPAD)
            keyPadNavigator.right()
    }

    fun enter() {
        if (focusType == FocusType.KEYPAD)
            this.listener.select(keyPadNavigator.currentIndex)
        else if (focusType == FocusType.RESIGN) {
            this.listener.selectResign()
        }
    }

    fun setListener(listener: ModelListener) {
        this.listener = listener
    }

    interface ModelListener {
        fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int)
        fun select(index: Int)
        fun selectResign()
        fun focusResign()
        fun back()
    }


}

