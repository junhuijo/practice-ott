package com.homechoice.ott.vod.ui.popup.play

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SeriesExitPopupModel : ViewModel(){
    var posterUrl: MutableLiveData<String> = MutableLiveData()
    var title : MutableLiveData<String> = MutableLiveData()

}