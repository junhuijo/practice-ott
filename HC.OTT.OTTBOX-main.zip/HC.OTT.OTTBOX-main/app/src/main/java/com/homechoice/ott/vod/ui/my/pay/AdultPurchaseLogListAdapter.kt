package com.homechoice.ott.vod.ui.my.pay

import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.ItemMyAdultPurchaseLogListBinding
import com.homechoice.ott.vod.model.purchaseLog.PurchaseLog
import com.homechoice.ott.vod.util.Logger

class AdultPurchaseLogListAdapter(var logListLayout: LinearLayout, private var items: ArrayList<PurchaseLog>, private val actionHandler: Handler) {

    private var viewList: ArrayList<ViewHolder> = arrayListOf()

    init {
        Logger.Log(Log.DEBUG, this, "onBindViewHolder init : ${items.size}")

        for (index in items.indices) {
            onBindViewHolder(onCreateViewHolder(logListLayout, index), index)
        }
        if (viewList.size > 0)
            actionHandler.obtainMessage(0, 0, 0, viewList[0]).sendToTarget()
    }

    private fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.apply {
            bind(item.build())
        }
        viewList.add(holder)
        logListLayout.addView(holder.binding.root)
    }

    fun focus(cur: Int, pre: Int) {
        Logger.Log(Log.ERROR, this, "focus cur $cur / pre $pre")
        viewList[cur].focus()
        if (pre > -1)
            viewList[pre].unfocus()
    }

    fun unfocus(cur: Int) {
        viewList[cur].unfocus()
    }

    fun removeItem(index: Int) {
        items.removeAt(index)
        viewList.removeAt(index)
        logListLayout.removeViewAt(index)
        actionHandler.obtainMessage(2).sendToTarget()
    }

    private fun onCreateViewHolder(parent: ViewGroup, index: Int): ViewHolder {
        val binding = ItemMyAdultPurchaseLogListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding, actionHandler, index)
    }

    class ViewHolder(val binding: ItemMyAdultPurchaseLogListBinding, private val actionHandler: Handler, val index: Int) {
        lateinit var purchaseLog: PurchaseLog
        fun bind(item: PurchaseLog) {
            purchaseLog = item
            binding.apply {
                log = PurchaseLogViewModel(item)
            }
            if (purchaseLog.productType == "buy") {
                binding.btnCancel.visibility = View.GONE
            } else if (purchaseLog.productType == "subscription") {
                binding.btnDetail.visibility = View.GONE
            } else {
                binding.btnCancel.visibility = View.VISIBLE
            }

            binding.executePendingBindings()
        }

        fun focus() {
            Logger.Log(Log.DEBUG, this, "focus adapterPosition $index")
            binding.itemMyPurchaseLogLayout.setBackgroundResource(R.drawable.list_focus)

            actionHandler.obtainMessage(0, index, 0, this).sendToTarget()
        }

        fun unfocus() {
            Logger.Log(Log.DEBUG, this, "unfocus adapterPosition $index")
            binding.itemMyPurchaseLogLayout.setBackgroundResource(R.color.transparent)
        }

        fun select() {
            Logger.Log(Log.DEBUG, this, "select")
            binding.itemMyPurchaseLogLayout.isSelected = true
            binding.itemMyPurchaseLogBtnLayout.visibility = View.VISIBLE
            actionHandler.obtainMessage(1).sendToTarget()
        }

        fun unSelect() {
            Logger.Log(Log.DEBUG, this, "unSelect")
            binding.itemMyPurchaseLogLayout.isSelected = false
            binding.itemMyPurchaseLogBtnLayout.visibility = View.INVISIBLE
        }
    }

}