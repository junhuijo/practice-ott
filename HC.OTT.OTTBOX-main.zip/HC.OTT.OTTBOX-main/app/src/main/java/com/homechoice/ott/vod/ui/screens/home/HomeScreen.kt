@file:OptIn(ExperimentalFoundationApi::class)

package com.homechoice.ott.vod.ui.screens.home

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.foundation.lazy.list.TvLazyListState
import androidx.tv.foundation.lazy.list.rememberTvLazyListState
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.ActivityChangeAgent
import com.homechoice.ott.vod.agent.Categories
import com.homechoice.ott.vod.agent.CategoryWrapper
import com.homechoice.ott.vod.agent.ContentsProvider
import com.homechoice.ott.vod.agent.HomeScreens
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.ui.screens.adultpassqrscan.AdultQrScreen
import com.homechoice.ott.vod.ui.screens.adultpassqrscanfail.AdultQrFailScreen
import com.homechoice.ott.vod.ui.screens.ContentFilter
import com.homechoice.ott.vod.ui.screens.home.dialogs.HomeAdultVerificationDialog
import com.homechoice.ott.vod.ui.screens.home.dialogs.PopupHandler
import com.homechoice.ott.vod.ui.screens.home.dialogs.QuitAppDialog
import kotlinx.coroutines.delay

@SuppressLint("ResourceType", "StateFlowValueCalledInComposition")
@Composable
fun HomeScreen(
    viewModel: HomeViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val isMenuExpanded by viewModel.isMenuExpanded.collectAsState()// 메뉴 확장 상태를 추가
    val listState = rememberTvLazyListState()

    val topFlag by viewModel.topFlag.collectAsState()
    var isLoading by remember { mutableStateOf(false) }
    val isRankScrollComplete by viewModel.isRankScrollComplete.collectAsState()
    val popupState by viewModel.popupState.collectAsState()

    // 키즈락, 성인 콘텐츠
    val adultContentState by viewModel.adultContentState.collectAsState()
    val currentScreen by viewModel.uiState.collectAsState()

    val showAdultPasswordDialog by viewModel.showAdultPasswordDialog.collectAsState()
    val isAdultUser = ContentFilter.isAdultUser()

    fun onClickNavIcon(resource: Int) {
        if (resource == R.drawable.icon_nav_top10 && currentScreen.currentScreen != HomeScreens.Main) {
            isLoading = true
            viewModel.onClickNavIcon(resource)
        } else {
            viewModel.onClickNavIcon(resource)
        }
    }

    Box(
        modifier = Modifier
            .background(color = Color.Black)
            .fillMaxSize()
    ) {
        when (uiState.currentScreen) {
            HomeScreens.Main, HomeScreens.Category, HomeScreens.Cp, HomeScreens.CategoryAdult -> {
                Row {
                    NavMenu(
                        viewModel = viewModel,
                        isMenuExpanded = isMenuExpanded,
                        onClickNavIcon = ::onClickNavIcon,
                        topFlag = topFlag
                    )
                    if(viewModel.getCategoryList().isNullOrEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(540.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.width(64.dp),
                                color = colorResource(R.color.kids_lock_notification_text),
                                strokeWidth = 4.dp,
                            )
                        }
                    }
                    Nav(
                        currentScreen = uiState.currentScreen,
                        categoryLists = viewModel.getCategoryList(),
                        isCategoryDrawerVisible = viewModel.isCategoryDrawerVisible.collectAsState().value,
                        listState = listState,
                        topFlag = topFlag,
                        viewModel = viewModel
                    )
                }
            }
            HomeScreens.AdultQr -> {
                AdultQrScreen(
                    onNavigateBack = { viewModel.navigateFromHome() }
                )
            }
            HomeScreens.AdultQrFail -> {
                AdultQrFailScreen(
                    onConfirm = { viewModel.navigateFromAdultQr() }
                )
            }
        }
    }
    QuitAppDialog(viewModel = viewModel)

    if (isLoading) {
        Box(
            modifier = Modifier
                .padding(start = 110.dp)
                .fillMaxWidth()
                .height(540.dp)
                .background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator(
                modifier = Modifier.width(64.dp),
                color = colorResource(R.color.kids_lock_notification_text),
                strokeWidth = 4.dp,
            )
        }
    }

    if (showAdultPasswordDialog) {
        HomeAdultVerificationDialog()
    }

    PopupHandler(
        popupState = popupState,
        onDismiss = {
            viewModel.dismissPopup()
            viewModel.navCategoryFocusRequester.requestFocus()
        },
        onConflictLogin = {
            viewModel.onConflictLogin(
                context,
                onDismiss = { viewModel.dismissPopup() }
            )
        }
    )

    DisposableEffect(showAdultPasswordDialog) {
        onDispose {
            if (!showAdultPasswordDialog) {
                viewModel.navCategoryFocusRequester.requestFocus()
            }
        }
    }

    LaunchedEffect(adultContentState, currentScreen.currentScreen) {
        viewModel.updateAdultContentVisibility()
        viewModel.setHomeScreenLaunchedEffectCompleted(true)
    }
    LaunchedEffect(isRankScrollComplete) {
        isLoading = false
        viewModel.setRankScrollComplete(false)
    }

    if (currentScreen.currentScreen == HomeScreens.CategoryAdult) {
        LaunchedEffect(adultContentState.includeRrated, isAdultUser) {
            if (!adultContentState.includeRrated || !isAdultUser) {
                viewModel.updateCurrentScreen(HomeScreens.Main)
            }
        }
    }
}

@Composable
fun NavMenu(
    viewModel: HomeViewModel,
    isMenuExpanded: Boolean,
    onClickNavIcon: (Int) -> Unit,
    topFlag: Boolean
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(dimensionResource(R.dimen.nav_width))
            .background(color = Color.Black)
            .padding(
                start = dimensionResource(R.dimen.nav_icon_padding_start),
                top = dimensionResource(R.dimen.nav_icon_padding_top)
            )
    ) {
        val icons = listOf(
            R.drawable.icon_nav_profile,
            R.drawable.icon_nav_search,
            R.drawable.icon_nav_home,
            R.drawable.icon_nav_vod,
            R.drawable.icon_nav_top10
//            신규 아이콘 추가 : 탑텐 (기존) / 찜 (신규) / 시청 (신규)
//            R.drawable.icon_nav_wish,
//            R.drawable.icon_nav_servicelog
        )

        NavIcon(drawableRes = icons[0], onClick = { ActivityChangeAgent.goToMyMenu(ctx = context) })
        Spacer(modifier = Modifier.height(dimensionResource(R.dimen.nav_icon_padding_top)))
        NavIcon(drawableRes = icons[1], onClick = { ActivityChangeAgent.goToSearchMenu(ctx = context) })
        Spacer(modifier = Modifier.height(dimensionResource(R.dimen.nav_icon_padding_top)))
        NavIcon(drawableRes = icons[2], onClick = { onClickNavIcon(icons[2]) }, modifier = Modifier.focusRequester(viewModel.navHomeFocusRequester))
        Spacer(modifier = Modifier.height(dimensionResource(R.dimen.nav_icon_padding_top)))
        NavIcon(drawableRes = icons[3], onClick = { onClickNavIcon(icons[3]) }, modifier = Modifier.focusRequester(viewModel.navCategoryFocusRequester))
        Spacer(modifier = Modifier.height(dimensionResource(R.dimen.nav_icon_padding_top)))
        NavIcon(drawableRes = icons[4], onClick = { onClickNavIcon(icons[4]) })
        Spacer(modifier = Modifier.height(dimensionResource(R.dimen.nav_icon_padding_top)))
    }
    LaunchedEffect(Unit) {
        viewModel.navHomeFocusRequester.requestFocus()
    }
}

@Composable
fun NavIcon(
    drawableRes: Int,
    onClick: (Int) -> Unit,
    viewModel: HomeViewModel = viewModel(),
    modifier: Modifier = Modifier) {
    var backgroundColor by remember { mutableStateOf(Color.Transparent) }

    Box(
        modifier = modifier
            .size(dimensionResource(R.dimen.nav_icon_height))
            .onFocusChanged {
                backgroundColor = if (it.hasFocus) Color(0x33D9D9D9) else Color.Transparent
                if (it.hasFocus && viewModel.isCategoryDrawerVisible.value) {
                    viewModel.closeCategoryDrawer()
                    viewModel.navCategoryFocusRequester.requestFocus()
                }
            }
            .background(color = backgroundColor, RoundedCornerShape(10))
            .clickable {
                onClick(drawableRes)
            }
    ) {
        Image(
            painter = painterResource(id = drawableRes),
            contentDescription = null,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun Nav(
    currentScreen: HomeScreens,
    categoryLists: List<CategoryList>,
    isCategoryDrawerVisible: Boolean,
    viewModel: HomeViewModel,
    listState: TvLazyListState,
    topFlag: Boolean,
    modifier: Modifier = Modifier
) {
    Box {
        MainCategories(
            categoryLists = categoryLists,
            listState = listState,
            topFlag = topFlag,
            viewModel = viewModel
        )
        if (isCategoryDrawerVisible){
            VerticalDrawerItems(viewModel = viewModel)
        }
    }
}


@Composable
fun VerticalDrawerItems(
    viewModel: HomeViewModel,
    modifier: Modifier = Modifier
) {
    val isAdultUser = ContentFilter.isAdultUser()
    val isSpecificMsoName = ContentFilter.isSpecificMsoName()
    val adultContentState by viewModel.adultContentState.collectAsState()

    val items = listOfNotNull(
        CategoryWrapper.RegularCategory(Categories.Movie),
        if (isAdultUser && adultContentState.includeRrated && !isSpecificMsoName) CategoryWrapper.RegularCategory(Categories.Adult) else null,
        CategoryWrapper.RegularCategory(Categories.BroadCast),
        CategoryWrapper.RegularCategory(Categories.OverseasDrama),
        CategoryWrapper.RegularCategory(Categories.KidAnime),
        CategoryWrapper.RegularCategory(Categories.Life),
        CategoryWrapper.RegularCategory(Categories.Documentary),
        CategoryWrapper.CpCategory(ContentsProvider.Cp),
    )

    val screenWidth = with(LocalDensity.current) { LocalConfiguration.current.screenWidthDp.dp } / 5
    val screenHeight = with(LocalDensity.current) { LocalConfiguration.current.screenHeightDp.dp } / items.size
    val context = LocalContext.current


    Column(
        modifier = modifier
    ) {
        items.forEachIndexed { index, item ->
            var backgroundColor by remember { mutableStateOf(Color.Black) }
            Text(
                text = when(item) {
                    is CategoryWrapper.RegularCategory -> stringResource(getCategoryStringResource(item.category))
                    is CategoryWrapper.CpCategory -> stringResource(getSpecialCategoryStringResource(item.contentsProvider))
                },
                fontSize = with(LocalDensity.current) { dimensionResource(R.dimen.sub_navigation_item_text_size).toSp() },
                color = Color.White,
                modifier = Modifier
                    .width(screenWidth)
                    .height(screenHeight)
                    .background(backgroundColor)
                    .onFocusChanged {
                        backgroundColor = if (it.hasFocus) Color.Red else Color.Black
                    }
                    .focusable()
                    .let { modifier ->
                        if (index == 0) {
                            modifier.focusRequester(viewModel.navExpandFocusRequester)
                        } else {
                            modifier
                        }
                    }
                    .fillMaxHeight()
                    .wrapContentHeight(Alignment.CenterVertically)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        when (item) {
                            is CategoryWrapper.RegularCategory -> {
                                if (item.category == Categories.Adult) {
                                    viewModel.completeAdultVerification(
                                        context,
                                        onSuccess = {
                                            viewModel.checkAndShowAdultVerification()
                                        },
                                        onFailure = {
                                            viewModel.navigateFromAdultQr()
                                        },
                                    )
                                } else {
                                    viewModel.fetchCategory(item.category)
                                }
                            }

                            is CategoryWrapper.CpCategory -> {
                                viewModel.fetchAllCpItems()
                            }
                        }
                    },
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier
                .width(screenWidth)
                .height(dimensionResource(R.dimen.sub_navigation_bottom_line_width))
                .background(Color.White)
            )
        }

        LaunchedEffect(Unit) {
            delay(100)
            viewModel.navExpandFocusRequester.requestFocus()
        }
    }
}

// 카테고리에 따른 문자열 리소스 ID를 반환하는 함수
// 기존 카테고리
@Composable
private fun getCategoryStringResource(category: Categories): Int {
    return when (category) {
        Categories.Movie -> R.string.category_movie
        Categories.BroadCast -> R.string.category_broadcast
        Categories.OverseasDrama -> R.string.category_overseas_drama
        Categories.KidAnime -> R.string.category_kid_anime
        Categories.Life -> R.string.category_life
        Categories.Documentary -> R.string.category_documentary
        Categories.Adult -> R.string.category_adult
    }
}
// CP
@Composable
private fun getSpecialCategoryStringResource(contentsProvider: ContentsProvider): Int {
    return when (contentsProvider) {
        ContentsProvider.Cp -> R.string.category_cp
    }
}

@Preview(device = "id:tv_1080p")
@Composable
fun PreviewContentScreen(
) {
    HomeScreen()
}