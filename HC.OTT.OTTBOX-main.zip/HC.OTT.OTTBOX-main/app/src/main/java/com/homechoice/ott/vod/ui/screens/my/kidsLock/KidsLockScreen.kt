package com.homechoice.ott.vod.ui.screens.my.kidsLock

import KeypadLayout
import android.annotation.SuppressLint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.homechoice.ott.vod.R

@SuppressLint("StateFlowValueCalledInComposition")
@Composable
fun KidsLockScreen(
    viewModel: KidsLockViewModel = viewModel()
) {
    val adultContentState by viewModel.adultContentState.collectAsState()
    val alertMessage by viewModel.alertMessage.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(color = colorResource(R.color.dialog_background)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            KidsLockScreenTitleBar()
            Spacer(modifier = Modifier.height(58.dp))
            Row {
                KeypadLayout(
                    onInputClick = { char -> viewModel.inputPassword(char) },
                    onDeleteClick = { viewModel.deletePassword() },
                    onConfirmClick = { viewModel.checkPassword() })
                Spacer(modifier = Modifier.width(76.dp))
                PasswordInputLayout(alertMessage = alertMessage, viewModel = viewModel)
            }
        }
    }
}

@Composable
private fun KidsLockScreenTitleBar() {
    Box(
        modifier = Modifier
            .width(dimensionResource(R.dimen.screen_title_bar_width))
            .height(dimensionResource(R.dimen.screen_title_bar_height))
            .background(
                color = colorResource(R.color.kids_lock_notification_text),
                shape = RoundedCornerShape(dimensionResource(R.dimen.corner_radius))
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = stringResource(R.string.kids_lock_title),
            style = TextStyle(
                fontSize = 26.sp,
                color = colorResource(R.color.kids_lock_text)
            )
        )
    }
}

@Composable
private fun PasswordInputLayout(
    alertMessage: Message?,
    viewModel: KidsLockViewModel
) {
    val passwordInputSpacing = 10.dp

    Column(
        modifier = Modifier
            .padding(top = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.kids_lock_content1),
            modifier = Modifier.padding(bottom = 8.dp),
            style = TextStyle(
                fontSize = 20.sp,
                color = colorResource(R.color.kids_lock_text),
                textAlign = TextAlign.Center
            )
        )
        Text(
            text = stringResource(R.string.kids_lock_content2),
            modifier = Modifier.padding(bottom = 36.dp),
            style = TextStyle(
                fontSize = 16.sp,
                color = colorResource(R.color.kids_lock_text),
                textAlign = TextAlign.Center
            )
        )
        Box(
            modifier = Modifier
                .padding(bottom = 24.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            PasswordInputFields(passwordInputSpacing, viewModel)
            AlertMessageDisplay(alertMessage)
        }
        KidsLockIndicator(viewModel)
    }
}

@Composable
private fun PasswordInputFields(
    spacing: Dp,
    viewModel: KidsLockViewModel
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(spacing)
    ) {
        repeat(4) {index ->
            PasswordInputField(
                index = index,
                viewModel = viewModel
            )
        }
    }
}

@Composable
private fun PasswordInputField(
    index: Int,
    viewModel: KidsLockViewModel
) {
    val inputText = if (index < viewModel.inputPassword.size) "*" else ""

    Box(
        modifier = Modifier
            .width(56.dp)
            .height(56.dp)
            .background(
                color = Color.White,
                shape = RoundedCornerShape(dimensionResource(R.dimen.icon_corner_radius))
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = inputText,
            style = TextStyle(
                fontSize = 30.sp,
                color = Color.Black
            )
        )
    }
}

@Composable
private fun KidsLockIndicator(
    viewModel: KidsLockViewModel
) {
    val isKidsLockEnabled by viewModel.isKidsLockEnabled.collectAsState()

    ToggleIndicator(
        text = if (isKidsLockEnabled) stringResource(R.string.kids_lock_on) else stringResource(R.string.kids_lock_off),
        backgroundColor = if (isKidsLockEnabled) colorResource(R.color.kids_lock_toggle_off) else colorResource(R.color.kids_lock_toggle_on),
        textColor = Color.White,
        shape = RoundedCornerShape(40.dp),
        translateX = if(isKidsLockEnabled) 240f else -240f
    )
}

@Composable
private fun ToggleIndicator(
    text: String,
    backgroundColor: Color,
    textColor: Color,
    shape: RoundedCornerShape,
    translateX: Float
) {
    Box(
        modifier = Modifier
            .width(300.dp)
            .height(56.dp)
            .background(color = backgroundColor, shape = shape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            translate(left = translateX, top = 0f) {
                scale(0.8f, 0.8f) {
                    drawCircle(
                        color = Color(0xFFD9D9D9),
                    )
                }
            }
        }
        Text(
            text = text,
            style = TextStyle(
                fontSize = 32.sp,
                color = textColor
            )
        )
    }
}

@Composable
fun AlertMessageDisplay(message: Message?) {
    val context = LocalContext.current
    val messageText = when (message) {
        Message.KidsLockOn -> stringResource(R.string.kids_lock_message_on)
        Message.KidsLockOff -> stringResource(R.string.kids_lock_message_off)
        Message.PasswordMismatch -> stringResource(R.string.kids_lock_message_pw_mismatch)
        Message.InvalidPasswordFormat -> stringResource(R.string.kids_lock_message_pw_invalid_format)
        null -> ""
    }

    val text = messageText.ifEmpty { stringResource(R.string.kids_lock_popup) }

    Text(
        text = text,
        modifier = Modifier
            .width(300.dp)
            .padding(top = 80.dp)
            .background(Color.Transparent),
        style = TextStyle(
            fontSize = 18.sp,
            color = if (messageText.isNotEmpty()) colorResource(R.color.kids_lock_notification_text) else Color.Transparent,
            textAlign = TextAlign.Center
        )
    )
}

@Preview(device = "id:tv_1080p")
@Composable
fun Preview() {
    KidsLockScreen()
}