package com.homechoice.ott.vod.ui.sub

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.ScrollView
import androidx.core.view.isVisible
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.ui.navigation.view.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.sub.SubCategoryActivity.ActionType.UNFOCUS
import com.homechoice.ott.vod.ui.sub.mainCategory.SubMainCategoryView
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SubCategoryListFragment(
    private val navigationController: NavigationController,
    var actionEventHandler: Handler
) :
    NavigationView2() {
    var listViewLayout: LinearLayout? = null
    lateinit var scrollview: ScrollView
    private lateinit var searchIcon: ImageView
    private lateinit var myIcon: ImageView
    private lateinit var arrowImage: ImageView
    private lateinit var notiIcon: ImageView
    var categoryViewList = mutableMapOf<Int, SubMainCategoryView?>()
    var indicatorLayout: RelativeLayout? = null
    var isMyMenuBack = false
    var isLoading = true
    var isMyMenuIconBack = false

    @SuppressLint("InflateParams")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_home_category_list, null)
        listViewLayout = view?.findViewById(R.id.home_category_list)
        scrollview = view?.findViewById(R.id.home_category_list_scrollview)!!
        myIcon = view.findViewById(R.id.home_icon_my)
        searchIcon = view.findViewById(R.id.home_icon_search)
        arrowImage = view.findViewById(R.id.arr_down)

        notiIcon = view.findViewById(R.id.icon_point_noti)
        notiIcon.visibility = if (STBAgent.hasPointNoti) View.VISIBLE else View.INVISIBLE

        indicatorLayout?.visibility = View.GONE

        val list = navigationController.getDataList() as ArrayList<*>

        val event: NavigationEvent = object :
            NavigationEvent {
            override fun rightLineChange(position: Int) {
                Logger.Log(Log.DEBUG, this, "rightLineChange position: $position")

                if (position < 9999) {
                    if (!categoryViewList.containsKey(position)) {
                        val categoryView: SubMainCategoryView? = context?.let { SubMainCategoryView(it, list[position] as CategoryList) }
                        categoryViewList[position] = categoryView
                        listViewLayout?.addView(categoryView)
                    }
                } else {
                    if (!categoryViewList.containsKey(position)) {
                        val categoryView: SubMainCategoryView? =
                            context?.let { SubMainCategoryView(it) }
                        categoryViewList[position] = categoryView
                        listViewLayout?.addView(categoryView)
                    }
                }
                UIAgent.smoothScrollDxBy(scrollview, R.dimen.home_category_move_height, true)
            }

            override fun lastLineChange() {
                Logger.Log(Log.DEBUG, this, "lastLineChange")
                UIAgent.smoothScrollDxBy(scrollview, R.dimen.home_category_move_height, true)
            }

            override fun leftLineChange() {
                Logger.Log(Log.DEBUG, this, "leftLineChange")
                UIAgent.smoothScrollDxBy(scrollview, R.dimen.home_category_move_height, false)
            }

            override fun firstLineChange() {
                Logger.Log(Log.DEBUG, this, "firstLineChange")
                UIAgent.smoothScrollDxBy(scrollview, R.dimen.home_category_move_height, false)
            }

            override fun focusChange() {
                Logger.Log(Log.DEBUG, this, "focusChange")
                if (controller.getPreIndex() >= 0) {
                    categoryViewList[controller.getPreIndex()]?.unfocus()
                    categoryViewList[controller.getCurIndex()]?.focus()
                }
                if (controller.getTotalCount() > controller.getVisibleThreshold()) {
                    if (controller.isLastItem())
                        arrowImage.visibility = View.INVISIBLE
                    else
                        arrowImage.visibility = View.VISIBLE
                }
            }

            override fun addEmptyRow() {
                Logger.Log(Log.DEBUG, this, "addEmptyRow")
                smoothScrollDxBy(true)
            }

            override fun lineChange(isDown: Boolean) {
                smoothScrollDxBy(isDown)
            }
        }

        setNavigationController(navigationController)
        setEvent(event)


        for (index in list.indices) {
            val categoryView = SubMainCategoryView(context!!, list[index] as CategoryList)
            categoryViewList[index] = categoryView
            listViewLayout?.addView(categoryView)
            categoryView.unfocus()
        }

        return view
    }

    override fun onResume() {
        super.onResume()
        if (isMyMenuBack) {
            isMyMenuBack = false
        } else {
            GlobalScope.launch(Dispatchers.Main) {
                delay(500)
                scrollview.smoothScrollBy(
                    0,
                    CMBApp.RES.getDimensionPixelSize(R.dimen.home_category_move_height) * (controller.getStartIndex())
                )
                categoryViewList[controller.getCurIndex()]?.selectedFocus()

                if (controller.getTotalCount() > controller.getVisibleThreshold()) {
                    if (controller.isLastItem())
                        arrowImage.visibility = View.INVISIBLE
                    else
                        arrowImage.visibility = View.VISIBLE
                }
            }
        }
        isLoading = false
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.INFO, this, "onKeyDown keyCode : $keyCode")
        var result = false
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (myIcon.hasFocus() || searchIcon.hasFocus()) {
                    myIcon.clearFocus()
                    searchIcon.clearFocus()
                    categoryViewList[controller.getCurIndex()]?.focus()
                    val category = getCategory()
                    checkAdultCategory(category)
                    isMyMenuIconBack = true
                    result = true
                } else {
                    if (controller.increase()) {
                        val category = getCategory()
                        checkAdultCategory(category)
                    }
                    isMyMenuIconBack = false
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (controller.getCurIndex() == 0) {
                    categoryViewList[controller.getCurIndex()]?.unfocus()
                    searchIcon.requestFocus()
                    isMyMenuIconBack = false
                    result = true
                } else {
                    if (controller.decrease()) {
                        val category = getCategory()
                        checkAdultCategory(category)
                        result = true
                    }
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (searchIcon.hasFocus()) {
                    myIcon.requestFocus()
                } else if (myIcon.hasFocus()) {
                } else {
                    checkCategory()
                }
                result = true
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                if (searchIcon.hasFocus()) {
                    ActivityChangeAgent.goToSearchMenu(context!!)
                } else if (myIcon.hasFocus()) {
                    if (isPointNotiVisible()) {
                        STBAgent.hasPointNoti = false
                        hidePointNotiIcon()
                        MBSAgent.pointNotiConfirm(object : Callback<ResponseNoBody> {
                            override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                                // 통신 성공 여부에 상관없이 액션에 대한 처리를 우선 함.
                                PopupAgent.showNormalPopup(context!!, PopupType.NormalPopupType.POINT_ISSUE, object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        when (btn) {
                                            PopupType.Label.POINT_CONFIRM.label -> {
                                                d.dismiss()
                                                goToMyMenu(CategoryTarget.POINT_HISTORY)
                                            }
                                            else -> {
                                                d.dismiss()
                                            }
                                        }
                                    }
                                })
                            }

                            override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                                goToMyMenu()
                            }
                        })

                    } else {
                        goToMyMenu()
                    }
                }
            }
            else -> result = false
        }
        return result
    }

    fun isFirstCategory(): Boolean {
        return (controller.getCurIndex() == 0 && isMyMenuIconBack)
    }

    private fun checkCategory() {
        val category = getCategory()
        if (category.isAdult) {
            if (STBAgent.isAuth) {
                if (STBAgent.isAdultAuth) {
                    actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.CONTENTS_FOCUS).sendToTarget()
                } else {
                    actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.ADULT_FOCUS).sendToTarget()
                }
            } else {
                actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.LOGIN_FOCUS, category.id).sendToTarget()
            }
        } else {
            actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.CONTENTS_FOCUS).sendToTarget()
        }
    }

    private fun goToMyMenu() {
        isMyMenuBack = true
        actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.GO_MY_MENU).sendToTarget()
    }

    private fun goToMyMenu(linkInfo: String?) {
        isMyMenuBack = true
        actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.GO_MY_MENU, linkInfo).sendToTarget()
    }

    override fun active() {
        TODO("Not yet implemented")
    }

    private fun getCategory(): CategoryList {
        return controller.getCurItem() as CategoryList
    }

    private fun checkAdultCategory(category: CategoryList): Boolean {
        Logger.Log(
            Log.DEBUG,
            this,
            "category.isAdult ${category.isAdult} / STBAgent.isAuth ${STBAgent.isAuth} / STBAgent.isAdultAuth:${STBAgent.isAdultAuth}"
        )
        var isShowContentView = false
        if (category.isAdult) {
            if (STBAgent.isAuth) {
                if (STBAgent.isAdultAuth) {
                    // 성인컨텐츠 노출
                    actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.TOP_CATEGORY_UPDATE, category.id, UNFOCUS).sendToTarget()
                    isShowContentView = true
                } else {
                    // 성인인증 뷰
                    actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.ADULT_UPDATE, category.id, UNFOCUS).sendToTarget()
                }
            } else {
                // 로그인 뷰
                actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.LOGIN_UPDATE, category.id, UNFOCUS).sendToTarget()
            }
        } else {
            actionEventHandler.obtainMessage(SubCategoryActivity.ActionType.TOP_CATEGORY_UPDATE, category.id, UNFOCUS).sendToTarget()
            isShowContentView = true
        }
        return isShowContentView
    }

    fun focus() {
        Logger.Log(Log.ERROR, this, "focus")
        categoryViewList[controller.getCurIndex()]?.focus()
    }

    fun unfocus() {
        categoryViewList[controller.getCurIndex()]?.unfocus()
    }

    fun selected() {
        Logger.Log(Log.ERROR, this, "selected")
        categoryViewList[controller.getCurIndex()]?.selectedFocus()
    }

    private fun smoothScrollDxBy(isDown: Boolean) {
        UIAgent.smoothScrollDxBy(scrollview, R.dimen.home_category_move_height, isDown)
    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        TODO("Not yet implemented")
    }

    fun showPointNotiIcon() {
        if (::notiIcon.isInitialized)
            notiIcon.visibility = View.VISIBLE
        STBAgent.hasPointNoti = true
    }

    fun hidePointNotiIcon() {
        if (::notiIcon.isInitialized)
            notiIcon.visibility = View.INVISIBLE
        STBAgent.hasPointNoti = false
    }

    fun isPointNotiVisible(): Boolean {
        return if (::notiIcon.isInitialized)
            notiIcon.isVisible
        else
            false
    }
}