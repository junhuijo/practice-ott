package com.homechoice.ott.vod.ui.detail.series

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import com.homechoice.ott.vod.model.content.Series

class SeriesActivity : ComponentActivity() {
    private val viewModel: SeriesViewModel = SeriesViewModel.getInstance()
    private val playerManager: PlayerManager by lazy { PlayerManager(this, viewModel) }
    lateinit var resultLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if(result.resultCode == Activity.RESULT_OK) {
                playerManager.playEnd()
            }
        }
        val series = intent.getParcelableExtra<Series>("series")
        series?.let {
            viewModel.setSeries(it)
            setContent {
                MaterialTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        SeriesScreen(this , viewModel = viewModel)
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.resetCurrentEpisodeIndex()
    }
}