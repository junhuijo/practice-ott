package com.homechoice.ott.vod.model.home

data class CpItem(
    val name: String,
    val id: Int
)
