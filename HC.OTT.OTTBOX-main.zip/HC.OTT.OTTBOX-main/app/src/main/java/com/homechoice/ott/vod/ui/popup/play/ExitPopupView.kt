package com.homechoice.ott.vod.ui.popup.play

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.KeyEvent
import android.view.Window
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.ui.popup.PopupEvent

class ExitPopupView(ctx: Context, event: PopupEvent) :
    Dialog(ctx, R.style.Theme_Design_NoActionBar) {

    init {
        var vIndex = 0
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setCancelable(false)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setContentView(R.layout.dialog_play_exit)

        val dialog = this

        val btnExit = findViewById<TextView>(R.id.btn_exit)
        val btnCancel = findViewById<TextView>(R.id.watch_btn_cancel)


        btnExit.setOnClickListener {
            event.onClick(dialog, BtnLabel.PLAY_STOP)
        }


        btnCancel.setOnClickListener {
            event.onClick(dialog, BtnLabel.CANCEL)
        }

        setOnKeyListener { _, keyCode, kEvent ->
            var result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        event.onClick(dialog, BtnLabel.CANCEL)
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT-> {
                        if (vIndex > 0) {
                            vIndex--
                            btnExit.requestFocus() // "종료하기" 버튼에 포커스 이동
                        }
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        if (vIndex < 1) {
                            vIndex++
                            btnCancel.requestFocus() // "취소하기" 버튼에 포커스 이동
                        }
                        result = true
                    }
                }
            }
            result
        }
        show()
    }
}