package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseAuth(
    val terminalKey: String = "",
    val bgImgUrl: String = "",
    val transactionId: String = "",
    val errorString: String = "",
    val sessionState: String = ""
) : Parcelable