package com.homechoice.ott.vod.ui.home.content

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.HomeCategoryType
import com.homechoice.ott.vod.agent.HomeContentFocusType
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.agent.UIAgent.focusAnims
import com.homechoice.ott.vod.agent.UIAgent.unfocusAnims
import com.homechoice.ott.vod.model.CategoryItem
import java.util.*


@SuppressLint("ViewConstructor")
class ContentGroupListView(
    val ctx: Context,
    val parent: LinearLayout,
    isAdult: Boolean,
    private var type: String,
    private val item: CategoryItem,
    visibility: Int
) :
    LinearLayout(ctx) {

    private var focusType: HomeContentFocusType = HomeContentFocusType.LEFT
    private var layout: LinearLayout
    private var imageView: ImageView
    private lateinit var titleView: TextView
    private var view: View

    init {
        view = LayoutInflater.from(ctx).inflate(R.layout.home_content_list_item, parent, false)
        when (type.toUpperCase(Locale.ROOT)) {
            HomeCategoryType.QUICKMENUGROUP.name -> {
                view = LayoutInflater.from(ctx).inflate(R.layout.home_quick_menu_list_item, parent, false)
                titleView = view.findViewById(R.id.content_text)
            }
        }

        layout = view.findViewById(R.id.main_content_poster_layout)
        imageView = view.findViewById(R.id.main_content_poster)

        this.visibility = visibility

        if (isAdult) {
            type = HomeCategoryType.ADULT.name
            val layoutParams = UIAgent.createLayoutParamsWithMargin(
                lId = R.dimen.home_content_list_scrollview_margin_start,
                tId = R.dimen.home_content_mid_banner_margin_top_bottom,
                rId = R.dimen.home_content_mid_banner_margin_end,
                bId = R.dimen.home_content_mid_banner_margin_top_bottom
            )
            layout.layoutParams = layoutParams
            layout.layoutParams.width = CMBApp.getPixelSize(R.dimen.home_content_mid_banner_width)
            layout.layoutParams.height = CMBApp.getPixelSize(R.dimen.home_content_mid_banner_height)

        } else {
            when (type.toUpperCase(Locale.ROOT)) {
                HomeCategoryType.MAINBANNER.name -> {
                    layout.layoutParams.width = CMBApp.getPixelSize(R.dimen.home_main_banner_w)
                    layout.layoutParams.height = CMBApp.getPixelSize(R.dimen.home_main_banner_h)
                }
                HomeCategoryType.ASSET.name,
                HomeCategoryType.CATEGORY.name -> {
                    layout.layoutParams.height = CMBApp.getPixelSize(R.dimen.home_content_poster_height)
                    when (item.posterSizeLevel) {
                        2 -> layout.layoutParams.width = CMBApp.getPixelSize(R.dimen.home_content_two_w)
                        3 -> layout.layoutParams.width = CMBApp.getPixelSize(R.dimen.home_content_three_w)
                        else -> layout.layoutParams.width = CMBApp.getPixelSize(R.dimen.home_content_poster_width)
                    }
                }
                HomeCategoryType.MIDBANNER.name -> {
                    /**
                     * horizontalScrollView의 넓이는 포함된 레이어의 크기에 영향을 받기 때문에, 레이어 생서 필요한 만큼 마진값을 추가 함
                     * */
                    val layoutParams = UIAgent.createLayoutParamsWithMargin(
                        lId = R.dimen.home_content_list_scrollview_margin_start,
                        tId = R.dimen.home_content_mid_banner_margin_top_bottom,
                        rId = R.dimen.home_content_mid_banner_margin_end,
                        bId = R.dimen.home_content_mid_banner_margin_top_bottom
                    )

                    layoutParams.width = CMBApp.getPixelSize(R.dimen.home_content_mid_banner_width)
                    layoutParams.height = CMBApp.getPixelSize(R.dimen.home_content_mid_banner_height)

                    layout.layoutParams = layoutParams
                }
                HomeCategoryType.QUICKMENUGROUP.name -> {
                    titleView.text = item.title
                }
            }
        }
        var defaultImageId = R.drawable.main_poster_1_d
        var posterUrl = item.posterUrl
        if (type.toUpperCase(Locale.ROOT) != HomeCategoryType.NONE.name) {
            when (type.toUpperCase(Locale.ROOT)) {
                HomeCategoryType.MAINBANNER.name -> {
                    defaultImageId = R.drawable.main_topbanner_d
                }
                HomeCategoryType.MIDBANNER.name -> {
                    defaultImageId = R.drawable.main_long_banner_d
                }
                HomeCategoryType.QUICKMENUGROUP.name -> {
                    defaultImageId = R.drawable.main_q_default
                    posterUrl = item.selectedIconUrl
                }
                else -> {
                    if (isAdult) {
                        defaultImageId = R.drawable.adult_banner_default
                    } else {
                        when (item.posterSizeLevel) {
                            2 -> defaultImageId = R.drawable.main_poster_2_d
                            3 -> defaultImageId = R.drawable.main_poster_3_d
                        }
                    }
                }
            }
        } else {
            imageView.alpha = 0F
        }

        Glide.with(ctx).load(posterUrl).placeholder(defaultImageId).into(imageView)

        parent.addView(view)
    }


//    fun focus() {
//        val anim: Animation
//        var size = 0
//        if (type.toUpperCase(Locale.ROOT) == HomeCategoryType.CATEGORY.name || type.toUpperCase(Locale.ROOT) == HomeCategoryType.ASSET.name)
//            size = item.posterSizeLevel
//
//        anim = AnimationUtils.loadAnimation(ctx, focusAnims[type.toUpperCase(Locale.ROOT)]?.get(size)!!)
//
//        anim.fillAfter = true
//        anim.zAdjustment = Animation.ZORDER_TOP
//
//        view.startAnimation(anim)
//    }

    fun focus() {
        layout.background = ContextCompat.getDrawable(ctx, R.drawable.border_red)
    }

    fun unfocus() {
        val anim: Animation
        var size = 0
        if (type.toUpperCase(Locale.ROOT) == HomeCategoryType.CATEGORY.name)
            size = item.posterSizeLevel

        anim = AnimationUtils.loadAnimation(ctx, unfocusAnims[type.toUpperCase(Locale.ROOT)]?.get(size)!!)

        anim.fillAfter = true
        anim.zAdjustment = Animation.ZORDER_TOP

        view.startAnimation(anim)
    }

}