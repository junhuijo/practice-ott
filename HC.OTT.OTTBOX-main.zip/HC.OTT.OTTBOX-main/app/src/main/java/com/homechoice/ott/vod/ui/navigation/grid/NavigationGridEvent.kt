package com.homechoice.ott.vod.ui.navigation.grid

interface NavigationGridEvent {
    fun upRowChange()
    fun downRowChange() // 다음 라인 불러오기
    fun lastRowChange()
    fun firstRowChange() // 서브 카테고리로 이동 이벤트
    fun firstColChange() // 메인 카테고리로 이동 이벤트
    fun focusChange()
    fun addEmptyRow()
}