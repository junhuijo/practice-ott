package com.homechoice.ott.vod.ui.popup

import android.app.Dialog

interface PopupEvent {
    fun onClick(d: Dialog, btn: String)
}