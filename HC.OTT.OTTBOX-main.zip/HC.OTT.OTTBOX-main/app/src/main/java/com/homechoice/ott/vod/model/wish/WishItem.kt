package com.homechoice.ott.vod.model.wish

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class WishItem (
    var id: Long? = null,
    var type : String? = "",
    var title : String? = "",
    var date : String = "",
    var targetType : String? = null,
    var targetId : Long? = null,
    var episodeNo : Long? = null,
    var runTimeDisplay : String = "",
    var posterUrl: String = "",
    var rating: String? = "",
//    var genre: String? = ""
) : Parcelable
