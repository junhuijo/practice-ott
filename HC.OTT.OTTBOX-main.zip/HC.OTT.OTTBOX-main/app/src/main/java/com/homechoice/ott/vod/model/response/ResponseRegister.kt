package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseRegister(
    val transactionId: String,
    val sessionState: String = "",
    val errorString: String,
    val registerTransactionId: String
) : Parcelable