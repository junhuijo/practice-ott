package com.homechoice.ott.vod.ui.popup.purchase

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Paint
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.view.isVisible
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.DialogPurchaseBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.point.PointProduct
import com.homechoice.ott.vod.model.popup.Payment
import com.homechoice.ott.vod.model.popup.Phone
import com.homechoice.ott.vod.model.popup.Purchase
import com.homechoice.ott.vod.model.response.*
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.navigation.popup.NavigationPopupController
import com.homechoice.ott.vod.ui.navigation.popup.NavigationPopupData
import com.homechoice.ott.vod.ui.navigation.popup.NavigationPopupEvent
import com.homechoice.ott.vod.ui.navigation.popup.NavigationPopupModel
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.ui.popup.point.PurchasePointSuccessPopupView
import com.homechoice.ott.vod.ui.popup.purchase.PurchasePopupView.ActionType.DROP_BTN_FOCUS
import com.homechoice.ott.vod.ui.popup.purchase.PurchasePopupView.ActionType.DROP_BTN_SELECT
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class PurchasePopupView(ctx: Context, val purchase: Purchase, val event: PopupEvent) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {

    private lateinit var vBinding: DialogPurchaseBinding
    private lateinit var startList: ArrayList<ImageView>
    private lateinit var model: PurchasePopupViewModel

    private lateinit var adapter: PurchasePointProductListAdapter

    private lateinit var actionHandler: Handler
    private lateinit var pointProduct: PointProduct

    private lateinit var keyPadList: ArrayList<LinearLayout>

    private lateinit var selectLayout: View

    private var dialog: Dialog = this

    object ActionType {
        const val DROP_BTN_FOCUS = 0
        const val DROP_BTN_SELECT = 1
    }

    init {
        Logger.Log(Log.INFO, this, "init purchase $purchase")
        init(ctx as Activity, purchase)
    }

    fun init(ctx: Activity, purchase: Purchase) {
        model = PurchasePopupViewModel(purchase)

        vBinding = DialogPurchaseBinding.inflate(LayoutInflater.from(ctx))
        vBinding.apply {
            viewModel = model
        }
        setContentView(vBinding.root)
        STBAgent.setBackgroundImage(vBinding.backgroundImage)

        keyPadList = arrayListOf(
            vBinding.numDel, // 0 <-
            vBinding.num0, // 1
            vBinding.numOk, // 2
            vBinding.num1, // 3 <-
            vBinding.num2, // 4
            vBinding.num3, // 5
            vBinding.num4, // 6 <-
            vBinding.num5, // 7
            vBinding.num6, // 8
            vBinding.num7, // 9 <-
            vBinding.num8, // 10
            vBinding.num9  // 11
        )

        startList = arrayListOf(
            vBinding.pwStar0,
            vBinding.pwStar1,
            vBinding.pwStar2,
            vBinding.pwStar3
        )

        for (item in keyPadList) {
            item.setOnClickListener {
                pushKey(it)
            }
        }

        val btnEvent: NavigationPopupEvent = object : NavigationPopupEvent {
            override fun focusChange(pos: Int) {
                keyPadList[pos].requestFocus()
            }

            override fun unfocusChange(pos: Int) {
                keyPadList[pos].requestFocus()
            }
        }

        val btnController = NavigationPopupController(
            NavigationPopupModel(NavigationPopupData(curIndex = 1, colCount = 3, totalCount = 12)),
            btnEvent
        )

        fun keypadFocus() {
            btnController.setCurIndex(1)
            keyPadList[1].requestFocus()
        }

        actionHandler = Handler {
            Logger.Log(Log.DEBUG, this, "activityHandler it.what $it")
            when (it.what) {
                DROP_BTN_FOCUS -> {
                    vBinding.pointProductList.visibility = View.INVISIBLE
                    vBinding.pointProductPrice.requestFocus()
                }
                DROP_BTN_SELECT -> {
                    pointProduct = it.obj as PointProduct
                    vBinding.pointProductList.visibility = View.INVISIBLE
                    vBinding.pointPrice?.text = pointProduct.mileagePriceStr
                    keypadFocus()
                }
            }
            true
        }

        requestPointProductList()

        if (purchase.isDiscount) {
            vBinding.discountLayout.visibility = View.VISIBLE
            vBinding.discountLayout.paintFlags = Paint.STRIKE_THRU_TEXT_FLAG
        }

        /** 콘텐츠 정보 노출 시 레이아웃 설정 */
        vBinding.contentTitle.maxLines = purchase.maxLines
        if (purchase.maxLines > 2) {
            val barLayoutParams = vBinding.contentTitleLayout.layoutParams as LinearLayout.LayoutParams
            barLayoutParams.weight = barLayoutParams.weight + 35
            vBinding.contentInfoLayout.visibility = View.GONE
        }

        fun keypadFocus(selectedView: View) {
            btnController.setCurIndex(1)
            keyPadList[1].requestFocus()
            selectLayout = selectedView
        }

        fun entry(it: View) {
            if (!model.purchase.value?.isAuth!!) {
                Logger.Log(Log.DEBUG, this, "로그인 필요!")
                if(STBAgent.linkedHomeChoice){
                    PopupAgent.showNormalPopup(context!!,
                        PopupType.NormalPopupType.LOGIN_GUIDE,
                        object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                d.dismiss()
                            }
                        })
                } else {
                    PopupAgent.showLoginPopup(context, object : LoginPopupEvent {
                        override fun onLogin(loginDialog: Dialog, btn: String) {
                            when (btn) {
                                BtnLabel.SUCCESS -> {
                                    model.purchase.value!!.isAuth = STBAgent.isAuth
                                    model.purchase.value?.payment?.set(0, Payment(paymentType = "카드간편 결제", paymentName = STBAgent.cardName))
                                    showPaymentInfo()
                                    it.requestFocus()
                                }
                                BtnLabel.CANCEL -> {
                                    loginDialog.dismiss()
                                }
                            }
                        }
                    })
                }
            }
            else {
                if (hasPayment()) {
                    when (it) {
                        vBinding.pointCardLayout -> {
                            if (purchase.pointBalance > 0) {
                                it.isSelected = true
                                keypadFocus(it)
                            }
                        }
                        vBinding.pointChargeLayout -> {
                            it.isSelected = true
                            if (purchase.enoughPoint) {
                                keypadFocus(it)
                            }
                            else {
                                selectLayout = it
                                vBinding.pointProductPrice.requestFocus()
                            }
                        }
                        else -> {
                            it.isSelected = true
                            keypadFocus(it)
                        }
                    }
                }
                else {
                    when (it) {
                        vBinding.paymentLayout -> {
                            getCardInfo()
                        }
                        vBinding.pointLayout -> {
                            // 포인트 결제는 포인트 잔액이 충분한 경우 활성화 됨
                            it.isSelected = true
                            keypadFocus(it)
                        }
                        vBinding.pointChargeLayout,
                        vBinding.pointCardLayout -> {
                            getCardInfo()
                        }
                        else -> {

                        }
                    }

                }
            }
        }

        showPaymentInfo()

        var ratingId = R.drawable.icon_s_age_all
        ratingId = when (purchase.rating) {
            12 -> R.drawable.icon_s_age_12
            15 -> R.drawable.icon_s_age_15
            19 -> R.drawable.icon_s_age_19
            else -> R.drawable.icon_s_age_all
        }

        vBinding.contentRating.setImageResource(ratingId)

        vBinding.paymentLayout.setOnClickListener {
            entry(it)
        }

        vBinding.pointLayout.setOnClickListener {
            if (STBAgent.pointBalance >= 0) {
                entry(it)
            }
        }

        vBinding.pointCardLayout.setOnClickListener {
            entry(it)
        }

        vBinding.pointChargeLayout.setOnClickListener {
            entry(it)
        }

        vBinding.pointProductPrice.setOnClickListener {
            vBinding.pointProductList.visibility = View.VISIBLE
            vBinding.pointProductList.requestFocus();
        }

        vBinding.btnCancel.setOnClickListener { dismiss() }

        vBinding.paymentLayout.requestFocus()

        if (model.purchase.value?.posterUrl != "") {
            Glide.with(ctx).load(model.purchase.value?.posterUrl).into(vBinding.contentPoster)
        }

        setOnKeyListener { _, keyCode, event ->
            var result = false
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        result = true
                        when (vBinding.root.findFocus()) {
                            vBinding.paymentLayout,
                            vBinding.pointLayout,
                            vBinding.pointChargeLayout,
                            vBinding.pointCardLayout,
                            vBinding.btnCancel -> {
                                // 아무것도 하지 않음
                            }
                            vBinding.num0,
                            vBinding.num1,
                            vBinding.num2,
                            vBinding.num3,
                            vBinding.num4,
                            vBinding.num5,
                            vBinding.num6,
                            vBinding.num7,
                            vBinding.num8,
                            vBinding.num9,
                            vBinding.numOk,
                            vBinding.numDel -> {
                                if (btnController.data.curIndex % btnController.data.colCount == 0) {
                                    selectLayout.isSelected = false
                                    selectLayout.requestFocus()
                                }
                                else {
                                    btnController.decrease()
                                }
                            }
                            vBinding.pointProductPrice -> {
                                selectLayout.isSelected = false
                                selectLayout.requestFocus()
                            }
                            else -> {
                                result = false
                            }
                        }
                    }

                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        result = true
                        when (vBinding.root.findFocus()) {
                            vBinding.paymentLayout -> {
                                if (hasPayment()) {
                                    vBinding.root.findFocus().isSelected = true
                                    keypadFocus(vBinding.root.findFocus())
                                }
                            }
                            vBinding.pointLayout -> {
                                if (STBAgent.pointBalance > 0) {
                                    vBinding.root.findFocus().isSelected = true
                                    keypadFocus(vBinding.root.findFocus())
                                }
                            }
                            vBinding.pointCardLayout -> {
                                if (hasPayment()) {
                                    if (purchase.pointBalance > 0) {
                                        vBinding.root.findFocus().isSelected = true
                                        keypadFocus(vBinding.root.findFocus())
                                    }
                                }
                            }
                            vBinding.pointChargeLayout -> {
                                if (hasPayment()) {
                                    vBinding.root.findFocus().isSelected = true
                                    selectLayout = vBinding.root.findFocus()
                                    vBinding.pointProductPrice.requestFocus()
                                }
                            }
                            vBinding.btnCancel -> {
                            }
                            vBinding.num0,
                            vBinding.num1,
                            vBinding.num2,
                            vBinding.num3,
                            vBinding.num4,
                            vBinding.num5,
                            vBinding.num6,
                            vBinding.num7,
                            vBinding.num8,
                            vBinding.num9,
                            vBinding.numOk,
                            vBinding.numDel -> {
                                if ((btnController.data.curIndex + 1) % btnController.data.colCount != 0) {
                                    btnController.increase()
                                }
                            }
                            else -> {
                                result = false
                            }
                        }

                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        result = true
                        when (vBinding.root.findFocus()) {
                            // 간편카드결제
                            vBinding.paymentLayout -> {
                                // 아무것도 하지 않음.
                            }
                            // 포인트결제
                            vBinding.pointLayout -> {
                                showPaymentInfo(vBinding.paymentLayout)
                                vBinding.paymentLayout.requestFocus()
                            }
                            // 포인트+카드결제
                            vBinding.pointCardLayout -> {
                                showPaymentInfo(vBinding.paymentLayout)
                                vBinding.paymentLayout.requestFocus()
                            }
                            // 포인트 충전
                            vBinding.pointChargeLayout -> {
                                if (purchase.hasPayment) {
                                    showPaymentInfo(vBinding.pointCardLayout)
                                    vBinding.pointCardLayout.requestFocus()
                                }
                                else {
                                    showPaymentInfo(vBinding.pointCardLayout)
                                    vBinding.pointCardLayout.requestFocus()
                                }
                            }
                            // 취소 버튼
                            vBinding.btnCancel -> {
                                if (purchase.enoughPoint) {
                                    showPaymentInfo(vBinding.pointLayout)
                                    vBinding.pointLayout.requestFocus()
                                }
                                else {
                                    if (vBinding.pointChargeLayout.isVisible) {
                                        showPaymentInfo(vBinding.pointChargeLayout)
                                        vBinding.pointChargeLayout.requestFocus()
                                    }
                                    else {
                                        showPaymentInfo(vBinding.pointCardLayout)
                                        vBinding.pointCardLayout.requestFocus()
                                    }

                                }
                            }
                            vBinding.num0,
                            vBinding.num1,
                            vBinding.num2,
                            vBinding.num3,
                            vBinding.num4,
                            vBinding.num5,
                            vBinding.num6,
                            vBinding.num7,
                            vBinding.num8,
                            vBinding.num9,
                            vBinding.numOk,
                            vBinding.numDel -> {
                                // 키패드 UP
                                if (btnController.data.curIndex > 8) {
                                    if (selectLayout == vBinding.pointChargeLayout) {
                                        vBinding.pointProductPrice.requestFocus()
                                    }
                                    else {
                                        btnController.increaseRow()
                                    }
                                }
                                else {
                                    btnController.increaseRow()
                                }
                            }
                            else -> {
                                // 포인트 상품 리스트
                                result = false
                            }
                        }

                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        result = true
                        when (vBinding.root.findFocus()) {
                            vBinding.paymentLayout -> {
                                if (purchase.enoughPoint) {
                                    showPaymentInfo(vBinding.pointLayout)
                                    vBinding.pointLayout.requestFocus()
                                }
                                else {
                                    showPaymentInfo(vBinding.pointCardLayout)
                                    vBinding.pointCardLayout.requestFocus()
                                }
                            }
                            vBinding.pointLayout -> {
                                vBinding.btnCancel.requestFocus()
                            }
                            vBinding.pointCardLayout -> {
                                if (vBinding.pointChargeLayout.isVisible) {
                                    showPaymentInfo(vBinding.pointChargeLayout)
                                    vBinding.pointChargeLayout.requestFocus()
                                }
                                else {
                                    vBinding.btnCancel.requestFocus()
                                }
                            }
                            vBinding.pointChargeLayout -> {
                                vBinding.btnCancel.requestFocus()
                            }
                            vBinding.btnCancel -> {
                                // 아무것도 하지 않음.
                            }
                            vBinding.pointProductPrice -> {
                                keypadFocus()
                            }
                            vBinding.num0,
                            vBinding.num1,
                            vBinding.num2,
                            vBinding.num3,
                            vBinding.num4,
                            vBinding.num5,
                            vBinding.num6,
                            vBinding.num7,
                            vBinding.num8,
                            vBinding.num9,
                            vBinding.numOk,
                            vBinding.numDel -> {
                                btnController.decreaseRow()
                            }
                            else -> {
                                // 포인트 상품 리스트
                                result = false
                            }
                        }

                    }
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER, 96 -> {
                        result = false
                    }

                    KeyEvent.KEYCODE_BACK, 97 -> {
                        result = true
                        when (vBinding.root.findFocus()) {
                            vBinding.paymentLayout,
                            vBinding.pointLayout,
                            vBinding.pointCardLayout,
                            vBinding.pointChargeLayout,
                            vBinding.btnCancel,
                            vBinding.pointProductPrice,
                            vBinding.num0,
                            vBinding.num1,
                            vBinding.num2,
                            vBinding.num3,
                            vBinding.num4,
                            vBinding.num5,
                            vBinding.num6,
                            vBinding.num7,
                            vBinding.num8,
                            vBinding.num9,
                            vBinding.numOk,
                            vBinding.numDel -> {
                                dismiss()
                            }
                            else -> {
                                result = false
                            }
                        }

                    }
                }
            }
            result
        }

    }

    private fun getCardInfo() {
        MBSAgent.getCard(object : Callback<ResponseCardName> {
            override fun onFailure(call: Call<ResponseCardName>, t: Throwable) {
                Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
            }

            override fun onResponse(call: Call<ResponseCardName>, response: Response<ResponseCardName>) {
                Logger.Log(Log.DEBUG, this, "onResponse")
                if (response.isSuccessful && response.body() != null) {
                    val cardName = response.body()!!.cardName
                    STBAgent.cardName = cardName ?: ""
                    model.purchase.value?.payment?.set(0, Payment(paymentType = "카드간편 결제", paymentName = STBAgent.cardName))
                    model.purchase.value?.build()
                    if (cardName != "") {
                        showPaymentInfo()
                    }
                    else {
                        RegCardPopupView(context, Phone(
                            head = "카드 등록하기", body = "간편 결제를 하기 위해서\n" +
                                "카드 정보를 등록해야 합니다.\n" +
                                "간편 결제 카드 등록을 위해\n" +
                                "휴대폰 번호를 입력해 주세요."
                        ), object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {

                                /**
                                 * 카드등록 후 다시 로그인을 해야 함.
                                 *
                                 * ID/PW 저장해도 문제는 없는가?
                                 * */

                                d.dismiss()
                            }

                        })
                    }
                }
                else {
                    when (response.code()) {
                        CODE.CONFLICT -> {
                            UIAgent.showPopup(context, response.code(), object : RetryCallback {
                                override fun call() {
                                    getCardInfo()
                                }

                                override fun cancel() {
                                }
                            })
                        }
                        else -> {
                        }
                    }
                }
            }
        })
    }

    private fun showPaymentInfo() {
        if (model.purchase.value?.isAuth!!) {
            if (hasPayment()) {
                vBinding.keypadLayout.visibility = View.VISIBLE
                vBinding.authInfoLayout.visibility = View.GONE
            }
            else {
                vBinding.authInfoLayout.visibility = View.VISIBLE
                vBinding.keypadLayout.visibility = View.GONE
                model.purchase.value?.noticeStr = "카드가 미등록 되었거나\n결제 정보가 부족합니다.\n결제 수단을 눌러 카드 정보를\n 모두 입력해 주시기 바랍니다."
            }
        }
        else {
            model.purchase.value?.noticeStr = "콘텐츠를 구매하기 위해서\n로그인이 필요합니다.\n결제 수단을 눌러 로그인 또는\n회원가입을 진행해 주시기 바랍니다."
            vBinding.authInfoLayout.visibility = View.VISIBLE
            vBinding.keypadLayout.visibility = View.GONE
        }
        vBinding.invalidateAll()
    }

    private fun showPaymentInfo(it: View) {

        if (model.purchase.value?.isAuth!!) {
            vBinding.pointChargeBtnLayout.visibility = View.INVISIBLE
            vBinding.pointProductList.visibility = View.INVISIBLE
            vBinding.priceInfo.visibility = View.INVISIBLE

            when (it) {
                vBinding.paymentLayout -> {
                    if (!hasPayment()) {
                        vBinding.authInfoLayout.visibility = View.VISIBLE
                        vBinding.keypadLayout.visibility = View.GONE
                        model.purchase.value?.noticeStr = "카드가 미등록 되었거나\n결제 정보가 부족합니다.\n결제 수단을 눌러 카드 정보를\n 모두 입력해 주시기 바랍니다."
                    }
                    else {
                        vBinding.priceInfo.visibility = View.VISIBLE
                    }
                }
                vBinding.pointLayout -> {
                    // 포인트 결제
                    // 포인트 잔액이 충분한 경우 포커스가 활성화 됨
                    vBinding.priceInfo.visibility = View.VISIBLE
                    vBinding.keypadLayout.visibility = View.VISIBLE
                    vBinding.authInfoLayout.visibility = View.GONE
                }
                vBinding.pointCardLayout -> {
                    // 포인트+카드 결제
                    if (!hasPayment()) {
                        vBinding.authInfoLayout.visibility = View.VISIBLE
                        vBinding.keypadLayout.visibility = View.GONE
                        model.purchase.value?.noticeStr = "콘텐츠를 구매하기 위해서\n카드 등록이 필요합니다.\n결제 수단을 눌러 카드 등록을\n완료해 주시기 바랍니다."
                    }
                    else {
                        vBinding.priceInfo.visibility = View.VISIBLE
                    }
                }
                vBinding.pointChargeLayout -> {
                    if (hasPayment()) {
                        vBinding.pointChargeBtnLayout.visibility = View.VISIBLE
                        vBinding.keypadLayout.visibility = View.VISIBLE
                        vBinding.authInfoLayout.visibility = View.GONE
                    }
                    else {
                        vBinding.authInfoLayout.visibility = View.VISIBLE
                        vBinding.keypadLayout.visibility = View.GONE
                        model.purchase.value?.noticeStr = "콘텐츠를 구매하기 위해서\n카드 등록이 필요합니다.\n결제 수단을 눌러 카드 등록을\n완료해 주시기 바랍니다."
                    }
                }
                else -> {
                }
            }

            // 비밀번호 초기화 처리
            for (index in 0 until model.purchase.value?.password?.length!!) {
                removePin()
            }

            //            if (hasPayment()) {
            //                vBinding.pointChargeBtnLayout.visibility = View.INVISIBLE
            //                vBinding.pointProductList.visibility = View.INVISIBLE
            //                vBinding.priceInfo.visibility = View.INVISIBLE
            //
            //                when (it) {
            //                    vBinding.paymentLayout,
            //                    vBinding.pointLayout,
            //                    vBinding.pointCardLayout -> {
            //                        vBinding.priceInfo.visibility = View.VISIBLE
            //                    }
            //                    vBinding.pointChargeLayout -> {
            //                        vBinding.pointChargeBtnLayout.visibility = View.VISIBLE
            //                    }
            //                    else -> {
            //                    }
            //                }
            //
            //                for (index in 0 until model.purchase.value?.password?.length!!) {
            //                    removePin()
            //                }
            //
            //                vBinding.keypadLayout.visibility = View.VISIBLE
            //                vBinding.authInfoLayout.visibility = View.GONE
            //            } else {
            //                vBinding.authInfoLayout.visibility = View.VISIBLE
            //                vBinding.keypadLayout.visibility = View.GONE
            //                model.purchase.value?.noticeStr = "카드가 미등록 되었거나\n결제 정보가 부족합니다.\n결제 수단을 눌러 카드 정보를\n 모두 입력해 주시기 바랍니다."
            //            }

        }
        else {
            model.purchase.value?.noticeStr = "콘텐츠를 구매하기 위해서\n로그인이 필요합니다.\n결제 수단을 눌러 로그인 또는\n회원가입을 진행해 주시기 바랍니다."
            vBinding.authInfoLayout.visibility = View.VISIBLE
            vBinding.keypadLayout.visibility = View.GONE

            vBinding.pointProductList.visibility = View.INVISIBLE
            vBinding.priceInfo.visibility = View.INVISIBLE
        }
        vBinding.invalidateAll()
    }

    private fun hasPayment(): Boolean {
        return model.purchase.value?.payment?.get(0)?.paymentName != "등록 필요"
    }

    private fun pushKey(view: View) {
        Logger.Log(Log.DEBUG, this, "view.id ${view.id}")
        when (view.id) {
            vBinding.numOk.id -> okPin()
            vBinding.numDel.id -> removePin()
            else ->
                appendPin(view.tag as String)
        }
    }

    private fun appendPin(pin: String) {
        if (model.purchase.value?.password?.length!! < 4) {
            model.purchase.value?.password?.append(pin)
            drawPwStar()
        }
    }

    private fun removePin() {
        if (model.purchase.value?.password?.length!! > 0) {
            model.purchase.value?.password?.deleteCharAt(model.purchase.value?.password?.lastIndex!!)
        }
        drawPwStar()
        vBinding.warnText.visibility = View.INVISIBLE
    }

    private fun okPin() {
        Logger.Log(Log.DEBUG, this, "okPin!")
        if (model.purchase.value?.password?.length!! == 4) {
            when (selectLayout) {
                vBinding.paymentLayout -> {
                    Logger.Log(Log.DEBUG, this, "간편 결제")
                    purchase.pointPrice = 0
                    if (purchase.discountPrice > 0) {
                        purchase.normalPrice = purchase.discountPrice
                    }
                    else {
                        purchase.normalPrice = purchase.price
                    }
                    Logger.Log(
                        Log.DEBUG,
                        this,
                        "price : ${purchase.price} / pointPrice : ${purchase.pointPrice} /  discount : ${purchase.discountPrice} / normalPrice :${purchase.normalPrice}"
                    )
                    requestCheckPin()
                }
                vBinding.pointCardLayout -> {
                    Logger.Log(Log.DEBUG, this, "포인트+카드결제")
                    purchase.pointPrice = STBAgent.pointBalance
                    if (purchase.discountPrice > 0) {
                        purchase.normalPrice = purchase.discountPrice - STBAgent.pointBalance
                    }
                    else {
                        purchase.normalPrice = purchase.price - STBAgent.pointBalance
                    }
                    Logger.Log(
                        Log.DEBUG,
                        this,
                        "price : ${purchase.price} / pointPrice : ${purchase.pointPrice} / discount : ${purchase.discountPrice} / point : ${purchase.pointBalance} / normalPrice :${purchase.normalPrice}"
                    )
                    requestCheckPin()
                }
                vBinding.pointLayout -> {
                    Logger.Log(Log.DEBUG, this, "포인트 결제")
                    purchase.normalPrice = 0
                    if (purchase.discountPrice > 0) {
                        purchase.pointPrice = purchase.discountPrice
                    }
                    else {
                        purchase.pointPrice = purchase.price
                    }
                    Logger.Log(
                        Log.DEBUG,
                        this,
                        "price : ${purchase.price} / pointPrice : ${purchase.pointPrice} / discount : ${purchase.discountPrice} / pointBalance : ${purchase.pointBalance} / normalPrice :${purchase.normalPrice}"
                    )
                    requestCheckPin()
                }
                vBinding.pointChargeLayout -> {
                    Logger.Log(Log.DEBUG, this, "포인트 잔액 충전!")
                    Logger.Log(
                        Log.DEBUG,
                        this,
                        "price : ${pointProduct.price} /  pointPrice : ${purchase.pointPrice} / id : ${pointProduct.id} / name : ${pointProduct.name}"
                    )
                    purchasePointProduct(pointProduct.id, pointProduct.name, pointProduct.price, model.purchase.value?.password.toString())
                }
            }
        }
    }

    private fun drawPwStar() {
        for (index in 0 until startList.size) {
            if (index < model.purchase.value?.password?.length!!)
                startList[index].visibility = View.VISIBLE
            else
                startList[index].visibility = View.GONE
        }
    }

    private fun requestCheckPin() {
        Logger.Log(Log.INFO, this, "purchase $purchase")

        //if (STBAgent.isEmulator() && !STBAgent.isLiveMode()) {
        if (false) {
            PurchaseSuccessPopupView(
                ctx = context,
                title = model.purchase.value?.offerTitle!!,
                popupType = PopupType.NormalPopupType.PURCHASE_SUCCESS,
                event = object : PopupEvent {
                    override fun onClick(d: Dialog, text: String) {
                        when (text) {
                            BtnLabel.SUCCESS -> {
                                event.onClick(dialog, text)
                            }
                        }
                    }
                })
        }
        else {
            MBSAgent.easyPayment(
                offerId = purchase.offerId,
                paymentPw = model.purchase.value?.password?.toString()!!,
                price = purchase.price,
                discountPrice = purchase.discountPrice,
                normalPrice = purchase.normalPrice,
                pointPrice = purchase.pointPrice,
                targetType = purchase.targetType,
                targetId = purchase.targetId,
                episodeNo = purchase.episodeNo,
                contentId = purchase.contentId,
                enterPath = purchase.enterPath,
                pointPolicyId = purchase.pointPolicyId,
                callback = object : Callback<ResponsePurchase> {
                    override fun onFailure(call: Call<ResponsePurchase>, t: Throwable) {
                        Logger.Log(Log.DEBUG, this, "실패")
                        PopupAgent.showNormalPopup(
                            context,
                            PopupType.getErrorType(
                                TYPE.DEFAULT,
                                CODE.NONE
                            ),
                            object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    when (btn) {
                                        BtnLabel.OK -> {
                                            d.dismiss()
                                        }
                                    }
                                }
                            })

                    }

                    override fun onResponse(call: Call<ResponsePurchase>, response: Response<ResponsePurchase>) {
                        Logger.Log(Log.DEBUG, this, "결제성공! : ${response.code()} / ${response.isSuccessful}")
                        if (response.isSuccessful) {
                            STBAgent.pointBalance = response.body()?.point!!
                            Logger.Log(Log.DEBUG, this, "STBAgent.pointBalance ${STBAgent.pointBalance}")
                            PurchaseSuccessPopupView(
                                ctx = context,
                                title = model.purchase.value?.offerTitle!!,
                                popupType = PopupType.NormalPopupType.PURCHASE_SUCCESS,
                                event = object : PopupEvent {
                                    override fun onClick(d: Dialog, text: String) {
                                        when (text) {
                                            BtnLabel.SUCCESS -> {
                                                event.onClick(dialog, text)
                                            }
                                        }
                                    }
                                })
                        }
                        else {
                            when (response.code()) {
                                CODE.UNAUTHORIZED -> {
                                    vBinding.warnText.visibility = View.VISIBLE
                                }
                                CODE.PIN_CHECK,
                                CODE.PIN_FAIL,
                                CODE.UNAVAILABLE_CARD -> {
                                    // 사용할 수 없는 카드 입니다.
                                    val type = when (response.code()) {
                                        CODE.PIN_CHECK -> {
                                            val t = PopupType.NormalPopupType.PURCHASE_PIN_CHECK
                                            val error = response.errorBody()?.let { MBSAgent.error(it) }
                                            t.body = error?.errorString!!
                                            t
                                        }
                                        CODE.PIN_FAIL -> {
                                            val t = PopupType.NormalPopupType.PURCHASE_PIN_FAIL
                                            val error = response.errorBody()?.let { MBSAgent.error(it) }
                                            t.body = error?.errorString!!
                                            t
                                        }
                                        else -> PopupType.NormalPopupType.PURCHASE_FAIL
                                    }
                                    PurchaseFailPopupView(
                                        ctx = context,
                                        code = response.code(),
                                        popupType = type,
                                        event = object : PopupEvent {
                                            override fun onClick(d: Dialog, text: String) {
                                                when (text) {
                                                    BtnLabel.OK -> {
                                                        model.purchase.value?.password?.delete(
                                                            0,
                                                            model.purchase.value?.password?.length!!
                                                        )
                                                        drawPwStar()
                                                        d.dismiss()
                                                    }
                                                }
                                            }
                                        })

                                }
                                CODE.CONFLICT -> {
                                    UIAgent.showPopup(context, CODE.CONFLICT, object : RetryCallback {
                                        override fun call() {
                                            requestCheckPin()
                                        }

                                        override fun cancel() {
                                        }
                                    })
                                }
                                else -> {
                                    val error = response.errorBody()?.let { MBSAgent.error(it) }
                                    PopupAgent.showNormalPopup(
                                        context,
                                        PopupType.getErrorType(
                                            TYPE.AUTH,
                                            response.code(),
                                            error?.errorString!!
                                        ),
                                        object : PopupEvent {
                                            override fun onClick(d: Dialog, btn: String) {
                                                when (btn) {
                                                    BtnLabel.OK -> {
                                                        d.dismiss()
                                                    }
                                                }
                                            }
                                        })
                                }
                            }
                        }

                    }

                }
            )
        }
    }

    private fun requestPointProductList() {
        GlobalScope.launch(Dispatchers.Main) {
            MBSAgent.pointProductList(
                startIdx = 1,
                pageSize = 0,
                transactionId = UUID.randomUUID().toString(),
                callback = object : Callback<ResponsePointProductList> {
                    override fun onResponse(call: Call<ResponsePointProductList>, res: Response<ResponsePointProductList>) {
                        if (res.isSuccessful && res.body() != null) {
                            val response = res.body()
                            if (response != null) {
                                val productList = response.productList
                                val totalCount = response.totalCount

                                if (totalCount > 0) {
                                    model.purchase.value?.hasPointProductList = true
                                    adapter = PurchasePointProductListAdapter(productList, actionHandler)
                                    vBinding.pointProductList.adapter = adapter
                                    pointProduct = productList[0].build()
                                    vBinding.pointPrice.text = pointProduct.mileagePriceStr
                                }
                            }
                        }
                    }

                    override fun onFailure(call: Call<ResponsePointProductList>, t: Throwable) {
                    }
                }
            )
        }
    }

    private fun purchasePointProduct(productId: Long, productTitle: String, price: Int, paymentPw: String) {
        MBSAgent.purchasePointProduct(
            productId = productId,
            productTitle = productTitle,
            price = price,
            paymentPw = paymentPw,
            transactionId = UUID.randomUUID().toString(),
            callback = object : Callback<ResponsePoint> {
                override fun onFailure(call: Call<ResponsePoint>, t: Throwable) {
                    PopupAgent.showNormalPopup(
                        context,
                        PopupType.getErrorType(
                            TYPE.AUTH,
                            CODE.NONE
                        ),
                        object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                when (btn) {
                                    BtnLabel.OK -> {
                                        d.dismiss()
                                    }
                                }
                            }
                        })
                }

                override fun onResponse(call: Call<ResponsePoint>, response: Response<ResponsePoint>) {
                    if (response.isSuccessful && response.body() != null) {
                        STBAgent.pointBalance = response.body()!!.point
                        PurchasePointSuccessPopupView(
                            ctx = context,
                            type = PopupType.NormalPopupType.PURCHASE_POINT,
                            balance = STBAgent.pointBalance,
                            event = object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    d.dismiss()

                                    model.purchase.value!!.pointBalance = STBAgent.pointBalance
                                    model.purchase.value!!.build()

                                    selectLayout.isSelected = false
                                    selectLayout = vBinding.paymentLayout

                                    showPaymentInfo(selectLayout)

                                    selectLayout.requestFocus()
                                }
                            }).show()
                    }
                    else {
                        when (response.code()) {
                            CODE.UNAUTHORIZED -> {
                                //                                binding.warnText.visibility = View.VISIBLE
                            }
                            CODE.PIN_CHECK,
                            CODE.PIN_FAIL,
                            CODE.UNAVAILABLE_CARD -> {
                                // 사용할 수 없는 카드 입니다.
                                val type = when (response.code()) {
                                    CODE.PIN_CHECK -> {
                                        val t = PopupType.NormalPopupType.PURCHASE_PIN_CHECK
                                        val error = response.errorBody()?.let { MBSAgent.error(it) }
                                        t.body = error?.errorString!!
                                        t
                                    }
                                    CODE.PIN_FAIL -> {
                                        val t = PopupType.NormalPopupType.PURCHASE_PIN_FAIL
                                        val error = response.errorBody()?.let { MBSAgent.error(it) }
                                        t.body = error?.errorString!!
                                        t
                                    }
                                    else -> PopupType.NormalPopupType.PURCHASE_FAIL
                                }
                                PurchaseFailPopupView(
                                    ctx = context,
                                    code = response.code(),
                                    popupType = type,
                                    event = object : PopupEvent {
                                        override fun onClick(d: Dialog, text: String) {
                                            when (text) {
                                                BtnLabel.OK -> {
                                                    d.dismiss()
                                                }
                                            }
                                        }
                                    })
                            }

                            CODE.CONFLICT -> {
                                UIAgent.showPopup(context, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                        //                                        okNumber()
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                val error = response.errorBody()?.let { MBSAgent.error(it) }
                                PopupAgent.showNormalPopup(
                                    context,
                                    PopupType.getErrorType(
                                        TYPE.AUTH,
                                        response.code(),
                                        error?.errorString!!
                                    ),
                                    object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            when (btn) {
                                                BtnLabel.OK -> {
                                                    d.dismiss()
                                                }
                                            }
                                        }
                                    })
                            }
                        }
                    }
                }

            })
    }

}