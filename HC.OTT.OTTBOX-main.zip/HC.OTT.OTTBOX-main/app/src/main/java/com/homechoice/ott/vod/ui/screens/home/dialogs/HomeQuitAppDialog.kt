package com.homechoice.ott.vod.ui.screens.home.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.ui.screens.home.HomeViewModel

// 앱 종료 팝업
@Composable
fun QuitAppDialog(
    viewModel: HomeViewModel
) {
    val showQuitAppDialog by viewModel.showQuitAppDialog.collectAsState()
    val quitAppDialogCancelBtnFocusRequester = FocusRequester()

    if (showQuitAppDialog) {
        Dialog(
            onDismissRequest = { viewModel.updateQuitAppDialog(false) },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = true
            )
        ) {
            Card(
                modifier = Modifier
                    .width(360.dp)
                    .height(220.dp)
                    .padding(16.dp),
                shape = RoundedCornerShape(dimensionResource(R.dimen.dialog_radius)),
                colors = CardDefaults.cardColors(
                    containerColor = colorResource(R.color.quit_app_dialog_bg)
                ),
                border = BorderStroke(dimensionResource(R.dimen.border_width), colorResource(R.color.dialog_border3))
            ) {
                QuitAppDialogContent(
                    onCancel = { viewModel.updateQuitAppDialog(false) },
                    onConfirm = { viewModel.finishAffinity() },
                    cancelBtnFocusRequester = quitAppDialogCancelBtnFocusRequester
                )
            }
        }
    }
}

@Composable
fun QuitAppDialogContent(
    onCancel: () -> Unit,
    onConfirm: () -> Unit,
    cancelBtnFocusRequester: FocusRequester
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 10.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        QuitAppDialogText()
        QuitAppDialogButtons(onCancel, onConfirm, cancelBtnFocusRequester)
    }

    LaunchedEffect(Unit) {
        cancelBtnFocusRequester.requestFocus()
    }
}

@Composable
fun QuitAppDialogText() {
    Text(
        text = stringResource(R.string.quit_app_dialog_body_text),
        modifier = Modifier.padding(32.dp),
        style = TextStyle(
            fontSize = 16.sp,
            color = Color.White
        )
    )
}

@Composable
fun QuitAppDialogButtons(
    onCancel: () -> Unit,
    onConfirm: () -> Unit,
    cancelBtnFocusRequester: FocusRequester
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center
    ) {
        QuitAppDialogCancelButton(onClick = onCancel, focusRequester = cancelBtnFocusRequester)
        Spacer(modifier = Modifier.width(8.dp))
        QuitAppDialogConfirmButton(onClick = onConfirm)
    }
}

@Composable
fun QuitAppDialogCancelButton(onClick: () -> Unit, focusRequester: FocusRequester) {
    QuitAppDialogButton(
        onClick = onClick,
        text = stringResource(R.string.quit_app_dialog_cancel_btn),
        focusRequester = focusRequester
    )
}

@Composable
fun QuitAppDialogConfirmButton(onClick: () -> Unit) {
    QuitAppDialogButton(
        onClick = onClick,
        text = stringResource(R.string.quit_app_dialog_confirm_btn)
    )
}

@Composable
fun QuitAppDialogButton(
    onClick: () -> Unit,
    text: String,
    focusRequester: FocusRequester? = null
) {
    var borderColor by remember { mutableStateOf(Color.DarkGray) }

    TextButton(
        onClick = onClick,
        shape = RoundedCornerShape(dimensionResource(R.dimen.dialog_radius)),
        modifier = Modifier
            .padding(8.dp)
            .focusRequester(focusRequester ?: FocusRequester())
            .onFocusChanged {
                borderColor = if (it.hasFocus) Color.Red else Color.DarkGray
            }
            .focusable(),
        colors = ButtonDefaults.textButtonColors(contentColor = Color.Transparent),
        contentPadding = PaddingValues(36.dp, 0.dp),
        border = BorderStroke(dimensionResource(R.dimen.border_width), borderColor)
    ) {
        Text(
            text = text,
            style = TextStyle(fontSize = 14.sp, color = Color.White),
        )
    }
}