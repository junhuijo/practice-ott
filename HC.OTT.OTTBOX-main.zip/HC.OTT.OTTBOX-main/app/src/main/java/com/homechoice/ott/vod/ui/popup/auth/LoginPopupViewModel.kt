package com.homechoice.ott.vod.ui.popup.auth

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.popup.Login

class LoginPopupViewModel(data: Login) : ViewModel() {
    var login: MutableLiveData<Login> = MutableLiveData()

    init {
        login.value = data
    }
}