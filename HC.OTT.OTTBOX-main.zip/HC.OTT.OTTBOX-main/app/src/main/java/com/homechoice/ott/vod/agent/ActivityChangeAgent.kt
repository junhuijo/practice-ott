package com.homechoice.ott.vod.agent

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.util.Log
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.event.MBSCallback
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.ResponseContentGroup
import com.homechoice.ott.vod.model.content.Display
import com.homechoice.ott.vod.model.content.OfferContent
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.model.response.ResponseAuth
import com.homechoice.ott.vod.model.response.ResponseOfferContent
import com.homechoice.ott.vod.model.response.ResponseSeries
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.ui.my.contentfilter.KidsLockActivity
import com.homechoice.ott.vod.ui.detail.DetailActivity
import com.homechoice.ott.vod.ui.detail.series.SeriesActivity
import com.homechoice.ott.vod.ui.home.HomeActivity2
import com.homechoice.ott.vod.ui.my.MyActivity2
import com.homechoice.ott.vod.ui.my.contentfilter.AdultVerificationActivity
import com.homechoice.ott.vod.ui.pack.PackageActivity
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.ui.qrscreen.QrActivity
import com.homechoice.ott.vod.ui.search.SearchActivity
import com.homechoice.ott.vod.ui.sub.SubCategoryActivity
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.HttpURLConnection

object ActivityChangeAgent {

    fun goToContent(ctx: Context, contentGroupId: Long, enterPath: String, callback: MBSCallback?) {
        MBSAgent.getContentGroup(
            contentGroupId = contentGroupId,
            transcodingType = "dash",
            drmType = "widevine",
            callback = object : Callback<ResponseContentGroup> {
                override fun onResponse(call: Call<ResponseContentGroup>, res: Response<ResponseContentGroup>) {
                    if (res.isSuccessful && res.body() != null) {
                        val response = res.body()!!
                        when (response.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                                UIAgent.showPopup(ctx, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                        goToContent(ctx, contentGroupId, enterPath, callback)
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                val intent = Intent(ctx, DetailActivity::class.java)
                                intent.putExtra(Name.ENTER_PATH, enterPath)
                                intent.putExtra(Name.CONTENT_GROUP, response.contentGroup)
                                ctx.startActivity(intent)
                                callback?.success()
                            }
                        }
                    } else {
                        UIAgent.showPopup(ctx, res.code(), null)
                    }
                }

                override fun onFailure(call: Call<ResponseContentGroup>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, t.message.orEmpty())
                    UIAgent.showPopup(ctx, CODE.NONE, null)
                }
            })
    }




    fun goToSeriesContent(id: Long, episodeNo: Int, context: Context, enterPath: String, callback: MBSCallback?) {
        MBSAgent.getSeries(
            seriesId = id,
            callback = object : Callback<ResponseSeries> {
                override fun onResponse(call: Call<ResponseSeries>, res: Response<ResponseSeries>) {
                    if (res.isSuccessful && res.body() != null) {
                        val response = res.body()!!
                        when (response.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                                UIAgent.showPopup(context, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                        goToSeriesContent(id, episodeNo, context, enterPath, callback)
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                if (response.series.episodeNoList.isNotEmpty()) {
                                    val intent = Intent(context, SeriesActivity::class.java)
                                    intent.putExtra("series", response.series)
                                    context.startActivity(intent)
                                    callback?.success()
                                } else {
                                    UIAgent.showPopup(context, CODE.NOT, null)
                                }
                            }
                        }

                    } else {
                        UIAgent.showPopup(context, res.code(), null)
                    }
                }

                override fun onFailure(call: Call<ResponseSeries>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, t.message.orEmpty())
                    UIAgent.showPopup(context, CODE.NONE, null)
                }
            })
    }


    fun goToPackage(ctx: Context, transactionId: String, offerId: Long, enterPath: String, callback: MBSCallback?) {
        MBSAgent.offerContent(transactionId = transactionId, offerId = offerId, callback = object : Callback<ResponseOfferContent> {
            override fun onFailure(call: Call<ResponseOfferContent>, t: Throwable) {
                Logger.Log(Log.ERROR, this, t.message.orEmpty())
                UIAgent.showPopup(ctx, CODE.NONE, null)
            }

            override fun onResponse(call: Call<ResponseOfferContent>, response: Response<ResponseOfferContent>) {
                if (response.isSuccessful && response.body() != null) {
                    val offerContent: OfferContent = response.body()!!.offerContent

                    when (response.body()!!.sessionState) {
                        SessionState.FORCE_LOGOUT -> {
                            UIAgent.showPopup(ctx, CODE.CONFLICT, object : RetryCallback {
                                override fun call() {
                                    goToPackage(ctx, transactionId, offerId, enterPath, callback)
                                }

                                override fun cancel() {
                                }
                            })
                        }
                        else -> {
                            // 성인컨텐츠 유무 판단하기
                            var isAdult = false
                            for (item in offerContent.contentList) {
                                if (item.isAdult!!) {
                                    isAdult = true
                                    break
                                }
                            }

                            if (isAdult) {
                                if (STBAgent.isAuth) {
                                    if (STBAgent.isAdultAuth) {
                                        // 묶음 상품 상세
                                        goToPackageDetail(ctx, offerContent, enterPath)
                                    } else {
                                        // 성인인증
                                        showAdultAuthWithPackage(ctx, offerContent, enterPath)
                                    }
                                } else {
                                    // 로그인
                                    if(STBAgent.linkedHomeChoice){
                                        PopupAgent.showNormalPopup(ctx,
                                            PopupType.NormalPopupType.LOGIN_GUIDE,
                                            object : PopupEvent {
                                                override fun onClick(d: Dialog, btn: String) {
                                                    d.dismiss()
                                                }
                                            })
                                    } else {
                                        PopupAgent.showLoginPopup(ctx, Login(isAdult = true, loginqr = null), object : LoginPopupEvent {
                                            override fun onLogin(loginDialog: Dialog, btn: String) {
                                                loginDialog.dismiss()
                                                when (btn) {
                                                    BtnLabel.SUCCESS -> {
                                                        // 구매여부를 위해 컨텐츠 업데이트 필요
                                                        MBSAgent.offerContent(
                                                            transactionId = transactionId,
                                                            offerId = offerId,
                                                            callback = object : Callback<ResponseOfferContent> {
                                                                override fun onFailure(call: Call<ResponseOfferContent>, t: Throwable) {
                                                                    Logger.Log(Log.ERROR, this, t.message.orEmpty())
                                                                    UIAgent.showPopup(ctx, CODE.NONE, null)
                                                                }

                                                                override fun onResponse(
                                                                    call: Call<ResponseOfferContent>,
                                                                    response: Response<ResponseOfferContent>
                                                                ) {
                                                                    if (response.isSuccessful && response.body() != null) {
                                                                        showAdultAuthWithPackage(ctx, response.body()!!.offerContent, enterPath)
                                                                        callback?.success()
                                                                    }
                                                                }
                                                            })
                                                    }
                                                    BtnLabel.CANCEL -> {
                                                        loginDialog.dismiss()
                                                    }
                                                }
                                            }
                                        })
                                    }
                                }
                            } else {
                                // 묶음 상품 상세
                                goToPackageDetail(ctx, offerContent, enterPath)
                            }
                        }
                    }

                } else {
                    UIAgent.showPopup(ctx, response.code(), object : RetryCallback {
                        override fun call() {
                            goToPackage(ctx, transactionId, offerId, enterPath, callback)
                        }

                        override fun cancel() {
                        }
                    })
                }
            }
        })
    }

    fun goToSubCategoryList(ctx: Context, id: Int, focusType: Int) {
        val intent = Intent(ctx, SubCategoryActivity::class.java)
        intent.putExtra(Home.CATEGORY_ID, id)
        intent.putExtra(Home.CATEGORY_FOCUS, focusType)
        ctx.startActivity(intent)
    }

    private fun goToPackageDetail(ctx: Context, offerContent: OfferContent, enterPath: String) {
        val intent = Intent(ctx, PackageActivity::class.java)
        intent.putExtra(Home.ENTER_PATH, enterPath)
        intent.putExtra(Home.OFFER_CONTENT, offerContent)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        ctx.startActivity(intent)
    }

    private fun showAdultAuthWithPackage(ctx: Context, offerContent: OfferContent, enterPath: String) {
        PopupAgent.showAdultPopup(ctx, object : PopupEvent {
            override fun onClick(d: Dialog, btn: String) {
                d.dismiss()
                goToPackageDetail(ctx, offerContent, enterPath)
            }
        })
    }

    fun goToSearchMenu(ctx: Context) {
        val intent = Intent(ctx, SearchActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        ctx.startActivity(intent)
    }

    fun goToHomeMenu(ctx: Context) {
        val intent = Intent(ctx, HomeActivity2::class.java)
        intent.putExtra("TARGET_INFO", CategoryTarget.HOME)
        ctx.startActivity(intent)
    }



    fun goToMyMenu(ctx: Context) {
        val intent = Intent(ctx, MyActivity2::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)

        if (STBAgent.isAuth) {
            intent.putExtra("TARGET_INFO", CategoryTarget.ROOT)
            ctx.startActivity(intent)
        } else {
            authenticate(ctx, object : AuthListener {
                override fun next() {
                    val newIntent = Intent(ctx, MyActivity2::class.java)
                    newIntent.putExtra("TARGET_INFO", CategoryTarget.ROOT)
                    newIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    ctx.startActivity(newIntent)
                }
            })
        }
    }

    fun goToKidsLockMenu(ctx: Context) {
        val intent = Intent(ctx, KidsLockActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)

        intent.putExtra("TARGET_INFO", CategoryTarget.KIDS_LOCK)
        ctx.startActivity(intent)
    }

    fun goToAdultPasswordSettingMenu(ctx: Context) {
        val intent = Intent(ctx, AdultVerificationActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)

        intent.putExtra("TARGET_INFO", CategoryTarget.ADULT)
        ctx.startActivity(intent)
    }

    private fun authenticate(ctx: Context, listener: AuthListener) {
        GlobalScope.launch {
            MBSAgent.sessionAuth(
                Constant.appCode,
                ctx.getString(R.string.device_type),
                STBAgent.getAndroidId(ctx),
                object : Callback<ResponseAuth> {
                    override fun onFailure(call: Call<ResponseAuth>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure")
                        if (!(ctx is Activity && ctx.isFinishing)) {
                            UIAgent.showPopup(ctx, CODE.NONE, null)
                        }
                    }

                    override fun onResponse(call: Call<ResponseAuth>, response: Response<ResponseAuth>) {
                        when (response.code()) {
                            HttpURLConnection.HTTP_OK -> {
                                val res = response.body()
                                if (res != null) {
                                    MBSAgent.terminalKey = res.terminalKey
                                    STBAgent.backgroundImageUrl = res.bgImgUrl

                                    PopupAgent.appStartShowLoginPopup(ctx, Login(forceLogin = true, terminalKey = res.terminalKey, loginqr = null), object : LoginPopupEvent {
                                        override fun onLogin(loginDialog: Dialog, btn: String) {
                                            when (btn) {
                                                BtnLabel.SUCCESS -> {
                                                    listener.next()
                                                }
                                                else -> {
                                                    // Handle other cases if needed
                                                }
                                            }
                                        }
                                    })
                                } else {
                                    UIAgent.showPopup(ctx, response.code(), null)
                                }
                            }
                            else -> {
                                UIAgent.showPopup(ctx, response.code(), null)
                            }
                        }
                    }
                }
            )
        }
    }

    fun startQrActivity(ctx: Context, display: Display?, contentGroupId: Long, enterPath: String) {
        val intent = Intent(ctx, QrActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NO_HISTORY
            if (display != null) {
                putExtra("display", display)
                putExtra("contentGroupId", contentGroupId)
                putExtra("enterPath", enterPath)
            }
        }
        ctx.startActivity(intent)
    }


    private interface AuthListener {
        fun next()
    }
}