package com.homechoice.ott.vod.ui.navigation.popup


class NavigationPopupModel(
    var data: NavigationPopupData
)