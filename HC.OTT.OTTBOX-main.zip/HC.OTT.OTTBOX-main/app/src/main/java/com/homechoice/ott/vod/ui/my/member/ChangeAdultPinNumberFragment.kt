package com.homechoice.ott.vod.ui.my.member

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.homechoice.ott.vod.agent.Constant
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.databinding.FragmentMyChangeAuthBinding
import com.homechoice.ott.vod.io.PVSClient
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.model.response.ResponsePasswordSet
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.HttpURLConnection
import java.util.*

class ChangeAdultPinNumberFragment(private val activityHandler: Handler) : NavigationListView() {

    private lateinit var binding: FragmentMyChangeAuthBinding

    private var pinNumber = ""

    private var newPinNumber = ""

    private var rePinNumber = ""

    private var pinInput: ArrayList<TextView> = arrayListOf()

    private var newPinInput: ArrayList<TextView> = arrayListOf()

    private var reNewPinInput: ArrayList<TextView> = arrayListOf()

    private var successPinInput: ArrayList<TextView> = arrayListOf()

    // 0 : 초기화, 1 : 변경, 2 : 완료
    var type = 0

    private var initInfoText = "최초 비밀번호는 0000입니다."

    @SuppressLint("InflateParams")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentMyChangeAuthBinding.inflate(inflater)
        type = 0
        initMenu()
        initPinNumber()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume====================")
        val keyPadList: ArrayList<ImageView> =
            arrayListOf(
                binding.keypadNumDel, // 0 <-
                binding.keypadNum0, // 1
                binding.keypadNumOk, // 2
                binding.keypadNum1, // 3 <-
                binding.keypadNum2, // 4
                binding.keypadNum3, // 5
                binding.keypadNum4, // 6 <-
                binding.keypadNum5, // 7
                binding.keypadNum6, // 8
                binding.keypadNum7, // 9 <-
                binding.keypadNum8, // 10
                binding.keypadNum9  // 11
            )

        pinInput = arrayListOf(binding.keypadInput0, binding.keypadInput1, binding.keypadInput2, binding.keypadInput3)
        newPinInput = arrayListOf(binding.newKeypadInput0, binding.newKeypadInput1, binding.newKeypadInput2, binding.newKeypadInput3)
        reNewPinInput = arrayListOf(binding.newKeypadInput4, binding.newKeypadInput5, binding.newKeypadInput6, binding.newKeypadInput7)
        successPinInput = arrayListOf(binding.successKeypadInput0, binding.successKeypadInput1, binding.successKeypadInput2, binding.successKeypadInput3)

        Logger.Log(Log.DEBUG, this, "keyPadList size ${keyPadList.size}")

        for (item in keyPadList) {
            Logger.Log(Log.DEBUG, this, "keyPadList")
            item.setOnClickListener {
                Logger.Log(Log.DEBUG, this, "pushKey setOnClickListener")
                pushKey(it)
            }
        }

    }

    private fun initMenu() {
        if (type == 0) {
            binding.adultAuthChange.visibility = View.VISIBLE
            binding.inputAdultAuthChange.visibility = View.INVISIBLE
            binding.successAdultAuthChange.visibility = View.INVISIBLE
            binding.keypadLayout.visibility = View.VISIBLE
        }
        else if (type == 1) {
            binding.adultAuthChange.visibility = View.INVISIBLE
            binding.inputAdultAuthChange.visibility = View.VISIBLE
            binding.successAdultAuthChange.visibility = View.INVISIBLE
            binding.keypadLayout.visibility = View.VISIBLE
        }
        else {
            binding.adultAuthChange.visibility = View.INVISIBLE
            binding.inputAdultAuthChange.visibility = View.INVISIBLE
            binding.successAdultAuthChange.visibility = View.VISIBLE
            binding.keypadLayout.visibility = View.INVISIBLE
        }
    }

    private fun pushKey(view: View) {
        when (view.id) {
            binding.keypadNumOk.id -> okNumber()
            binding.keypadNumDel.id -> removeNumber()
            else ->
                appendNumber(view.tag as String)
        }
        showPinNumber()
    }

    private fun appendNumber(num: String) {
        Logger.Log(Log.DEBUG, this, "appendNumber $num")
        when (type) {
            0 -> {
                if (pinNumber.length < 4)
                    pinNumber += num
            }

            1 -> {
                if (newPinNumber.length < 4)
                    newPinNumber += num
                else if (rePinNumber.length < 4)
                    rePinNumber += num
            }

            else -> {
            }
        }
    }

    private fun removeNumber() {
        Logger.Log(Log.DEBUG, this, "removeNumber : $type")
        when (type) {
            0 -> {
                if (pinNumber.isNotEmpty())
                    pinNumber = pinNumber.substring(0, pinNumber.length - 1)
                showPinNumber()
            }

            1 -> {
                Logger.Log(Log.DEBUG, this, "removeNumber : ${rePinNumber.isNotEmpty()}")
                if (rePinNumber.isNotEmpty())
                    rePinNumber = rePinNumber.substring(0, rePinNumber.length - 1)
                else if (newPinNumber.isNotEmpty())
                    newPinNumber = newPinNumber.substring(0, newPinNumber.length - 1)

                showPinNumber()
            }

            else -> {
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun showPinNumber() {
        Logger.Log(Log.DEBUG, this, "showPinNumber $type")
        when (type) {
            0 -> {
                for (i in 0..3) {
                    if (i > pinNumber.length - 1) {
                        pinInput[i].text = ""
                    }
                    else {
                        pinInput[i].text = "●"
                    }
                }
                if (pinNumber.length == 4) {
                    binding.keypadNumOk.requestFocus()
                }
            }

            1 -> {
                for (i in 0..3) {
                    if (i > newPinNumber.length - 1) {
                        newPinInput[i].text = ""
                    }
                    else {
                        newPinInput[i].text = "●"
                    }

                    if (i > rePinNumber.length - 1) {
                        reNewPinInput[i].text = ""
                    }
                    else {
                        reNewPinInput[i].text = "●"
                    }

                    Logger.Log(Log.DEBUG, this, "rePinNumber.length ${rePinNumber.length}")
                    if (rePinNumber.length > 0) {
                        if (newPinNumber == rePinNumber) {
                            binding.newAdultAuthInfo.text = "인증번호가 일치합니다."
                        } else {
                            binding.newAdultAuthInfo.text = "인증번호가 일치하지 않습니다."
                        }
                    }
                    else {
                        binding.newAdultAuthInfo.text = initInfoText
                    }
                }
            }
            else -> {
                for (i in newPinNumber.indices) {
                    successPinInput[i].text = newPinNumber[i].toString()
                }
            }
        }
    }

    private fun initPinNumber() {
        pinNumber = ""
        newPinNumber = ""
        rePinNumber = ""
        binding.adultAuthInfo.text = initInfoText
        for (i in pinInput.indices) {
            pinInput[i].text = ""
        }
        for (i in newPinInput.indices) {
            newPinInput[i].text = ""
        }
        for (i in reNewPinInput.indices) {
            reNewPinInput[i].text = ""
        }
        for (i in successPinInput.indices) {
            successPinInput[i].text = ""
        }
    }

    //
    private fun okNumber() {
        Logger.Log(Log.DEBUG, this, "확인키 처리")
        when (type) {
            0 -> {
                if (pinNumber.length == 4) {
                    MBSAgent.adultPwCheck(STBAgent.encrypt(pinNumber)!!, object : Callback<ResponseNoBody> {
                        override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                            Logger.Log(Log.DEBUG, this, "response " + response.message().toString())
                            if (response.isSuccessful && response.body() != null) {
                                type = 1
                                initMenu()
                                focus()
                            }
                            else {
                                binding.adultAuthInfo.text = "인증번호가 맞지 않습니다."
                                binding.keypadNumDel.requestFocus()
                                pinNumber = ""
                                showPinNumber()
                            }
                        }

                        override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                            binding.adultAuthInfo.text = "잠시후 다시 시도해 주세요."
                        }
                    })
                }
                else {
                    binding.adultAuthInfo.text = "비밀번호 4자리를 입력해 주세요."
                }
            }

            1 -> {
                if (newPinNumber.length == 4 && rePinNumber.length == 4 && newPinNumber == rePinNumber) {
                    PVSClient.passwordSet(
                        UUID.randomUUID().toString(),
                        "MB",
                        STBAgent.account_id,
                        STBAgent.getAndroidId(context!!),
                        Constant.pvsAppCode,
                        STBAgent.encrypt(pinNumber)!!,
                        STBAgent.encrypt(newPinNumber)!!,
                        "CHAN",
                        object : Callback<ResponsePasswordSet> {
                            override fun onResponse(call: Call<ResponsePasswordSet>, response: Response<ResponsePasswordSet>) {
                                Logger.Log(Log.DEBUG, this, "response " + response.message().toString())
                                when (response.code()) {
                                    HttpURLConnection.HTTP_OK -> {
                                        if (response.body()?.result_code == 100) {
                                            type = 2
                                            rePinNumber = ""
                                            initMenu()
                                            showPinNumber()
                                            binding.successAdultAuthOk.requestFocus()
                                        }
                                        else {
                                            rePinNumber = ""
                                            newPinNumber = ""
                                            showPinNumber()
                                            binding.newAdultAuthInfo.text = "인증번호가 맞지 않습니다."
                                            binding.keypadNumDel.requestFocus()
                                        }
                                    }

                                    else -> {
                                        rePinNumber = ""
                                        newPinNumber = ""
                                        showPinNumber()
                                        binding.newAdultAuthInfo.text = "인증번호가 맞지 않습니다."
                                        binding.keypadNumDel.requestFocus()
                                    }
                                }
                            }

                            override fun onFailure(call: Call<ResponsePasswordSet>, t: Throwable) {
                                binding.newAdultAuthInfo.text = "잠시후 다시 시도해 주세요."
                            }
                        })
                }
                else {
                    rePinNumber = ""
                    newPinNumber = ""
                    showPinNumber()
                    binding.newAdultAuthInfo.text = "인증번호가 일치하지 않습니다."
                    binding.keypadNumDel.requestFocus()
                }
            }

            else -> {
            }
        }
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (binding.keypadNumDel.hasFocus() || binding.keypadNum1.hasFocus() || binding.keypadNum4.hasFocus() || binding.keypadNum7.hasFocus()) {
                    activityHandler.obtainMessage(2).sendToTarget()
                    true
                }
                else if (binding.successAdultAuthOk.hasFocus()) {
                    binding.successAdultAuthOk.clearFocus()
                    activityHandler.obtainMessage(2).sendToTarget()
                    true
                }
                else
                    false
            }

            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                binding.keypadNum9.hasFocus() || binding.keypadNum6.hasFocus() || binding.keypadNum3.hasFocus() || binding.keypadNumOk.hasFocus()
            }

            KeyEvent.KEYCODE_DPAD_UP -> {
                binding.keypadNum7.hasFocus() || binding.keypadNum8.hasFocus() || binding.keypadNum9.hasFocus()
            }

            KeyEvent.KEYCODE_DPAD_DOWN -> {
                binding.keypadNumDel.hasFocus() || binding.keypadNum0.hasFocus() || binding.keypadNumOk.hasFocus()
            }

            KeyEvent.KEYCODE_BACK, 97 -> {
                if (binding.successAdultAuthOk.hasFocus()) {
                    type = 0
                    pinNumber = ""
                    newPinNumber = ""
                    rePinNumber = ""
                    initMenu()
                    initPinNumber()
                }
                activityHandler.obtainMessage(2).sendToTarget()
                true
            }

            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_DPAD_CENTER,
            96-> {
                if (binding.successAdultAuthOk.hasFocus()) {
                    Logger.Log(Log.DEBUG, this, "성인인증 초기화 완료")
                    type = 0
                    initMenu()
                    initPinNumber()
                    activityHandler.obtainMessage(2).sendToTarget()
                }
                else {
                    if (binding.keypadNumDel.hasFocus()) {
                        removeNumber()
                    }
                    else if (binding.keypadNum0.hasFocus()) {
                        pushKey(binding.keypadNum0)
                    }
                    else if (binding.keypadNumOk.hasFocus()) {
                        okNumber()
                    }
                    else if (binding.keypadNum1.hasFocus()) {
                        pushKey(binding.keypadNum1)
                    }
                    else if (binding.keypadNum2.hasFocus()) {
                        pushKey(binding.keypadNum2)
                    }
                    else if (binding.keypadNum3.hasFocus()) {
                        pushKey(binding.keypadNum3)
                    }
                    else if (binding.keypadNum4.hasFocus()) {
                        pushKey(binding.keypadNum4)
                    }
                    else if (binding.keypadNum5.hasFocus()) {
                        pushKey(binding.keypadNum5)
                    }
                    else if (binding.keypadNum6.hasFocus()) {
                        pushKey(binding.keypadNum6)
                    }
                    else if (binding.keypadNum7.hasFocus()) {
                        pushKey(binding.keypadNum7)
                    }
                    else if (binding.keypadNum8.hasFocus()) {
                        pushKey(binding.keypadNum8)
                    }
                    else if (binding.keypadNum9.hasFocus()) {
                        pushKey(binding.keypadNum9)
                    }
                }
                true
            }

            else -> false
        }
    }

    override fun active() {
        focus()
    }

    fun focus() {
        Logger.Log(Log.DEBUG, this, "성인인증 변경 focus")
        when (type) {
            0, 1 -> {
                binding.keypadNum0.requestFocus()
            }

            else -> {
                binding.successAdultAuthOk.requestFocus()
            }
        }

    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        binding.root.visibility = visible
    }

}