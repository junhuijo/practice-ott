package com.homechoice.ott.vod.util

import android.graphics.Bitmap
import android.util.Log
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.security.SecureRandom

object AuthUtil {

    fun generateRandomCode(): Int {
//        const min = 1000009
//        const max = 9999999
//        // 랜덤 숫자 생성 (min 이상, max 미만)
//        return Math.floor(Math.random() * (max - min) + min);
        val min: Int = 1000009
        val max: Int = 9999999
        val range = max - min
        val secureRandom = SecureRandom()

        Logger.Log(Log.DEBUG, this, "-----------secureRandom${secureRandom.nextInt(range) + min}")
        return secureRandom.nextInt(range) + min
    }


    fun generateQRCode(content: String, width: Int = 500, height: Int = 500): Bitmap? {
        return try {
            val qrCodeWriter = QRCodeWriter()
            val bitMatrix = qrCodeWriter.encode(content, BarcodeFormat.QR_CODE, width, height)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
            for (x in 0 until width) {
                for (y in 0 until height) {
                    bitmap.setPixel(x, y, if (bitMatrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                }
            }
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }



}