package com.homechoice.ott.vod.ui.my.pay

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.homechoice.ott.vod.agent.CategoryTarget
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentMyLoginButtonBinding
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger

class LoginButtonFragment(private val activityHandler: Handler, categoryTarget: String) : NavigationListView() {

    private lateinit var binding: FragmentMyLoginButtonBinding

    var head = UIAgent.createLoginHead(categoryTarget)
    var title = UIAgent.createLoginTitle(categoryTarget)
    var body = UIAgent.createLoginBody(categoryTarget)

    @SuppressLint("InflateParams")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentMyLoginButtonBinding.inflate(inflater)
        binding.apply { frg = this@LoginButtonFragment }
        return binding.root
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                activityHandler.obtainMessage(2).sendToTarget()
                true
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                if(STBAgent.linkedHomeChoice){
                    PopupAgent.showNormalPopup(context!!,
                        PopupType.NormalPopupType.LOGIN_GUIDE,
                        object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                d.dismiss()
                            }
                        })
                } else {
                    activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                }
                true
            }
            KeyEvent.KEYCODE_BACK, 97 -> {
                activityHandler.obtainMessage(2).sendToTarget()
                true
            }
            else -> false
        }
    }

    override fun active() {
        focus()
    }

    fun focus() {
        Logger.Log(Log.DEBUG, this, "로그 리스트 focus")
        binding.btnLogin.requestFocus()
    }

    override fun setVisible(visible: Int) {
        binding.root.visibility = visible
    }

    override fun lateActive() {
    }
}