package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
data class ResponseWishItem(
    var terminalKey: String,
    val sessionState: String = "",
    var contentId: Long,
    var actionType: String,
    var targetType: String,
    var targetId: Long,
    var episodeNo: Int? = 0
) : Parcelable
