package com.homechoice.ott.vod.ui.detail.series.utils

object Utils {
    fun parseContentId(movieUrl: String?): String {
        val contentIdStr: String
        val dotIndex = movieUrl.toString().lastIndexOf(".")
        contentIdStr = if (movieUrl.toString().lastIndexOf("/") > 0) {
            movieUrl.toString().substring(movieUrl.toString().lastIndexOf("/") + 1, dotIndex)
        } else {
            movieUrl.toString().substring(0, dotIndex)
        }
        return contentIdStr
    }
}