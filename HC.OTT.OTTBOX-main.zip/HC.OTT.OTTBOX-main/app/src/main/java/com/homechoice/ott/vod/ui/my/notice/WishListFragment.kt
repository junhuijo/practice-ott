package com.homechoice.ott.vod.ui.my.notice

import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentWishListBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.model.response.ResponseWishItemList
import com.homechoice.ott.vod.model.wish.WishItem
import com.homechoice.ott.vod.ui.navigation.list.NavigationListData
import com.homechoice.ott.vod.ui.navigation.list.NavigationListEvent
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.sub.SubCategoryActivity
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_wish_list.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class WishListFragment(private val activityHandler: Handler, val categoryTarget: String) : NavigationListView() {

    private lateinit var adapter: WishListAdapter
    private lateinit var viewHolder: WishListAdapter.ViewHolder
    private lateinit var bind: FragmentWishListBinding
    private var logList: ArrayList<WishItem> = arrayListOf()
    private lateinit var emptyList: LinearLayout
    private lateinit var logScrollView: ScrollView

    var head = UIAgent.createLoginHead(categoryTarget)
    var isAdult: Boolean = categoryTarget == CategoryTarget.FAV_ADULT
    var description: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_wish_list, container, false)
        bind.frg = this
//        bind.lifecycleOwner = this
        bind.lifecycleOwner = viewLifecycleOwner
        logScrollView = bind.logListScrollView
        emptyList  = bind.wishListEmptyLayout!!
        Log.d("age rating", "isAdult: $isAdult, isAdultAuth: ${STBAgent.isAdultAuth}")

//        if (isAdult) {
////            description = "관심있는 콘텐츠를 찜한 목록입니다.\n" +
////                    "무제한으로 찜하기가 가능하며, 홈초이스에서 찜한 모든 콘텐츠를 한번에 확인하실 수 있습니다."
//        } else {
////            description = "관심있는 콘텐츠를 찜한 목록입니다. \n무제한으로 찜하기가 가능하며, 홈초이스에서 찜한 모든 콘텐츠를 한번에 확인하실 수 있습니다."
//        }
        requestWishList(isAdult)
        return bind.root
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume")
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "ServiceLogListFragment onKeyDown keyCode $keyCode")
        if (!::viewHolder.isInitialized) {
            return false
        }
        if (!STBAgent.enableKeyInput(150L)) {
            return true
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (viewHolder.binding.myWishPosterFrame!!.isSelected) {
                    true
                } else {
                    controller.decrease()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (viewHolder.binding.myWishPosterFrame!!.isSelected) {
                    true
                } else {
                    controller.increase()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                !viewHolder.binding.myWishPosterFrame!!.isSelected
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (viewHolder.binding.myWishPosterFrame!!.isSelected) {
                    viewHolder.binding.btnDetail.hasFocus()
                } else {
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                if (!viewHolder.binding.myWishPosterFrame!!.hasFocus()) {
                    viewHolder.select()
                    viewHolder.binding.myWishPosterFrame!!.requestFocus()
                } else {
                    if (viewHolder.binding.myWishPosterFrame!!.hasFocus()) {
                        viewHolder.unSelect()
                        val wishItem = logList[controller.getCurIndex()]
                        if (!wishItem.targetType.isNullOrBlank() && wishItem.targetId != null) {
                            val enterPath = UIAgent.createEnterPath(EnterPath.WISH_ITEM, wishItem.id!!)
                            when (wishItem.targetType) {
                                CategoryItemType.SERIES -> ActivityChangeAgent.goToSeriesContent(
                                    wishItem.targetId!!,
                                    logList[controller.getCurIndex()].episodeNo!!.toInt(),
                                    context!!,
                                    enterPath,
                                    null
                                )
                                CategoryItemType.CONTENTGROUP -> ActivityChangeAgent.goToContent(
                                    context!!,
                                    wishItem.targetId!!,
                                    enterPath,
                                    null
                                )
                                CategoryItemType.PACKAGE -> ActivityChangeAgent.goToPackage(
                                    context!!,
                                    UUID.randomUUID().toString(),
                                    wishItem.targetId!!,
                                    enterPath, null
                                )
                            }
                        }
//                        activityHandler.obtainMessage(1).sendToTarget() // 여기를 추가함
                    } else {
                        viewHolder.unSelect()
                        selectItem()
                    }
                }
                false
            }

            KeyEvent.KEYCODE_BACK, 97 -> {
                requireActivity().supportFragmentManager.beginTransaction().remove(this).commit()
                activityHandler.obtainMessage(2).sendToTarget()
                true
            }
            else -> false
        }
    }

    private fun selectItem() {
        val wishItem = viewHolder.wishItem

        if (wishItem.id != null && !wishItem.targetType.isNullOrBlank() && wishItem.targetId != null) {
            wishItem.episodeNo?.let {
                MBSAgent.wishItem(
                    contentId = wishItem.id!!,
                    actionType = "del",
                    targetType = wishItem.targetType!!,
                    targetId = wishItem.targetId!!,
                    episodeNo = it.toInt(),
                    callback = object : Callback<ResponseNoBody> {
                        override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                            Logger.Log(Log.ERROR, this, "onFailure")
                        }

                        override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                            if (response.isSuccessful) {
                                adapter.removeItem(controller.getCurIndex())
                                controller.removeItem(controller.getCurIndex())
                                controller.resetRemoveData()

                                if (controller.getTotalCount() > 0) {
                                    adapter.focus(controller.getCurIndex(), -1)
                                } else {
                                    log_list_layout.isVisible = false
                                    wish_list_empty_layout?.visibility = View.VISIBLE
                                    activityHandler.obtainMessage(2).sendToTarget()
                                }
                            } else {
                                UIAgent.showPopupForMyMenu(context!!, response.code(), object : RetryCallback {
                                    override fun call() {
                                        activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                        activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                    }

                                    override fun cancel() {
                                        activityHandler.obtainMessage(12).sendToTarget()
                                    }
                                })
                            }

                        }
                    })
            } ?: run {
                MBSAgent.wishItem(
                    contentId = wishItem.id!!,
                    actionType = "del",
                    targetType = wishItem.targetType!!,
                    targetId = wishItem.targetId!!,
                    callback = object : Callback<ResponseNoBody> {
                        override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                            Logger.Log(Log.ERROR, this, "onFailure")
                        }

                        override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                            if (response.isSuccessful) {
                                adapter.removeItem(controller.getCurIndex())
                                controller.removeItem(controller.getCurIndex())
                                controller.resetRemoveData()

                                if (controller.getTotalCount() > 1) {
                                    adapter.focus(controller.getCurIndex(), -1)
                                } else {
                                    log_list_layout.isVisible = false
                                    wish_list_empty_layout?.visibility = View.VISIBLE
                                }
                            } else {
                                UIAgent.showPopupForMyMenu(context!!, response.code(), object : RetryCallback {
                                    override fun call() {
                                        activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                        activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                    }

                                    override fun cancel() {
                                        activityHandler.obtainMessage(12).sendToTarget()
                                    }
                                })
                            }
                        }
                    })
            }
        }
    }


    override fun active() {
        focus()
    }

    private fun requestWishList(isAdult: Boolean) {
        GlobalScope.launch(Dispatchers.Main) {
            /**
             * 409 return api
             * */
            MBSAgent.wishItemList(
                isAdult = isAdult,
                transactionId = UUID.randomUUID().toString(),
                callback = object : Callback<ResponseWishItemList> {
                    override fun onFailure(call: Call<ResponseWishItemList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
                    }

                    override fun onResponse(call: Call<ResponseWishItemList>, res: Response<ResponseWishItemList>) {
                        if (res.isSuccessful && res.body() != null) {
                            val response = res.body()
                            if (response != null) {
                                val wishItemList = response.wishItemList
//                                val filteredList = wishItemList.filter { it.rating != "19세" }
                                val totalCount = response.totalCount

                                val filteredList = filterWishList(wishItemList)

//                                val filteredList = if (STBAgent.isAdultAuth && STBAgent.includeRrated) {
//                                    wishItemList
//                                } else {
//                                    wishItemList.filter { it.rating != "19세" }
////                                    wishItemList
//                                }

                                if (filteredList.isNotEmpty()) {
                                    if (totalCount > 0) {
                                        val actionHandler = Handler {
                                            Logger.Log(Log.DEBUG, this, "actionHandler ${it.what}")
                                            when (it.what) {
                                                0 -> {
                                                    viewHolder = it.obj as WishListAdapter.ViewHolder
                                                }
                                            }
                                            true
                                        }

                                        logList.clear()
                                        logList.addAll(filteredList)
//                                        for (item in wishItemList) {
//                                            if (item.rating != "19세") {
//                                                logList.add(item)
//                                            }
//                                        }
                                        Logger.Log(Log.DEBUG, this, "logList: ${logList}")

                                        loadImage()
                                        adapter = WishListAdapter(bind.logList!!, logList, actionHandler)

                                        setModel(
                                            NavigationListData(
                                                curIndex = 0,
                                                visibleThreshold = 1
                                            ).build(wishItemList), object : NavigationListEvent {
                                                override fun focusChange() {
                                                    Logger.Log(Log.DEBUG, this, "focusChange")
                                                    adapter.focus(controller.getCurIndex(), controller.getPreIndex())
                                                }

                                                override fun plusLineChange() {
                                                    Logger.Log(Log.DEBUG, this, "plusLineChange")
                                                    log_list_scroll_view.smoothScrollBy(0, CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                                                }

                                                override fun minusLineChange() {
                                                    Logger.Log(Log.DEBUG, this, "minusLineChange")
                                                    log_list_scroll_view.smoothScrollBy(0, -CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                                                }
                                            })

                                        if (log_list_layout != null)
                                            log_list_layout.visibility = View.VISIBLE
                                        activityHandler.obtainMessage(11).sendToTarget()
                                        if (isLateActive) {
                                            active()
                                        }
                                    }
                                } else {
                                    logScrollView.visibility = View.GONE
                                    emptyList.visibility = View.VISIBLE
                                    activityHandler.obtainMessage(2).sendToTarget()
                                }
                            } else {
                                logScrollView.visibility = View.GONE
                                emptyList.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()
                            }
                        } else {
                            UIAgent.showPopupForMyMenu(context!!, res.code(), object : RetryCallback {
                                override fun call() {
                                    parentFragmentManager.popBackStack("MY_CATEGORY_LIST", 1)
                                    activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                }

                                override fun cancel() {
                                    parentFragmentManager.popBackStack("MY_CATEGORY_LIST", 1)
                                    activityHandler.obtainMessage(13).sendToTarget()
                                }
                            })
                        }
                    }
                })

        }
    }

    fun filterWishList(wishItemList: List<WishItem>): List<WishItem> {
        return if (STBAgent.includeRrated) {
            wishItemList
//            wishItemList.filter { it.genre != "성인" }
        } else {
            wishItemList.filter { it.rating != "19세" }
//            wishItemList.filter { it.rating != "19세" && it.genre != "성인"}
        }
    }

    private fun isEnable(): Boolean {
        return bind.logListLayout.isVisible
    }

    fun focus() {
        if (isEnable()) {
            adapter.focus(controller.getCurIndex(), controller.getPreIndex())
        } else {
            activityHandler.obtainMessage(2).sendToTarget()
        }
    }

    var isLateActive: Boolean = false

    override fun lateActive() {
        isLateActive = true
    }

    override fun setVisible(visible: Int) {
        bind.root.visibility = visible
    }


    private fun loadImage() {
        logList.forEach { item ->
            view?.findViewById<ImageView>(R.id.my_poster)?.let { imageView ->
                item.posterUrl?.let { url ->
                    Glide.with(this).load(item.posterUrl).into(imageView)
                }
            }
        }
    }
}