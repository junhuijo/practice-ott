package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.event.Event
import kotlinx.android.parcel.Parcelize


@Parcelize
data class ResponseEventList(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val totalCount : Int,
    val eventList : List<Event>
) : Parcelable