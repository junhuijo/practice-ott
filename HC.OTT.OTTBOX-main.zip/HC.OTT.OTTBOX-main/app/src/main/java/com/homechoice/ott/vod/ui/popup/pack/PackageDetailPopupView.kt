package com.homechoice.ott.vod.ui.popup.pack

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.KeyEvent
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.DialogPackageDetailBinding
import com.homechoice.ott.vod.model.content.Content
import com.homechoice.ott.vod.ui.popup.PopupEvent

class PackageDetailPopupView(ctx: Context, content: Content, isPurchase: Boolean, event: PopupEvent) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {

    private var binding: DialogPackageDetailBinding

    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        binding = DialogPackageDetailBinding.inflate(LayoutInflater.from(ctx))
        binding.apply {
            viewModel = PackageDetailViewModel(detailContent = content)
        }
        setContentView(binding.root)

        binding.rating.setImageResource(UIAgent.getRatingImageResource(content.rating!!))

        if (content.isWish!!) {
            binding.iconWish.setImageResource(R.drawable.zzim)
        }

        val starList: Array<ImageView> = arrayOf(binding.imgStar0, binding.imgStar1, binding.imgStar2, binding.imgStar3, binding.imgStar4)

        for (index in 0 until content.reviewRating!!) {
            starList[index].setImageResource(R.drawable.star_full)
        }

        if (content.posterUrl != "")
            Glide.with(ctx).load(content.posterUrl).placeholder(R.drawable.poster).into(binding.contentPoster)

        if (isPurchase)
            binding.btnDetail.text = "자세히 보기"

        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {

                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER, 96 -> {
                        event.onClick(this, (currentFocus as TextView).text.toString())
                        result = true
                    }
                }
            }
            result
        }
    }

}