package com.homechoice.ott.vod.ui.play

import android.util.Log
import com.homechoice.ott.vod.util.Logger
import com.pallycon.widevinelibrary.*

class PallyconEventImpl : PallyconEventListener {

    override fun onDrmKeysRestored() {
        Logger.playerLog(Log.INFO, "DRM key Restored !!!!!")
    }

    override fun onDrmKeysLoaded(licenseInfo: Map<String?, String?>) {
        val stringBuilder = StringBuilder()
        val keys: Iterator<Map.Entry<String?, String?>> = licenseInfo.iterator()
        while (keys.hasNext()) {
            val key = keys.next()
            var value = licenseInfo[key.key]
            try {
                if (value!!.toLong() == 0x7fffffffffffffffL) {
                    value = "Unlimited"
                }
            } catch (e: java.lang.Exception) {
                // e.printStackTrace();
            }
            stringBuilder.append(key).append(" : ").append(value)
            if (keys.hasNext()) {
                stringBuilder.append("\n")
            }
        }
        //print License Info in log
        Logger.playerLog(Log.INFO, "DRM License Info:$stringBuilder")
    }

    override fun onDrmKeysRemoved() {
        Logger.playerLog(Log.INFO, "DRM key Removed !!!!!")
    }

    override fun onDrmSessionManagerError(e: Exception) {
        val message = when (e) {
            is NetworkConnectedException -> "DRM NetworkConnectedException"
            is PallyconServerResponseException -> "DRM PallyconServerResponseException"
            is DatabaseDecryptException -> "DRM DatabaseDecryptException"
            is DetectedDeviceTimeModifiedException -> "DRM DetectedDeviceTimeModifiedException"
            else -> "DRM Exception"
        }
        Logger.playerLog(Log.ERROR, "$message -> ${e.message}")
    }
}