package com.homechoice.ott.vod.model.request

data class RequestPasswordSet(
    val transaction_id: String,
    val device_type: String,
    val account_id: String,
    val wifi_mac: String,
    val app_code: String,
    val password: String,
    val new_password: String,
    val type: String
)
