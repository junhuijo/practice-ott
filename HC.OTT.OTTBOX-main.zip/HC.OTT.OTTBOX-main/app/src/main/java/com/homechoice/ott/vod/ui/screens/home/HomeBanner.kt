package com.homechoice.ott.vod.ui.screens.home

import android.content.Context

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.ActivityChangeAgent
import com.homechoice.ott.vod.agent.CategoryItemType
import com.homechoice.ott.vod.agent.EnterPath
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.ui.screens.home.banner.BannerBackground
import com.homechoice.ott.vod.ui.screens.home.banner.BannerButtons
import com.homechoice.ott.vod.ui.screens.home.banner.BannerPreviewSection

@Composable
fun BannerSection(
    viewModel: HomeViewModel
) {
    val banner by viewModel.currentBanner.collectAsState()
    val isPopupState by viewModel.showAdultPasswordDialog.collectAsState()
    val context = LocalContext.current
    fun nextBanner(){
        viewModel.nextBanner()
    }

    //rating test_null
    if (banner == null) { return }

    Box(modifier = Modifier
        .width(dimensionResource(R.dimen.home_banner_width))
        .height(dimensionResource(R.dimen.home_banner_poster_height))
    ) {
        BannerBackground(banner = banner!!)
        if (!isPopupState) { BannerPreviewSection(banner = banner!!, nextBanner = { nextBanner() }) }
        BannerButtons(
            playNowOnClick = { playNowOnClick(banner = banner,context = context) },
            nextBanner = { nextBanner() }
        )
    }

    LaunchedEffect(Unit) {
        if(viewModel.currentBanner.value == null){
            viewModel.setRandomBanner()
        }else{
            viewModel.nextBanner()
        }
    }
}

fun playNowOnClick(banner: CategoryItem?, context: Context){
    when (banner?.linkType) {
                CategoryItemType.CONTENTGROUP -> {
                    ActivityChangeAgent.goToContent(
                        ctx = context,
                        contentGroupId = banner?.linkInfo?.toLong() ?: 0,
                        enterPath = EnterPath.BANNER,
                        callback = null
                    )
                }

                CategoryItemType.SERIES -> {
                    ActivityChangeAgent.goToSeriesContent(
                        context = context,
                        id = banner?.linkInfo?.toLong() ?: 0,
                        episodeNo = 0,
                        enterPath = EnterPath.BANNER,
                        callback = null
                    )
                }
            }
}