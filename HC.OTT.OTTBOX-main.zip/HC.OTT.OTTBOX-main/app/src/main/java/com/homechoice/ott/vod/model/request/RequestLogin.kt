package com.homechoice.ott.vod.model.request

data class RequestLogin(
    val terminalKey: String,
    val memberId: String,
    val memberPw: String,
    val forceLogin: Boolean
)
