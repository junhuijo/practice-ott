package com.homechoice.ott.vod.ui.navigation.grid

import androidx.fragment.app.Fragment

abstract class NavigationGridView : Fragment() {

    var isActive = false

    var controller: NavigationGridController? = null

    fun setModel(navigationModel: NavigationGridModel, event: NavigationGridEvent) {
        controller =
            NavigationGridController(
                navigationModel,
                event
            )
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    abstract fun onKeyDown(keyCode: Int): Boolean

}