package com.homechoice.ott.vod.model.request

data class RequestPlayStop (
    val terminalKey: String,
    val serviceId: Long,
    val offset: Int
)