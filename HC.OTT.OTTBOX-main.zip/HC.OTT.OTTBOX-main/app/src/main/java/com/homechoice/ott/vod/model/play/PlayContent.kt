package com.homechoice.ott.vod.model.play

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
//잘못된 URL수정
@Parcelize
data class PlayContent(
    var id: Long = 0,
    var title: String = "",
    var movieUrl: String = "",
    var genre: String = "",
    var thumbnailUrl: String = "",
    var thumbnailServerInfo: String = "",
    var currentTimeStr: String = "00:00:00",
    var durationStr: String = "00:00:00",
    var offset: Int = 0,
    var advUrl: String = "",
    var rating: String = "전체",
    var isFree: Boolean = false,
    var isPurchase: Boolean = false,
    var isTrailer: Boolean = false,
    var isPreview: Boolean = false,
    var previewDurationInSec: Int = 0,
    var offerId: Long = -1,
    var enterPath: String = "",
    var drmToken: String =""
) : Parcelable {
    fun converter() {
        val word = movieUrl.split("/")
        movieUrl = movieUrl.replace(word.last(), "DASH/stream.mpd")
    }
}
