package com.homechoice.ott.vod.ui.popup.auth

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.popup.Phone

class PhonePopupViewModel(data: Phone) : ViewModel() {
    var phone: MutableLiveData<Phone> = MutableLiveData()

    init {
        phone.value = data
    }
}