package com.homechoice.ott.vod.ui.my.pay

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.purchaseLog.PurchaseLog

class PurchaseLogViewModel(value: PurchaseLog) : ViewModel() {
    var purchaseLog: MutableLiveData<PurchaseLog> = MutableLiveData()

    init {
        purchaseLog.value = value
    }
}