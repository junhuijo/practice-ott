package com.homechoice.ott.vod.ui.detail.series

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.model.content.Content
import kotlinx.coroutines.delay

@Composable
fun EpisodeItem(
    content: Content,
    onFocusChanged: (Boolean) -> Unit,
    focusRequest: FocusRequester,
    viewModel: SeriesViewModel,
    playerManager: PlayerManager
) {
    val borderColor = remember { mutableStateOf(Color.Transparent) }
    val imageScale = remember { mutableStateOf(0.9f) }

    var isClickable by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .height(122.dp)
            .fillMaxWidth()
            .padding(horizontal = 15.dp, vertical = 10.dp)
    ) {
        AsyncImage(
            model = content.posterUrl,
            contentDescription = null,
            modifier = Modifier
                .width(180.dp)
                .fillMaxSize()
                .border(
                    width = 2.dp,
                    color = borderColor.value,
                    shape = RoundedCornerShape(8.dp)
                )
                .scale(imageScale.value) // 이미지 스케일 적용
                .focusRequester(focusRequest)
                .onFocusChanged {
                    onFocusChanged(it.isFocused)
                    borderColor.value = if (it.isFocused) Color.Red else Color.Transparent
                    imageScale.value = if (it.isFocused) 1f else 0.9f // 포커스에 따른 이미지 스케일 조정
                }
                .focusable()
                .clickable(enabled = isClickable) {
                    val index = viewModel.contents.value.indexOfFirst { it.id == content.id }
                    viewModel.updateCurrentEpisodeIndex(index)
                    playerManager.processPlay(content, skipOffset = false)
                    isClickable = false
                }
                .clip(RoundedCornerShape(8.dp)),
            alignment = Alignment.Center,
            error = painterResource(id = R.drawable.unimage) // 로드 실패 시 표시할 이미지
        )
        Column(
            modifier = Modifier
                .width(280.dp)
                .height(90.dp)
                .align(Alignment.CenterEnd)){
            Text(
                text = content.title ?: "제목 없음",
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = (content.releaseYear + " | " + content.runTime),
                fontSize = 12.sp,
                color = Color(0xFFCFCFCF)
            )
            Spacer(modifier = Modifier.height(5.dp))
            Text(
                text = content.synopsis ?: "줄거리 정보 없음",
                color = Color(0xFFCFCFCF),
                maxLines = 2,
                fontSize = 12.sp,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(end = 30.dp)
            )
        }
    }

    LaunchedEffect(isClickable) {
        if(!isClickable) {
            delay(3000)
            isClickable = true
        }
    }
}