package com.homechoice.ott.vod.ui.popup.normal

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogNormalBinding
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupType.ErrorType
import com.homechoice.ott.vod.popup.PopupType.NormalPopupType
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.PopupViewModel
import com.homechoice.ott.vod.ui.popup.component.PopupButtonView
import com.homechoice.ott.vod.util.Logger

class NormalPopupView : Dialog {
    private var binding: DialogNormalBinding
    private var model: PopupViewModel
    private var btns: ArrayList<PopupButtonView> = arrayListOf()

    constructor(
        ctx: Context,
        type: NormalPopupType,
        event: PopupEvent
    ) : super(ctx, R.style.Theme_Design_NoActionBar) {
        binding = DialogNormalBinding.inflate(LayoutInflater.from(ctx))
        model = PopupViewModel(type)
        init()
        showNormalPopup(ctx, type, event)
    }

    constructor(
        ctx: Context,
        type: ErrorType,
        event: PopupEvent
    ) : super(ctx, R.style.Theme_Design_NoActionBar) {
        binding = DialogNormalBinding.inflate(LayoutInflater.from(ctx))
        model = PopupViewModel(type)
        init()
        showErrorPopup(ctx, type, event)
    }

    private fun init() {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        binding.apply {
            viewModel = model
        }
        setContentView(binding.root)

        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            Logger.Log(Log.DEBUG, this, "kCode:$kCode")
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                        result = true
                    }
                }
            }
            result
        }
    }

    private fun showNormalPopup(
        ctx: Context,
        type: NormalPopupType,
        event: PopupEvent
    ) {

        for (item in model.content.value?.buttons!!) {
            val btnView = PopupButtonView(
                ctx,
                binding.btnLayout,
                item.label
            )
            btns.add(btnView)
            btnView.btn.setOnClickListener {
                event.onClick(this, (it as TextView).text.toString())
            }
        }

        if (type.timer > 0)
            Handler().postDelayed({
                dismiss()
                event.onClick(this, BtnLabel.INIT)
            }, type.timer * 1000L)

        if (btns.isNotEmpty())
            btns.first().focus()

    }

    private fun showErrorPopup(ctx: Context, type: ErrorType, event: PopupEvent) {
        if (type.code != CODE.NONE)
            model.content.value?.code = "[${type.code}]"

        if (type.body == "")
            model.content.value?.body = type.defaultBody

        for (item in model.content.value?.buttons!!) {
            val btnView = PopupButtonView(
                ctx,
                binding.btnLayout,
                item.label
            )
            btns.add(btnView)
            btnView.btn.setOnClickListener {
                event.onClick(this, (it as TextView).text.toString())
            }
        }


        if (type.timer > 0)
            Handler().postDelayed({
                dismiss()
                event.onClick(this, BtnLabel.INIT)
            }, type.timer * 1000L)

        Logger.Log(Log.DEBUG, this, "btns.isNotEmpty() ${btns.isNotEmpty()}")

        if (btns.isNotEmpty())
            btns.first().focus()
    }
}