package com.homechoice.ott.vod.ui.my.point

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.point.PointHistory

class PointHistoryListViewModel(value: PointHistory) : ViewModel() {
    var item: MutableLiveData<PointHistory> = MutableLiveData()

    init {
        item.value = value
    }
}