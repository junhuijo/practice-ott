package com.homechoice.ott.vod.ui.my.notice

import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.homechoice.ott.vod.R


import com.homechoice.ott.vod.databinding.ItemNoticeListBinding


import com.homechoice.ott.vod.util.Logger

class NoticeListAdapter(var logListLayout: LinearLayout, private var items: ArrayList<NoticeListFragment.Display>, private val actionHandler: Handler) {

    private var viewList: ArrayList<ViewHolder> = arrayListOf()

    init {
        Logger.Log(Log.DEBUG, this, "onBindViewHolder init : ${items.size}")

        for (index in items.indices) {
            onBindViewHolder(onCreateViewHolder(logListLayout, index), index)
        }
        if (viewList.size > 0)
            actionHandler.obtainMessage(0, 0, 0, viewList[0]).sendToTarget()
    }

    private fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.apply {
            bind(item)
        }
        viewList.add(holder)
        logListLayout.addView(holder.binding.root)
    }

    fun focus(cur: Int, pre: Int) {
        viewList[cur].focus()
        if (pre > -1)
            viewList[pre].unfocus()
    }

    fun unfocus(cur: Int) {
        viewList[cur].unfocus()
    }

    fun removeItem(index: Int) {
        items.removeAt(index)
        viewList.removeAt(index)
        logListLayout.removeViewAt(index)
        actionHandler.obtainMessage(2).sendToTarget()
    }

    private fun onCreateViewHolder(parent: ViewGroup, index: Int): ViewHolder {
        val binding = ItemNoticeListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding, actionHandler, index)
    }

    class ViewHolder(val binding: ItemNoticeListBinding, private val actionHandler: Handler, val index: Int) {
        lateinit var display : NoticeListFragment.Display
        fun bind(item: NoticeListFragment.Display) {
            display = item
            binding.apply {
                log = NoticeListViewModel(index , item)
            }
            binding.executePendingBindings()
        }

        fun focus() {
            Logger.Log(Log.DEBUG, this, "focus adapterPosition $index")
            binding.itemNoticeListLayout.setBackgroundResource(R.drawable.fragment_notice_list_focus_border)

            actionHandler.obtainMessage(0, index, 0, this).sendToTarget()
        }

        fun unfocus() {
            Logger.Log(Log.DEBUG, this, "unfocus adapterPosition $index")
            binding.itemNoticeListLayout.setBackgroundResource(R.color.transparent)
        }

        fun select() {
            Logger.Log(Log.DEBUG, this, "select")
            binding.itemNoticeListLayout.isSelected = true
            binding.itemNoticeBtnLayout.visibility = View.VISIBLE
            actionHandler.obtainMessage(1).sendToTarget()
        }

        fun unSelect() {
            Logger.Log(Log.DEBUG, this, "unSelect")
            binding.itemNoticeListLayout.isSelected = false
            binding.itemNoticeBtnLayout.visibility = View.INVISIBLE
        }
    }

}