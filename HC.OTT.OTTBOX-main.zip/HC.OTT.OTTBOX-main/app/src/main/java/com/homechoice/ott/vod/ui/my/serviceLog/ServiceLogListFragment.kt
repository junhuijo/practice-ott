package com.homechoice.ott.vod.ui.my.serviceLog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentMyServiceListBinding
import com.homechoice.ott.vod.event.MBSCallback
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.model.response.ResponseServiceLogList
import com.homechoice.ott.vod.model.serviceLog.ServiceLog
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.ui.navigation.list.NavigationListData
import com.homechoice.ott.vod.ui.navigation.list.NavigationListEvent
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger
import com.homechoice.ott.vod.util.StringUtil
import kotlinx.android.synthetic.main.fragment_my_service_list.log_list_empty_layout
import kotlinx.android.synthetic.main.fragment_my_service_list.log_list_layout
import kotlinx.android.synthetic.main.fragment_my_service_list.log_list_scroll_view
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Objects

class ServiceLogListFragment(private val activityHandler: Handler, val categoryTarget: String) : NavigationListView() {

    private lateinit var adapter: ServiceLogListAdapter
    private var currentPosition: Int = 0
    private lateinit var viewHolder: ServiceLogListAdapter.ViewHolder

    private var logList: ArrayList<ServiceLog> = arrayListOf()
    private lateinit var emptyList: LinearLayout
    private lateinit var logScrollView: ScrollView

    private var heightList: IntArray = intArrayOf()
    private lateinit var bind: FragmentMyServiceListBinding
    var head = UIAgent.createLoginHead(categoryTarget)
    var isAdult: Boolean = categoryTarget == CategoryTarget.WAT_ADULT
    var description: String = ""

//    lateinit var btnDelete : Button

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_my_service_list, container, false)
        bind.frg = this
        bind.lifecycleOwner = viewLifecycleOwner
        logScrollView = bind.logListScrollView
        emptyList  = bind.logListEmptyLayout


//        Log.d("age rating", "isAdult: $isAdult, isAdultContentBlockEnabled: ${STBAgent.includeRrated}")
//        btnDelete = bind.btnDelete
//        btnDelete.requestFocus()
//        btnDelete.isSelected

        if (isAdult) {
//            description = "최근 성인 콘텐츠 시청내역으로 최대 7일간 노출됩니다.\n" +
//                    "시청 콘텐츠를 선택하여 OK 버튼을 누르면 시청, 구매, 삭제 하실 수 있습니다"
        } else {
//            description = "최근 콘텐츠 시청내역으로 최대 7일간 노출됩니다. \n시청 콘텐츠를 선택하여 OK 버튼을 누르면 시청, 구매, 삭제 하실 수 있습니다."
        }

        requestServiceLogList(isAdult)

        return bind.root
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume")
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }


    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "ServiceLogListFragment onKeyDown keyCode $keyCode")
        if (!::viewHolder.isInitialized) {
            return false
        }
        if (!STBAgent.enableKeyInput(STBAgent.GapTime)) {
            return true
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (viewHolder.binding.myServiceLogPosterFrame.isSelected) {
                    true
                } else {
                    controller.decrease()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (viewHolder.binding.myServiceLogPosterFrame.isSelected) {
                    true
                } else {
                    controller.increase()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                !viewHolder.binding.myServiceLogPosterFrame.isSelected
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (viewHolder.binding.myServiceLogPosterFrame.isSelected) {
                    viewHolder.binding.btnDetail?.hasFocus()!!
                } else {
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                if (!viewHolder.binding.myServiceLogPosterFrame.hasFocus()) {
                    viewHolder.select()
                    viewHolder.binding.myServiceLogPosterFrame.requestFocus()
                } else {
                    if (viewHolder.binding.myServiceLogPosterFrame.hasFocus()) {
                        val log = logList[controller.getCurIndex()]
                        val enterPath = UIAgent.createEnterPath(EnterPath.SERVICE_LOG, log.serviceId)
                        if (log.seriesId != null) {
                            log.seriesId?.let { seriesId ->
                                val episodeNoValue = log.episodeNo?.toInt() ?: 0
                                goToSeriesContent(
                                    seriesId,
                                    episodeNoValue,
                                    enterPath,
                                    context!!
                                )
                            }
                        } else if (log.contentGroupId != null) {
                            log.contentGroupId?.let {
                                ActivityChangeAgent.goToContent(context!!, it, enterPath, object : MBSCallback {
                                    override fun success() {
                                        viewHolder.unSelect()
                                        focus()
                                    }

                                    override fun error(responseCode: Int) {
                                        viewHolder.unSelect()
                                        focus()
                                    }

                                    override fun failure(responseCode: Int) {
                                        viewHolder.unSelect()
                                        focus()
                                    }
                                })
                            }
                        }
                    } else {
                        viewHolder.unSelect()
                        DeleteServiceLogPopupView(context!!, object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                when (btn) {
                                    BtnLabel.DELETE -> {
                                        viewHolder.serviceLog.contentId?.let {

                                            MBSAgent.serviceLog(it, false, object : Callback<ResponseNoBody> {
                                                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                                                    Logger.Log(Log.ERROR, this, "onFailure")
                                                }

                                                override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                                                    if (response.isSuccessful) {
                                                        adapter.removeItem(controller.getCurIndex())
                                                        controller.removeItem(controller.getCurIndex())
                                                        controller.resetRemoveData()

                                                        if (controller.getTotalCount() > 0) {
                                                            adapter.focus(controller.getCurIndex(), -1)
                                                        } else {
                                                            log_list_layout.isVisible = false
                                                            log_list_empty_layout?.visibility = View.VISIBLE
                                                            activityHandler.obtainMessage(2).sendToTarget()
                                                        }
                                                    } else {
                                                        UIAgent.showPopupForMyMenu(context!!, response.code(), object : RetryCallback {
                                                            override fun call() {
                                                                activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                                                activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                                            }

                                                            override fun cancel() {
                                                                activityHandler.obtainMessage(12).sendToTarget()
                                                            }
                                                        })
                                                    }
                                                    d.dismiss()
                                                }
                                            })
                                        }
                                    }
                                    BtnLabel.CANCEL -> {
                                        d.dismiss()
                                    }
                                }
                            }
                        })

                    }
                }
                true
            }

            KeyEvent.KEYCODE_BACK, 97 -> {
                requireActivity().supportFragmentManager.beginTransaction().remove(this).commit()
                activityHandler.obtainMessage(2).sendToTarget()
                true
            }
            else -> false
        }
    }

    override fun active() {
        focus()
    }

    private fun goToSeriesContent(id: Long, episodeNo: Int, enterPath: String, context: Context) {
        ActivityChangeAgent.goToSeriesContent(id, episodeNo, context, enterPath, object : MBSCallback {
            override fun success() {
                viewHolder.unSelect()
                focus()
            }

            override fun error(responseCode: Int) {
            }

            override fun failure(responseCode: Int) {
            }
        })
    }

    private fun requestServiceLogList(isAdult: Boolean) {
        GlobalScope.launch(Dispatchers.Main) {
            MBSAgent.serviceLogList(
                startDatetime = StringUtil.getInstance().getEndDate(0, -7),
                endDatetime = StringUtil.getInstance().getStartDate(),
                isAdult = isAdult,
                startIdx = 1,
                pageSize = 100,
                callback = object : Callback<ResponseServiceLogList> {
                    override fun onFailure(call: Call<ResponseServiceLogList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
                    }

//                    fun isAdultContent(rating: String): Boolean {
//                        return rating.contains("19")
//                    }

                    override fun onResponse(call: Call<ResponseServiceLogList>, res: Response<ResponseServiceLogList>) {
                        if (res.isSuccessful && res.body() != null) {
                            val response = res.body()
                            if (response != null) {
                                val serviceLogList = response?.serviceLogList
//                                val filteredList = serviceLogList.filter { it.rating != "19세" }
                                val totalCount = response?.totalCount

                                val filteredList = filterWishList(serviceLogList)
//                                val filteredList = if (STBAgent.isAdultAuth && STBAgent.includeRrated) {
//                                    serviceLogList
//                                } else {
//                                    serviceLogList.filter { it.rating != "19세" }
//                                }

                                if (filteredList.isNotEmpty()) {
                                    if (totalCount > 0) {
                                        val actionHandler = Handler {
                                            Logger.Log(Log.DEBUG, this, "actionHandler ${it.what}")
                                            when (it.what) {
                                                0 -> {
                                                    currentPosition = it.arg1
                                                    viewHolder = it.obj as ServiceLogListAdapter.ViewHolder
                                                }
                                            }
                                            true
                                        }

                                        logList.clear()
//                                    for (item in serviceLogList) {
//                                        if (item.rating != "19세") {
//                                            logList.add(item)
//                                        }
//                                        Logger.Log(Log.DEBUG, this, "logList: ${logList}")
//                                    }
                                        logList.addAll(filteredList)
                                        Logger.Log(Log.DEBUG, this, "logList: ${logList}")

                                        adapter = ServiceLogListAdapter(bind.logList!!, logList, actionHandler)

                                        setModel(
                                            NavigationListData(
                                                curIndex = 0,
                                                visibleThreshold = 2
                                            ).build(logList), object : NavigationListEvent {
                                                override fun focusChange() {
                                                    Logger.Log(Log.DEBUG, this, "focusChange")
                                                    adapter.focus(controller.getCurIndex(), controller.getPreIndex())
                                                }

                                                override fun plusLineChange() {
                                                    Logger.Log(Log.DEBUG, this, "plusLineChange")
                                                    log_list_scroll_view.smoothScrollBy(0, CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                                                }

                                                override fun minusLineChange() {
                                                    Logger.Log(Log.DEBUG, this, "minusLineChange")
                                                    log_list_scroll_view.smoothScrollBy(0, -CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                                                }
                                            })

                                        if (log_list_layout != null)
                                            log_list_layout.visibility = View.VISIBLE

                                        activityHandler.obtainMessage(11).sendToTarget()
                                        if (isLateActive) {
                                            active()
                                        }
                                    }
                                } else {
                                    logScrollView.visibility = View.GONE
                                    emptyList.visibility = View.VISIBLE
                                    activityHandler.obtainMessage(2).sendToTarget()
                                }
                            } else {
                                logScrollView.visibility = View.GONE
                                emptyList.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()
                            }

                        } else {
                            UIAgent.showPopupForMyMenu(context!!, res.code(), object : RetryCallback {
                                override fun call() {
                                    parentFragmentManager.popBackStack("MY_CATEGORY_LIST", 1)
                                    activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                }

                                override fun cancel() {
                                    parentFragmentManager.popBackStack("MY_CATEGORY_LIST", 1)
                                    activityHandler.obtainMessage(13).sendToTarget()
                                }
                            })
                        }
                    }
                })
        }
    }



    fun filterWishList(serviceLogList: List<ServiceLog>): List<ServiceLog> {
        return if (STBAgent.includeRrated) {
            serviceLogList
//            serviceLogList.filter { it.genre != "성인" }
        } else {
            serviceLogList.filter { it.rating != "19세" }
//            serviceLogList.filter { it.rating != "19세" && it.genre != "성인" }
        }
    }

    private fun isEnable(): Boolean {
        return bind.logListLayout?.isVisible!!
    }

    fun focus() {
        Logger.Log(Log.DEBUG, this, "로그 리스트 focus")
        if (isEnable()) {
            adapter.focus(controller.getCurIndex(), controller.getPreIndex())
        } else {
            activityHandler.obtainMessage(2).sendToTarget()
        }
    }

    var isLateActive: Boolean = false

    override fun lateActive() {
        isLateActive = true
    }

    override fun setVisible(visible: Int) {
        bind.root.visibility = visible
    }

}