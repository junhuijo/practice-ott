package com.homechoice.ott.vod.ui.navigation.navigator

class ListNode {
    var data: Int
    var next: ListNode? = null
    var previous: ListNode? = null

    constructor(data: Int) {
        this.data = data
    }
}