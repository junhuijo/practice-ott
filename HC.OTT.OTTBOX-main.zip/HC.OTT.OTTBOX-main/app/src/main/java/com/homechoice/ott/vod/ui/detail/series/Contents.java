package com.homechoice.ott.vod.ui.detail.series;

public class Contents {
    private String title;
    private String posterUrl;
    private String synopsis;
    private String runTime;

    public Contents(String title, String posterUrl, String synopsis, String runTime) {
        this.title = title;
        this.posterUrl = posterUrl;
        this.synopsis = synopsis;
        this.runTime = runTime;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getPosterUrl() {
        return posterUrl;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public String getRunTime() {
        return runTime;
    }
}