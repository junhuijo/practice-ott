package com.homechoice.ott.vod.model.content

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Display(
    var title: String,
    var ratingImageResource: Int,
    var genre: String,
    var runningTime: String,
    var runTime: String,
    var price: String,
    var director: String,
    var actor: String,
    var synopsys: String,
    var reviewRating: Int,
    var isWish: Boolean,
    var imageUrl: String,
    var eventType: String,
    var stickerType: String,
    var secondStickerType: String,
    var translationType: String,
    var viewablePeriod: String,
    var isExpand: Boolean,
    var expandText: String,
    var disPrice: String,
    var isDiscount: Boolean,
    var releaseYesar: String?
): Parcelable