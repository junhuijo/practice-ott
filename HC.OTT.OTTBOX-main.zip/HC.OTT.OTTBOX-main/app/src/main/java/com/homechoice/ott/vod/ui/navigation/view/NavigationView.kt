package com.homechoice.ott.vod.ui.navigation.view

import androidx.fragment.app.Fragment

abstract class NavigationView : Fragment() {

    var isActive = false

    var controller: NavigationController? = null

    fun setModel(navigationModel: NavigationModel, event: NavigationEvent) {
        controller = NavigationController(
            navigationModel,
            event
        )
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    abstract fun onKeyDown(keyCode: Int): Boolean

}