package com.homechoice.ott.vod.ui.sub


import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TableRow
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentSubContentListBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.model.response.ResponseCategoryItemList
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.navigation.grid.NavigationGridData
import com.homechoice.ott.vod.ui.navigation.grid.NavigationGridEvent
import com.homechoice.ott.vod.ui.navigation.grid.NavigationGridModel
import com.homechoice.ott.vod.ui.navigation.grid.NavigationGridView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.sub.content.SubContentView
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.math.ceil

class SubContentListFragment(var categoryId: Int, val hasTopCategory: Boolean, val type: Int, val activityHandler: Handler) :
    NavigationGridView() {

    private var contentViewList: ArrayList<SubContentView> = arrayListOf()
    private var transactionContentId: String = ""
    private var requestContent: Call<ResponseCategoryItemList>? = null
    private var categoryItemList: List<CategoryItem>? = null

    private lateinit var response: ResponseCategoryItemList
    private lateinit var binding: FragmentSubContentListBinding
    private var focusType = type

    var isLoading = true

    interface ConnectionListener {
        fun responseEnd(state: Int)
    }

    val connectionListener = object : ConnectionListener {
        override fun responseEnd(state: Int) {//데이터를 전부 받아왔을 경우 실행됨
            Logger.Log(Log.DEBUG, this, "responseEnd : $focusType")
            object : Thread() {
                override fun run() {
                    super.run()
                    val msg = adapterFrontTask.obtainMessage()
                    msg.what = state
                    adapterFrontTask.sendMessage(msg)
                }
            }.run()
        }
    }

    val event: NavigationGridEvent = object : NavigationGridEvent {
        override fun upRowChange() {
            Logger.Log(Log.INFO, this, "upRowChange")
            UIAgent.smoothScrollDxBy(binding.subContentListScrollView, R.dimen.sub_content_layout_row_height, false)
        }

        override fun downRowChange() {
            Logger.Log(Log.INFO, this, "downRowChange")
            isLoading = true
            UIAgent.smoothScrollDxBy(
                binding.subContentListScrollView,
                R.dimen.sub_content_layout_row_height, true
            )

            requestCategoryItemList(
                categoryId,
                controller?.data?.totalIndex!!.plus(2),
                controller?.data?.pageSize!!,
                1,
                SubCategoryActivity.ActionType.UNFOCUS
            )
        }

        override fun lastRowChange() {
            Logger.Log(Log.INFO, this, "lastRowChange")
            binding.subContentListScrollView.smoothScrollBy(
                0,
                CMBApp.RES.getDimensionPixelSize(R.dimen.sub_content_layout_row_height)!!
            )
        }

        override fun firstRowChange() {
            Logger.Log(Log.INFO, this, "firstRowChange")
            if (hasTopCategory) {
                contentViewList[controller?.getCurIndex()!!].unfocus()
                activityHandler.obtainMessage(SubCategoryActivity.ActionType.TOP_CATEGORY_FOCUS)
                    .sendToTarget()
            }
        }

        override fun firstColChange() {
            Logger.Log(Log.INFO, this, "firstColChange")
            contentViewList[controller?.getCurIndex()!!].unfocus()
            activityHandler.obtainMessage(SubCategoryActivity.ActionType.MAIN_CATEGORY_FOCUS)
                .sendToTarget()
        }

        override fun focusChange() {
            Logger.Log(Log.INFO, this, "focusChange")
            contentViewList[controller?.getPreIndex()!!].unfocus()
            contentViewList[controller?.getCurIndex()!!].focus()
        }

        override fun addEmptyRow() {
            Logger.Log(Log.INFO, this, "addEmptyRow")
            val tableRow = TableRow(context)
            val view = SubContentView(context!!, "")
            tableRow.addView(view)
            binding.subContentListTableLayout.addView(tableRow)
            UIAgent.smoothScrollDxBy(
                binding.subContentListScrollView,
                R.dimen.sub_content_layout_row_height, true
            )
        }
    }

    val adapterFrontTask: Handler = @SuppressLint("HandlerLeak")
    object : Handler() {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            if (context != null) {
                val defaultCount = (7).toDouble()

                Logger.Log(Log.INFO, this, "adapterFrontTask handleMessage msg.what : ${msg.what}")
                when (msg.what) {
                    0 -> {
                        val totalCount = response.totalCount.toDouble()
                        val itemCount = categoryItemList!!.size.toDouble()

                        if (totalCount > 0) {
                            val rows =
                                if ((itemCount / defaultCount) > 1) ceil(itemCount / defaultCount) else (1).toDouble()

                            for (rowIndex in 0 until rows.toInt()) {
                                val tableRow = TableRow(context)
                                for (colIndex in (rowIndex * defaultCount.toInt()) until ((rowIndex * defaultCount.toInt()) + defaultCount.toInt())) {
                                    if (colIndex > categoryItemList!!.size - 1) {
                                        break
                                    }
                                    val view = SubContentView(context!!, categoryItemList!![colIndex].posterUrl, categoryId.toLong())
                                    tableRow.addView(view)
                                    contentViewList.add(view)
                                }
                                binding.subContentListTableLayout.addView(tableRow)
                            }

                            setModel(
                                NavigationGridModel(
                                    NavigationGridData(
                                        rightFixedIndex = 2,
                                        totalCount = response.totalCount,
                                        colCount = defaultCount.toInt(),
                                        startIndex = 0,
                                        visibleThreshold = 3,
                                        pageSize = 35
                                    ).build(response.categoryItemList)
                                ), event
                            )
                        }

                        binding.root.visibility = View.VISIBLE
                        activityHandler.obtainMessage(SubCategoryActivity.ActionType.CONTESTS_LOADED, focusType, -1).sendToTarget()
                        isLoading = false
                    }
                    1 -> {
                        val arrayList: ArrayList<Any> = arrayListOf()
                        for (item in response.categoryItemList) {
                            arrayList.add(item)
                        }
                        controller?.appendData(arrayList)

                        val rows = if ((arrayList.size / defaultCount) > 1) ceil(arrayList.size / defaultCount) else (1).toDouble()
                        for (rowIndex in 0 until rows.toInt()) {
                            val tableRow = TableRow(context)
                            for (colIndex in (rowIndex * defaultCount.toInt()) until ((rowIndex * defaultCount.toInt()) + defaultCount.toInt())) {
                                if (colIndex > arrayList.size - 1) {
                                    break
                                }
                                val view = SubContentView(context!!, (arrayList[colIndex] as CategoryItem).posterUrl)
                                tableRow.addView(view)
                                contentViewList.add(view)
                            }
                            binding.subContentListTableLayout.addView(tableRow)
                        }

                        //activityHandler.obtainMessage(SubCategoryActivity.ActionType.CONTESTS_LOADED, SubCategoryActivity.ActionType.DOWN_FOCUS, -1).sendToTarget()
//                        controller?.increaseRow()


                        isLoading = false
                    }
                }
            }
        }
    }

    @SuppressLint("InflateParams")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentSubContentListBinding.inflate(inflater)
        requestContent = requestCategoryItemList(categoryId, 1, 35, 0, focusType)
        return binding.root
    }

    override fun onPause() {
        super.onPause()
        requestCancel()
    }

    private fun requestCancel() {
        if (requestContent != null)
            requestContent?.cancel()
        transactionContentId = ""
    }

    fun update(categoryList: CategoryList) {
        Logger.Log(Log.DEBUG, this, "init id : $id")
        requestCancel()
        binding.subContentListTableLayout.removeAllViews()
        controller = null
        contentViewList.clear()
        categoryId = categoryList.id
        requestContent = requestCategoryItemList(categoryList.id, 1, 35, 0, SubCategoryActivity.ActionType.UNFOCUS)
    }

    private fun requestCategoryItemList(id: Int, startIdx: Int, pageSize: Int, state: Int, type: Int): Call<ResponseCategoryItemList> {
        transactionContentId = UUID.randomUUID().toString()
        focusType = type
        return MBSAgent.getCategoryItemList(
            id,
            STBAgent.isAdultAuth,
            STBAgent.includeRrated,
            false,
            startIdx,
            pageSize,
            transactionContentId,
            object : Callback<ResponseCategoryItemList> {
                override fun onResponse(call: Call<ResponseCategoryItemList>, res: Response<ResponseCategoryItemList>) {
                    if (res.isSuccessful && res.body() != null) {
                        response = res.body()!!

                        when (response.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                                UIAgent.showPopup(context!!, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                        requestCategoryItemList(id, startIdx, pageSize, state, type)
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                if (transactionContentId == response.transactionId) {
                                    Logger.Log(Log.DEBUG, this, "성공 homeCategoryList : $response")
                                    categoryItemList = response.categoryItemList
                                    connectionListener.responseEnd(state)
                                }
                            }
                        }
                    } else {
                        Logger.Log(Log.DEBUG, this, "실패")
                        GlobalScope.launch(Dispatchers.Main) {
                            delay(500)
                            activityHandler.obtainMessage(SubCategoryActivity.ActionType.CONTESTS_LOADED, focusType, -1).sendToTarget()
                        }

                    }
                }

                override fun onFailure(call: Call<ResponseCategoryItemList>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, "실패 call.isCanceled ${call.isCanceled} / URL : ${call.request().url}")
                    if (!call.isCanceled) {
                        showPopup(context!!, CODE.NONE)
                    }
                }
            })

    }

    fun focus() {
        if (!contentViewList.isNullOrEmpty())
            contentViewList[controller?.getCurIndex()!!].focus()
    }

    fun setFocusType(type: Int) {
        focusType = type
    }


    private fun goToContent(id: Long, enterPath: String) {
        ActivityChangeAgent.goToContent(context!!, id, enterPath, null)
    }

    private fun goToSeriesContent(id: Long, enterPath: String) {
        ActivityChangeAgent.goToSeriesContent(id, 0, context!!, enterPath, null)
    }

    private fun showPopup(context: Context, code: Int) {
        PopupAgent.showNormalPopup(
            context,
            PopupType.getErrorType(
                TYPE.DEFAULT,
                code
            ),
            object : PopupEvent {
                override fun onClick(d: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.OK -> {
                            d.dismiss()
                        }
                    }
                }
            })
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        var result = false

        if (STBAgent.enableKeyInput() && !isLoading) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    result = true
                    controller?.increaseRow()
                }
                KeyEvent.KEYCODE_DPAD_UP -> {
                    controller?.decreaseRow()
                    result = true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    controller?.increase()
                    result = true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    controller?.decrease()
                    result = true
                }
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER, 96 -> {
                    val item = controller?.getCurItem() as CategoryItem
                    val enterPath = UIAgent.createEnterPath(EnterPath.SUB_CATEGORY, categoryId.toLong())
                    when (item.type) {
                        CategoryItemType.CONTENTGROUP -> goToContent(item.id, enterPath)
                        CategoryItemType.SERIES -> goToSeriesContent(item.id, enterPath)
                        CategoryItemType.PACKAGE_OFFER -> ActivityChangeAgent.goToPackage(
                            context!!,
                            UUID.randomUUID().toString(),
                            item.id,
                            enterPath,
                            null
                        )
                    }

                    result = true
                }
            }
        } else {
            result = true
        }
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode :$keyCode / result : $result")
        return result
    }

}