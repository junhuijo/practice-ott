import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import com.homechoice.ott.vod.R

@Composable
fun AgeGrade(grade: String, modifier: Modifier = Modifier) {
    when(grade){
        "전체" -> {
            Image(painter = painterResource(R.drawable.gradeall), contentDescription = null, modifier)
        }
        "12세"->{
            Image(painter = painterResource(R.drawable.grade12), contentDescription = null, modifier)
        }
        "15세"->{
            Image(painter = painterResource(R.drawable.grade15), contentDescription = null, modifier)
        }
        "19세"->{
            Image(painter = painterResource(R.drawable.grade19), contentDescription = null, modifier)
        }
        else->{
            Image(painter = painterResource(R.drawable.gradeall), contentDescription = null, modifier)
        }
    }
}