package com.homechoice.ott.vod.ui.detail

import android.os.Bundle
import android.view.KeyEvent
import androidx.appcompat.app.AppCompatActivity
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.STBAgent


class DetailActivity : AppCompatActivity() {
    lateinit var detailFragment: DetailFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        STBAgent.setBackgroundImage(findViewById(R.id.background_image))
        detailFragment = DetailFragment.newInstance(intent)
        supportFragmentManager.beginTransaction().add(R.id.detail_fragment, detailFragment)
            .commit()

        DetailActivityManager.addActivity(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        DetailActivityManager.removeActivity(this)
    }

    override fun onResume() {
        super.onResume()
        detailFragment.refreshData()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        return when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.keyCode == KeyEvent.KEYCODE_BACK || event.keyCode == KeyEvent.KEYCODE_BUTTON_B) {
                    finish()
                    true
                } else {
                    detailFragment.onKeyDown(event.keyCode, event)
                }
            }
            else -> super.dispatchKeyEvent(event)
        }
    }
}