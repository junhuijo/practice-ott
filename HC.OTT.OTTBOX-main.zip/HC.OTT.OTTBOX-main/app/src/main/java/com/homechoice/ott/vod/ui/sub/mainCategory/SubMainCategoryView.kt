package com.homechoice.ott.vod.ui.sub.mainCategory

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Typeface
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.CustomColor
import com.homechoice.ott.vod.databinding.SubCategoryListItemBinding
import com.homechoice.ott.vod.model.CategoryList
import com.homechoice.ott.vod.util.Logger

@SuppressLint("ViewConstructor")
class SubMainCategoryView : LinearLayout {

    private lateinit var item: CategoryList
    private lateinit var vBinding: SubCategoryListItemBinding
    private val binding get() = vBinding

    constructor(ctx: Context) : super(ctx) {
        vBinding = SubCategoryListItemBinding.inflate(LayoutInflater.from(ctx))
        addView(binding.root)
    }

    constructor(ctx: Context, item: CategoryList) : super(ctx) {
        init(ctx, item)
    }

    private fun init(ctx: Context, category: CategoryList) {
        vBinding = SubCategoryListItemBinding.inflate(LayoutInflater.from(ctx))
        item = category

        binding.mainCategoryTitle.text = item.title
        binding.mainCategoryLayout.visibility = View.VISIBLE
        binding.mainCategoryListIndicator.visibility = View.VISIBLE
        addView(binding.root)
    }

    fun focus() {
        Logger.Log(Log.ERROR, this, "focus")
        binding.mainCategoryTitle.setTextColor(CustomColor.CATEGORY_TEXT_FOCUS.rgb())
        binding.mainCategoryTitle.setTypeface(CMBApp.TYPEFACE, Typeface.BOLD)
        binding.mainCategoryTitle.setTextSize(
            TypedValue.COMPLEX_UNIT_PX,
            context.resources.getDimensionPixelSize(R.dimen.home_category_font_focus).toFloat()
        )
        binding.mainCategoryListIndicator.setImageResource(R.drawable.left_indicator)
        binding.mainCategoryListIndicator.visibility = View.VISIBLE
    }

    fun unfocus() {
        binding.mainCategoryTitle.setTextColor(CustomColor.CATEGORY_TEXT_UNFOCUS.rgb())
        binding.mainCategoryTitle.setTypeface(CMBApp.TYPEFACE, Typeface.NORMAL)
        binding.mainCategoryTitle.setTextSize(
            TypedValue.COMPLEX_UNIT_PX,
            context.resources.getDimensionPixelSize(R.dimen.home_category_font_unfocus).toFloat()
        )
        binding.mainCategoryListIndicator.visibility = View.INVISIBLE
    }

    fun selectedFocus() {
        binding.mainCategoryTitle.setTextColor(CustomColor.CATEGORY_TEXT_SELECT.rgb())
        binding.mainCategoryTitle.setTypeface(CMBApp.TYPEFACE, Typeface.BOLD)
        binding.mainCategoryTitle.setTextSize(
            TypedValue.COMPLEX_UNIT_PX,
            context.resources.getDimensionPixelSize(R.dimen.home_category_font_focus).toFloat()
        )
        binding.mainCategoryListIndicator.setImageResource(R.drawable.left_indicator_s)
        binding.mainCategoryListIndicator.visibility = View.VISIBLE
    }

}