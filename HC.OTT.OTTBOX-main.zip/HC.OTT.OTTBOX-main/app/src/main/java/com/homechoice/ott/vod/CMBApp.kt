package com.homechoice.ott.vod

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Resources
import android.graphics.Typeface
import android.util.Log
import androidx.core.content.res.ResourcesCompat
import androidx.multidex.MultiDexApplication
import com.bumptech.glide.request.target.ViewTarget
import com.homechoice.ott.vod.agent.Constant
import com.homechoice.ott.vod.agent.PreferenceUtil
import com.homechoice.ott.vod.util.Logger
import com.homechoice.ott.vod.util.StringUtil

class CMBApp : MultiDexApplication() {
    companion object {
        lateinit var prefs: PreferenceUtil

        @SuppressLint("StaticFieldLeak")
        lateinit var CTX: Context
        lateinit var RES: Resources
        fun getPixelSize(id: Int): Int {
            return RES.getDimensionPixelSize(id)
        }

        lateinit var TYPEFACE: Typeface
    }

    override fun onCreate() {
        super.onCreate()
        prefs = PreferenceUtil(applicationContext)
        CTX = applicationContext
        RES = applicationContext.resources
        TYPEFACE = ResourcesCompat.getFont(CTX, R.font.sanserif2)!!

        ViewTarget.setTagId(R.id.glide_tag);

        Logger.init(RES.getString(R.string.app_log_mode))
        Logger.LogOnCreate(this)

//        var appMode = prefs.getString("app_mode", RES.getString(R.string.app_mode))
        var appMode = prefs.getString("app_mode", RES.getString(R.string.app_mode))
        var appCode = prefs.getString("app_code", RES.getString(R.string.app_code))
        var version = prefs.getString("version", BuildConfig.VERSION_NAME)

        appMode = if (version == BuildConfig.VERSION_NAME) {
            // 앱이 첫 로딩이거나, 바뀌지 않음
            if (appMode != "") appMode else RES.getString(R.string.app_mode)
        } else {
            // 앱이 바뀌었음
            version = BuildConfig.VERSION_NAME
            appCode = RES.getString(R.string.app_code)
            RES.getString(R.string.app_mode)
        }

        prefs.setString("version", version)
        prefs.setString("app_mode", appMode)

        Logger.Log(Log.ERROR, this, "version: $version / appMode: $appMode / ${BuildConfig.VERSION_NAME}")

        Constant.init(applicationContext, appMode, appCode)
    }

}