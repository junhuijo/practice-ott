package com.homechoice.ott.vod.ui.navigation.popup

data class NavigationPopupData(
    var curIndex: Int = 0, // 전체 모델중 데이터 현재 인덱스
    var preIndex: Int = -1, // 전체 모델중 데이터 이전 인덱스
    var totalCount: Int = 0, // 전체 모델 데이터 갯수
    var colCount: Int = 0,
    var list: ArrayList<Any> = arrayListOf()
) {
    override fun toString() =
        "cur:$curIndex / preIndex: $preIndex / totalCount : $totalCount"
}