package com.homechoice.ott.vod.model.purchaseLog

import android.os.Parcelable
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.util.StringUtil
import kotlinx.android.parcel.Parcelize
import java.text.DecimalFormat

@Parcelize
data class PurchaseLog(
    var purchaseId: Long = -1,
    var title: String = "",
    var viewablePeriod: String = "",
    var packageType: String = "",
    var productType: String = "",
    var paymentType: String = "",
    var price: Int = 0,
    var purchasedDatetime: String = "",
    var targetType: String = "",
    var targetId: Long = -1,
    var episodeNo: Long = 0,
    var priceStr: String = "",
    var paymentTypeStr: String = "",
    var productTypeStr: String = "",
    var viewablePeriodStr: String = "",
    var btnStr: String = ""
) : Parcelable {
    fun build(): PurchaseLog {
        priceStr = "${DecimalFormat("#,###").format(price)}원"
        episodeNo = 0
        purchasedDatetime = StringUtil.getInstance().getPurchaseDate(purchasedDatetime)
        paymentTypeStr = UIAgent.createPaymentTypeStr(paymentType)
        productTypeStr = UIAgent.createProductTypeStr(productType, packageType)
        viewablePeriodStr = UIAgent.createViewablePeriodStr(productType, viewablePeriod)
        btnStr = UIAgent.createPurchaseLogBtnName(productType)
        return this
    }
}