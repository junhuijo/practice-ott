package com.homechoice.ott.vod.agent

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.SharedPreferences
import android.database.Cursor
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.RelativeLayout
import androidx.annotation.RequiresApi
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent.terminalKey
import com.homechoice.ott.vod.model.response.ResponseLogin
import com.homechoice.ott.vod.model.response.ResponseUserInfo
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.screens.ContentFilter
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.UnsupportedEncodingException
import java.net.NetworkInterface
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*

object STBAgent {
    var isAuth = false
    var isAdult = false
    var isAdultAuth = false
    var includeRrated = false        //나중에 mbs 수정
    var isMyAdultAuth = false
    var isSearchAdultAuth = false
    var registerTransactionId = ""
    var backgroundImageUrl = ""
    var macAddress: String = ""
    var prevKeyInputTime: Long = 0
    const val GapTime = 150L
    var pointBalance = -1
    var hasPointNoti = false
    var hasPayment = false
    var storedPassword: String? = null
    var storedAdultPassword: String? = null

    var cardName: String = ""
        get() {
//            Logger.Log(Log.DEBUG, this, "cardName : $field")
            return if (field == "") "등록 필요" else field
        }

    var linkedHomeChoice = false
    var autoQrLogin = false
    var userId = ""
    var userName = ""
    var account_id = ""
    var userAge: Int = 0
    var msoName: String = ""

    private lateinit var prefs: PreferenceUtil

    fun init() {
        isAuth = false
        isAdult = false
        isAdultAuth = true
        includeRrated = true
        isMyAdultAuth = false
        isSearchAdultAuth = false
        pointBalance = -1
        backgroundImageUrl = ""
        registerTransactionId = ""
        prevKeyInputTime = 0
        cardName = ""
        hasPointNoti = false
        hasPayment = false
        userName = ""
        userId = ""
        storedPassword = null
        storedAdultPassword = null
        userAge = 0
        msoName = ""
    }

    fun initPreference() {
        CMBApp.prefs.setBoolean("auto_login", false)
        CMBApp.prefs.setString("loginId", "")
        CMBApp.prefs.setString("loginPw", "")
    }

    fun setBackgroundImage(view: View) {
        val background = view.findViewById<RelativeLayout>(R.id.default_background)
        if (backgroundImageUrl != "") {
            Glide.with(CMBApp.CTX).load(backgroundImageUrl).into(object : SimpleTarget<Drawable>() {
                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                    background.alpha = 0.88F
                    view.background = resource
                }
            })
        }
        else {
            background.alpha = 1F
        }
    }

    fun saveData(context: Context, loginId: String, loginPw: String) {
        val prefs2: SharedPreferences =
            context.getSharedPreferences("user_info", Context.MODE_PRIVATE)
        val edit = prefs2.edit()
        edit.putString("loginId", loginId)
        edit.putString("loginPw", loginPw)
        edit.apply()
    }

    fun clearData(context: Context) {
        val prefs: SharedPreferences = context.getSharedPreferences("user_info", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor.clear()
        editor.apply()
    }

    // 일반
    fun login(context: Context, loginId: String, loginPw: String, isChecked: Boolean, forceLogin: Boolean, event: LoginEvent) {

        MBSAgent.login(loginId, if (linkedHomeChoice) loginPw else encrypt(loginPw)!!, forceLogin, object : Callback<ResponseLogin> {
            override fun onFailure(call: Call<ResponseLogin>, t: Throwable) {
                Logger.Log(Log.DEBUG, this, "로그인 실패")
                isAuth = false
                cardName = ""
                account_id = ""
                event.onFailure()
            }

            override fun onResponse(call: Call<ResponseLogin>, response: Response<ResponseLogin>) {
                Logger.Log(Log.DEBUG, this, "code ${response.code()}")
                if (response.isSuccessful && response.body() != null) {
                    isAuth = true
                    val responseLogin = response.body()
                    if (responseLogin != null) {
                        cardName = responseLogin.cardName
                        hasPayment = (cardName != "등록 필요")
                        isAdult = responseLogin.isAdult
                        pointBalance = -1
                        setAutoLogin(loginId, loginPw, isChecked)
                        account_id = loginId

                        val encryptedPw = if (linkedHomeChoice) loginPw else encrypt(loginPw)!!
                        saveData(context, loginId, encryptedPw)

                        getUserInfo {
                            event.onAccount(true)
                        }

//                        Logger.Log(Log.DEBUG, this, "STBAgent.hasPayment $hasPayment")
                        if (!responseLogin.isActive) {
                            // 팝업
                            PopupAgent.showNormalPopup(
                                context,
                                PopupType.NormalPopupType.DORMANT_ACCOUNT,
                                object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        when (btn) {
                                            BtnLabel.OK -> {
                                                d.dismiss()
                                                event.onAccount(true)
                                            }
                                        }
                                    }
                                })
                        }
                        else {
                            event.onAccount(true)
                        }
                    }
                    else {
                        account_id = ""
                        event.onFailure()
                    }
                }
                else {
                    when (response.code()) {
                        CODE.CONFLICT -> {
                            PopupAgent.showThreeLinePopup(
                                context,
                                PopupType.NormalPopupType.DOUBLE_CHECK_LOGIN,
                                object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        Logger.Log(Log.ERROR, this, "CONFLICT btn $btn")
                                        when (btn) {
                                            BtnLabel.LOGIN -> {
                                                MBSAgent.login(loginId, if (linkedHomeChoice) loginPw else encrypt(loginPw)!!, true, object : Callback<ResponseLogin> {
                                                    override fun onResponse(call: Call<ResponseLogin>, response: Response<ResponseLogin>) {
                                                        if (response.isSuccessful) {
                                                            val responseLogin = response.body()
                                                            if (responseLogin != null) {
                                                                cardName = responseLogin.cardName
                                                                hasPayment = (cardName != "등록 필요")
                                                            }

                                                            isAuth = true
                                                            account_id = loginId
                                                            setAutoLogin(loginId, loginPw, isChecked)
                                                            event.onAccount(true)
                                                        }
                                                        else {
                                                            isAuth = false
                                                            account_id = ""
                                                            setAutoLogin(loginId, loginPw, false)
                                                            event.onContinue(response.code())
                                                        }
                                                        d.dismiss()
                                                    }

                                                    override fun onFailure(call: Call<ResponseLogin>, t: Throwable) {
                                                        isAuth = false
                                                        hasPayment = false
                                                        account_id = ""
                                                        setAutoLogin(loginId, loginPw, false)
                                                        event.onAccount(false)
                                                        UIAgent.showPopup(context, CODE.NONE, null)
                                                        d.dismiss()
                                                    }
                                                })
                                            }
                                            else -> {
                                                setAutoLogin(loginId, loginPw, false)
                                                event.onAccount(false)
                                                d.dismiss()
                                            }
                                        }
                                    }
                                })
                        }
                        else -> {
                            isAuth = false
                            cardName = ""
                            hasPayment = false
                            // 로그인 실패 시 자동 로그인 해제
                            CMBApp.prefs.setBoolean("auto_login", false)
                            CMBApp.prefs.setString("loginId", "")
                            CMBApp.prefs.setString("loginPw", "")
                            event.onContinue(response.code())
                        }
                    }

                    // event.onContinue(response.code())

                }

            }
        })
    }

    // 자동
    fun login2(context: Context, loginId: String, loginPw: String, isChecked: Boolean, forceLogin: Boolean, event: LoginEvent) {
        MBSAgent.login(loginId, loginPw, forceLogin, object : Callback<ResponseLogin> {
            override fun onFailure(call: Call<ResponseLogin>, t: Throwable) {
                Logger.Log(Log.DEBUG, this, "로그인 실패")
                isAuth = false
                cardName = ""
                account_id = ""
                event.onFailure()
            }

            override fun onResponse(call: Call<ResponseLogin>, response: Response<ResponseLogin>) {
                Logger.Log(Log.DEBUG, this, "code ${response.code()}")
                if (response.isSuccessful && response.body() != null) {
                    isAuth = true
                    val responseLogin = response.body()
                    if (responseLogin != null) {
                        cardName = responseLogin.cardName
                        hasPayment = (cardName != "등록 필요")
                        isAdult = responseLogin.isAdult
                        pointBalance = -1
                        setAutoLogin(loginId, loginPw, isChecked)
                        account_id = loginId

                        getUserInfo {
                            event.onAccount(true)
                        }

//                        Logger.Log(Log.DEBUG, this, "STBAgent.hasPayment $hasPayment")
                        if (!responseLogin.isActive) {
                            // 팝업
                            PopupAgent.showNormalPopup(
                                context,
                                PopupType.NormalPopupType.DORMANT_ACCOUNT,
                                object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        when (btn) {
                                            BtnLabel.OK -> {
                                                d.dismiss()
                                                event.onAccount(true)
                                            }
                                        }
                                    }
                                })
                        }
                        else {
                            event.onAccount(true)
                        }
                    }
                    else {
                        account_id = ""
                        event.onFailure()
                    }
                }
                else {
                    when (response.code()) {
                        CODE.CONFLICT -> {
                            PopupAgent.showThreeLinePopup(
                                context,
                                PopupType.NormalPopupType.DOUBLE_CHECK_LOGIN,
                                object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        Logger.Log(Log.ERROR, this, "CONFLICT btn $btn")
                                        when (btn) {
                                            BtnLabel.LOGIN -> {
                                                MBSAgent.login(loginId, if (autoQrLogin) loginPw else encrypt(loginPw)!!, true, object : Callback<ResponseLogin> {
                                                    override fun onResponse(call: Call<ResponseLogin>, response: Response<ResponseLogin>) {
                                                        if (response.isSuccessful) {
                                                            val responseLogin = response.body()
                                                            if (responseLogin != null) {
                                                                cardName = responseLogin.cardName
                                                                hasPayment = (cardName != "등록 필요")
                                                            }

                                                            isAuth = true
                                                            account_id = loginId
                                                            setAutoLogin(loginId, loginPw, isChecked)
                                                            event.onAccount(true)
                                                        }
                                                        else {
                                                            isAuth = false
                                                            account_id = ""
                                                            setAutoLogin(loginId, loginPw, false)
                                                            event.onContinue(response.code())
                                                        }
                                                        d.dismiss()
                                                    }

                                                    override fun onFailure(call: Call<ResponseLogin>, t: Throwable) {
                                                        isAuth = false
                                                        hasPayment = false
                                                        account_id = ""
//                                                      setAutoLogin(loginId, loginPw, false)
                                                        event.onAccount(false)
                                                        UIAgent.showPopup(context, CODE.NONE, null)
                                                        d.dismiss()
                                                    }
                                                })
                                            }
                                            else -> {
                                                setAutoLogin(loginId, loginPw, false)
                                                event.onAccount(false)
                                                d.dismiss()
                                            }
                                        }
                                    }
                                })
                        }
                        else -> {
                            isAuth = false
                            cardName = ""
                            hasPayment = false
                            // 로그인 실패 시 자동 로그인 해제
                            CMBApp.prefs.setBoolean("auto_login", false)
                            CMBApp.prefs.setString("loginId", "")
                            CMBApp.prefs.setString("loginPw", "")
                            event.onContinue(response.code())
                        }
                    }
                    // event.onContinue(response.code())
                }

            }
        })
    }

    private fun setAutoLogin(loginId: String, loginPw: String, isChecked: Boolean) {
        CMBApp.prefs.setBoolean("auto_login", isChecked)
        if (isChecked) {
            CMBApp.prefs.setString("loginId", loginId)
            CMBApp.prefs.setString("loginPw", loginPw)
        }
        else {
            CMBApp.prefs.setString("loginId", "")
            CMBApp.prefs.setString("loginPw", "")
        }
    }

    fun enableKeyInput(): Boolean {
        val gap = 200L
        val curTime: Long = SystemClock.elapsedRealtime()
        val enable: Boolean = (curTime - prevKeyInputTime > gap)
        if (enable)
            prevKeyInputTime = curTime;
        return enable;
    }

    fun enableKeyInput(gap: Long): Boolean {
        val curTime: Long = SystemClock.elapsedRealtime()
        val enable: Boolean = (curTime - prevKeyInputTime > gap)
        if (enable)
            prevKeyInputTime = curTime;
        return enable;
    }

    fun getMac2(context: Context): String {
        var macAddress = ""
        val defaultUri = Uri.parse("content://com.humaxdigital.ott.provider/property").buildUpon()
            .appendPath("device.eth_mac_Address").build()
        val cursor: Cursor? = context.contentResolver.query(
            defaultUri, arrayOf("property_value"),
            null as String?, null as Array<String?>?, null as String?
        )
        Logger.Log(Log.DEBUG, this, "cursor! : $cursor")

        if (cursor != null) {
            var value: ByteArray? = null
            if (cursor.count == 1 && cursor.moveToFirst()) {
                value = cursor.getBlob(0)
            }
            cursor.close()
            if (value != null) {
                try {
                    macAddress = String(value, Charsets.UTF_8)
                }
                catch (e: UnsupportedEncodingException) {
                    e.printStackTrace()
                }
            }
        }
        else {
            if (isEmulator()) {
                macAddress = STBAgent.macAddress
            }
        }
        return macAddress
    }

    //    @JvmName("getMacAddress1")
    fun getWIFIMacAddress(): String {
        val interfaceName = "eth0"
        var macAddress = ""

        try {
            if (isEmulator()) {
                macAddress = STBAgent.macAddress
                return macAddress
            }
            else {
                Logger.Log(Log.ERROR, this, "0")
                val interfaces: List<NetworkInterface> = Collections.list(NetworkInterface.getNetworkInterfaces())
                for (inf in interfaces) {
                    Logger.Log(Log.ERROR, this, "1 ${inf.name} / ${inf.name.equals(interfaceName, ignoreCase = true)}")

                    if (!inf.name.equals(interfaceName, ignoreCase = true)) continue
                    val mac = inf.hardwareAddress
                    Logger.Log(Log.ERROR, this, "3 mac:$mac")
                    val buf = StringBuilder()
                    for (idx in mac.indices) {
                        buf.append(String.format("%02X:", mac[idx]))
                    }
                    if (buf.isNotEmpty()) buf.deleteCharAt(buf.length - 1)

                    Logger.Log(Log.ERROR, this, "2 ${buf.toString()}")
                    return buf.toString()
                }
            }
        }
        catch (ex: Exception) {
            ex.printStackTrace()
        } // for now eat exceptions
        return UUID.randomUUID().toString() //STBAgent.macAddress
    }

    fun getAndroidId(context: Context): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        Logger.Log(Log.DEBUG, this, "androidId:${androidId}")
        return androidId
    }

    /**
     * OTT STB INFO
     * H3
     * FINGERPRINT:BILLY/h3dlive/h3dlive:4.4.2/KOT49H/20180824:user/dev-keys
     * MODEL:h3dlive
     * MANUFACTURER:humaxdigital
     * BRAND:BILLY
     * DEVICE:h3dlive
     * BOARD:h3dlive
     * HOST:android-slave
     * PRODUCT:h3dlive
     *
     * H5
     * FINGERPRINT:humaxdigital/h5mini_dlive/h5mini:9/PI/20210216:user/release-keys
     * MODEL:H5_DLIVE
     * MANUFACTURER:D'Live
     * BRAND:humaxdigital
     * DEVICE:h5mini
     * BOARD:braun
     * HOST:build
     * PRODUCT:h5mini_dlive
     * */
    fun isEmulator(): Boolean {
        return (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic")
                || Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.HARDWARE.contains("goldfish")
                || Build.HARDWARE.contains("ranchu")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || Build.PRODUCT.contains("sdk_google")
                || Build.PRODUCT.contains("google_sdk")
                || Build.PRODUCT.contains("sdk")
                || Build.PRODUCT.contains("sdk_x86")
                || Build.PRODUCT.contains("vbox86p")
                || Build.PRODUCT.contains("emulator")
                || Build.PRODUCT.contains("simulator"))
    }

    fun isLiveMode(): Boolean {
        val appMode = CMBApp.prefs.getString("app_action_mode", CMBApp.RES.getString(R.string.app_mode))
        return (!isEmulator() && appMode.indexOf("live") > -1)
    }

    @kotlin.jvm.Throws(NoSuchAlgorithmException::class)
    fun encrypt(text: String): String? {
        val md: MessageDigest = MessageDigest.getInstance("SHA-256")
        md.update(text.toByteArray())
        return bytesToHex(md.digest())
    }

    private fun bytesToHex(bytes: ByteArray): String? {
        val builder = java.lang.StringBuilder()
        for (b in bytes) {
            builder.append(String.format("%02x", b))
        }
        return builder.toString()
    }

    fun logout() {
        isAdultAuth = true
        includeRrated = true
        storedPassword = null
        userAge = 0
        msoName = ""
    }

    fun getUserInfo(callback: (ResponseUserInfo?) -> Unit) {
        MBSAgent.userInfo(
            terminalKey,
            object : Callback<ResponseUserInfo> {
                @RequiresApi(Build.VERSION_CODES.O)
                @SuppressLint("SetTextI18n")
                override fun onResponse(call: Call<ResponseUserInfo>, response: Response<ResponseUserInfo>) {
                    val userInfo = response.body()
                    Logger.Log(Log.DEBUG, this, "User info retrieved: ${response.body().toString()}")
                    if (userInfo != null) {
                        val socialNumber = userInfo.socialNumber
                        val age = calculateAge(socialNumber)
                        userAge = age
                        userName = userInfo.userName
                        msoName = userInfo.msoName
                        ContentFilter.isAdultUser()
                        callback(userInfo)
                    } else {
                        callback(null)
                    }
                }
                override fun onFailure(call: Call<ResponseUserInfo>, t: Throwable) {
                    Logger.Log(Log.DEBUG, this, "failed: ${t.message}")
                    callback(null)
                }
            }
        )
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun calculateAge(socialNumber: String): Int {
        if (socialNumber.length < 7 || !socialNumber.contains("-")) return 0

        val birthNum = socialNumber.substring(0, 6)
        val checkNum = socialNumber.substring(7, 8)

        val fullBirthYear = when (checkNum) {
            "1", "2", "5", "6" -> "19$birthNum"
            "3", "4", "7", "8" -> "20$birthNum"
            else -> "18$birthNum"
        }

        val now = LocalDate.now()
        try {
            val birth = LocalDate.parse(fullBirthYear, DateTimeFormatter.ofPattern("yyyyMMdd"))
            var age = now.year - birth.year
            if (now.monthValue < birth.monthValue ||
                (now.monthValue == birth.monthValue && now.dayOfMonth < birth.dayOfMonth)
            ) {
                age--
            }
            return age
        } catch (e: Exception) {
            Logger.Log(
                Log.ERROR,
                this,
                "Failed to calculate age: $fullBirthYear, Error: ${e.message}"
            )
            return 0
        }
    }
}

data class AdultContentState (
    val isAdultAuth: Boolean,
    val includeRrated: Boolean
)

interface LoginEvent {
    fun onFailure()
    fun onAccount(isForce: Boolean)
    fun onContinue(code: Int)
}