package com.homechoice.ott.vod.ui.my.point

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import androidx.core.view.get
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentPointRegisterBinding
import com.homechoice.ott.vod.model.response.ResponsePoint
import com.homechoice.ott.vod.model.response.ResponsePointPinNo
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.point.PurchasePointSuccessPopupView
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_point_register.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PointRegisterFragment(private val activityHandler: Handler, val categoryTarget: String) : NavigationListView() {
    private lateinit var bind: FragmentPointRegisterBinding


    var head = UIAgent.createLoginHead(categoryTarget)
    var description: String = ""
    private lateinit var inputMethodManager: InputMethodManager
    private var isShowSoftInput = false
    private lateinit var viewModel: PointRegisterViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_point_register, container, false)
        bind.frg = this
        bind.lifecycleOwner = this
        description = "수령하신 쿠폰의 인증번호를 입력하시면 포인트를 이용하실 수 있습니다."

        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        inputMethodManager = context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        viewModel = ViewModelProvider(this).get(PointRegisterViewModel::class.java)

        viewModel.setModelListener(object : PointRegisterViewModel.ModelListener {
            override fun focused(focusType: PointRegisterViewModel.FocusType) {
                isShowSoftInput = false
                when (focusType) {
                    PointRegisterViewModel.FocusType.FIRST_EDIT -> {
                        first_edit_box.requestFocus()
                    }

                    PointRegisterViewModel.FocusType.SECOND_EDIT -> {
                        second_edit_box.requestFocus()
                    }

                    PointRegisterViewModel.FocusType.THIRD_EDIT -> {
                        third_edit_box.requestFocus()
                    }

                    PointRegisterViewModel.FocusType.BUTTON -> {
                        button_layout.requestFocus()
                    }
                }
            }

            override fun buttonFocused(index: Int) {
                button_layout[index].requestFocus()
            }

            override fun select(focusType: PointRegisterViewModel.FocusType, currentIndex: Int) {
                when (focusType) {
                    PointRegisterViewModel.FocusType.FIRST_EDIT -> {
                        inputMethodManager.showSoftInput(first_edit_box, 0)
                    }
                    PointRegisterViewModel.FocusType.SECOND_EDIT -> {
                        inputMethodManager.showSoftInput(second_edit_box, 0)
                    }
                    PointRegisterViewModel.FocusType.THIRD_EDIT -> {
                        inputMethodManager.showSoftInput(third_edit_box, 0)
                    }
                    PointRegisterViewModel.FocusType.BUTTON -> {
                        when (currentIndex) {
                            0 -> { //확인
                                val pinNo = """${first_edit_box.text}${second_edit_box.text}${third_edit_box.text}"""
                                if (pinNo.length < 12) {
                                    register_info.text = "쿠폰 번호가 바르지 않습니다. 다시 입력해 주세요."

                                    register_info.setTextColor(ContextCompat.getColor(context!!, R.color.wrong_password))
                                } else {
                                    requestPointPinNo(pinNo)
                                }
                            }
                            1 -> { //취소
                                first_edit_box.setText("")
                                second_edit_box.setText("")
                                third_edit_box.setText("")
//                                viewModel.back()
//                                viewModel.focusType = PointRegisterViewModel.FocusType.FIRST_EDIT
//                                first_edit_box.requestFocus()
                            }
                        }
                    }
                }
            }

            override fun back(focusType: PointRegisterViewModel.FocusType) {
                isShowSoftInput = false
                activityHandler.obtainMessage(2).sendToTarget()
                view.clearFocus()
                when (focusType) {
                    PointRegisterViewModel.FocusType.FIRST_EDIT -> {
                        first_edit_box.clearFocus()
                    }

                    PointRegisterViewModel.FocusType.SECOND_EDIT -> {
                        second_edit_box.clearFocus()
                    }

                    PointRegisterViewModel.FocusType.THIRD_EDIT -> {
                        third_edit_box.clearFocus()
                    }

                    PointRegisterViewModel.FocusType.BUTTON -> {
                        button_layout.clearFocus()
                    }
                }
            }

            override fun hideIME() {
                isShowSoftInput = false
            }

        })

        first_edit_box.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_NEXT) {
                viewModel.focusType = PointRegisterViewModel.FocusType.SECOND_EDIT
                false
            } else {
                false
            }
        }

        second_edit_box.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_NEXT) {
                viewModel.focusType = PointRegisterViewModel.FocusType.THIRD_EDIT
                false
            } else {
                false
            }
        }

        third_edit_box.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_NEXT) {
                inputMethodManager.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
                viewModel.down()
                isShowSoftInput = false
                true
            } else {
                false
            }
        }
        //if(STBAgent.pointBalance == -1)
        requestPointBalance()

        first_edit_box.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                Logger.Log(Log.DEBUG, this, "onTextChanged s ${s.toString()} / start $start / count $count")
                if (s.toString().length > 3) {
                    viewModel.right()
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        second_edit_box.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                Logger.Log(Log.DEBUG, this, "onTextChanged s ${s.toString()} / start $start / count $count")
                if (s.toString().length > 3) {
                    viewModel.right()
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        third_edit_box.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                Logger.Log(Log.DEBUG, this, "onTextChanged s ${s.toString()} / start $start / count $count")
                if (s.toString().length > 3) {
                    inputMethodManager.hideSoftInputFromWindow(third_edit_box.windowToken, 0)
                    viewModel.down()
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        activityHandler.obtainMessage(11).sendToTarget()
    }

    private fun requestPointBalance() {
        MBSAgent.pointBalance(object : Callback<ResponsePoint> {
            override fun onResponse(call: Call<ResponsePoint>, response: Response<ResponsePoint>) {
                if (response.isSuccessful && response.body() != null) {
                    STBAgent.pointBalance = response.body()!!.point
                    bind.invalidateAll()
                }
            }

            override fun onFailure(call: Call<ResponsePoint>, t: Throwable) {
                STBAgent.pointBalance = -1
            }

        })
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        var result = false
        Logger.Log(Log.INFO, this, "onKeyDown $keyCode")
        when (keyCode) {
            KeyEvent.KEYCODE_BACK, 97 -> {
                Logger.Log(Log.ERROR, this, "KEYCODE_BACK")
                if (!isShowSoftInput) {
                    viewModel.back()
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (!isShowSoftInput) {
                    viewModel.up()
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!isShowSoftInput) {
                    viewModel.down()
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (!isShowSoftInput) {
                    viewModel.right()
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (!isShowSoftInput) {
                    viewModel.left()
                    result = true
                }
            }
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_DPAD_CENTER, 96
            -> {
                if (!isShowSoftInput) {
                    viewModel.enter()
                    result = true
                }
            }
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_DPAD_CENTER, 96-> {
                result = true
            }
        }
        Logger.Log(Log.INFO, this, "onKeyDown $keyCode / result:$result")

        return result
    }

    fun focus() {
        Logger.Log(Log.INFO, this, "call focus PointRegister")
        viewModel.init()
        first_edit_box.requestFocus()
    }

    override fun active() {
        Logger.Log(Log.INFO, this, "call active PointRegister")
        focus()
    }

    var isLateActive: Boolean = false

    override fun lateActive() {
        isLateActive = true
    }

    override fun setVisible(visible: Int) {
        bind.root.visibility = visible
    }

    fun getPointBalance(): Int {
        return STBAgent.pointBalance
    }

    fun getPoint(): String {
        return String.format("%,d", STBAgent.pointBalance)
    }

    fun requestPointPinNo(pinNo: String) {
        MBSAgent.pointPinNo(pinNo, object : Callback<ResponsePointPinNo> {
            override fun onResponse(call: Call<ResponsePointPinNo>, res: Response<ResponsePointPinNo>) {
                if (res.isSuccessful && res.body() != null) {
                    STBAgent.pointBalance = res.body()!!.pointBalance
                    bind.invalidateAll()
                    first_edit_box.setText("")
                    second_edit_box.setText("")
                    third_edit_box.setText("")
                    register_info.setTextColor(ContextCompat.getColor(context!!, R.color.password))
                    register_info.text = "쿠폰 인증번호 12자리를 입력해 주세요."
                    context?.let {
                        PurchasePointSuccessPopupView(
                            ctx = it,
                            type = PopupType.NormalPopupType.POINT_REGISTER_SUCCESS,
                            balance = res.body()!!.registerPrice,
                            event = object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    d.dismiss()
                                }
                            }).show()
                    }
                } else {
                    when (res.code()) {
                        CODE.NOT -> {
                            register_info.setTextColor(ContextCompat.getColor(context!!, R.color.wrong_password))
                            register_info.text = "쿠폰 번호가 바르지 않습니다. 다시 입력해 주세요."
                        }
                        CODE.CONFLICT -> {
                            register_info.setTextColor(ContextCompat.getColor(context!!, R.color.wrong_password))
                            register_info.text = "이미 사용된 쿠폰입니다."
                        }
                        CODE.INVALID -> {
                            register_info.setTextColor(ContextCompat.getColor(context!!, R.color.wrong_password))
                            register_info.text = "사용 기한이 만료된 쿠폰 입니다."
                        }
                        else -> {
                            val error = res.errorBody()?.let { MBSAgent.error(it) }
                            PopupAgent.showNormalPopup(
                                context!!,
                                PopupType.getErrorType(
                                    TYPE.DEFAULT,
                                    res.code(),
                                    error?.errorString!!
                                ),
                                object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        when (btn) {
                                            BtnLabel.OK -> {
                                                d.dismiss()
                                            }
                                        }
                                    }
                                })
                        }

                    }
                }
            }

            override fun onFailure(call: Call<ResponsePointPinNo>, t: Throwable) {
                PopupAgent.showNormalPopup(
                    context!!,
                    PopupType.getErrorType(
                        TYPE.DEFAULT,
                        CODE.NONE
                    ),
                    object : PopupEvent {
                        override fun onClick(d: Dialog, btn: String) {
                            when (btn) {
                                BtnLabel.OK -> {
                                    d.dismiss()
                                }
                            }
                        }
                    })
            }

        })
    }
}