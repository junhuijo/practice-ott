package com.homechoice.ott.vod.ui.my.category

import android.graphics.Typeface
import android.os.Handler
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.Category
import com.homechoice.ott.vod.agent.CategoryAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.my_category_list_item.view.*

class CategoryListAdapter(private var items: ArrayList<Category>, private val actionHandler: Handler) :
    RecyclerView.Adapter<CategoryListAdapter.ViewHolder>() {

    private var holderList: HashMap<Int, ViewHolder> = hashMapOf()

    init {
        Logger.Log(Log.DEBUG, this, "onBindViewHolder init : ${items.size}")
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.apply {
            bind(item, position)
            itemView.tag = item
        }
        holderList[position] = holder
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflatedView = LayoutInflater.from(parent.context).inflate(R.layout.my_category_list_item, parent, false)
        return ViewHolder(inflatedView, actionHandler)
    }

    fun update(list: ArrayList<Category>) {
        CategoryAgent.onUserDataLoaded()
        items = list
        notifyDataSetChanged()
    }

    fun updateWithFocus(list: ArrayList<Category>) {
        items = list
        notifyDataSetChanged()

        Logger.Log(Log.DEBUG, this, "updateWithFocus ${holderList.containsKey(1)}")

        if(holderList.containsKey(1)){
            Logger.Log(Log.DEBUG, this, "updateWithFocus ${holderList[1]?.category?.name}")
            holderList[1]?.itemView?.category_name?.requestFocus()
        }
    }

    fun getItems(): ArrayList<Category> {
        return items
    }

    class ViewHolder(v: View, private val actionHandler: Handler) : RecyclerView.ViewHolder(v) {
        private var view: View = v
        private var isBack = false
        lateinit var category: Category
        fun bind(item: Category, position: Int) {
            Logger.Log(Log.DEBUG, this, "bind item $item")
            category = item

            if(category.name == "로그아웃"){
                if(STBAgent.isAuth) {
                    view.category_name.text = "로그아웃"
                }else{
                    view.category_name.text = "로그인"
                }
            }else{
                view.category_name.text = category.name
            }

            view.category_name.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    Logger.Log(Log.DEBUG, this, "focus $item / isBack: $isBack")
                    if (!isBack) {
                        if (item.leaf) {
                            Logger.Log(Log.DEBUG, this, "하위 카테고리 미노출")
                            actionHandler.obtainMessage(2, this).sendToTarget()
                        } else {
                            Logger.Log(Log.DEBUG, this, "하위 카테고리 노출")
                            actionHandler.obtainMessage(3, this).sendToTarget()
                        }
                    }
                    isBack = false
                }
            }

            view.category_name.setOnClickListener {
                Logger.Log(Log.DEBUG, this, "setOnClickListener")
            }
        }

        fun select() {
            Logger.Log(Log.DEBUG, this, "select")
            view.category_name.isSelected = true

        }

        fun back() {
            // 포커스가 목록에 되 돌아 올때 onFocusChangeListener 호출 로 인해 목록을 다시 불러오는 이슈가 있음.
            view.category_name.isSelected = false
            isBack = true
        }
    }
}