package com.homechoice.ott.vod.model.popup

data class Phone(
    val head: String = "",
    val body: String = "",
    var number: String = ""
)