package com.homechoice.ott.vod.io;

import android.util.Log
import com.homechoice.ott.vod.model.purchaseLog.ResponsePurchaseLogListAdapter
import com.homechoice.ott.vod.model.request.RequestPasswordCheck
import com.homechoice.ott.vod.model.request.RequestPasswordSet
import com.homechoice.ott.vod.model.request.RequestUserInfo
import com.homechoice.ott.vod.model.response.ResponsePasswordCheck
import com.homechoice.ott.vod.model.response.ResponsePasswordSet
import com.homechoice.ott.vod.util.Logger
import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory
import com.squareup.moshi.Moshi
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.lang.reflect.Type
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.*

object PVSClient {
    //    var BASE_URL = "http://192.168.145.5:9002/"
    var BASE_URL = "https://prod-pvs.ochoice.co.kr/"
    //    var BASE_URL = "https://dev-pvs.ochoice.co.kr/"
    var client: OkHttpClient? = null

    var pvs: PVSService? = null

    init {
        init()
    }

    fun init(url: String) {
        Logger.Log(Log.DEBUG, this, "PVSClient BASE_URL: $url / Logger.isLogMode() ${Logger.isLogMode()}")
        BASE_URL = url
        pvs = pvsService()
    }

    fun init() {

        val loggingInterceptor: HttpLoggingInterceptor

        if (Logger.isLogMode()) {
            loggingInterceptor = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
        }
        else {
            loggingInterceptor = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.NONE
            }
        }

        client = getUnsafeOkHttpClient()?.addInterceptor(loggingInterceptor)?.addInterceptor { chain ->
            val request: Request = chain.request().newBuilder().addHeader("Content-Type", "application/json").build()
            chain.proceed(request)
        }?.hostnameVerifier(NullHostNameVerifier2())?.build()
    }

    private fun withNullSerialization(): Moshi {
        return Moshi.Builder().add { _: Type?, annotations: Set<Annotation>, _: Moshi? ->
            for (annotation in annotations) {
                Logger.Log(Log.INFO, this, "annotation $annotation")
            }
            null
        }.add(ResponsePurchaseLogListAdapter()).build()
    }

    fun retrofit(): Retrofit = Retrofit.Builder()
        .client(client)
        .baseUrl(BASE_URL)
        .addConverterFactory(MoshiConverterFactory.create(withNullSerialization()))
        .addCallAdapterFactory(CoroutineCallAdapterFactory())
        .build()

    private fun pvsService(): PVSService {
        return retrofit().create(PVSService::class.java)
    }

    private fun getUnsafeOkHttpClient(): OkHttpClient.Builder? {
        return try {
            // Create a trust manager that does not validate certificate chains
            val trustAllCerts: Array<TrustManager> = arrayOf<TrustManager>(
                object : X509TrustManager {
                    @Throws(CertificateException::class)
                    override fun checkClientTrusted(chain: Array<X509Certificate?>?, authType: String?) {
                    }

                    @Throws(CertificateException::class)
                    override fun checkServerTrusted(chain: Array<X509Certificate?>?, authType: String?) {
                    }

                    override fun getAcceptedIssuers(): Array<X509Certificate> {
                        return arrayOf()
                    }
                }
            )

            // Install the all-trusting trust manager
            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, SecureRandom())

            // Create an ssl socket factory with our all-trusting manager
            val sslSocketFactory = sslContext.socketFactory
            val builder = OkHttpClient.Builder()
            builder.sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
            builder.hostnameVerifier { _, _ -> true }
            builder
        }
        catch (e: java.lang.Exception) {
            throw RuntimeException(e)
        }
    }

    fun passwordCheck(transaction_id: String, device_type: String, account_id: String, wifi_mac: String, app_code: String, password: String, checkType: String, callback: Callback<ResponsePasswordCheck>) {
        val call: Call<ResponsePasswordCheck> =
            pvs!!.passwordCheck(RequestPasswordCheck(transaction_id = transaction_id, device_type = device_type, account_id = account_id, wifi_mac = wifi_mac, app_code = app_code, password = password, checkType = checkType))
        call.enqueue(callback)
    }

    fun passwordSet(transaction_id: String, device_type: String, account_id: String, wifi_mac: String, app_code: String, password: String, new_password: String, type: String, callback: Callback<ResponsePasswordSet>) {
        val call: Call<ResponsePasswordSet> =
            pvs!!.passwordSet(RequestPasswordSet(transaction_id = transaction_id, device_type = device_type, account_id = account_id, wifi_mac = account_id, app_code = app_code, password = password, new_password = new_password, type = type))
        call.enqueue(callback)
    }
}

class NullHostNameVerifier2 : HostnameVerifier {
    override fun verify(hostname: String?, session: SSLSession?): Boolean {
        return true
    }
}