package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.purchaseLog.PurchaseLog
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponsePurchaseLogList(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val totalCount: Int,
    val purchaseLogList: List<PurchaseLog>
) : Parcelable