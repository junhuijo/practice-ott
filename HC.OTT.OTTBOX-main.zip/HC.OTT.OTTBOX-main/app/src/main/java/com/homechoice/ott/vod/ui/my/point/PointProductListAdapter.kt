package com.homechoice.ott.vod.ui.my.point

import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import com.homechoice.ott.vod.R

import com.homechoice.ott.vod.databinding.ItemPointProductListBinding
import com.homechoice.ott.vod.model.point.PointProduct
import com.homechoice.ott.vod.util.Logger

class PointProductListAdapter(var logListLayout: LinearLayout, private var items: ArrayList<PointProduct>, private val actionHandler: Handler) {

    private var viewList: ArrayList<ViewHolder> = arrayListOf()

    init {
        Logger.Log(Log.DEBUG, this, "onBindViewHolder init : ${items.size}")

        for (index in items.indices) {
            onBindViewHolder(onCreateViewHolder(logListLayout, index), index)
        }
        if (viewList.size > 0)
            actionHandler.obtainMessage(0, 0, 0, viewList[0]).sendToTarget()
    }

    private fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.apply {
            bind(item)
        }
        viewList.add(holder)
        logListLayout.addView(holder.binding.root)
    }

    fun focus(cur: Int, pre: Int) {
        viewList[cur].focus()
        if (pre > -1)
            viewList[pre].unfocus()
    }

    fun unfocus(cur: Int) {
        viewList[cur].unfocus()
    }

    fun removeItem(index: Int) {
        items.removeAt(index)
        viewList.removeAt(index)
        logListLayout.removeViewAt(index)
        actionHandler.obtainMessage(2).sendToTarget()
    }

    private fun onCreateViewHolder(parent: ViewGroup, index: Int): ViewHolder {
        val binding = ItemPointProductListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding, actionHandler, index)
    }

    class ViewHolder(val binding: ItemPointProductListBinding, private val actionHandler: Handler, val index: Int) {
        lateinit var pointProduct: PointProduct
        fun bind(item: PointProduct) {
            pointProduct = item
            binding.apply {
                log = PointProductListViewModel(item.build())

            }
            binding.executePendingBindings()
        }

        fun focus() {
            Logger.Log(Log.DEBUG, this, "focus adapterPosition $index")
            binding.itemWishListLayout.setBackgroundResource(R.drawable.list_focus)
            actionHandler.obtainMessage(0, index, 0, this).sendToTarget()
        }

        fun unfocus() {
            Logger.Log(Log.DEBUG, this, "unfocus adapterPosition $index")
            binding.itemWishListLayout.setBackgroundResource(R.drawable.p_box_normal)
        }

        fun select() {
            Logger.Log(Log.DEBUG, this, "select")
            binding.itemWishListLayout.isSelected = true
            actionHandler.obtainMessage(1).sendToTarget()
        }

        fun unSelect() {
            Logger.Log(Log.DEBUG, this, "unSelect")
            binding.itemWishListLayout.isSelected = false
        }
    }

}