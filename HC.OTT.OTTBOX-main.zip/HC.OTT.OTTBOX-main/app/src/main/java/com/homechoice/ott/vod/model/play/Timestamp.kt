package com.homechoice.ott.vod.model.play

import com.homechoice.ott.vod.util.StringUtil
import com.tickaroo.tikxml.TypeConverter

class Timestamp : TypeConverter<Int> {

    override fun write(value: Int?): String {
        return value.toString()
    }

    override fun read(value: String?): Int? {
        return StringUtil.getInstance().getSecondStr(value)
    }

}