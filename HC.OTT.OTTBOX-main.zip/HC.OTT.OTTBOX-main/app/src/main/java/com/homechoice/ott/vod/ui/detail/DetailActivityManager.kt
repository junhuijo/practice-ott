package com.homechoice.ott.vod.ui.detail

import java.util.LinkedList

object DetailActivityManager {
    private const val MAX_ACTIVITIES = 10
    private val activities = LinkedList<DetailActivity>()

    fun addActivity(activity: DetailActivity) {
        if (activities.size >= MAX_ACTIVITIES) {
            val oldestActivity = activities.removeFirst()
            oldestActivity.finish()
        }
        activities.addLast(activity)
    }

    fun removeActivity(activity: DetailActivity) {
        activities.remove(activity)
    }

    fun clearActivities() {
        activities.forEach { it.finish() }
        activities.clear()
    }
}