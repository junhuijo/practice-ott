package com.homechoice.ott.vod.ui.my.notice

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentNoticeListBinding
import com.homechoice.ott.vod.event.MBSCallback
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.notice.Notice
import com.homechoice.ott.vod.model.response.ResponseFaqList
import com.homechoice.ott.vod.model.response.ResponseNoticeList
import com.homechoice.ott.vod.model.response.ResponsePoint
import com.homechoice.ott.vod.ui.navigation.list.NavigationListData
import com.homechoice.ott.vod.ui.navigation.list.NavigationListEvent
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.notice.NoticePopupView
import com.homechoice.ott.vod.ui.sub.SubCategoryActivity
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_notice_list.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

open class NoticeListFragment(private val activityHandler: Handler, val category: Category) : NavigationListView() {

    class Display(
        var id: Long = 0,
        var title: String? = "",
        var type: String? = "",
        var text: String? = "",
        var imgUrl: String? = "",
        var linkType: String? = "",
        var linkInfo: String? = ""
    )

    private lateinit var adapter: NoticeListAdapter
    private lateinit var viewHolder: NoticeListAdapter.ViewHolder
    private lateinit var bind: FragmentNoticeListBinding

    private var logList: ArrayList<Display> = arrayListOf()

    private var isLateActive: Boolean = false

    var head = category.name
    var body: String = ""
    var description: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_notice_list, container, false)
        bind.frg = this
        bind.lifecycleOwner = this

        when (category.target) {
            CategoryTarget.NOTICE_LIST -> {
//                description = "홈초이스 서비스 공지사항 입니다."
                body = "공지사항이 없습니다."
                requestNoticeList()
            }
            CategoryTarget.POINT_FAQ -> {
                description = "포인트 이용안내 FAQ 입니다.\n자세한 사항이 궁금하시면 고객센터로 문의해 주시기 바랍니다."
                body = "FAQ가 없습니다."
                requestPointFaqList()
            }
            else -> {
                description = "자주 문의하시는 사항을 FAQ로 해결하실 수 있습니다."
                body = "FAQ가 없습니다."
                requestFaqList()
            }
        }
        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (category.target == CategoryTarget.POINT_FAQ) {
            if (STBAgent.isAuth) {
                point_layout.visibility = View.VISIBLE
                requestPointBalance()
            }
        }
    }

    private fun requestPointBalance() {
        MBSAgent.pointBalance(object : Callback<ResponsePoint> {
            override fun onResponse(call: Call<ResponsePoint>, response: Response<ResponsePoint>) {
                if (response.isSuccessful && response.body() != null) {
                    STBAgent.pointBalance = response.body()!!.point
                    bind?.invalidateAll()
                }
            }

            override fun onFailure(call: Call<ResponsePoint>, t: Throwable) {
                STBAgent.pointBalance = -1
            }

        })
    }

    fun getPointBalance(): Int {
        return STBAgent.pointBalance
    }

    fun getPoint(): String {
        return String.format("%,d", STBAgent.pointBalance)
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume")
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "NoticeListFragment onKeyDown keyCode $keyCode")
        if (!::viewHolder.isInitialized) {
            return false
        }

        if (!STBAgent.enableKeyInput(150L)) {
            return true
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (viewHolder.binding.itemNoticeListLayout.isSelected) {
                    true
                } else {
                    controller.decrease()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (viewHolder.binding.itemNoticeListLayout.isSelected) {
                    true
                } else {
                    controller.increase()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                true
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            96 -> {
                context?.let {
                    val log = logList[controller.getCurIndex()]
                    NoticePopupView(title = log.title,
                        imgUrl = log.imgUrl,
                        description = log.text,
                        useLinkDetail = !(log.linkInfo.isNullOrEmpty() || log.linkType.isNullOrEmpty()),
                        context = it, event = object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                if (btn == NoticePopupView.Label.DETAIL) {
                                    when (log.linkType) {
                                        "contentGroup" -> {
                                            log.linkInfo?.let { it1 -> goToContent(it1.toLong(), log.id) }
                                        }
                                        "series" -> {
                                            log.linkInfo?.let { it1 -> goToSeriesContent(id = it1.toLong(), noticeId = log.id, context = context!!) }
                                        }
                                        "category" -> {
                                            log.linkInfo?.let { it1 ->
                                                ActivityChangeAgent.goToSubCategoryList(
                                                    ctx = context!!,
                                                    id = it1.toInt(),
                                                    focusType = SubCategoryActivity.ActionType.MAIN_CATEGORY_FOCUS
                                                )
                                            }
                                        }
                                    }
                                } else if (btn == NoticePopupView.Label.CLOSE) {
                                    d.dismiss()
                                }
                            }
                        })
                }
                true
            }

            KeyEvent.KEYCODE_BACK, 97 -> {
                requireActivity().supportFragmentManager.beginTransaction().remove(this).commit()
                activityHandler.obtainMessage(2).sendToTarget()
                true
            }
            else -> false
        }
    }

    override fun active() {
        focus()
    }

    private fun goToContent(contentGroupId: Long, noticeId: Long) {
        ActivityChangeAgent.goToContent(context!!, contentGroupId, UIAgent.createEnterPath(EnterPath.NOTICE, noticeId), object : MBSCallback {
            override fun success() {
                viewHolder.unSelect()
                focus()
            }

            override fun error(responseCode: Int) {
            }

            override fun failure(responseCode: Int) {
            }
        })
    }

    private fun goToSeriesContent(id: Long, noticeId: Long, context: Context) {
        ActivityChangeAgent.goToSeriesContent(id, 0, context, UIAgent.createEnterPath(EnterPath.NOTICE, noticeId), object : MBSCallback {
            override fun success() {
                viewHolder.unSelect()
                focus()
            }

            override fun error(responseCode: Int) {
            }

            override fun failure(responseCode: Int) {
            }
        })
    }

    private fun createList(displayList: List<Display>, totalCount: Int) {
        if (totalCount > 0) {
            val actionHandler = Handler {
                Logger.Log(Log.DEBUG, this, "actionHandler ${it.what}")
                when (it.what) {
                    0 -> {
                        viewHolder = it.obj as NoticeListAdapter.ViewHolder
                    }
                }
                true
            }

            logList.clear()
            for (item in displayList) {
                logList.add(item)
            }
            adapter = NoticeListAdapter(bind.logList, logList, actionHandler)

            setModel(
                NavigationListData(
                    curIndex = 0,
                    visibleThreshold = 6
                ).build(displayList), object : NavigationListEvent {
                    override fun focusChange() {
                        Logger.Log(Log.DEBUG, this, "focusChange")
                        adapter.focus(controller.getCurIndex(), controller.getPreIndex())
                        checkArrow()
                    }

                    override fun plusLineChange() {
                        Logger.Log(Log.DEBUG, this, "plusLineChange")
                        log_list_scroll_view.smoothScrollBy(0, CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                    }

                    override fun minusLineChange() {
                        Logger.Log(Log.DEBUG, this, "minusLineChange")
                        log_list_scroll_view.smoothScrollBy(0, -CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                    }
                })

            checkArrow()
            log_list_layout?.visibility = View.VISIBLE
            activityHandler.obtainMessage(11).sendToTarget()
            if (isLateActive) {
                active()
            }
        } else {
            login_line?.visibility = View.VISIBLE
            log_list_empty_layout?.visibility = View.VISIBLE
            activityHandler.obtainMessage(2).sendToTarget()
        }
    }

    private fun requestPointFaqList() {
        GlobalScope.launch(Dispatchers.Main) {
            MBSAgent.pointFaqList(
                startIdx = 1,
                pageSize = 0,
                callback = object : Callback<ResponseFaqList> {
                    override fun onFailure(call: Call<ResponseFaqList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
                    }

                    override fun onResponse(call: Call<ResponseFaqList>, res: Response<ResponseFaqList>) {
                        if (res.isSuccessful && res.body() != null) {
                            val response = res.body()
                            if (response != null) {
                                val faqList = response.faqList
                                val totalCount = response.totalCount
                                createList(displayList = faqList.map { faq ->
                                    Display(
                                        id = faq.id,
                                        type = faq.type,
                                        title = faq.title,
                                        imgUrl = faq.imgUrl,
                                        text = faq.text
                                    )
                                }, totalCount = totalCount)
                            } else {
                                login_line?.visibility = View.VISIBLE
                                log_list_empty_layout?.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()
                            }
                        } else {
                            showPopupForMyMenu(res.code())
                        }
                    }
                })
        }
    }

    private fun requestFaqList() {
        GlobalScope.launch(Dispatchers.Main) {
            MBSAgent.faqList(
                startIdx = 1,
                pageSize = 0,
                callback = object : Callback<ResponseFaqList> {
                    override fun onFailure(call: Call<ResponseFaqList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
                    }

                    override fun onResponse(call: Call<ResponseFaqList>, res: Response<ResponseFaqList>) {
                        if (res.isSuccessful && res.body() != null) {
                            val response = res.body()
                            if (response != null) {
                                val faqList = response.faqList
                                val totalCount = response.totalCount
                                createList(displayList = faqList.map { faq ->
                                    Display(
                                        id = faq.id,
                                        type = faq.type,
                                        title = faq.title,
                                        imgUrl = faq.imgUrl,
                                        text = faq.text
                                    )
                                }, totalCount = totalCount)
                            } else {
                                login_line?.visibility = View.VISIBLE
                                log_list_empty_layout?.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()
                            }
                        } else {
                            showPopupForMyMenu(res.code())
                        }
                    }
                })
        }
    }

    data class DummyNoticeList(
        val id: Long,
        val title: String,
        val type: String,
        val text: String,
        val imgUrl: String?,
        val linkType: String?,
        val linkInfo: String?
    )

    private fun getDummyNoticeList(): List<NoticeListFragment.Display> {
        return listOf(
            NoticeListFragment.Display(
                id = 1,
                title = "[지역콘텐츠 통합플랫폼 가지 1주년]",
                type = "test_dummy",
                text = "1년 동안 함께 해주셔서 진심으로 감사드립니다. (2/23)",
                imgUrl = null,
                linkType = null,
                linkInfo = null
            ),
            NoticeListFragment.Display(
                id = 2,
                title = "[오초이스 1주년 기념 이벤트 안내]",
                type = "test_dummy",
                text = "케이블TV 가입자라면 오초이스! (3/1)",
                imgUrl = null,
                linkType = null,
                linkInfo = null
            ),
            NoticeListFragment.Display(
                id = 3,
                title = "[KCTA 2024 케이블 TV 방송대상]",
                type = "test_dummy",
                text = "2024.04.19(금) 16:00~17:30 / 서울 콘래드호텔 그랜드볼룸",
                imgUrl = null,
                linkType = null,
                linkInfo = null
            )
        )
    }

    private fun requestNoticeList() {
        GlobalScope.launch(Dispatchers.Main) {
            MBSAgent.noticeList(
                startIdx = 1,
                pageSize = 0,
                callback = object : Callback<ResponseNoticeList> {
                    override fun onFailure(call: Call<ResponseNoticeList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
                    }

                    override fun onResponse(call: Call<ResponseNoticeList>, res: Response<ResponseNoticeList>) {
                        if (res.isSuccessful && res.body() != null) {
                            val response = res.body()
                            if (response != null) {
//                                val dummyNoticeList = getDummyNoticeList()
                                val noticeList = response.noticeList
                                val totalCount = response.totalCount
                                createList(displayList = noticeList.map { notice ->
                                    Display(
                                        id = notice.id,
                                        title = notice.title,
                                        type = notice.type,
                                        linkType = notice.linkType,
                                        imgUrl = notice.imgUrl,
                                        linkInfo = notice.linkInfo,
                                        text = notice.text
                                    )
                                }, totalCount = totalCount)
                            } else {
                                login_line?.visibility = View.VISIBLE
                                log_list_empty_layout?.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()
                            }
                        } else {
                            showPopupForMyMenu(res.code())
                        }
                    }
                })
        }
    }

    private fun showPopupForMyMenu(code: Int) {
        UIAgent.showPopupForMyMenu(context!!, code, object : RetryCallback {
            override fun call() {
                activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
            }

            override fun cancel() {
                activityHandler.obtainMessage(12).sendToTarget()
            }
        })
    }

    private fun checkArrow() {
        if (controller.getTotalCount() > controller.getVisibleThreshold()) {
            if (controller.isLastItem())
                bind.myNoticeListArrow.visibility = View.INVISIBLE
            else
                bind.myNoticeListArrow.visibility = View.VISIBLE
        }
    }

    private fun isEnable(): Boolean {
        return bind.logListLayout.isVisible
    }

    fun focus() {
        Logger.Log(Log.DEBUG, this, "로그 리스트 focus")
        if (isEnable()) {
            adapter.focus(controller.getCurIndex(), controller.getPreIndex())
        } else {
            activityHandler.obtainMessage(2).sendToTarget()
        }
    }

    override fun lateActive() {
        isLateActive = true
    }

    override fun setVisible(visible: Int) {
        bind.root.visibility = visible
    }

}