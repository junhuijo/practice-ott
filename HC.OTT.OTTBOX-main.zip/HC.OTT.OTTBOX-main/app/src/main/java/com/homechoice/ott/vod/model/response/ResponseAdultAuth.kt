package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseAdultAuth(
    val isAdult: Boolean,
    val transactionId: String,
    val errorString: String,
    val sessionState: String = ""
) : Parcelable