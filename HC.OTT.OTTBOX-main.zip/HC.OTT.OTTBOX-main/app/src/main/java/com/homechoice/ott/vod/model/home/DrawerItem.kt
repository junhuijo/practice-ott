package com.homechoice.ott.vod.model.home

data class DrawerItem (
    val name: String,
    val id: Int
)