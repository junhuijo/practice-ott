package com.homechoice.ott.vod.io;

import com.homechoice.ott.vod.model.play.Thumbnail
import com.homechoice.ott.vod.model.play.Timestamp
import com.tickaroo.tikxml.TikXml
import com.tickaroo.tikxml.retrofit.TikXmlConverterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Retrofit
import java.util.*


class RetrofitXmlClient private constructor() {

    //    private const val BASE_URL = "http://220.126.164.198:3000/"
//    private const val BASE_URL = "http://211.244.244.60:3000/"
//    private const val BASE_URL = "http://192.168.141.16:8443/"
//    private const val BASE_URL = "http://58.143.201.132:8443/"
//    private const val BASE_URL = "http://192.168.1.2:3000/"

    companion object {
        private val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        private val client = OkHttpClient().newBuilder().addInterceptor(loggingInterceptor).build()

        @Volatile
        private var instance: RetrofitXmlClient? = null

        @JvmStatic
        fun getInstance(): RetrofitXmlClient = instance ?: synchronized(this) {
            instance ?: RetrofitXmlClient().also {
                instance = it
            }
        }
    }

    private lateinit var mbs: RetrofitXmlService

    private fun retrofit(thumbnailUrl: String): Retrofit {
        val tikXml: TikXml =
            TikXml.Builder().addTypeConverter(Date::class.java, Timestamp()).build()
        return Retrofit.Builder()
            .client(client)
            .baseUrl(thumbnailUrl)
            .callFactory(OkHttpClient.Builder().build())
            .addConverterFactory(TikXmlConverterFactory.create(tikXml))
            .build()
    }

    private fun mbsService(thumbnailUrl: String): RetrofitXmlService {
        return retrofit(thumbnailUrl).create(RetrofitXmlService::class.java)
    }

    fun setService(thumbnailUrl: String) {
        mbs = mbsService(thumbnailUrl)
    }

    fun getThumbnail(url: String, callback: Callback<Thumbnail>) {
        val call: Call<Thumbnail> = mbs.requestThumbnail(url)
        call.enqueue(callback)
    }


}
