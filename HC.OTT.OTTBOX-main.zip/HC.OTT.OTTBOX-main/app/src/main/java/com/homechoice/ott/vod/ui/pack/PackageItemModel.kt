package com.homechoice.ott.vod.ui.pack

import androidx.lifecycle.MutableLiveData
import com.homechoice.ott.vod.model.content.Content
import java.text.DecimalFormat

class PackageItemModel(content: Content) {
    var title: MutableLiveData<String> = MutableLiveData()
    var info: MutableLiveData<String> = MutableLiveData()
    var actor: MutableLiveData<String> = MutableLiveData()
    var priceInfo: MutableLiveData<String> = MutableLiveData()

    init {
        var runTimeMinute = 0
        val runTime = content.runTime
        val hReg = Regex("(\\d)시간")
        val mReg = Regex("(\\d+)분")

        if (!runTime.isNullOrEmpty()) {
            val hGroups = hReg.find(runTime)?.groups
            val mGroups = mReg.find(runTime)?.groups

            if (hGroups != null && hGroups.size > 1) {
                runTimeMinute = hGroups[1]?.value?.toInt()!! * 60
            }

            if (mGroups != null && mGroups.size > 1) {
                runTimeMinute += mGroups[1]?.value?.toInt()!!
            }
        }
        title.value = content.title
        info.value = "${runTimeMinute}분 | ${content.genre} | "
        actor.value = content.actor

        var price = ""
        for (offer in content.offerList) {
            if (offer.packageType == "single") {
                price = if (offer.price == 0) {
                    "무료"
                } else {
                    "${DecimalFormat("#,###").format(offer.price)}원"
                }
                break
            }
        }
        priceInfo.value = price
    }
}