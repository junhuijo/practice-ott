package com.homechoice.ott.vod.ui.popup.play

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.KeyEvent
import android.view.LayoutInflater
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogPlaySeriesExitBinding
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.ui.popup.PopupEvent
import kotlinx.android.synthetic.main.dialog_play_exit.*

class SeriesExitPopupView : Dialog {
    private var binding: DialogPlaySeriesExitBinding
    private var model: SeriesExitPopupModel
    private var popupEvent: PopupEvent

    constructor(
        title: String,
        posterUrl: String,
        ctx: Context,
        event: PopupEvent
    ) : super(ctx, R.style.Theme_Design_NoActionBar) {
        binding = DialogPlaySeriesExitBinding.inflate(LayoutInflater.from(ctx))
        popupEvent = event
        model = SeriesExitPopupModel()
        init()
        addClickEvent()
        model.posterUrl.value = posterUrl
        model.title.value = title
        btn_ok.requestFocus()

        setOnKeyListener { _, keyCode, kEvent ->
            var result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        event.onClick(this, BtnLabel.CANCEL)
                        result = true
                    }
                }
            }
            result
        }
    }

    private fun addClickEvent() {
        btn_ok.setOnClickListener { this.popupEvent.onClick(this, btn_ok.text.toString()) }
        btn_cancel.setOnClickListener { this.popupEvent.onClick(this, btn_cancel.text.toString()) }
    }

    private fun init() {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        binding.apply {
            viewModel = model
        }
        setContentView(binding.root)
    }


}