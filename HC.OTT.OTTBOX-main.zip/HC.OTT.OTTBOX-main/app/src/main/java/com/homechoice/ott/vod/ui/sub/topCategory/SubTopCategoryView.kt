package com.homechoice.ott.vod.ui.sub.topCategory

import android.content.Context
import android.graphics.Color
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.CustomColor
import com.homechoice.ott.vod.util.Logger

class SubTopCategoryView : LinearLayout {
    private lateinit var categoryTextView: TextView
    private lateinit var categoryBottomLine: LinearLayout

    constructor(ctx: Context) : super(ctx) {
        val view =
            LayoutInflater.from(ctx).inflate(R.layout.sub_top_category_list_item, this, false)
        view.visibility = View.INVISIBLE
        addView(view)
    }

    constructor(ctx: Context, categoryName: String) : super(ctx) {
        init(ctx, categoryName)
    }

    private fun init(ctx: Context, categoryName: String) {
        val view =
            LayoutInflater.from(ctx).inflate(R.layout.sub_top_category_list_item, this, false)
        categoryTextView = view.findViewById(R.id.sub_top_category_name_text_view)
        categoryBottomLine = view.findViewById(R.id.sub_top_category_bottom_line)
        categoryTextView.text = categoryName

        addView(view)
    }


    fun focus() {
        Logger.Log(Log.INFO, this, "focus")
        categoryTextView.setTextColor(CustomColor.CATEGORY_TEXT_FOCUS.rgb())
        categoryTextView.setTextSize(
            TypedValue.COMPLEX_UNIT_PX,
            CMBApp.RES.getDimension(R.dimen.sub_top_category_name_text_view_focus_font_size)!!
        )
        categoryBottomLine.setBackgroundColor(CustomColor.CATEGORY_TEXT_FOCUS.rgb())
        categoryBottomLine.visibility = View.VISIBLE
        categoryTextView.requestFocus()

    }

    fun unfocus() {
        categoryTextView.setTextColor(CustomColor.CATEGORY_TEXT_UNFOCUS.rgb())
        categoryTextView.setTextSize(
            TypedValue.COMPLEX_UNIT_PX,
            CMBApp.RES.getDimension(R.dimen.sub_top_category_name_text_view_unfocus_font_size)!!
        )
        categoryBottomLine.visibility = View.INVISIBLE
    }

    fun selectFocus() {
        categoryTextView.setTextColor(CustomColor.CATEGORY_TEXT_SELECT.rgb())
        categoryTextView.setTextSize(
            TypedValue.COMPLEX_UNIT_PX,
            CMBApp.RES.getDimension(R.dimen.sub_top_category_name_text_view_focus_font_size)!!
        )
        categoryBottomLine.setBackgroundColor(CustomColor.CATEGORY_TEXT_SELECT.rgb())
        categoryBottomLine.visibility = View.VISIBLE
        categoryTextView.clearFocus()
    }

}