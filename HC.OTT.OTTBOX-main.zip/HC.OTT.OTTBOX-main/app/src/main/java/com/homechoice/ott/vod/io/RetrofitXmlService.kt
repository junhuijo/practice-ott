package com.homechoice.ott.vod.io;


import com.homechoice.ott.vod.model.play.Thumbnail
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Url

interface RetrofitXmlService {
    @GET
    fun requestThumbnail(@Url url: String?): Call<Thumbnail>
}
