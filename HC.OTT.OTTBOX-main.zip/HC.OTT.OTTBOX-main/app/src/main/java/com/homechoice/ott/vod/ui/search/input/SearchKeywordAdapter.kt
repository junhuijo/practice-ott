package com.homechoice.ott.vod.ui.search.input

import android.content.Context
import android.os.Handler
import android.os.Message
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.homechoice.ott.vod.databinding.ItemSearchWordListBinding
import com.homechoice.ott.vod.ui.search.SearchActivity
import com.homechoice.ott.vod.util.Logger

class SearchKeywordAdapter(private var items: List<String>, private val eventHandler: Handler) :
    RecyclerView.Adapter<SearchKeywordAdapter.ViewHolder>() {

    private var includeAdult = false

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemSearchWordListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding, parent.context)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.itemSearchKeywordLayout.setOnClickListener {
            Logger.Log(Log.DEBUG, this, "keyword ${items[position]}")
            val msg = Message()
            msg.what = SearchActivity.ActionType.RESULT_UPDATE
            msg.obj = items[position]
            msg.arg1 = if (includeAdult) 1 else 0
            eventHandler.sendMessage(msg)
        }

        holder.binding.itemSearchKeywordLayout.setOnKeyListener { v, keyCode, event ->
            Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        eventHandler.obtainMessage(SearchActivity.ActionType.INPUT_FOCUS).sendToTarget()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN,
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        false
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        eventHandler.obtainMessage(SearchActivity.ActionType.HIDE_KEYWORD).sendToTarget()
                        false
                    }
                    else -> false
                }
            } else
                false
        }

        holder.bindViews(items[position], position)
    }

    fun setIncludeAdult(isAdult: Boolean) {
        includeAdult = isAdult
    }

    override fun getItemCount(): Int {
        return items.size
    }

    fun setItems(keywordList: List<String>) {
        items = keywordList
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: ItemSearchWordListBinding, val ctx: Context) : RecyclerView.ViewHolder(binding.root), UpdateViewHolder {
        override fun bindViews(keyword: String, position: Int) {
            binding.searchKeyword.text = keyword
        }
    }

    private interface UpdateViewHolder {
        fun bindViews(keyword: String, position: Int)
    }

}