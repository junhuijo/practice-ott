package com.homechoice.ott.vod.ui.navigation.view

import androidx.fragment.app.Fragment

abstract class NavigationView2 : Fragment() {

    var isActive = false

    var controller = NavigationController()

    fun setModel(navigationModel: NavigationModel, event: NavigationEvent) {
        controller = NavigationController(
            navigationModel,
            event
        )
    }

    fun setNavigationController(navigationController: NavigationController) {
        controller = navigationController
    }

    fun setEvent(event: NavigationEvent) {
        controller.event = event
    }

    fun setData(newData: NavigationData) {
        controller.setNavigationData(newData)
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    abstract fun onKeyDown(keyCode: Int): Boolean

    abstract fun active()

    abstract fun lateActive()

    abstract fun setVisible(visible: Int)

}