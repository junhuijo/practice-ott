package com.homechoice.ott.vod.ui.detail

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.FrameLayout
import androidx.core.view.get
import androidx.core.view.size
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentDetailBinding
import com.homechoice.ott.vod.event.MBSCallback
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.ResponseContentGroup
import com.homechoice.ott.vod.model.content.Content
import com.homechoice.ott.vod.model.content.ContentGroup
import com.homechoice.ott.vod.model.content.Display
import com.homechoice.ott.vod.model.content.DisplayAddition
import com.homechoice.ott.vod.model.content.Offer
import com.homechoice.ott.vod.model.content.OfferContent
import com.homechoice.ott.vod.model.play.PlayContent
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.model.response.*
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.navigation.navigator.NavigatorModel
import com.homechoice.ott.vod.ui.play.PlayerActivity
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.button_item.view.*
import kotlinx.android.synthetic.main.fragment_detail.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*


class DetailFragment : Fragment() {

    companion object {
        fun newInstance(intent: Intent): DetailFragment {
            val fragment = DetailFragment()
            val bundle = Bundle()
            val contentGroup = intent.getParcelableExtra<ContentGroup>(Name.CONTENT_GROUP)
            bundle.putParcelable(Name.CONTENT_GROUP, contentGroup)
            bundle.putString(Name.ENTER_PATH, intent.getStringExtra(Name.ENTER_PATH))
            fragment.arguments = bundle
            return fragment
        }
    }

    private lateinit var viewModel: DetailViewModel
    private var display: Display? = null
    private lateinit var bind: FragmentDetailBinding
    private var contentGroupId = 0L
    private var enterPath = ""
    private var offerid = 0L

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_detail, container, false)
        return bind.root
    }

    fun isAdultContent(rating: String): Boolean {
        return rating.contains("19")
    }

    fun refreshData() {
        arguments?.let { bundle ->
            val contentGroup = bundle.getParcelable<ContentGroup>(Name.CONTENT_GROUP)
            contentGroup?.let {
                contentGroupId = it.id
                viewModel.checkContentPermission(contentGroupId, offerid)
                updateDetailFragment(contentGroupId, object : UpdateListener {
                    override fun success() {
                        updateButtonStates()
                    }
                })
                getRecommend(contentGroupId, it.isAdult == true)
            }
        }
    }

    private fun updateButtonStates() {
        viewModel.contentGroup?.let { contentGroup ->
            createButton(contentGroup, viewModel.offerList.value ?: emptyList())
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val bundle = arguments
        val contentGroup = bundle?.getParcelable<ContentGroup>(Name.CONTENT_GROUP)
        enterPath = bundle?.getString(Name.ENTER_PATH).toString()

        Logger.Log(Log.ERROR, this, "===================================")
        Logger.Log(Log.ERROR, this, "contentGroup id : ${contentGroup?.id}")
        Logger.Log(Log.ERROR, this, "enterPath : $enterPath")
        Logger.Log(Log.ERROR, this, "===================================")

        contentGroupId = contentGroup?.id!!
        offerid  = contentGroup?.offerContentList.get(0).id
        viewModel = ViewModelProvider(this).get(DetailViewModel::class.java)
        viewModel.display.observe(viewLifecycleOwner) { newDisplay ->
            display = newDisplay
        }


        viewModel.offerList.observe(viewLifecycleOwner) { offerList ->
            offerList?.let { offers ->
                viewModel.contentGroup?.let { contentGroup ->
                    createButton(contentGroup, offers)
                }
            } ?: run {
            }
        }

        viewModel.checkContentPermission(offerid, offerid)

        viewModel.listener = object : DetailViewModelListener {
            override fun select(offerContent: OfferContent) {

                if (!viewModel.isButtonClickable()) return
                viewModel.disableButton()

                if(button_recyclerview.focusedChild.detail_button.text.toString().startsWith("결제")) {

                    Log.d("세부" ,"구매 버튼 클릭 전: offerContent ID = ${offerContent.id}")
                    ActivityChangeAgent.startQrActivity(
                        requireContext(),
                        viewModel.display.value,
                        contentGroupId,
                        enterPath
                    )
                }

                if( button_recyclerview.focusedChild.detail_button.text.toString().startsWith("시청")) {
                    if (STBAgent.isAuth) {
                        if (STBAgent.isAdultAuth || offerContent.contentList[0].rating?.let { isAdultContent(it) } == false) {
                            requestPlayOffset(
                                offerContent.id,
                                offerContent.isPurchase!!,
                                offerContent.contentList[0]
                            )
                        } else {
                            context?.let {
                                ActivityChangeAgent.goToKidsLockMenu(context!!)
                            }
                        }
                    } else {
                        contentGroup?.let {
                            processLogin(it, offerContent, object : LoginProcessListener {
                                override fun playFod(offerContent: OfferContent) {
                                    playContent(offerContent)
                                }
                            })
                        }
                    }
                }
//                if (button_recyclerview.focusedChild.detail_button.text.toString() == BtnLabel.PREVIEW) {
//                    contentGroup?.let { processPreview(it, offerContent, true, false) }
//                }
//                else if (button_recyclerview.focusedChild.detail_button.text.toString() == BtnLabel.TRAILER) {
//                    contentGroup?.let { processPreview(it, offerContent, false, true) }
//                }
                if (button_recyclerview.focusedChild.detail_button.text.toString() == BtnLabel.PACKAGE) {
                    ActivityChangeAgent.goToPackage(context!!, UUID.randomUUID().toString(), offerContent.id, "", object : MBSCallback {
                        override fun success() {
                            updateDetailFragment(contentGroup?.id!!, null)
                        }

                        override fun error(responseCode: Int) {

                        }

                        override fun failure(responseCode: Int) {

                        }
                    })
                }
            }

            override fun select(categoryItem: CategoryItem) {
                when (categoryItem.type) {

                    CategoryItemType.CONTENTGROUP -> goToContent(categoryItem.id, context!!)
                    CategoryItemType.SERIES -> goToSeriesContent(categoryItem.id, context!!)
                    CategoryItemType.PACKAGE_OFFER -> ActivityChangeAgent.goToPackage(
                        context!!,
                        UUID.randomUUID().toString(),
                        categoryItem.id,
                        "",
                        object : MBSCallback {
                            override fun success() {
                                updateDetailFragment(contentGroup?.id!!, null)
                            }

                            override fun error(responseCode: Int) {
                            }

                            override fun failure(responseCode: Int) {
                            }
                        })
                }
            }

            override fun likeFocused() {
                detail_like_focus.requestFocus()
            }

            override fun buttonListFocused(index: Int) {
                button_recyclerview[index].requestFocus()
            }

            override fun recommendFocused(index: Int, isFocus: Boolean) {
                if (isFocus) {
                    recommend_layer?.let { moveUp(it) }
                    recommendFocused(recommend_poster_list[index], true)
                }
                else {
                    recommend_layer?.let { moveDown(it) }
                    recommendFocused(recommend_poster_list[index], false)
                }
            }

            override fun update() {
                setFlags()
            }

            override fun like(content: Content, isLike: Boolean) {
                if (viewModel.isAdultContent.value == true) {
                    return
                }
                Logger.Log(Log.ERROR, this, "like click $isLike")

                if (STBAgent.isAuth) {
                    if (isAdultContent(content.rating ?: "")) {
                        if (STBAgent.includeRrated) {
                            processLike(content, isLike)
                        } else {
                            context?.let { ActivityChangeAgent.goToKidsLockMenu(it) }
                        }
                    } else {
                        processLike(content, isLike)
                    }
                } else {
                    handleUnauthenticatedUser(content, isLike)
                }
            }

            private fun processLike(content: Content, isLike: Boolean) {
                val actionType: String = if (isLike) "add" else "del"
                contentGroup?.let { it1 ->
                    MBSAgent.wishItem(
                        content.id,
                        actionType,
                        targetId = it1.id,
                        targetType = Name.CONTENT_GROUP,
                        callback = object : Callback<ResponseNoBody> {
                            override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                                if (response.isSuccessful) {
                                    handleSuccessfulLike(isLike, content)
                                } else {
                                    handleUnsuccessfulLike(content, isLike, response)
                                }
                            }

                            override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                                UIAgent.showPopup(context!!, CODE.NONE, null)
                            }
                        })
                }
            }
            //'좋아요' 동작이 성공했을 때 팝업창 호출
            private fun handleSuccessfulLike(isLike: Boolean, content: Content) {
                if (isLike) {
                    PopupAgent.showOneLineNoBtn(
                        context!!,
                        PopupType.NormalPopupType.REG_ZZIM,
                        object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                updateLikeStatus(isLike, content)
                            }
                        })
                } else {
                    updateLikeStatus(isLike, content)
                }
            }
            //'좋아요' 상태를 업데이트
            private fun updateLikeStatus(isLike: Boolean, content: Content) {
                viewModel.isLike.value = isLike
                content.isWish = isLike
            }

            //, '좋아요' 요청이 실패했을 때 특정 동작을 처리하는 함수
            private fun handleUnsuccessfulLike(content: Content, isLike: Boolean, response: Response<ResponseNoBody>) {
                UIAgent.showPopup(context!!, response.code(), object : RetryCallback {
                    override fun call() {
                        like(content, isLike)
                    }

                    override fun cancel() {
                    }
                })
            }

            //인증되지 않은 사용자가 '좋아요' 버튼을 눌렀을 때, 로그인 팝업을 표시하고 로그인 성공 시 '좋아요' 동작을 처리
            private fun handleUnauthenticatedUser(content: Content, isLike: Boolean) {
                context?.let {
                    PopupAgent.showLoginPopup(it, Login(isAdult = content.isAdult!!, loginqr = null), object : LoginPopupEvent {
                        override fun onLogin(loginDialog: Dialog, btn: String) {
                            when (btn) {
                                BtnLabel.SUCCESS -> {
                                    processLike(content, isLike)
                                    contentGroup?.let { it1 ->
                                        updateDetailFragment(it1.id, object : UpdateListener {
                                            override fun success() {
                                            }
                                        })
                                    }
                                }
                                BtnLabel.CANCEL -> {
                                    loginDialog.dismiss()
                                }
                            }
                        }
                    })
                }
            }
        }

        bind.viewModel = viewModel
        bind.lifecycleOwner = this

        contentGroup.let {
            update(it)
            setFlags()
            getRecommend(contentGroupId = it.id, includeAdult = contentGroup.isAdult == true)
        }

        updateLikeButtonVisibility()

    }

    // OfferContent 객체를 받아서 해당 콘텐츠를 재생
    fun playContent(offerContent: OfferContent) {
        val offerContentId = offerContent.id
        val contentGroup = viewModel.contentGroup
        contentGroup?.let { it1 ->
            findOfferPlay(offerContentId, offerContent.isPurchase!!, it1)
        }
    }
    //로그인 과정 후에 수행할 동작
    private interface LoginProcessListener {
        fun playFod(offerContent: OfferContent)
    }

    // 사용자가 로그인하도록 처리하고 로그인 성공 후 콘텐츠를 재생하거나 다른 동작을 수행하는 로직
    private fun processLogin(contentGroup: ContentGroup, offerContent: OfferContent, callback: LoginProcessListener) {
        context?.let {
            val content = offerContent.contentList[0]
            PopupAgent.showLoginPopup(context!!, Login(isAdult = content.isAdult!!, loginqr = null), object : LoginPopupEvent {
                override fun onLogin(loginDialog: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.SUCCESS -> {
                            if (contentGroup != null) {
                                updateDetailFragment(contentGroup.id, object : UpdateListener {
                                    override fun success() {
                                        if (content.isAdult == true || content.rating?.let { it1 -> isAdultContent(it1) } == true) {
                                            context?.let {
                                                if (STBAgent.includeRrated) {
                                                    if (offerContent.price == 0) {
                                                        callback.playFod(offerContent)
                                                    } else { //현재 구매 콘텐츠 없음
                                                    }
                                                } else {
                                                    ActivityChangeAgent.goToKidsLockMenu(context!!)
                                                }
                                            }
                                        }
                                        else {
                                            if (offerContent.price == 0) {
                                                callback.playFod(offerContent)
                                            }
                                        }
                                    }
                                })
                            }
                        }
                        BtnLabel.CANCEL -> {
                            loginDialog.dismiss()
                        }
                    }
                }
            })
        }
    }

    interface UpdateListener {
        fun success()
    }

    private fun updateDetailFragment(id: Long, callback: UpdateListener?) {
        MBSAgent.getContentGroup(
            contentGroupId = id,
            transcodingType = "dash",
            drmType = "widevine",
            callback = object : Callback<ResponseContentGroup> {
                override fun onResponse(call: Call<ResponseContentGroup>, res: Response<ResponseContentGroup>) {
                    if (res.isSuccessful && res.body() != null) {
                        val response = res.body()!!
                        when (response.sessionState) {
                            SessionState.FORCE_LOGOUT -> {
                                UIAgent.showPopup(context!!, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                        updateDetailFragment(id, callback)
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                response.contentGroup.let { contentGroup ->
                                    update(contentGroup)
                                    setFlags()
                                    updateLikeButtonVisibility()
                                }
                                callback?.success()
                            }
                        }
                    } else {
                        UIAgent.showPopup(context!!, res.code(), null)
                    }
                }

                override fun onFailure(call: Call<ResponseContentGroup>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, t.message.orEmpty())
                    UIAgent.showPopup(context!!, CODE.NONE, null)
                }
            })
    }

    private fun findOfferPlay(offerContentId: Long, isPurchase: Boolean, contentGroup: ContentGroup) {
        contentGroup.offerContentList.find { oc -> oc.id == offerContentId }
            ?.let {
                if (it.price == 0)
                    requestPlayOffset(it.id, isPurchase, it.contentList[0])
            }
    }

    private fun update(contentGroup: ContentGroup) {
        val offerList = contentGroup.offerContentList.sortedBy { it.isPurchase != true }
        if (offerList != null) {
            if (contentGroup != null) {
                ContentGroup( //builder parttern
                    id = contentGroup.id,
                    title = contentGroup.title,
                    isAdult = contentGroup.isAdult,
                    trailerUrl = contentGroup.trailerUrl,
                    previewUrl = contentGroup.previewUrl,
                    previewDurationInSec = contentGroup.previewDurationInSec,
                    advUrl = contentGroup.advUrl,
                    offerContentList = offerList
                ).also {
                    viewModel.contentGroup = it
                    if (it.offerContentList != null) {
                        createButton(it)
                    }
                }
            }
        }

    }

    private fun setFlags() {
        Logger.Log(Log.ERROR, this, "display : ${viewModel.display.value}")
        Logger.Log(Log.ERROR, this, "display : ${viewModel.display.value?.isDiscount!!}")
        if (viewModel.display.value?.isDiscount!!)
            bind.price.paintFlags = bind.price.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        else
            bind.price.paintFlags = bind.price.paintFlags and Paint.ANTI_ALIAS_FLAG
        bind.executePendingBindings()
    }

    private fun createButton(contentGroup: ContentGroup, vararg oferrValue: List<Offer>) {
        viewModel.createButton(button_recyclerview, contentGroup = contentGroup, oferrValue = oferrValue)
        val pageSize = 6
        val totalSize = button_recyclerview.size
        NavigatorModel(0, 0, button_recyclerview.size, pageSize = 6, callback = object : NavigatorModel.Callback {
            override fun init(index: Int) {
                buttonFocusChanged(index)
                if (totalSize > pageSize) {
                    val leftIndicator: Boolean = false
                    val rightIndicator: Boolean = 0 != totalSize - 1 - (pageSize - 1)
                    DisplayAddition(leftIndicator, rightIndicator, false).also {
                        viewModel.displayAddition.value = it
                    }
                }
            }

            override fun pageStartIndexChanged() {
            }

            override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
                buttonFocusChanged(index)
                Logger.Log(Log.ERROR, this, "pageStartIndex : $pageStartIndex , currentIndex : $index")

                if (totalSize > pageSize) {
                    val leftIndicator: Boolean = pageStartIndex != 0
                    val rightIndicator: Boolean = pageStartIndex != totalSize - 1 - (pageSize - 1)

                    viewModel.displayAddition.value = DisplayAddition(leftIndicator, rightIndicator, false)
                    DisplayAddition(leftIndicator, rightIndicator, false).also {
                        viewModel.displayAddition.value = it
                    }
                }
            }
        }).also {
            it.isActive = true
            viewModel.buttonListModel = it
        }
    }

    private fun getRecommend(contentGroupId: Long, includeAdult: Boolean) {
        MBSAgent.recommend(srcType = Name.CONTENT_GROUP, srcId = contentGroupId, includeAdult = false, includeRrated = STBAgent.includeRrated,
            startIdx = 0, pageSize = 7, callback = object : Callback<ResponseCategoryItemList> {
                override fun onResponse(
                    call: Call<ResponseCategoryItemList>,
                    res: Response<ResponseCategoryItemList>
                ) {
                    if (res.isSuccessful && res.body() != null) {
                        val body = res.body()
                        val categoryItemList = body?.categoryItemList
                        val filteredList = categoryItemList?.filter { it.type == "contentGroup" }
                        if (filteredList != null && filteredList.isNotEmpty()) {
                            viewModel.categoryItemList = filteredList
                            viewModel.createRecommend(filteredList)
                            viewModel.recommendListModel =
                                NavigatorModel(
                                    0,
                                    0,
                                    filteredList.size,
                                    7,
                                    callback = object : NavigatorModel.Callback {
                                        override fun init(index: Int) {
                                        }

                                        override fun pageStartIndexChanged() {
                                        }

                                        override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
                                            recommendFocused(recommend_poster_list[previousIndex], false)
                                            recommendFocused(recommend_poster_list[index], true)
                                        }
                                    })
                        }
                        else {
                            recommend_info.text = "추천 콘텐츠를 준비 중입니다. 다른 영상을 탐색해보세요."
                        }
                    }
                    else {
                        recommend_info.text = "추천 콘텐츠를 준비 중입니다. 다른 영상을 탐색해보세요."
                    }
                }

                override fun onFailure(call: Call<ResponseCategoryItemList>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, t.localizedMessage)
                    recommend_info.text = "추천 콘텐츠를 준비 중입니다. 다른 영상을 탐색해보세요."
                }

            })
    }

    private fun recommendFocused(view: View, isFocus: Boolean) {
        when {
            isFocus -> {
                view.requestFocus()
                AnimationUtils.loadAnimation(context, R.anim.anim_detail_recommend_scale_up).also {
                    it.fillAfter = true
                    view.startAnimation(it)
                }
            }
            else -> {
                AnimationUtils.loadAnimation(context, R.anim.anim_detail_recommend_scale_down).also {
                    it.fillAfter = true
                    view.startAnimation(it)
                }
            }
        }
    }

    private fun buttonFocusChanged(index: Int) {
        if (button_recyclerview.size > 0)
            button_recyclerview[index].requestFocus()
    }

    private fun requestPlayOffset(offerContentId: Long, isPurchase: Boolean, content: Content) {
        MBSAgent.playOffset(content.id,
            object : Callback<ResponsePlayOffset> {
                override fun onFailure(call: Call<ResponsePlayOffset>, t: Throwable) {
                    UIAgent.showPopup(context!!, CODE.NONE, null)
                }

                override fun onResponse(call: Call<ResponsePlayOffset>, res: Response<ResponsePlayOffset>) {
                    if (res.isSuccessful && res.body() != null) {
                        val playOffset: ResponsePlayOffset? = res.body()

                        if (playOffset?.offset != null && playOffset.offset > 0) {
                            PopupAgent.showContinuePopup(context!!, object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    d.dismiss()
                                    when (btn) {
                                        BtnLabel.CONTINUE -> {
                                            play(offerContentId, isPurchase, content, playOffset.offset)
                                        }
                                        BtnLabel.FIRST -> {
                                            play(offerContentId, isPurchase, content, 0)
                                        }
                                    }
                                }
                            })
                        }
                        else {
                            play(offerContentId, isPurchase, content, 0)
                        }
                    } else {
                        UIAgent.showPopup(context!!, res.code(), object : RetryCallback {
                            override fun call() {
                                if(content.genre == "성인"){
                                    context?.let {
                                        ActivityChangeAgent.goToContent(
                                            it,
                                            contentGroupId,
                                            enterPath,
                                            null
                                        )
                                    }

                                }else{
                                    requestPlayOffset(offerContentId, isPurchase, content)
                                }
                            }

                            override fun cancel() {
                            }
                        })
                    }
                }
            })
    }

    private fun parseContentId(movieUrl: String?): String {
        val contentIdStr: String
        val dotIndex = movieUrl.toString().lastIndexOf(".");
        if (dotIndex < 0)
            return movieUrl.toString()
        if (movieUrl.toString().lastIndexOf("/") > 0) {
            contentIdStr = movieUrl.toString().substring(movieUrl.toString().lastIndexOf("/") + 1, dotIndex);
        }
        else {
            contentIdStr = movieUrl.toString().substring(0, dotIndex);
        }
        return contentIdStr
    }

    private fun play(offerContentId: Long, isPurchase: Boolean, content: Content, offset: Int) {
        Logger.Log(Log.DEBUG, this, "play ${content.movieUrl} / isPurchase $isPurchase")
        val contentIdStr = parseContentId(content.movieUrl)
        MBSAgent.getDrmToken(MBSAgent.terminalKey, contentIdStr, object : Callback<ResponseDrmToken> {
            override fun onResponse(call: Call<ResponseDrmToken>, response: Response<ResponseDrmToken>) {
                val drmToken = response.body();
                val intent = Intent(context, PlayerActivity::class.java)
                val playContent = PlayContent(
                    id = content.id, //TODO: contentId  static으로 들어있음
                    title = content.title ?: "",
                    movieUrl = content.movieUrl ?: "",
                    genre = content.genre ?: "",
                    thumbnailUrl = content.thumbnailUrl ?: "",
                    thumbnailServerInfo = content.thumbnailServerInfo ?: "",
                    offset = offset,
                    advUrl = content.advUrl ?: "",
                    offerId = offerContentId,
                    isPurchase = isPurchase,
                    rating = content.rating!!,
                    enterPath = enterPath,
                    drmToken = drmToken?.drmToken!!
                )
                intent.putExtra("content", playContent)
                startActivity(intent)
            }

            override fun onFailure(call: Call<ResponseDrmToken>, t: Throwable) {
            }
        })
    }

    private fun previewPlay(contentGroup: ContentGroup, content: Content, isPreview: Boolean, isTrailer: Boolean) {
        var url = contentGroup.previewUrl
        if (isTrailer)
            url = contentGroup.trailerUrl

        val contentIdStr = parseContentId(content.movieUrl)
        MBSAgent.getDrmToken(MBSAgent.terminalKey, contentIdStr, object : Callback<ResponseDrmToken> {
            override fun onResponse(call: Call<ResponseDrmToken>, response: Response<ResponseDrmToken>) {
                val drmToken = response.body();
                val playContent = PlayContent(
                    id = content.id, //TODO: contentId  static으로 들어있음
                    title = contentGroup.title ?: "",
                    movieUrl = url ?: "",
                    genre = content.genre ?: "",
                    thumbnailUrl = content.thumbnailUrl ?: "",
                    thumbnailServerInfo = content.thumbnailServerInfo ?: "",
                    offset = 0,
                    advUrl = contentGroup.advUrl ?: "",
                    isTrailer = isTrailer,
                    isPreview = isPreview,
                    isPurchase = false,
                    rating = content.rating!!,
                    previewDurationInSec = contentGroup.previewDurationInSec!!,
                    drmToken = drmToken?.drmToken!!
                )
                play(playContent)
            }

            override fun onFailure(call: Call<ResponseDrmToken>, t: Throwable) {
            }
        })
    }

    private fun play(playContent: PlayContent) {
        val intent = Intent(context, PlayerActivity::class.java)
        intent.putExtra("content", playContent)
        startActivity(intent)
    }

    /**
     * @Deprecated
     *  */
    private fun requestNavigator(assetType: String, assetId: Long, enterPath: String) {
        MBSAgent.navigation(
            assetType = assetType,
            assetId = assetId,
            enterPath = enterPath,
            callback = object : Callback<ResponseNoBody> {
                override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                    // 403 확인하지 않음
                }

                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                }

            })
    }

    fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        var result = false
        if (event != null) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        viewModel.up()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        viewModel.down()
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        viewModel.right()
                        result = true

                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        viewModel.left()
                        result = true

                    }
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER -> {
                        viewModel.enter()
                        result = true
                    }
                }
            }
        }
        return result
    }

    private fun goToContent(id: Long, context: Context) {
        ActivityChangeAgent.goToContent(context, id, UIAgent.createEnterPath(EnterPath.RECOMMEND, contentGroupId), object : MBSCallback {
            override fun success() {

            }

            override fun error(responseCode: Int) {
            }

            override fun failure(responseCode: Int) {
            }
        })
    }

    private fun goToSeriesContent(id: Long, context: Context) {
        ActivityChangeAgent.goToSeriesContent(id, 0, context, UIAgent.createEnterPath(EnterPath.RECOMMEND, contentGroupId), object : MBSCallback {
            override fun success() {
//                activity?.finish()
            }

            override fun error(responseCode: Int) {
            }

            override fun failure(responseCode: Int) {
            }
        })
    }

    fun moveDown(view: View) {
        AnimationUtils.loadAnimation(context, R.anim.anim_detail_scale_down).also {
            it.fillAfter = true
            view.startAnimation(it)
        }
    }

    fun moveUp(view: View) {
        AnimationUtils.loadAnimation(context, R.anim.anim_detail_scale_up).also {
            it.fillAfter = true
            view.startAnimation(it)
        }
    }

    private fun updateLikeButtonVisibility() {
        val contentGroup = viewModel.contentGroup
        val isAdultGenre = contentGroup?.offerContentList?.firstOrNull()?.contentList?.firstOrNull()?.genre == "성인"

        view?.findViewById<FrameLayout>(R.id.detail_like_focus)?.visibility =
            if (isAdultGenre) View.GONE else View.VISIBLE
    }
}