package com.homechoice.ott.vod.ui.my.point

import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.CategoryTarget
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentPointProductListBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.point.PointProduct
import com.homechoice.ott.vod.model.popup.Phone
import com.homechoice.ott.vod.model.response.ResponseCardName
import com.homechoice.ott.vod.model.response.ResponsePoint
import com.homechoice.ott.vod.model.response.ResponsePointProductList
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.popup.PopupType.Label
import com.homechoice.ott.vod.ui.navigation.list.NavigationListData
import com.homechoice.ott.vod.ui.navigation.list.NavigationListEvent
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.point.PurchasePointPopupView
import com.homechoice.ott.vod.ui.popup.purchase.RegCardPopupView
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_point_product_list.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class PointProductListFragment(private val activityHandler: Handler, val categoryTarget: String) : NavigationListView() {

    private lateinit var adapter: PointProductListAdapter
    private lateinit var viewHolder: PointProductListAdapter.ViewHolder
    private lateinit var bind: FragmentPointProductListBinding
    private var logList: ArrayList<PointProduct> = arrayListOf()

    var head = UIAgent.createLoginHead(categoryTarget)
    var description: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_point_product_list, container, false)
        bind.frg = this
        bind.lifecycleOwner = this
        description = UIAgent.createLoginTitle(categoryTarget)

        requestPointProductList()

        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requestPointBalance()

        Logger.Log(Log.DEBUG, this, "STBAgent.hasPayment ${STBAgent.hasPayment}")

        if (STBAgent.hasPayment) {
            register_button.visibility = View.INVISIBLE
        } else {
            register_button.visibility = View.VISIBLE
        }
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume")
    }

    fun getPointBalance(): Int {
        return STBAgent.pointBalance
    }

    fun getPoint(): String {
        return String.format("%,d", STBAgent.pointBalance)
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "ServiceLogListFragment onKeyDown keyCode $keyCode")
        if (!::viewHolder.isInitialized) {
            return false
        }
        if (!STBAgent.enableKeyInput(150L)) {
            return true
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (register_button.isSelected) {
                    register_button.isSelected = false
                    register_button.clearFocus()
                    adapter.focus(controller.getCurIndex(), controller.getPreIndex())
                    true
                } else {
                    controller.decrease()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (register_button.isSelected) {
                    true
                } else {
                    if (controller.isLastItem()) {
                        if (!STBAgent.hasPayment) {
                            adapter.unfocus(controller.getCurIndex())
                            register_button.requestFocus()
                            register_button.isSelected = true
                        }
                    } else {
                        controller.increase()
                    }
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                !viewHolder.binding.itemWishListLayout.isSelected
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                register_button.isSelected = false
                adapter.unfocus(controller.getCurIndex())
                activityHandler.obtainMessage(2).sendToTarget()
                true

            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                if (register_button.isSelected) {
                    context?.let {
                        RegCardPopupView(it, Phone(
                            head = "카드 등록하기", body = "간편 결제를 하기 위해서\n" +
                                    "카드 정보를 등록해야 합니다.\n" +
                                    "간편 결제 카드 등록을 위해\n" +
                                    "휴대폰 번호를 입력해 주세요."
                        ), object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                /**
                                 * 카드등록 후 다시 로그인을 해야 함.
                                 *
                                 * ID/PW 저장해도 문제는 없는가?
                                 * */
                                d.dismiss()
                            }

                        })
                    }
                } else {
                    selectItem()
                }
                true
            }

            KeyEvent.KEYCODE_BACK, 97 -> {
                register_button.isSelected = false
                adapter.unfocus(controller.getCurIndex())
                activityHandler.obtainMessage(2).sendToTarget()

                true
            }
            else -> false
        }
    }

    private fun selectItem() {
        val pointProduct = viewHolder.pointProduct
        /**
         * TODO: 선택했을때 처리 추가
         */
        context?.let {
            if (true) { //STBAgent.isAuth) {
                getCardInfo(object : CardInfoCallback {
                    override fun sucess() {
                        PurchasePointPopupView(ctx = it, pointProduct = pointProduct, event = object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                bind.invalidateAll()
                                d.dismiss()
                            }
                        })
                    }
                })
            }
        }
    }

    private fun getCardInfo(callback: CardInfoCallback) {
        MBSAgent.getCard(object : Callback<ResponseCardName> {
            override fun onFailure(call: Call<ResponseCardName>, t: Throwable) {
                Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
            }

            override fun onResponse(call: Call<ResponseCardName>, response: Response<ResponseCardName>) {
                Logger.Log(Log.DEBUG, this, "onResponse")
                if (response.isSuccessful && response.body() != null) {
                    val cardName = response.body()!!.cardName
                    STBAgent.cardName = cardName ?: ""
                    if (cardName != "") {
                        callback.sucess()
                    } else {
                        context?.let {
                            PopupAgent.showNormalPopup(
                                it,
                                PopupType.NormalPopupType.CARD_REGISTER,
                                object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        if (btn == Label.REG_CARD.label) {
                                            RegCardPopupView(it, Phone(
                                                head = "카드 등록하기", body = "간편 결제를 하기 위해서\n" +
                                                        "카드 정보를 등록해야 합니다.\n" +
                                                        "간편 결제 카드 등록을 위해\n" +
                                                        "휴대폰 번호를 입력해 주세요."
                                            ), object : PopupEvent {
                                                override fun onClick(d: Dialog, btn: String) {
                                                    d.dismiss()
                                                }

                                            })
                                        } else {

                                        }
                                        d.dismiss()

                                    }
                                })
                        }
                    }
                } else {
                    when (response.code()) {
                        CODE.CONFLICT -> {
                            context?.let {
                                UIAgent.showPopup(it, response.code(), object : RetryCallback {
                                    override fun call() {
                                        getCardInfo(callback)
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                        }
                        else -> {
                        }
                    }
                }
            }
        })
    }

    interface CardInfoCallback {
        fun sucess()
    }

    override fun active() {
        focus()
    }

    private fun requestPointProductList() {
        GlobalScope.launch(Dispatchers.Main) {
            /**
             * 409 return api
             * */
            MBSAgent.pointProductList(
                startIdx = 1,
                pageSize = 0,
                transactionId = UUID.randomUUID().toString(),
                callback = object : Callback<ResponsePointProductList> {
                    override fun onFailure(call: Call<ResponsePointProductList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
                    }

                    override fun onResponse(call: Call<ResponsePointProductList>, res: Response<ResponsePointProductList>) {
                        if (res.isSuccessful && res.body() != null) {
                            val response = res.body()
                            if (response != null) {
                                val productList = response.productList
                                val totalCount = response.totalCount

                                if (totalCount > 0) {
                                    val actionHandler = Handler {
                                        Logger.Log(Log.DEBUG, this, "actionHandler ${it.what}")
                                        when (it.what) {
                                            0 -> {
                                                viewHolder = it.obj as PointProductListAdapter.ViewHolder
                                            }
                                        }
                                        true
                                    }

                                    logList.clear()
                                    for (item in productList) {
                                        logList.add(item)
                                    }
                                    adapter = PointProductListAdapter(bind.logList!!, logList, actionHandler)

                                    setModel(
                                        NavigationListData(
                                            curIndex = 0,
                                            visibleThreshold = 4
                                        ).build(productList), object : NavigationListEvent {
                                            override fun focusChange() {
                                                Logger.Log(Log.DEBUG, this, "focusChange")
                                                adapter.focus(controller.getCurIndex(), controller.getPreIndex())
                                                //checkArrow()
                                            }

                                            override fun plusLineChange() {
                                                Logger.Log(Log.DEBUG, this, "plusLineChange")
                                                if (controller.getCurIndex() == controller.getTotalCount() - 1) {
                                                    log_list_scroll_view.smoothScrollBy(
                                                        0,
                                                        CMBApp.getPixelSize(R.dimen.my_point_product_last_height)
                                                    )
                                                } else {
                                                    log_list_scroll_view.smoothScrollBy(
                                                        0,
                                                        CMBApp.getPixelSize(R.dimen.my_point_product_height)
                                                    )
                                                }
                                            }

                                            override fun minusLineChange() {
                                                Logger.Log(Log.DEBUG, this, "minusLineChange")

                                                log_list_scroll_view.smoothScrollBy(
                                                    0,
                                                    -CMBApp.getPixelSize(R.dimen.my_point_product_height)
                                                )

                                            }
                                        })

                                    log_list_layout?.visibility = View.VISIBLE
                                    //checkArrow()
                                    activityHandler.obtainMessage(11).sendToTarget()
                                    if (isLateActive) {
                                        active()
                                    }
                                } else {
                                    log_list_empty_layout?.visibility = View.VISIBLE
                                    activityHandler.obtainMessage(2).sendToTarget()
                                }
                            } else {
                                log_list_empty_layout?.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()

                            }
                        } else {
                            UIAgent.showPopupForMyMenu(context!!, res.code(), object : RetryCallback {
                                override fun call() {
                                    activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                    activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                }

                                override fun cancel() {
                                    activityHandler.obtainMessage(12).sendToTarget()
                                }
                            })
                        }
                    }
                })
        }
    }

    private fun requestPointBalance() {
        MBSAgent.pointBalance(object : Callback<ResponsePoint> {
            override fun onResponse(call: Call<ResponsePoint>, response: Response<ResponsePoint>) {
                if (response.isSuccessful && response.body() != null) {
                    STBAgent.pointBalance = response.body()!!.point
                    bind.invalidateAll()
                }
            }

            override fun onFailure(call: Call<ResponsePoint>, t: Throwable) {
                STBAgent.pointBalance = -1
            }

        })
    }

    private fun isEnable(): Boolean {
        return bind.logListLayout.isVisible
    }

    fun focus() {
        if (isEnable()) {
            adapter.focus(controller.getCurIndex(), controller.getPreIndex())
        } else {
            activityHandler.obtainMessage(2).sendToTarget()
        }
    }

    var isLateActive: Boolean = false

    override fun lateActive() {
        isLateActive = true
    }

    override fun setVisible(visible: Int) {
        bind.root.visibility = visible
    }

}