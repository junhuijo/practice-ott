package com.homechoice.ott.vod.ui.navigation.view

import android.util.Log
import com.homechoice.ott.vod.util.Logger

class NavigationModel(
    var data: NavigationData
) {
    init {
        Logger.Log(Log.INFO, this, " ${data.toString()}")
    }

    fun addModel(addList: List<Any>) {
        for (item in addList) {
            data.list.add(item)
        }
        data.totalIndex = data.totalIndex + addList.size
    }
}