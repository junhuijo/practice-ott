package com.homechoice.ott.vod.ui.my.member

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.view.get
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.LoginEvent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.databinding.FragmentMyMemberLoginBinding
import com.homechoice.ott.vod.model.popup.Phone
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.my.member.MemberLoginViewModel.FocusType
import com.homechoice.ott.vod.ui.my.member.MemberLoginViewModel.ModelListener
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.RegJoinPopupView
import com.homechoice.ott.vod.ui.popup.auth.UserInfoFindPopupView
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_my_member_login.*


class MemberLoginFragment(val activityHandler: Handler) : NavigationView2() {

    private lateinit var bind: FragmentMyMemberLoginBinding
    private lateinit var inputMethodManager: InputMethodManager
    private lateinit var viewModel: MemberLoginViewModel

    private val METHOD: Int = InputMethodManager.SHOW_IMPLICIT
    private var isShowSoftInput = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_my_member_login, container, false)
        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        inputMethodManager = context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        viewModel = ViewModelProvider(this).get(MemberLoginViewModel::class.java)

        my_login_id_input.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_NEXT) {
                my_login_password_input.requestFocus()
                isShowSoftInput = true
                viewModel.focusType = FocusType.PASSWORD
                true
            } else {
                false
            }
        }

        my_login_password_input.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_NEXT) {
                inputMethodManager.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
                my_login_password_input.clearFocus()
                keep_login_checkbox.requestFocus()
                isShowSoftInput = false
                viewModel.focusType = FocusType.KEEP_LOGGED_IN
                true
            } else {
                false
            }
        }

        viewModel.setModelListener(object : ModelListener {
            override fun focused(focusType: FocusType) {
                Logger.Log(Log.DEBUG, this, "focused $focusType")
                isShowSoftInput = false
                when (focusType) {
                    FocusType.ID -> {
                        my_login_id_input.requestFocus()
                    }

                    FocusType.PASSWORD -> {
                        my_login_password_input.requestFocus()

                    }
                    FocusType.BUTTON -> {
                        login_button_layer.requestFocus()
                    }
                    FocusType.JOIN -> {
                        join_button.requestFocus()
                    }
                    FocusType.KEEP_LOGGED_IN -> {
                        keep_login_checkbox.requestFocus()
                    }
                }
            }

            override fun buttonFocused(index: Int) {
                login_button_layer[index].requestFocus()
            }

            override fun select(focusType: FocusType, index: Int) {
                Logger.Log(Log.DEBUG, this, "select $focusType")
                Logger.Log(Log.DEBUG, this, "isSelected ${keep_login_checkbox.isSelected}")
                when (focusType) {
                    FocusType.KEEP_LOGGED_IN -> {
                        (!keep_login_checkbox.isSelected).also { keep_login_checkbox.isSelected = it }
                    }
                    FocusType.ID -> {
                        inputMethodManager.showSoftInput(my_login_id_input, 0)
                        isShowSoftInput = true
                    }
                    FocusType.PASSWORD -> {
                        inputMethodManager.showSoftInput(my_login_password_input, 0)
                        isShowSoftInput = true
                    }
                    FocusType.JOIN -> {
                        RegJoinPopupView(
                            context!!, Phone(head = "회원가입하기", body = "홈초이스의 콘텐츠를 시청하기 \n위해서는 회원가입이 필요합니다.\n회원가입을 위해 휴대폰 번호를\n입력해 주세요."),
                            event = object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    d.dismiss()
                                }
                            })
                    }
                    FocusType.BUTTON -> {
                        when (index) {
                            0 -> { //확인
                                val memberId = my_login_id_input.text.toString()
                                val memberPw = my_login_password_input.text.toString()
                                login(memberId, memberPw)
                            }
                            1 -> { //아이디 비빌번호 찾기
                                UserInfoFindPopupView(
                                    context!!, Phone(head = "아이디/비밀번호 찾기", body = "아이디/비밀번호를 찾기 위해 가입 시 \n등록한 휴대폰 번호를 입력해 주세요.\n \n "),
                                    event = object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            d.dismiss()
                                        }
                                    })
                            }
                        }
                    }
                }
            }

            override fun back(focusType: FocusType) {
                Logger.Log(Log.DEBUG, this, "focusType:${focusType}")
                isShowSoftInput = false
                activityHandler.obtainMessage(2).sendToTarget()
                view.clearFocus()
                when (focusType) {
                    FocusType.ID -> {
                        Logger.Log(Log.DEBUG, this, "clearFocus / focusType:${focusType}")
                        my_login_id_input.clearFocus()
                    }

                    FocusType.PASSWORD -> {
                        my_login_password_input.clearFocus()

                    }
                    FocusType.BUTTON -> {
                        login_button_layer.clearFocus()
                    }
                    FocusType.JOIN -> {
                        join_button.clearFocus()
                    }
                    FocusType.KEEP_LOGGED_IN -> {
                        keep_login_checkbox.clearFocus()
                    }
                }

            }

            override fun hideIME() {
                Logger.Log(Log.DEBUG, this, "hideIME")
                isShowSoftInput = false
            }

        })
        my_login_id_input.setModelListener(viewModel.getModelListener())
        my_login_password_input.setModelListener(viewModel.getModelListener())
        bind.viewModel = viewModel
        bind.lifecycleOwner = this

    }

    private fun showPopup(code: Int, errorStr: String) {
        context?.let {
            PopupAgent.showNormalPopup(
                it,
                PopupType.getErrorType(
                    TYPE.AUTH,
                    code,
                    errorStr
                ),
                object : PopupEvent {
                    override fun onClick(d: Dialog, btn: String) {
                        when (btn) {
                            BtnLabel.OK -> {

                                d.dismiss()
                            }
                        }
                    }
                })
        }
    }

    private fun showPopup(code: Int) {
        context?.let {
            PopupAgent.showNormalPopup(
                it,
                PopupType.getErrorType(
                    TYPE.AUTH,
                    code
                ),
                object : PopupEvent {
                    override fun onClick(d: Dialog, btn: String) {
                        when (btn) {
                            BtnLabel.OK -> {
                                d.dismiss()
                            }
                        }
                    }
                })
        }
    }

    private fun login(memberId: String, memberPw: String) {
        context?.let {
            STBAgent.login(it, memberId, memberPw, keep_login_checkbox.isSelected, false, object : LoginEvent {
                override fun onFailure() {
                    showPopup(CODE.NONE)
                }

                override fun onAccount(isForce: Boolean) {
                    if (isForce) {
                        viewModel.invalidInfo.value = false
                        activityHandler.obtainMessage(7).sendToTarget()
                    }
                }

                override fun onContinue(code: Int) {
                    when (code) {
                        CODE.UNAUTHORIZED -> {
                            viewModel.invalidInfo.value = true
                        }
                        CODE.LOGIN_CANCEL -> {

                        }
                        else -> showPopup(code)
                    }
                }
            })
        }
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        var result = false
        Logger.Log(Log.INFO, this, "onKeyDown $keyCode")
        when (keyCode) {
            KeyEvent.KEYCODE_BACK, 97 -> {
                Logger.Log(Log.ERROR, this, "KEYCODE_BACK")
                if (!isShowSoftInput) {
                    viewModel.back()
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (!isShowSoftInput) {
                    viewModel.up()
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!isShowSoftInput) {
                    viewModel.down()
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (!isShowSoftInput) {
                    viewModel.right()
                    result = true
                }
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (!isShowSoftInput) {
                    viewModel.left()
                    result = true
                }
            }
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_DPAD_CENTER, 96 -> {
                if (!isShowSoftInput) {
                    viewModel.enter()
                    result = true
                }
            }
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_DPAD_CENTER, 96-> {
                result = true
            }
        }
        Logger.Log(Log.INFO, this, "onKeyDown $keyCode / result:$result")
            inputMethodManager.showSoftInput(my_login_password_input,InputMethodManager.SHOW_FORCED)
        return result
    }

    override fun active() {
        TODO("Not yet implemented")
    }


    fun focus() {
        viewModel.init()
        my_login_id_input.requestFocus()
    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        TODO("Not yet implemented")
    }


}