package com.homechoice.ott.vod.event

interface RetryCallback {
    fun call()
    fun cancel()
}