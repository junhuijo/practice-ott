package com.homechoice.ott.vod.model.event

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Event(
    var id : Long = 0,
    var isPushPopup: Boolean? = false,
    var imgUrl : String? = "",
    var popupType : String? = "",
    var popupImgUrl: String? = "",
    var popupTxt : String? = "",
    var linkType : String? = "",
    var linkInfo : String? = ""
) : Parcelable