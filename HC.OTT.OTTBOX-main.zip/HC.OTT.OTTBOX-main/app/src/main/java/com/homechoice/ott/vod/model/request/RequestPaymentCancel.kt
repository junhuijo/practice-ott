package com.homechoice.ott.vod.model.request

data class RequestPaymentCancel (
    val terminalKey: String,
    val purchaseId: Long,
    val paymentPw: String,
    val state:String
)