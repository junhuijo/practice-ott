package com.homechoice.ott.vod.ui.home.myList

import androidx.appcompat.app.AppCompatActivity

class MyListActivity: AppCompatActivity() {

}