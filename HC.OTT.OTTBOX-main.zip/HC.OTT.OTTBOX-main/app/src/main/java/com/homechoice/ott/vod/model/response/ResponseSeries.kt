package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.content.Series
import kotlinx.android.parcel.Parcelize

@Parcelize
class ResponseSeries(
    val errorString: String,
    val sessionState: String = "",
    var series: Series
) : Parcelable
