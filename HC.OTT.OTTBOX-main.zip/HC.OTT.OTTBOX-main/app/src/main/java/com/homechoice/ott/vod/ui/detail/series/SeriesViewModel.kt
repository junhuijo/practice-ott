package com.homechoice.ott.vod.ui.detail.series


import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.agent.ContentType
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.model.content.Content
import com.homechoice.ott.vod.model.content.Series
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.model.response.ResponseNoBody

class SeriesViewModel : ViewModel() {

    private val _series = MutableStateFlow<Series?>(null)
    val series: StateFlow<Series?> = _series.asStateFlow()

    private val _contents = MutableStateFlow<List<Content>>(emptyList())
    val contents: StateFlow<List<Content>> = _contents.asStateFlow()

    private val _currentEpisodeIndex = MutableStateFlow(0)
    val currentEpisodeIndex: StateFlow<Int> = _currentEpisodeIndex.asStateFlow()

    private val _currentEpisode = MutableStateFlow<Content?>(null)
    val currentEpisode: StateFlow<Content?> = _currentEpisode.asStateFlow()

    private val _isLiked = MutableStateFlow(false)
    val isLiked: StateFlow<Boolean> = _isLiked.asStateFlow()

    private val _backgroundColorDetail = MutableStateFlow(Color.Transparent)
    val backgroundColorDetail: StateFlow<Color> = _backgroundColorDetail.asStateFlow()

    private val _backgroundColorLike = MutableStateFlow(Color.Transparent)
    val backgroundColorLike = _backgroundColorLike.asStateFlow()

    private val _backgroundColorPlay = MutableStateFlow(Color.Transparent)
    val backgroundColorPlay = _backgroundColorPlay.asStateFlow()

    private val _episodeNoList = MutableStateFlow<List<Int>>(emptyList())
    private val episodeNoList: StateFlow<List<Int>> = _episodeNoList.asStateFlow()

    fun updateBackgroundColor(type: String, isFocused: Boolean) {
        val color = if (isFocused) Color(0xFFE51A14).copy(0.6f) else Color.Transparent
        when (type) {
            "detail" -> _backgroundColorDetail.value = color
            "like" -> _backgroundColorLike.value = color
            "play" -> _backgroundColorPlay.value = color
        }
    }
    companion object {
        private var instance: SeriesViewModel? = null

        fun getInstance(): SeriesViewModel {
            if (instance == null) {
                instance = SeriesViewModel()
            }
            return instance!!
        }
    }

    fun setSeries(series: Series) {
        _series.value = series
        _contents.value = series.contentList
        _episodeNoList.value = series.episodeNoList
        updateCurrentEpisode()
    }

    fun updateCurrentEpisodeIndex(index: Int) {
        _currentEpisodeIndex.value = index
        updateCurrentEpisode()
    }

    fun updateCurrentEpisode() {
        if(_currentEpisodeIndex.value < _contents.value.size) {
            _currentEpisode.value = _contents.value[_currentEpisodeIndex.value]
            _isLiked.value = _currentEpisode.value?.isWish ?: false
        } else {
            _currentEpisodeIndex.value = 0
            _currentEpisode.value = _contents.value.firstOrNull()
            _isLiked.value = _currentEpisode.value?.isWish ?: false
        }
    }
    
    private fun isAdultContent(rating: String): Boolean {
        return rating.contains(ContentType.ADULT_RATING)
    }

    fun resetCurrentEpisodeIndex() {
        _currentEpisodeIndex.value = 0
        updateCurrentEpisode()
    }

    fun handleLikeAction(content: Content, isLike: Boolean, onAdultContent: () -> Unit, onSuccess: () -> Unit, onLoginRequired: () -> Unit) {
        if (!STBAgent.isAuth) {
            onLoginRequired()
            return
        }

        if (isAdultContent(content.rating ?: "")) {
            if (STBAgent.includeRrated) {
                like(content, isLike) { success ->
                    if (success) onSuccess()
                }
            } else {
                onAdultContent()
            }
        } else {
            like(content, isLike) { success ->
                if (success) onSuccess()
            }
        }
    }

    private fun like(content: Content, isLike: Boolean, callback: (Boolean) -> Unit) {
        if (STBAgent.isAuth) {
            val actionType = if (isLike) "add" else "del"
            content.episodeNo?.let { episodeNo ->
                MBSAgent.wishItem(
                    contentId = content.id,
                    actionType = actionType,
                    targetType = "series",
                    targetId = series.value?.id ?: -1L,
                    episodeNo = episodeNo,
                    callback = object : Callback<ResponseNoBody> {
                        override fun onResponse(
                            call: Call<ResponseNoBody>,
                            response: Response<ResponseNoBody>
                        ) {
                            if (response.isSuccessful) {
                                content.isWish = isLike
                                updateCurrentEpisode()
                                callback(true)
                            } else {
                                callback(false)
                            }
                        }

                        override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                            callback(false)
                        }
                    }
                )
            }
        } else {
            callback(false)
        }
    }

    fun getFormattedEpisodeTitle(title: String?): String {
        if (title == null) return ""
        return title.split(" ").joinToString(" ") { if (it.endsWith("회")) "" else it }
    }

    fun getEpisodeInfo(episode: Content?): AnnotatedString {
        return buildAnnotatedString {
            if (!checkEpisodeOrderDifference() || isAllEpisodesNumberOne()) {
                episode?.let { content ->
                    val episodeNumber = getEpisodeNumber(content)
                    val releaseYear = content.releaseYear ?: ""

                    append(" | ")
                    addStyle(SpanStyle(color = Color(0xFF8F8F8F)), 0, 3)

                    append(releaseYear)
                    addStyle(SpanStyle(color = Color.White), 3, length)

                    if (episodeNumber.isNotEmpty()) {
                        append(" | ")
                        addStyle(SpanStyle(color = Color(0xFF8F8F8F)), length - 3, length)
                        append(episodeNumber)
                        addStyle(SpanStyle(color = Color.White), length - episodeNumber.length, length)
                    }
                }
            } else {
                val index = _contents.value.indexOf(episode)
                if (index != -1 && index < _episodeNoList.value.size) {
                    val episodeNo = _episodeNoList.value[index]
                    val episodeNumber = "${episodeNo}회"
                    val releaseYear = episode?.releaseYear ?: ""

                    append(" | ")
                    addStyle(SpanStyle(color = Color(0xFF8F8F8F)), 0, 3)

                    append(releaseYear)
                    addStyle(SpanStyle(color = Color.White), 3, length)

                    append(" | ")
                    addStyle(SpanStyle(color = Color(0xFF8F8F8F)), length - 3, length)
                    append(episodeNumber)
                    addStyle(SpanStyle(color = Color.White), length - episodeNumber.length, length)
                }
            }
        }
    }

    private fun getEpisodeNumber(content: Content): String {
        val episodeNo = content.episodeNo
        return if (episodeNo != null && episodeNoList.value.contains(episodeNo)) {
            "${episodeNo}회"
        } else {
            ""
        }
    }

    private fun checkEpisodeOrderDifference(): Boolean {
        val contentEpisodeNos = _contents.value.mapNotNull { it.episodeNo }
        val episodeNoListOrder = _episodeNoList.value

        if (contentEpisodeNos.size != episodeNoListOrder.size) {
            return true
        }

        return !contentEpisodeNos.zip(episodeNoListOrder).all { (a, b) -> a == b }
    }
    private fun isAllEpisodesNumberOne(): Boolean {
        return _contents.value.all { it.episodeNo == 1 }
    }
}