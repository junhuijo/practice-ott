package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponsePasswordCheck(
    val transaction_id: String = "",
    val result_code: Int = 0,
    val result_msg: String = "",
    val isActive: Boolean = false
) : Parcelable