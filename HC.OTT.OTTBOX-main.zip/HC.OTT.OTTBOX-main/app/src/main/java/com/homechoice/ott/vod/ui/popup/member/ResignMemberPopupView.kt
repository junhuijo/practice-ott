package com.homechoice.ott.vod.ui.popup.member

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.KeyEvent
import android.view.LayoutInflater
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogResignMemberPopBinding
import com.homechoice.ott.vod.ui.popup.PopupEvent

class ResignMemberPopupView : Dialog {
    private var binding: DialogResignMemberPopBinding

    constructor(
        ctx: Context,
        event: PopupEvent
    ) : super(ctx, R.style.Theme_Design_NoActionBar) {
        binding = DialogResignMemberPopBinding.inflate(LayoutInflater.from(ctx))//DialogDeletePurchaseLogBinding.inflate(LayoutInflater.from(ctx))
        init()
        showNormalPopup(event)
    }

    private fun init() {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        setContentView(binding.root)
    }

    private fun showNormalPopup(
        event: PopupEvent
    ) {
        binding.btnDelete.setOnClickListener {
            event.onClick(this, (it as TextView).text.toString())
        }

        binding.btnCancel.setOnClickListener {
            event.onClick(this, (it as TextView).text.toString())
        }

        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {

                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                        result = true
                    }
                }
            }
            result
        }

        binding.btnDelete.requestFocus()

        show()
    }
}