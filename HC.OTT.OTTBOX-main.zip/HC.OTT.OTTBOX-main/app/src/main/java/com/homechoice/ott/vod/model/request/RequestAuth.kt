package com.homechoice.ott.vod.model.request

data class RequestAuth(
    val appCode: String,
    val deviceType: String,
    val deviceId: String
)
