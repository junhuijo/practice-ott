package com.homechoice.ott.vod.ui.popup.event

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel


class EventPopupModel : ViewModel() {
    var title: MutableLiveData<String> = MutableLiveData()

    var imgUrl: MutableLiveData<String> = MutableLiveData()

    var description : MutableLiveData<String> = MutableLiveData()
}