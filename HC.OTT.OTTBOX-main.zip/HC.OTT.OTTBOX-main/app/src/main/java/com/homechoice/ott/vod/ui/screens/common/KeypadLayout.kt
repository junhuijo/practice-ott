import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.homechoice.ott.vod.R

@Composable
fun KeypadLayout(
    onInputClick: (Char) -> Unit,
    onDeleteClick: () -> Unit,
    onConfirmClick: () -> Unit,
    buttonSpacing: Dp = 22.dp,
    lineSpacing: Dp = 30.dp
) {
    Box(
        modifier = Modifier
            .width(390.dp)
            .height(332.dp)
            .background(color = Color(0xCC454545), shape = RoundedCornerShape(8.dp))
            .border(
                width = 1.dp,
                color = Color(0xFF676767),
                shape = RoundedCornerShape(8.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(lineSpacing)
        ) {
            KeypadGrid(
                buttonSpacing = buttonSpacing,
                onInputClick = onInputClick,
                onDeleteClick = onDeleteClick,
                onConfirmClick = onConfirmClick
            )
        }
    }
}

@Composable
private fun KeypadGrid(
    buttonSpacing: Dp,
    onInputClick: (Char) -> Unit,
    onDeleteClick: () -> Unit,
    onConfirmClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val focusRequesters = remember { List(12) { FocusRequester() } }
    val lifecycleOwner = LocalLifecycleOwner.current

    val buttonTexts = listOf(
        stringResource(R.string.kids_lock_keypad_button_1),
        stringResource(R.string.kids_lock_keypad_button_2),
        stringResource(R.string.kids_lock_keypad_button_3),
        stringResource(R.string.kids_lock_keypad_button_4),
        stringResource(R.string.kids_lock_keypad_button_5),
        stringResource(R.string.kids_lock_keypad_button_6),
        stringResource(R.string.kids_lock_keypad_button_7),
        stringResource(R.string.kids_lock_keypad_button_8),
        stringResource(R.string.kids_lock_keypad_button_9),
        stringResource(R.string.kids_lock_keypad_button_delete),
        stringResource(R.string.kids_lock_keypad_button_0),
        stringResource(R.string.kids_lock_keypad_button_ok),
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(buttonSpacing)
    ) {
        for (rowIndex in 0 until 4) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(buttonSpacing)
            ) {
                for (columnIndex in 0 until 3) {
                    val buttonIndex = rowIndex * 3 + columnIndex
                    val buttonText = buttonTexts.getOrNull(buttonIndex)
                    buttonText?.let { text ->
                        val isSpecialButton = (rowIndex == 3 && (text == stringResource(R.string.kids_lock_keypad_button_delete) || text == stringResource(
                            R.string.kids_lock_keypad_button_ok)))
                        KeypadButton(
                            buttonText = text,
                            buttonIndex = buttonIndex,
                            focusRequesters = focusRequesters,
                            modifier = modifier,
                            isSpecialButton = isSpecialButton,
                            onInputClick = onInputClick,
                            onDeleteClick = onDeleteClick,
                            onConfirmClick = onConfirmClick
                        )
                    }
                }
            }
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                focusRequesters[0].requestFocus()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
}

@Composable
private fun KeypadButton(
    buttonText: String,
    buttonIndex: Int,
    focusRequesters: List<FocusRequester>,
    modifier: Modifier = Modifier,
    isSpecialButton: Boolean = false,
    onInputClick: (Char) -> Unit,
    onDeleteClick: () -> Unit,
    onConfirmClick: () -> Unit
) {
    var borderColor by remember { mutableStateOf(Color(0xFF676767)) }
    val focusRequester = focusRequesters[buttonIndex]

    val context = LocalContext.current
    val deleteBtn = context.getString(R.string.kids_lock_keypad_button_delete)
    val confirmBtn = context.getString(R.string.kids_lock_keypad_button_ok)

    Box(
        modifier = modifier
            .width(102.dp)
            .height(48.dp)
            .background(
                color = colorResource(R.color.kids_lock_keypad_button_background),
                shape = RoundedCornerShape(dimensionResource(R.dimen.icon_corner_radius))
            )
            .border(
                BorderStroke(1.dp, color = borderColor),
                RoundedCornerShape(dimensionResource(R.dimen.icon_corner_radius)),
            )
            .focusRequester(focusRequester)
            .onFocusChanged { focusState ->
                borderColor = if (focusState.hasFocus) {
                    Color(0xFFD22E20)
                } else {
                    Color(0xFF676767)
                }
            }
            .focusable()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                when (buttonText) {
                    deleteBtn -> onDeleteClick()
                    confirmBtn -> onConfirmClick()
                    else -> onInputClick(buttonText.single())
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = buttonText,
            style = TextStyle(
                fontSize = if (isSpecialButton) 22.sp else 30.sp,
                color = colorResource(R.color.kids_lock_text),
                textAlign = TextAlign.Center
            )
        )
    }
}