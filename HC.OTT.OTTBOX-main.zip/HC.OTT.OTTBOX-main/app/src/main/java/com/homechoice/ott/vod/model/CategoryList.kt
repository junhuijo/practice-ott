package com.homechoice.ott.vod.model

import android.os.Parcelable
import com.homechoice.ott.vod.agent.Constant
import com.homechoice.ott.vod.agent.STBAgent
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CategoryList(
    var id: Int = 0,
    var title: String = "",
    var type: String = "",
    var parentId: Int = -1,
    var depth: Int = 0,
    var displayOrder: Int = 0,
    var isAdult: Boolean = false,
    var adultImgUrl: String = "",
    var isVisible: Boolean = false,
    var categoryItemList: List<CategoryItem> = listOf()
) : Parcelable {
    fun build() {
        if (parentId == null) {
            parentId = -1
        }
        if (adultImgUrl == null) {
            adultImgUrl = ""
        }

        if (id == Constant.userCategoryId.toInt()) {
            title = STBAgent.userName + title
        }

        val list: ArrayList<CategoryItem> = arrayListOf()
        for (item in categoryItemList) {
            item.build()
            list.add(item)
        }
        categoryItemList = list
    }
}