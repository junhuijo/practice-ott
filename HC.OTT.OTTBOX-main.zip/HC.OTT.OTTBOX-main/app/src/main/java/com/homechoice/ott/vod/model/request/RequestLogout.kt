package com.homechoice.ott.vod.model.request

data class RequestLogout (
    val terminalKey: String
)