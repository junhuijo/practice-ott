package com.homechoice.ott.vod.model.request

data class RequestServiceLog(
    val terminalKey: String,
    val contentId: Long,
    val isVisible: Boolean
)
