package com.homechoice.ott.vod.ui.my.pay

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentMyAdultPurchaseListBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.purchaseLog.PurchaseLog
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.model.response.ResponsePurchaseLogList
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.ui.navigation.list.NavigationListData
import com.homechoice.ott.vod.ui.navigation.list.NavigationListEvent
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.pay.DeletePurchaseLogPopupView
import com.homechoice.ott.vod.ui.popup.pay.UnSubscriptionPopupView
import com.homechoice.ott.vod.util.Logger
import com.homechoice.ott.vod.util.StringUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class AdultPurchaseLogListFragment(private val activityHandler: Handler) : NavigationListView() {

    private lateinit var binding: FragmentMyAdultPurchaseListBinding
    private lateinit var adapter: AdultPurchaseLogListAdapter
    private lateinit var viewHolder: AdultPurchaseLogListAdapter.ViewHolder
    private var isLateActive: Boolean = false
    private var logList: ArrayList<PurchaseLog> = arrayListOf()

    var head = "성인"
    var title = UIAgent.createLoginTitle(CategoryTarget.PAY_ADULT)

    @SuppressLint("InflateParams")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentMyAdultPurchaseListBinding.inflate(inflater)
        binding.apply {
            frg = this@AdultPurchaseLogListFragment
        }
        requestPurchaseLogList()
        return binding.root
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "PurchaseLogListFragment onKeyDown keyCode $keyCode")
        if (!::viewHolder.isInitialized) {
            return false
        }
        if (!STBAgent.enableKeyInput(STBAgent.GapTime)) {
            return true
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (viewHolder.binding.itemMyPurchaseLogLayout.isSelected) {
                    true
                } else {
                    controller.decrease()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (viewHolder.binding.itemMyPurchaseLogLayout.isSelected) {
                    true
                } else {
                    controller.increase()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                !viewHolder.binding.itemMyPurchaseLogLayout.isSelected
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (viewHolder.binding.itemMyPurchaseLogLayout.isSelected) {
                    viewHolder.binding.btnDetail.hasFocus()
                } else {
                    adapter.unfocus(controller.getCurIndex())
                    activityHandler.obtainMessage(2).sendToTarget()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                if (!viewHolder.binding.itemMyPurchaseLogLayout.isSelected) {
                    viewHolder.select()
                    viewHolder.binding.itemMyPurchaseLogBtnLayout.requestFocus()
                } else {
                    if (viewHolder.binding.btnDetail.hasFocus()) {
                        viewHolder.unSelect()
                        val log = logList[controller.getCurIndex()]
                        val enterPath = UIAgent.createEnterPath(EnterPath.PURCHASE_LOG, log.purchaseId)
                        when (log.targetType) {
                            CategoryItemType.SERIES -> ActivityChangeAgent.goToSeriesContent(
                                logList[controller.getCurIndex()].targetId,
                                logList[controller.getCurIndex()].episodeNo.toInt(),
                                context!!,
                                enterPath,
                                null
                            )
                            CategoryItemType.CONTENTGROUP -> ActivityChangeAgent.goToContent(
                                context!!,
                                logList[controller.getCurIndex()].targetId,
                                enterPath,
                                null
                            )
                            CategoryItemType.PACKAGE_OFFER -> ActivityChangeAgent.goToPackage(
                                context!!,
                                UUID.randomUUID().toString(),
                                logList[controller.getCurIndex()].targetId,
                                enterPath, null
                            )
                        }
                    } else {
                        viewHolder.unSelect()
                        when (logList[controller.getCurIndex()].productType) {
                            ProductType.SUBSCRIPTION -> {
                                UnSubscriptionPopupView(context!!, controller.getCurItem() as PurchaseLog, object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        when (btn) {
                                            BtnLabel.OK -> {
                                                updateList()
                                                d.dismiss()
                                            }
                                        }
                                    }
                                })
                            }
                            else -> {
                                DeletePurchaseLogPopupView(context!!, object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        when (btn) {
                                            BtnLabel.DELETE -> {
                                                deleteItem()
                                                d.dismiss()
                                            }
                                            BtnLabel.CANCEL -> {
                                                d.dismiss()
                                            }
                                        }
                                    }
                                })
                            }
                        }
                    }
                }
                true
            }

            KeyEvent.KEYCODE_BACK, 97 -> {
                if (viewHolder.binding.itemMyPurchaseLogLayout.isSelected) {
                    viewHolder.unSelect()
                } else {
                    adapter.unfocus(controller.getCurIndex())
                    activityHandler.obtainMessage(2).sendToTarget()
                }
                true
            }
            else -> false
        }
    }

    private fun deleteItem() {
        MBSAgent.purchaseLog(viewHolder.purchaseLog.purchaseId, false, object : Callback<ResponseNoBody> {
            override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                Logger.Log(Log.ERROR, this, "onFailure")
            }

            override fun onResponse(call: Call<ResponseNoBody>, res: Response<ResponseNoBody>) {
                val response = res.body()!!
                when (response.sessionState) {
                    SessionState.FORCE_LOGOUT -> {
                        UIAgent.showPopup(context!!, CODE.CONFLICT, object : RetryCallback {
                            override fun call() {
                                deleteItem()
                            }

                            override fun cancel() {
                            }
                        })
                    }
                    else -> {
                        updateList()
                    }
                }
            }
        })
    }

    private fun updateList(){
        adapter.removeItem(controller.getCurIndex())
        controller.removeItem(controller.getCurIndex())
        controller.resetRemoveData()

        if (controller.getTotalCount() > 0) {
            adapter.focus(controller.getCurIndex(), -1)
            checkArrow()
        } else {
            binding.loginLine.visibility = View.VISIBLE
            binding.logListLayout.isVisible = false
            binding.logListEmptyLayout.visibility = View.VISIBLE
            activityHandler.obtainMessage(2).sendToTarget()
        }
    }

    override fun active() {
        focus()
    }

    private fun requestPurchaseLogList() {
        GlobalScope.launch(Dispatchers.Main) {
            MBSAgent.purchaseLogList(
                StringUtil.getInstance().getEndDate(-2, 0),
                StringUtil.getInstance().getStartDate(),
                true,
                arrayListOf("normal", "series", "subscribe", "package"),
                1,
                0,
                object : Callback<ResponsePurchaseLogList> {
                    override fun onFailure(call: Call<ResponsePurchaseLogList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
                    }

                    override fun onResponse(call: Call<ResponsePurchaseLogList>, res: Response<ResponsePurchaseLogList>) {
                        Logger.Log(Log.INFO, this, "onResponse ${res.body()}")

                        if (res.isSuccessful && res.body() != null) {
                            val purchaseLogList = res.body()!!.purchaseLogList
                            val totalCount = res.body()!!.totalCount

                            if (totalCount > 0) {
                                val actionHandler = Handler {
                                    Logger.Log(Log.DEBUG, this, "actionHandler ${it.what}")
                                    when (it.what) {
                                        0 -> {
                                            viewHolder = it.obj as AdultPurchaseLogListAdapter.ViewHolder
                                        }
                                    }
                                    true
                                }

                                for (item in purchaseLogList) {
                                    logList.add(item)
                                }
                                adapter = AdultPurchaseLogListAdapter(binding.logList, logList, actionHandler)

                                setModel(NavigationListData(
                                    curIndex = 0,
                                    visibleThreshold = 6
                                ).build(purchaseLogList), object : NavigationListEvent {
                                    override fun focusChange() {
                                        Logger.Log(Log.DEBUG, this, "focusChange")
                                        adapter.focus(controller.getCurIndex(), controller.getPreIndex())
                                        checkArrow()
                                    }

                                    override fun plusLineChange() {
                                        Logger.Log(Log.DEBUG, this, "plusLineChange")
                                        binding.logListScrollView.smoothScrollBy(0, CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                                    }

                                    override fun minusLineChange() {
                                        Logger.Log(Log.DEBUG, this, "minusLineChange")
                                        binding.logListScrollView.smoothScrollBy(0, -CMBApp.getPixelSize(R.dimen.my_purchase_log_height))
                                    }
                                })

                                binding.logListLayout.visibility = View.VISIBLE
                                checkArrow()

                                activityHandler.obtainMessage(11).sendToTarget()
                                if (isLateActive) {
                                    active()
                                }
                            } else {
                                binding.loginLine.visibility = View.VISIBLE
                                binding.logListEmptyLayout.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()
                            }
                        } else {
                            Logger.Log(Log.ERROR, this, "실패 팝업 처리")
                            when (res.code()) {
                                CODE.CONFLICT -> {
                                    UIAgent.showPopupForMyMenu(context!!, CODE.CONFLICT, object : RetryCallback {
                                        override fun call() {
                                            activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                            activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                        }

                                        override fun cancel() {
                                        }
                                    })
                                }
                                else -> {
                                    binding.loginLine.visibility = View.VISIBLE
                                    binding.logListEmptyLayout.visibility = View.VISIBLE
                                    activityHandler.obtainMessage(2).sendToTarget()
                                }
                            }
                        }
                    }
                })
        }
    }

    private fun checkArrow() {
        if (controller.getTotalCount() > controller.getVisibleThreshold()) {
            if (controller.isLastItem())
                binding.myPurchaseLogArrow.visibility = View.INVISIBLE
            else
                binding.myPurchaseLogArrow.visibility = View.VISIBLE
        }
    }

    private fun isEnable(): Boolean {
        return binding.logListLayout.isVisible
    }

    fun focus() {
        if (isEnable()) {
            adapter.focus(controller.getCurIndex(), controller.getPreIndex())
        } else {
            activityHandler.obtainMessage(2).sendToTarget()
        }
    }

    override fun lateActive() {
        isLateActive = true
    }

    override fun setVisible(visible: Int) {
        binding.root.visibility = visible
    }
}