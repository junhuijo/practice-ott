package com.homechoice.ott.vod.ui.play

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Rect
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.castis.castisplayer.CastisException
import com.castis.castisplayer.CastisPlayer
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.drm.DrmSessionManager
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.ActivityPlayerBinding
import com.homechoice.ott.vod.io.RetrofitXmlClient
import com.homechoice.ott.vod.model.play.Frame
import com.homechoice.ott.vod.model.play.PlayContent
import com.homechoice.ott.vod.model.play.Thumbnail
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.model.response.ResponsePlayStart
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.util.Logger
import com.pallycon.widevinelibrary.PallyconWVMSDK
import com.pallycon.widevinelibrary.PallyconWVMSDKFactory
import kotlinx.android.synthetic.main.dialog_hidden.*
import kotlinx.coroutines.*
import okhttp3.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.concurrent.timer
import kotlin.math.abs
import kotlin.math.floor


class PlayerActivity : AppCompatActivity() {

    object CustomPlayEvent {
        const val READY = 10000
        const val PLAY = 10001
        const val END = 10002
        const val LOADING_CHANGED = 20000
        const val TRACKS_CHANGED = 20001
        const val TIMELINE_CHANGED = 20002
    }


    data class PlayStatus(
        var serviceId: Long = 0L,
        var seekPosition: Int = 0,
        private var _curPosition: Int = 0,
        var status: Int = CustomPlayEvent.READY,
        var hasThumbnail: Boolean = false
    ) {
        var curPosition: Int
            get() = _curPosition
            set(value) {
                _curPosition = value
            }
    }

    interface PlayStopEvent {
        fun end()
    }

    private var wvmAgent: PallyconWVMSDK? = null
    private var drmSessionManager: DrmSessionManager? = null
    private val snapHelper: LinearSnapHelper = LinearSnapHelper()
    private val context = this
    private var job: Job = Job()
    private var showTimer: Timer? = null
    private var isPause = false
    private val viewModel: PlayViewModel by viewModels()
    private lateinit var playerEventListener: Player.EventListener
    private lateinit var binding: ActivityPlayerBinding
    private lateinit var frames: List<Frame>
    private lateinit var adapter: ThumbnailListAdapter
    private lateinit var player: CastisPlayer
    private lateinit var content: PlayContent
    private var transparentIconHandler: Handler? = null
    private var playStatus = PlayStatus()
    private var enterPath: String = ""
    private var introPlayer: SimpleExoPlayer? = null
    private var isIntroVideoPlaying = false
    private var isIntroLoading = false
    private lateinit var skipButton: Button
    private var countDownTimer: CountDownTimer? = null
    private val skipButtonCountDownSec = 5
    private lateinit var seekManager: PlayerSeekManager
    private lateinit var uiHelper: PlayerUiHelper // uiHelper 선언 (초기화 제거)

    private fun startSkipButtonCountDown() {
        skipButton.isEnabled = false    //카운트다운 중에는 버튼 클릭 비활성화
        var remainingSec = skipButtonCountDownSec
        countDownTimer = object : CountDownTimer((skipButtonCountDownSec * 1000).toLong(), 1000) {
            override fun onTick(millisUntilFinished: Long) {
                skipButton.text = "${remainingSec}초 후 건너뛰기"
                remainingSec--
            }

            override fun onFinish() {
                skipButton.text = "건너뛰기 ▶"
                skipButton.isEnabled = true
                skipButton.requestFocus()
            }
        }.start()
    }
    private fun playMainContent() {
        // 기존 로직에 따라 메인 콘텐츠 재생
        player.play(content.movieUrl, true, if (content.offset > 0) content.offset else 0)
        skipButton.visibility = View.GONE // 메인 콘텐츠 재생 시에는 스킵 버튼 숨김
        findViewById<TextView>(R.id.leftButton).visibility = View.GONE // leftButton 숨김
        binding.introPlayerView?.visibility = View.GONE
        binding.root.clearFocus()
        binding.playerView.requestFocus()
        setOnKeyListener(binding.playerView)
    }


    private fun playIntro() {
        isIntroLoading = true
        binding.loading.visibility = View.VISIBLE
        //광고 URL을 가져오고, 결과에 따라 인트로 플레이어 설정 또는 메인 콘텐츠 재생

        // intro 스피너 테스트
//    Handler(Looper.getMainLooper()).postDelayed({
        MBSAgent.fetchAdUrl { adUrl ->
            Log.d("IntroPlay", "광고 URL: $adUrl")
            runOnUiThread {
                isIntroLoading = false
                binding.loading.visibility = View.GONE

                if (!adUrl.isNullOrEmpty() && !isPause) {
                    // 기존에 인트로 플레이어가 초기화되어 있다면 리소스를 해제합니다.
                    releaseIntroPlayer()
//                    introPlayer?.release() // 변경된 부분

                    // 인트로 플레이어 초기화 및 설정
                    introPlayer = SimpleExoPlayer.Builder(this@PlayerActivity).build().apply {
                        val mediaItem = MediaItem.fromUri(adUrl)
                        Log.d("IntroPlay", "미디어 아이템 생성: $mediaItem")
                        setMediaItem(mediaItem)
                        playWhenReady = true
                        prepare()
                        addListener(object : Player.EventListener {
                            override fun onPlaybackStateChanged(playbackState: Int) {
                                Log.d("IntroPlay", "재생 상태 변경: $playbackState")
                                when (playbackState) {
                                    Player.STATE_READY -> {
                                        binding.loading.visibility = View.GONE
                                        isIntroVideoPlaying = true
                                        binding.introPlayerView?.requestFocus()
                                        if (playWhenReady) {
                                            skipButton.visibility =
                                                View.VISIBLE // 재생 시작 시 바로 스킵 버튼 표시
                                            findViewById<TextView>(R.id.leftButton).visibility =
                                                View.VISIBLE // leftButton 보이기
                                            startSkipButtonCountDown() // 카운트다운 시작
                                        }
                                    }

                                    Player.STATE_ENDED -> {
                                        if (isIntroVideoPlaying) {
                                            playMainContent()
                                        }
                                        isIntroVideoPlaying = false
                                        skipButton.visibility = View.GONE
                                        findViewById<TextView>(R.id.leftButton).visibility =
                                            View.GONE // leftButton 숨김
                                        releaseIntroPlayer()
                                        binding.playerView.requestFocus()
                                    }
                                }
                            }
                        })
                    }
                    // 안전하게 플레이어 뷰에 플레이어를 설정합니다.
                    binding.playerView.player?.release() // 이미 안전 호출이므로 변경 필요 없음
                    binding.playerView.player = introPlayer
                } else {
                    // 광고 URL이 없는 경우 메인 콘텐츠 재생
                    Log.d("IntroPlay", "광고 URL 없음, 메인 콘텐츠 재생")
                    playMainContent()
                }
            }
        }
//      }, 3000)
    }

    private var errorEventHandler = Handler(Looper.getMainLooper()) {
        PopupAgent.showNormalPopup(context, PopupType.getErrorType(
            TYPE.PLAY,
            it.what,
            it.obj as String
        ), object : PopupEvent {
            override fun onClick(d: Dialog, btn: String){
                when (btn) {
                    BtnLabel.OK -> {
                        d.dismiss()
                        finish()
                    }
                }
            }
        })
        true
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 기본 윈도우 설정
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // 레이아웃 인플레이트 및 바인딩 설정
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        binding.apply {
            lifecycleOwner = this@PlayerActivity // 라이프사이클 오너 설정
            playViewModel = viewModel // 뷰모델 연결
        }
        setContentView(binding.root) // 설정된 뷰를 화면에 표시

        // 콘텐츠 설정
        content = intent.getParcelableExtra("content")!! // 인텐트에서 콘텐츠 정보 가져오기
        content.converter() // 콘텐츠 데이터 변환 처리
        viewModel.playContent.value = content // 뷰모델에 콘텐츠 데이터 설정
        enterPath = content.enterPath // 콘텐츠 경로 설정

        // UI 컴포넌트 초기화
        setupUIComponents() // 버튼 등의 UI 컴포넌트 초기화 메서드 호출

        // 플레이어 초기화
        initializePlayer() // 플레이어 관련 설정 및 초기화 메서드 호출

        // 뒤로 가기 디스패처 설정
        setupBackPressedDispatcher() // 뒤로 가기 버튼 처리를 위한 콜백 설정

        // 추가 설정(예: DRM, 애니메이션 등)
        additionalSetups() // DRM 초기화, 애니메이션 설정 등 추가적인 설정 메서드 호출

        // 썸네일 초기화
        initThumbnail() // 썸네일 관련 데이터 처리 및 표시를 위한 초기화 메서드 호출
    }


    override fun onResume() {
        super.onResume()
        Logger.LogOnResume(this)
        if (isPause) {
            isPause = false
            finish()
        } else {
            var adTag = content.advUrl
            try {

                binding.playerView.setOnKeyListener { _, keyCode, event ->
                    player.hideController()
                    Logger.playerLog(
                        Log.DEBUG,
                        "playerView keyCode : $keyCode / isPlaying : ${isPlay()} / isShowThumbnailView() : ${uiHelper.isShowThumbnailView()} / isPlayingAD ${isAdPlay()}"
                    )
                    false
                }

                if (content.isPreview || content.isTrailer) {
                    adTag = ""
                }
                if (adTag.isEmpty() || content.isPurchase) {
                    playIntro()
                } else {
                    playIntro()
                }
            } catch (e: CastisException) {
                finish()
            }
            player.hideController()
            isPause = false
        }
    }

    private fun setupUIComponents() {
        skipButton = findViewById<Button>(R.id.skipButton)
        skipButton.setOnClickListener {
            handleSkipButtonClick()
        }
        binding.playerKeyLayout.visibility = View.INVISIBLE
        setRatingIcon(content.rating)
    }

    private fun handleSkipButtonClick() {
        if (isIntroVideoPlaying) {
            introPlayer?.stop()
            introPlayer?.release()
            introPlayer = null
            isIntroVideoPlaying = false
            skipButton.visibility = View.GONE
            playMainContent()
        }
    }
    private fun initializePlayer() {
        player = CastisPlayer()
        seekManager = PlayerSeekManager(player, playStatus, binding)
        uiHelper = PlayerUiHelper(binding)
        playerEventListener = PlayerEventImpl(initPlayEvent(), errorEventHandler)
        player.setEventListener(playerEventListener)
    }

    private fun setupBackPressedDispatcher() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isIntroVideoPlaying) {
                    introPlayer?.stop()
                    introPlayer?.release()
                    introPlayer = null
                    isIntroVideoPlaying = false
                    onBackPressedDispatcher.onBackPressed()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }
    private fun additionalSetups() {
        try {
            wvmAgent = PallyconWVMSDKFactory.getInstance(this)
            wvmAgent!!.setPallyconEventListener(PallyconEventImpl())
            wvmAgent!!.init(
                this,
                Handler(Looper.getMainLooper()),
                player.aesDecode(player.siteId),
                player.siteKey
            )
            drmSessionManager = wvmAgent!!.createDrmSessionManagerByToken(
                C.WIDEVINE_UUID, player.drmLicenseUrl, Uri.parse(content.movieUrl), content.drmToken
            )
            player.setHighBitratePlay(true)
            player.initPlayer(this, binding.playerView, drmSessionManager)
            runOnUiThread {
                val animation = AnimationUtils.loadAnimation(this, R.anim.play_loading_rotate)
                binding.loading.startAnimation(animation)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onPause() {
        Logger.LogOnPaue(this)
        isPause = true
        try {
            releaseIntroPlayer()
            requestPlayStop(playStatus.curPosition, object : PlayStopEvent {
                override fun end() {
                    releasePlayer()
                    playStatus.serviceId = 0
                }
            })
        } catch (e: CastisException) {
            e.printStackTrace()
        }
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseIntroPlayer()
    }

    private fun releaseIntroPlayer() {
        isIntroLoading = false
        isIntroVideoPlaying = false
        introPlayer?.let {
            it.stop()
            it.clearMediaItems()
            it.release()
        }
        introPlayer = null
        binding.introPlayerView?.player = null
    }

    override fun onStop() {
        Logger.LogOnStop(this)
        super.onStop()
    }
    private fun initPlayEvent(): Handler {
        return Handler(Looper.getMainLooper()) {
            Logger.playerLog(
                Log.WARN,
                "PlayEvent what:${it.what} / isPlaying:${isPlay()} / isPlayingAD:${isAdPlay()} / status:${playStatus.status} / currentPositionSec: ${player.currentPositionSec} / durationSec:${player.durationSec}"
            )
            when (it.what) {

                ExoPlayer.STATE_BUFFERING -> {
                    player.hideController()
                }

                ExoPlayer.STATE_READY -> {
                    playStatus.curPosition = player.currentPositionSec
                    player.hideController()
                }

                ExoPlayer.STATE_ENDED -> {
                    playStatus.curPosition = 0
                    setResult(Activity.RESULT_OK)
                    finish()
                }

                CustomPlayEvent.TIMELINE_CHANGED -> {
                    player.hideController()
                }

                CustomPlayEvent.TRACKS_CHANGED -> {
                    player.hideController()
                    when (playStatus.status) {
                        CustomPlayEvent.READY -> {
                            if (isPlay()) {

                                binding.playerView.clearFocus()

                                binding.playerKeyLayout.visibility = View.VISIBLE
                                setOnKeyListener(binding.playerKeyLayout)
                                binding.playerKeyLayout.requestFocus()

                                seekManager.updateProgressBar(player.currentPositionSec)
                                createPreviewTimer()
                                requestPlayStart(content.id, content.offerId)

                            } else if (isAdPlay()) {
                                Logger.playerLog(Log.INFO, "앞 광고 재생 시작4")

                                uiHelper.setVisible(binding.playerKeyLayout, View.GONE)
                                binding.playerKeyLayout.clearFocus()

                            }
                            binding.loading.visibility = View.GONE
                            binding.loading.clearAnimation()
                            playStatus.status = CustomPlayEvent.PLAY
                        }

                        CustomPlayEvent.PLAY -> {

                            if (isPlay()) {
                                Logger.playerLog(Log.INFO, "다시 재생!!")
                                binding.playerView.clearFocus()
                                player.hideController()

                                binding.playerKeyLayout.visibility = View.VISIBLE
                                setOnKeyListener(binding.playerKeyLayout)
                                binding.playerKeyLayout.requestFocus()

                                seekManager.updateProgressBar(player.currentPositionSec)
                                createPreviewTimer()
                                requestPlayStart(content.id, content.offerId)

                            } else if (isAdPlay()) {

                                Logger.playerLog(Log.INFO, "끝 광고 재생")
                                uiHelper.setVisible(binding.playerKeyLayout, View.GONE)
                                binding.playerKeyLayout.clearFocus()
                                binding.playerView.requestFocus()
                                playStatus.curPosition = 0
                                playStatus.status = CustomPlayEvent.END
                            }
                        }
                    }
                }

                CustomPlayEvent.LOADING_CHANGED -> {
                    // 광고가 아닐 때 포지션 저장
                    if (isPlay())
                        playStatus.curPosition = player.currentPositionSec
                }
            }
            true
        }
    }

    private fun initThumbnail() {
        Logger.playerLog(Log.ERROR, "initThumbnail")
        adapter = ThumbnailListAdapter(content.thumbnailServerInfo, listOf())
        GlobalScope.launch(Dispatchers.Default) {
            try {
                Logger.playerLog(
                    Log.ERROR,
                    "content.thumbnailServerInfo : ${content.thumbnailServerInfo}"
                )
                Logger.playerLog(Log.ERROR, "content.thumbnailUrl : ${content.thumbnailUrl}")
                RetrofitXmlClient.getInstance().setService(content.thumbnailServerInfo + "/")
                RetrofitXmlClient.getInstance()
                    .getThumbnail(content.thumbnailUrl, object : Callback<Thumbnail> {
                        override fun onFailure(call: Call<Thumbnail>, t: Throwable) {
                            Logger.playerLog(Log.ERROR, "onFailure: ${t.message}")
                            adapter = ThumbnailListAdapter(content.thumbnailServerInfo, listOf())
                        }

                        override fun onResponse(call: Call<Thumbnail>, response: Response<Thumbnail>) {
                            try {
                                Logger.playerLog(
                                    Log.INFO,
                                    "RetrofitXmlClient response : ${response.body()}"
                                )

                                if (response.isSuccessful && response.body() != null) {
                                    val thumbnail: Thumbnail? = response.body()
                                    frames = thumbnail?.frames ?: listOf()

                                    Logger.playerLog(
                                        Log.INFO,
                                        "content?.thumbnailServerInfo : ${content.thumbnailServerInfo}"
                                    )
                                    Logger.playerLog(Log.INFO, "frames : $frames")

                                    adapter = ThumbnailListAdapter(content.thumbnailServerInfo, frames)

                                    binding.thumbnailList.layoutManager =
                                        LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
                                    binding.thumbnailList.setHasFixedSize(true)
                                    binding.thumbnailList.adapter = adapter

                                    snapHelper.attachToRecyclerView(binding.thumbnailList)

                                    binding.thumbnailList.addItemDecoration(object :
                                        RecyclerView.ItemDecoration() {
                                        override fun getItemOffsets(
                                            outRect: Rect,
                                            view: View,
                                            parent: RecyclerView,
                                            state: RecyclerView.State
                                        ) {
                                            val edgeMargin = (context.resources.getDimensionPixelSize(R.dimen.thumbnail_item_margin_left) * -1)
                                            val position = parent.getChildAdapterPosition(view)
                                            if (position == 0) {
                                                outRect.left = edgeMargin
                                            }
                                            if (position == state.itemCount - 1) {
                                                outRect.right = edgeMargin
                                            }
                                        }
                                    })
                                    playStatus.hasThumbnail = true
                                } else {
                                    adapter = ThumbnailListAdapter(content.thumbnailServerInfo, listOf())
                                }
                            } catch (e: Exception) {
                                finish()
                            }
                        }
                    })
            } catch (e: Exception) {
                finish()
            }
        }
    }

    private fun isPlay(): Boolean {
        return (player.isPlaying && !isAdPlay())
    }

    private fun isAdPlay(): Boolean {
        return player.isPlayingAD
    }

    private fun createPreviewTimer() {
        closePreviewTimer()
        if (content.isPreview) {
            job = GlobalScope.launch(Dispatchers.Main) {

                while (isActive) {
                    delay(1000L)
                    Logger.Log(
                        Log.WARN,
                        this,
                        "currentPositionSec ${player.currentPositionSec} / previewDurationInSec ${content.previewDurationInSec}"
                    )
                    if (isAblePreview()) {
                        if (STBAgent.isAuth) {
                            releasePlayer()
                            finish()
                        } else {
                            // 로그인 팝업 제공
                            uiHelper.hideProgressBar()
                            hideThumbnailList()
                            releasePlayer()
                            PopupAgent.showLoginPopup(context, object : LoginPopupEvent {
                                override fun onLogin(loginDialog: Dialog, btn: String) {
                                    when (btn) {
                                        BtnLabel.SUCCESS -> {
                                            loginDialog.dismiss()
                                            finish()
                                        }

                                        BtnLabel.CANCEL -> {
                                            loginDialog.dismiss()
                                        }

                                        BtnLabel.BACK -> {
                                            finish()
                                        }
                                    }
                                }
                            })
                        }
                    } else {
                        Logger.Log(Log.WARN, this, "미리보기 중")
                    }
                }

            }
        }
    }

    private fun isAblePreview(): Boolean {
        return player.currentPositionSec > content.previewDurationInSec
    }

    private fun isAblePreview(sec: Int): Boolean {
        // 마지막 시간기준으로 10초 앞에서 멈추도록 하기 위해서
        return sec >= content.previewDurationInSec - 10
    }

    private fun closePreviewTimer() {
        Logger.Log(Log.WARN, this, "closePreviewTimer")
        if (job.isActive)
            job.cancel()
    }

    private fun createProgressBarTimer() {
        closeProgressBarTimer()
        if (!uiHelper.isShowPlayView())
            uiHelper.showProgressBar()

        seekManager.updateProgressBar(player.currentPositionSec)
        var count = 0
        showTimer = timer(period = 1000, initialDelay = 1000) {
            count++
            runOnUiThread {
                seekManager.updateProgressBar(player.currentPositionSec)
                if (count == 3) {
                    uiHelper.hideProgressBar()
                    hideThumbnailList()
                    cancel()
                }
            }
        }
    }

    private fun closeProgressBarTimer() {
        if (showTimer != null) {
            showTimer?.cancel()
            showTimer = null
        }
    }

    private fun togglePlay() {
        if (player.isPlaying) {
            closeProgressBarTimer()
            player.pause()
            setPlayIcon(R.drawable.stop)
        } else {
            player.resume()
            setPlayIcon(R.drawable.play)
        }
    }

    private fun setPlayIcon(iconId: Int) {
        binding.startStop.setBackgroundResource(iconId)
    }

    private fun setRatingIcon(rating: String) {
        Logger.Log(Log.INFO, this, "setRatingIcon rating : $rating")
        binding.iconRating.setImageResource(UIAgent.getRatingImageResource(rating))
    }

    private fun updateFrames(currentPositionSec: Int) {
        adapter.updateList(currentPositionSec)
    }


    @Throws(CastisException::class)
    private fun releasePlayer() {
        Logger.Log(Log.INFO, this, "releasePlayer")
        closeProgressBarTimer()
        closePreviewTimer()
        player.stop()
    }

    private fun showExitPopup() {
        PopupAgent.showPlayExitPopup(context, object : PopupEvent {
            override fun onClick(d: Dialog, btn: String) {
                when (btn) {
                    BtnLabel.PLAY_STOP -> {
                        d.dismiss()
                        releasePlayer()
                        //시청 종료시 성인인증 여부 초기화
//                        STBAgent.isAdultAuth = false
                        finish()
                    }

                    BtnLabel.OK -> {
                        d.dismiss()
                    }

                    BtnLabel.CANCEL -> {
                        d.dismiss()
                        createProgressBarTimer()
                        player.resume()
                    }
                }
            }
        })
    }

    private fun requestPlayStart(id: Long, offerId: Long) {
        // 중복 호출 시 serviceId가 0인경우 호출(이전 호출 실패 시)
        Logger.Log(
            Log.INFO,
            this,
            "requestPlayStart isPreview:${content.isPreview} / isTrailer:${content.isTrailer} / ${(playStatus.serviceId == 0L)}"
        )
        if (!content.isPreview && !content.isTrailer && playStatus.serviceId == 0L) {
            MBSAgent.playStart(id, offerId, enterPath, object : Callback<ResponsePlayStart> {
                override fun onFailure(call: Call<ResponsePlayStart>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, "requestPlayStart 실패")
                    playStatus.serviceId = 0
                }

                override fun onResponse(
                    call: Call<ResponsePlayStart>,
                    response: Response<ResponsePlayStart>
                ) {
                    if (response.isSuccessful && response.body() != null) {
                        playStatus.serviceId = response.body()!!.serviceId
                    } else {
                        playStatus.serviceId = 0
                        when (response.code()) {
                            CODE.CONFLICT -> {
                                STBAgent.init()
                            }
                        }
                    }
                    Logger.Log(Log.INFO, this, "requestPlayStart 성공 serviceId = $playStatus")
                }
            })
        } else
            playStatus.serviceId = 0
    }

    private fun requestPlayStop(position: Int, event: PlayStopEvent) {
        Logger.Log(Log.INFO, this, "requestPlayStop serviceId:$playStatus / position:$position")
        if (playStatus.serviceId > 0) {
            MBSAgent.playStop(playStatus.serviceId, position, object : Callback<ResponseNoBody> {
                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                    Logger.Log(Log.ERROR, this, "requestPlayStop 실패")
                    event.end()
                }

                override fun onResponse(
                    call: Call<ResponseNoBody>,
                    response: Response<ResponseNoBody>
                ) {
                    Logger.Log(Log.INFO, this, "requestPlayStop 성공")
                    when (response.code()) {
                        CODE.CONFLICT -> {
                            STBAgent.init()
                        }
                    }
                    event.end()
                }
            })
        } else {
            event.end()
        }
    }

    private fun showThumbnailView() {
        if (uiHelper.isShowThumbnailView() || !::adapter.isInitialized || !playStatus.hasThumbnail)
            return

        playStatus.seekPosition = player.currentPositionSec
        binding.thumbnailList.visibility = View.VISIBLE

        Logger.Log(Log.DEBUG, this, "selectedPosition : $playStatus.seekPosition")
    }

    private fun hideThumbnailList() {
        binding.thumbnailList.visibility = View.INVISIBLE
    }

    private fun plusThumbnail() {
        playStatus.seekPosition = floor((playStatus.seekPosition.toDouble() / 10)).toInt() * 10
        if (playStatus.seekPosition + 10 < player.durationSec) {
            playStatus.seekPosition += 10
            seekManager.updateProgressBar(playStatus.seekPosition)
            updateFrames(playStatus.seekPosition)
        }
    }

    private fun minusThumbnail() {
        playStatus.seekPosition = floor((playStatus.seekPosition.toDouble() / 10)).toInt() * 10
        if (playStatus.seekPosition - 10 >= 0) {
            playStatus.seekPosition -= 10
            seekManager.updateProgressBar(playStatus.seekPosition)
            updateFrames(playStatus.seekPosition)
        }
    }

    private fun isPlayStart(): Boolean {
        return playStatus.status == CustomPlayEvent.PLAY && player.currentPosition > 0
    }

    private fun setOnKeyListener(view: View) {
        view.setOnKeyListener { _, keyCode, event ->
            var result = true

            if (event.action == KeyEvent.ACTION_DOWN && (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP || event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
                handleVolumeKey(event)
            }

            if (event.action == KeyEvent.ACTION_DOWN) {

                when (keyCode) {
                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER  -> {
                        result = handlePlayPauseKey()
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN,
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        handleUpDownKey()
                    }
                    KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        handleFastForwardKey()
                    }
                    KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_DPAD_LEFT -> {
                        handleRewindKey()
                    }
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        handleBackKey()
                    }
                    KeyEvent.KEYCODE_9 -> {
                        seekToSec()
                    }
                }
            }
            else {
                result = false
            }

            result
        }
    }

    private fun handlePlayPauseKey(): Boolean {
        if (isAdPlay()) {
            return false
        }
        if (!isPlayStart()) {
            togglePlay()
            return true
        }
        if (player.isPlaying) {
            closeProgressBarTimer()
            uiHelper.showProgressBar()
            setPlayIcon(R.drawable.play)
            if (transparentIconHandler == null) {
                transparentIconHandler = Handler()
            }
            transparentIconHandler?.removeCallbacksAndMessages(null)
            transparentIconHandler?.postDelayed({
                setPlayIconToTransparent()
            }, 3000) // 5초 지연 후 실행
            player.pause()
        } else {
            setPlayIcon(R.drawable.play)
            if (transparentIconHandler == null) {
                transparentIconHandler = Handler()
            }
            transparentIconHandler?.removeCallbacksAndMessages(null)
            transparentIconHandler?.postDelayed({
                setPlayIconToTransparent()
            }, 3000) // 5초 지연 후 실행
            if (uiHelper.isShowThumbnailView()) {
                val current: Int = player.currentPositionSec
                var direction = playStatus.seekPosition - current

                Logger.playerLog(
                    Log.INFO,
                    "current:$current / selectedPosition:$playStatus.seekPosition / direction:$direction"
                )

                if (direction < 0) {
                    direction = abs(direction)
                    Logger.playerLog(Log.INFO, "floor:${floor((direction.toDouble() / 10)).toInt() * 10}")
                    player.backwardSec(floor((direction.toDouble() / 10)).toInt() * 10)
                } else
                    player.forwardSec(direction)

                createProgressBarTimer()
                player.resume()
                setPlayIcon(R.drawable.stop)
                if (transparentIconHandler == null) {
                    transparentIconHandler = Handler()
                }
                transparentIconHandler?.removeCallbacksAndMessages(null)
                transparentIconHandler?.postDelayed({
                    setPlayIconToTransparent()
                }, 3000) // 5초 지연 후 실행
            } else {
                if (uiHelper.isShowPlayView()) {
                    createProgressBarTimer()
                } else {
                    closeProgressBarTimer()
                    uiHelper.hideProgressBar(R.anim.play_view_hide)
                }
                player.resume()
                setPlayIcon(R.drawable.stop)
                if (transparentIconHandler == null) {
                    transparentIconHandler = Handler()
                }
                transparentIconHandler?.removeCallbacksAndMessages(null)
                transparentIconHandler?.postDelayed({
                    setPlayIconToTransparent()
                }, 3000) // 5초 지연 후 실행
            }
        }
        return true
    }

    private fun handleFastForwardKey() {
        if (player.isPlayingAD || !isPlayStart()) {
            return
        }
        if (uiHelper.isShowPlayView()) {
            player.pause()
            setPlayIcon(R.drawable.play)
            closeProgressBarTimer()
            showThumbnailView()
            uiHelper.showProgressBar()
            if (transparentIconHandler == null) {
                transparentIconHandler = Handler()
            }
            transparentIconHandler?.removeCallbacksAndMessages(null)
            transparentIconHandler?.postDelayed({
                setPlayIconToTransparent()
            }, 3000) // 5초 지연 후 실행

            if (content.isPreview) {
                if (!isAblePreview(playStatus.seekPosition)) {
                    plusThumbnail()
                } else {
                    seekManager.forwardAndUpdateProgressBar()
                }
            } else {
                if (playStatus.hasThumbnail) {
                    plusThumbnail()
                } else {
                    seekManager.forwardAndUpdateProgressBar()
                }
            }
        } else {
            hideThumbnailList()
            createProgressBarTimer()
        }
    }


    private fun handleVolumeKey(event: KeyEvent) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        var currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        currentVolume += if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) -1 else 1
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, currentVolume, AudioManager.FLAG_SHOW_UI)
    }

    private fun handleUpDownKey() {

        if (player.isPlayingAD || !isPlayStart()) {
            return
        }
        if (uiHelper.isShowPlayView()) {
            closeProgressBarTimer()
            hideThumbnailList()
            uiHelper.hideProgressBar()
        } else {
            hideThumbnailList()
            createProgressBarTimer()
        }
    }

    private fun handleRewindKey() {
        if (player.isPlayingAD) {
            return
        }
        if (uiHelper.isShowPlayView()) {
            player.pause()
            setPlayIcon(R.drawable.play)
            closeProgressBarTimer()
            showThumbnailView()
            uiHelper.showProgressBar()
            if (playStatus.hasThumbnail) {
                minusThumbnail()
            } else {
                seekManager.backwardAndUpdateProgressBar()
            }
            if (transparentIconHandler == null) {
                transparentIconHandler = Handler()
            }
            transparentIconHandler?.removeCallbacksAndMessages(null)
            transparentIconHandler?.postDelayed({
                setPlayIconToTransparent()
            }, 3000) // 5초 지연 후 실행
        } else {
            if (!playStatus.hasThumbnail) {
                seekManager.backwardAndUpdateProgressBar()
            }
            createProgressBarTimer()
        }
    }

    private fun handleBackKey() {
        if (player.isPlayingAD || content.isPreview || content.isTrailer) {
            releasePlayer()
            finish()
            return
        }
        closeProgressBarTimer()
        uiHelper.hideProgressBar()
        if (uiHelper.isShowThumbnailView()) {
            hideThumbnailList()
            player.resume()
            setPlayIcon(R.drawable.play)
            if (transparentIconHandler == null) {
                transparentIconHandler = Handler()
            }
            transparentIconHandler?.removeCallbacksAndMessages(null)
            transparentIconHandler?.postDelayed({
                setPlayIconToTransparent()
            }, 3000) // 5초 지연 후 실행
        } else {
            player.pause()
            showExitPopup()
        }
    }

    private fun seekToSec() {
        playStatus.seekPosition = player.durationSec - 10
        playStatus.seekPosition = floor((playStatus.seekPosition.toDouble() / 10)).toInt() * 10
        if (playStatus.seekPosition + 10 < player.durationSec) {
            playStatus.seekPosition += 10
            seekManager.updateProgressBar(playStatus.seekPosition)
            updateFrames(playStatus.seekPosition)
        }
        player.seekToSec(playStatus.seekPosition)
        playStatus.curPosition = playStatus.seekPosition
    }
    private fun setPlayIconToTransparent() {
        setPlayIcon(R.drawable.transparent_image)
    }
}