package com.homechoice.ott.vod.ui.detail

import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.content.Content
import com.homechoice.ott.vod.model.content.OfferContent

interface DetailViewModelListener {
    fun select(offerContent: OfferContent)
    fun select(categoryItem: CategoryItem)
    fun like(content: Content, isLike: Boolean)
    fun likeFocused()
    fun buttonListFocused(index: Int)
    fun recommendFocused(index: Int, isFocus: Boolean)
    fun update()
}