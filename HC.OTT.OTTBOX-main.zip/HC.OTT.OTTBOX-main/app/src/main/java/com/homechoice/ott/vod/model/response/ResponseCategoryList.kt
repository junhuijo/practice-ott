package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.CategoryList
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseCategoryList(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val totalCount: Int,
    var categoryList: List<CategoryList>
) : Parcelable