package com.homechoice.ott.vod.model.play

import com.tickaroo.tikxml.annotation.Element
import com.tickaroo.tikxml.annotation.PropertyElement
import com.tickaroo.tikxml.annotation.Xml
// castis서버 xml파일 <video>양식변경 -> aws <video>삭제되서 video아닌 파일도 읽을수 있게 처리  
@Xml
data class Thumbnail(
    @Element(name = "video")
    val video: Video?,  // Nullable 필드로 선언

    @Element(name = "frame")
    val frames: List<Frame>
)

@Xml
data class Video(
    @PropertyElement
    var file: String
)

@Xml
data class Frame(
    @PropertyElement
    var framecnt: Int,

    @PropertyElement
    var img: String,
    @PropertyElement(name = "tc", converter = Timestamp::class)
    var tc: Int
)
