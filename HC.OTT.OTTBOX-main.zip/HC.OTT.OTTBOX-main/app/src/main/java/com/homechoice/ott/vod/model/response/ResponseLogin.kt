package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseLogin(
    val isActive: Boolean = false,
    val cardName: String = "",
    val sessionState: String = "",
    val isAdult: Boolean = false
) : Parcelable