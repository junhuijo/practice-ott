package com.homechoice.ott.vod.ui.popup.purchase

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.popup.Purchase

//class PurchasePopupViewModel(purchase: Purchase) : ViewModel() {
//    var purchase: MutableLiveData<Purchase> = MutableLiveData()
//}

class PurchasePopupViewModel(data: Purchase) : ViewModel() {
    var purchase: MutableLiveData<Purchase> = MutableLiveData()

    init {
        purchase.value = data
    }
}