package com.homechoice.ott.vod.ui.my.member

import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.view.get
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.CategoryTarget
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.PwReplace
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentMyChangePasswordBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_my_change_password.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ChangePasswordFragment(val activityHandler: Handler) : NavigationView2() {

    private lateinit var bind: FragmentMyChangePasswordBinding
    private lateinit var viewModel: ChangePasswordViewModel
    private var tabLayout: ArrayList<FrameLayout> = arrayListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_my_change_password, container, false)
        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this).get(ChangePasswordViewModel::class.java)

        with(viewModel) {
            this.setListener(listener = object : ChangePasswordViewModel.ModelListener {
                override fun focusChanged(previousIndex: Int, index: Int, pageStartIndex: Int) {
                    Logger.Log(Log.ERROR, this, "focusChanged:$index")
                    keypad_layout[index].requestFocus()
                }

                override fun select(index: Int) {
                    Logger.Log(Log.ERROR, this, "select:$index")
                    enter(keypad_layout[index])
                }

                override fun tabChanged(index: Int) {
//                    password_change_tab.requestFocus()
                    tabLayout[index].requestFocus()
                }

                override fun selectTab(index: Int) {

                }

                override fun back() {
                    backToCategory()
                }

            })
        }
        bind.viewModel = viewModel
        bind.lifecycleOwner = this
        bind.passwordChangeTab0?.let { tabLayout.add(it) }
        bind.passwordChangeTab1?.let { tabLayout.add(it) }
        bind.passwordChangeTab2?.let { tabLayout.add(it) }
        bind.passwordChangeTab3?.let { tabLayout.add(it) }
    }


    fun enter(view: View) {
        when (view) {
            keypad_num_0 -> {
                keypad_inputbox.append("0")
            }
            keypad_num_1 -> {
                keypad_inputbox.append("1")
            }
            keypad_num_2 -> {
                keypad_inputbox.append("2")
            }
            keypad_num_3 -> {
                keypad_inputbox.append("3")
            }
            keypad_num_4 -> {
                keypad_inputbox.append("4")
            }
            keypad_num_5 -> {
                keypad_inputbox.append("5")
            }
            keypad_num_6 -> {
                keypad_inputbox.append("6")
            }
            keypad_num_7 -> {
                keypad_inputbox.append("7")
            }
            keypad_num_8 -> {
                keypad_inputbox.append("8")
            }
            keypad_num_9 -> {
                keypad_inputbox.append("9")
            }
            keypad_num_del -> {
                var numbers = keypad_inputbox.text
                if (numbers.isNotEmpty()) {
                    numbers.substring(0, numbers.length - 1).also { numbers = it }
                }
                keypad_inputbox.text = numbers
            }
            keypad_num_ok -> {
                val tabStatus = viewModel.tabStatus.value
                val type: String
                if (tabStatus == 0 || tabStatus == 2) {
                    type = PwReplace.PURCHASE
                } else {
                    type = PwReplace.ADULT
                }
                okNumber(keypad_inputbox.text.toString(), type)
            }
            else -> {
                Logger.Log(Log.ERROR, this, "not exist key")
            }

        }
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
        var result = false
        when (keyCode) {

            KeyEvent.KEYCODE_BACK, 97 -> {
                backToCategory()
                result = true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                viewModel.up()
                result = true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                viewModel.down()
                result = true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                viewModel.right()
                result = true

            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                //activityHandler.obtainMessage(2).sendToTarget()
                viewModel.left()
                result = true

            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                viewModel.enter()
                result = true
            }
        }

        return result
    }

    override fun active() {
        TODO("Not yet implemented")
    }

    fun backToCategory() {
        drawTabFocus(viewModel.tabStatus.value ?: 0)
        activityHandler.obtainMessage(2).sendToTarget()
    }

    fun drawTabFocus(tabStatus: Int) {
        if (tabStatus == 2 || tabStatus == 3) {
            viewModel.tabStatus.value = tabStatus - 2
        }
    }

    fun focus() {
//        password_change_tab[0].requestFocus()
//        tabLayout[0].requestFocus()
        viewModel.init(true)
        viewModel.tabStatus.value = 2
    }

    private fun getPopupType(type: String): PopupType.NormalPopupType {
        return if (type == PwReplace.ADULT) {
            PopupType.NormalPopupType.ADULT_PASSWORD_CHANGE
        } else {
            PopupType.NormalPopupType.PURCHASE_PASSWORD_CHANGE
        }
    }

    private fun okNumber(numbers: String, type: String) {
        val numbers =
            if (UIAgent.isValidCellPhoneNumber(numbers)) {
                Logger.Log(Log.DEBUG, this, "전화번호 형식 맞음")

                MBSAgent.pwReplace(numbers, type, object : Callback<ResponseNoBody> {
                    override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                        context?.let {
                            PopupAgent.showNormalPopup(
                                it,
                                PopupType.getErrorType(
                                    TYPE.AUTH,
                                    CODE.NONE
                                ),
                                object : PopupEvent {
                                    override fun onClick(d: Dialog, btn: String) {
                                        when (btn) {
                                            BtnLabel.OK -> {
                                                d.dismiss()
                                            }
                                        }
                                    }
                                })
                        }

                    }

                    override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                        if (response.isSuccessful && response.body() != null) {
                            viewModel.invalidInfo.value = false
                            context?.let {
                                PopupAgent.showNormalPopup(
                                    it,
                                    getPopupType(type),
                                    object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            d.dismiss()
                                        }
                                    })
                            }

                        } else {
                            context?.let {
                                when (response.code()) {
                                    CODE.CONFLICT -> {
                                        UIAgent.showPopupForMyMenu(it, response.code(), object : RetryCallback {
                                            override fun call() {
                                                activityHandler.obtainMessage(12).sendToTarget()
                                                activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                            }

                                            override fun cancel() {
                                                activityHandler.obtainMessage(12).sendToTarget()
                                            }
                                        })
                                    }
                                    else -> {
                                        val error = response.errorBody()?.let { MBSAgent.error(it) }
                                        viewModel.invalidInfo.value = true
                                        PopupAgent.showNormalPopup(
                                            it,
                                            PopupType.getErrorType(
                                                TYPE.AUTH,
                                                response.code(),
                                                error?.errorString!!
                                            ),
                                            object : PopupEvent {
                                                override fun onClick(d: Dialog, btn: String) {
                                                    when (btn) {
                                                        BtnLabel.OK -> {
                                                            d.dismiss()
                                                        }
                                                    }
                                                }
                                            })
                                    }
                                }

                            }
                        }
                    }

                })


            } else {
                Logger.Log(Log.DEBUG, this, "전화번호 형식 아님")
                //binding.warnText.visibility = View.VISIBLE
                viewModel.invalidInfo.value = true
            }
    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        TODO("Not yet implemented")
    }

}