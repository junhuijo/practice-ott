package com.homechoice.ott.vod.ui.pack

import android.os.Bundle
import android.view.KeyEvent
import androidx.appcompat.app.AppCompatActivity
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.Home
import com.homechoice.ott.vod.agent.STBAgent

class PackageActivity : AppCompatActivity() {

    lateinit var packageFragment: PackageFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_package)
        STBAgent.setBackgroundImage(findViewById(R.id.background_image))

        packageFragment = PackageFragment(intent.getParcelableExtra(Home.OFFER_CONTENT)!!, intent.getStringExtra(Home.ENTER_PATH)!!)
        supportFragmentManager.beginTransaction().add(R.id.detail_fragment, packageFragment).commit()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        return when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.keyCode == KeyEvent.KEYCODE_BACK || event.keyCode == KeyEvent.KEYCODE_BUTTON_B) {
                    finish()
                    false
                } else
                    return packageFragment.onKeyDown(event.keyCode, event)
            }
            else -> {
                false
            }
        }
    }

}