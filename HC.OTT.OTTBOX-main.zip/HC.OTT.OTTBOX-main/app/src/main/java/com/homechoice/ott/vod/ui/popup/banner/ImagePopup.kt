package com.homechoice.ott.vod.ui.popup.banner

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogBannerImageBinding
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.event.Event
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.ui.popup.PopupEvent
import kotlinx.android.synthetic.main.dialog_banner_image.*

class ImagePopup : Dialog {
    private var binding: DialogBannerImageBinding

    constructor(ctx: Context, item: CategoryItem, event: PopupEvent) : super(ctx, R.style.Theme_Design_NoActionBar) {
        this.binding = DialogBannerImageBinding.inflate(LayoutInflater.from(ctx))
        val dialog = this
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setContentView(binding.root)
        if (item.linkType == "none") {
            binding.btnDetail.visibility = View.GONE
        } else {
            binding.btnDetail.setOnClickListener {
                event.onClick(dialog, BtnLabel.OK)
            }
        }
        binding.btnClose.setOnClickListener {
            dismiss()
        }
        if (item.popupImgUrl != "") {
            Glide.with(ctx).load(item.popupImgUrl).placeholder(R.drawable.popup_banner_big_d).into(banner_image)
        }
        show()
    }

    constructor(ctx: Context, item : Event, event: PopupEvent) : super(ctx, R.style.Theme_Design_NoActionBar) {
        this.binding = DialogBannerImageBinding.inflate(LayoutInflater.from(ctx))
        val dialog = this
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setContentView(binding.root)
        if (item.linkType == "none") {
            binding.btnDetail.visibility = View.GONE
        } else {
            binding.btnDetail.setOnClickListener {
                event.onClick(dialog, BtnLabel.OK)
            }
        }
        binding.btnClose.setOnClickListener {
            dismiss()
        }
        if (item.popupImgUrl != "") {
            Glide.with(ctx).load(item.popupImgUrl).placeholder(R.drawable.popup_banner_big_d).into(banner_image)
        }
        show()
    }
}