package com.homechoice.ott.vod.ui.popup.auth

import android.app.Dialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.InputFilter
import android.text.InputFilter.LengthFilter
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager.LayoutParams
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.DialogLoginBinding
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.AuthUtil
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONObject
import java.util.regex.Pattern


class LoginPopupView(ctx: Context, login: Login, event: PopupEvent) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {
    private var binding: DialogLoginBinding = DialogLoginBinding.inflate(LayoutInflater.from(ctx))
    private var model: LoginPopupViewModel = LoginPopupViewModel(login)
    private var isSuccess: Boolean = false
    private var qrUpdateJob: Job? = null

    init {
        val dialog = this

        val appLink = "https://ochoice.page.link/Tbeh"
        val appQrBitmap = AuthUtil.generateQRCode(appLink)
        binding.appQr?.setImageBitmap(appQrBitmap)

        //QR 키 발급
        var qrNum: String = AuthUtil.generateRandomCode().toString()
        var terminalKey = login.terminalKey
        //인증서버의 스펙정의
        val qrLoginMessage =
            "{\"event\":\"addNewDevice\", \"data\": {\"terminalKey\":\"${terminalKey}\", \"code\": ${qrNum}}}"
        //QR code 이미지 생성시 "tv/" 붙히는 이유는 모바일앱에서 QR스캔시 직원/티비로그인 나누어 사용하도록 처리돠어 있음
        var grBitmapcode = AuthUtil.generateQRCode("tv/${qrNum.toString()}")
        //QR로그인 수행
        performQRLogin(ctx, qrLoginMessage, event, dialog)

        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        setCancelable(false)

        binding.apply {
            viewModel = model
        }

        setContentView(binding.root)

//        if (login.isAdult)
//            binding.loginNoticeText?.visibility = View.VISIBLE

        binding.loginIdInput.setContainer(binding.loginIdInput)
        binding.loginPwInput.setContainer(binding.loginPwInput)
        binding.loginQr?.setImageBitmap(grBitmapcode) //로그인 qr 추가

        binding.loginIdInput.setOnClickListener {
            Logger.Log(Log.DEBUG, this, "loginIdInputLayout setOnClickListener")
//            binding.loginIdInput.move(-50F)
            binding.loginIdInput.requestFocus()
            imm.showSoftInput(binding.loginIdInput, InputMethodManager.SHOW_IMPLICIT)
        }

        binding.loginIdInput.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_NEXT) {
                binding.loginPwInput.requestFocus()
                binding.loginIdInput.move(0F)
                true
            } else {
                false
            }
        }

        binding.loginPwInput.setOnEditorActionListener { _, action, _ ->
            var handled = false
            Logger.Log(Log.DEBUG, this, "loginPwInput setOnKeyListener action $action")
            if (action == EditorInfo.IME_ACTION_NEXT) {
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
//                imm.showSoftInput(binding.loginPwInput, 0)
                binding.btnOk.requestFocus()
                binding.loginPwInput.move(0F)
                handled = true
            }
            handled
        }

        binding.btnOk.setOnClickListener {
            STBAgent.linkedHomeChoice = false
            val memberId = binding.loginIdInput.text.toString()
            val memberPw = binding.loginPwInput.text.toString()

            if (memberId.isNotEmpty() && memberPw.isNotEmpty()) {
                val forceLogin = true //강제 로그인 처리
                login.forceLogin = true
                STBAgent.login(
                    context,
                    memberId,
                    memberPw,
                    binding.checkBox.isSelected,
                    login.forceLogin,
                    object : LoginEvent {
                        override fun onFailure() {
                            showPopup(CODE.NONE)
                        }

                        override fun onAccount(isForce: Boolean) {
                            if (isForce) {
                                event.onClick(dialog, BtnLabel.SUCCESS)
                            }
                        }

                        override fun onContinue(code: Int) {
                            Logger.Log(Log.DEBUG, this, "onContinue : $code")
                            when (code) {
                                CODE.UNAUTHORIZED -> {
                                    binding.warnText.text = " 등록되지 않은 아이디이거나 잘못된 비밀번호 입니다."
                                    binding.warnText.visibility = View.VISIBLE
                                }

                                CODE.LOGIN_CANCEL -> {
                                    event.onClick(dialog, BtnLabel.CANCEL)
                                }

                                else -> showPopup(code)
                            }
                        }
                    })
            }
        }

        binding.btnCancel.setOnClickListener {
            event.onClick(dialog, BtnLabel.BACK)
            dismiss()
        }

        // safe calls
//        binding.btnFind?.setOnClickListener {
//            UserInfoFindPopupView(ctx, Phone(head = "아이디/비밀번호 찾기", body = "아이디/비밀번호를 찾기 위해 가입 시 \n등록한 휴대폰 번호를 입력해 주세요.\n \n "),
//                event = object : PopupEvent {
//                    override fun onClick(d: Dialog, btn: String) {
//                        vIndex = 0
//                        binding.loginIdInput.requestFocus()
//                        d.dismiss()
//                    }
//                })
//        }

        binding.checkBox.isSelected = CMBApp.prefs.isBoolean("auto_login", false)

        setOnKeyListener { _, kCode, kEvent ->
            Logger.Log(
                Log.DEBUG,
                this,
                "setOnKeyListener $kCode / kEvent.action: ${kEvent.action} / currentFocus:${currentFocus?.id}"
            )
            var result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        when (currentFocus) {
                            binding.btnOk -> binding.loginPwInput.requestFocus()
                            binding.loginPwInput -> binding.loginIdInput.requestFocus()
                            binding.loginIdInput -> binding.btnCancel.requestFocus()
                        }
                        result = true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        when (currentFocus) {
                            binding.btnCancel -> binding.loginIdInput.requestFocus()
                            binding.loginIdInput -> binding.loginPwInput.requestFocus()
                            binding.loginPwInput -> binding.btnOk.requestFocus()
                        }
                        result = true
                    }

                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        when (currentFocus) {
                            binding.loginIdInput -> binding.loginIdInput.moveCursorLeft()
                        }
                        result = true
                    }

                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        when (currentFocus) {
                            binding.loginIdInput -> binding.loginIdInput.moveCursorRight()
                        }
                        result = true
                    }
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        event.onClick(dialog, BtnLabel.BACK)
                        dismiss()
                    }
                }
            } else {
                when (kCode) {
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_DPAD_CENTER, 96 -> {
                    }
                }
            }
            Logger.Log(Log.INFO, this, "onKeyDown $kCode / result:$result")
            result
        }

        binding.loginIdInput.requestFocus()
        show()

        qrUpdateJob = CoroutineScope(Dispatchers.Main).launch {
            while (isActive) {
                delay(120000) // 2분 대기
                // 새 QR 코드 번호를 여기서 생성합니다.
                val newQRNum = AuthUtil.generateRandomCode().toString()
                // IO 스레드에서 서버와의 통신을 처리합니다.
                withContext(Dispatchers.IO) {
                    val newQRLoginMessage =
                        "{\"event\":\"addNewDevice\", \"data\": {\"terminalKey\":\"${terminalKey}\", \"code\": $newQRNum}}"
                    performQRLogin(getContext(), newQRLoginMessage, event, dialog)
                }
                // Main 스레드에서 UI를 업데이트합니다. 새로운 QR 코드 생성 로직을 여기에 포함시킵니다.
                val newQRCodeBitmap = withContext(Dispatchers.IO) {
                    AuthUtil.generateQRCode("tv/$newQRNum")
                }
                binding.loginQr?.setImageBitmap(newQRCodeBitmap)
                if(isSuccess){
                    qrUpdateJob?.cancel()
                    break
                }
            }
        }

    }


    private fun init() {
        binding.loginIdInput.setText("")
        binding.loginPwInput.setText("")
        binding.loginIdInput.requestFocus()
    }

    private fun showPopup(code: Int) {
        PopupAgent.showNormalPopup(
            context,
            PopupType.getErrorType(
                TYPE.AUTH,
                code
            ),
            object : PopupEvent {
                override fun onClick(d: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.OK -> {
                            init()
                            d.dismiss()
                        }
                    }
                }
            })
    }

    private fun showPopup(code: Int, errorStr: String) {
        PopupAgent.showNormalPopup(
            context,
            PopupType.getErrorType(
                TYPE.AUTH,
                code,
                errorStr
            ),
            object : PopupEvent {
                override fun onClick(d: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.OK -> {
                            init()
                            d.dismiss()
                        }
                    }
                }
            })
    }

    private fun setInputFilter(editText: EditText, i: Int) {
        editText.filters = arrayOf(LengthFilter(i),
            InputFilter { charSequence, i, i2, spanned, i3, i4 ->
                if (!Pattern.compile("^[0-9]*$").matcher(charSequence).matches()) {
                    ""
                } else null
            })
    }

    private fun EditText.moveCursorLeft() {
        val position = selectionStart
        if (position > 0) {
            setSelection(position - 1)
        }
    }

    private fun EditText.moveCursorRight() {
        val position = selectionStart
        if (position < text.length) {
            setSelection(position + 1)
        }
    }

    private fun isKeyboardVisible(): Boolean {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.isAcceptingText
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            // Dialog가 완전히 표시된 후에 포커스를 요청
            binding.loginIdInput.requestFocus()
        }
    }

    /**
     * QR 로그인
     */
    private fun performQRLogin(
        ctx: Context,
        qrLoginMessage: String,
        event: PopupEvent,
        dialog: Dialog
    ) {
        val appActionMode = CMBApp.prefs.getString(
            "app_mode",
            CMBApp.RES.getString(R.string.app_mode)
        )//pref에서 설정된 앱의 실행 모드
        val authUri = Auth.AuthServerUri

        val client = OkHttpClient()
        val request = Request.Builder().url(authUri).build()
        val webSocketListener = object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                super.onOpen(webSocket, response)
                webSocket.send(qrLoginMessage)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                // 서버로부터 응답을 받았을 때의 처리
                val responseObj = JSONObject(text)
                val memberId = responseObj.getString("memberId")
                val memberPw = responseObj.getString("memberPw")

                if (memberId.isNotEmpty() && memberPw.isNotEmpty()) {
                    val forceLogin = true //강제 로그인 처리
                    // QRlogin시 패스워드가 암호화 처리되어 있음 linkedHomechoie true 하면 STBagent.Login 함수에서 패스워드를 암호화 하지 않음
                    STBAgent.autoQrLogin = true
                    STBAgent.login2(
                        context,
                        memberId,
                        memberPw,
                        binding.checkBox.isSelected,
                        true,
                        object : LoginEvent {
                            override fun onFailure() {
                                showPopup(CODE.NONE)
                            }

                            override fun onAccount(isForce: Boolean) {
                                if (isForce) {
                                    isSuccess = true
                                    event.onClick(dialog, BtnLabel.SUCCESS)
                                    dismiss()
                                    webSocket.close(1000, null) // 성공 후 웹소켓 닫기

                                    STBAgent.saveData(context, memberId, memberPw)
                                }
                            }

                            override fun onContinue(code: Int) {
                                Logger.Log(Log.DEBUG, this, "onContinue : $code")
                                when (code) {
                                    CODE.UNAUTHORIZED -> {
                                        binding.warnText.text = " 등록되지 않은 아이디이거나 잘못된 비밀번호 입니다."
                                        binding.warnText.visibility = View.VISIBLE
                                    }

                                    CODE.LOGIN_CANCEL -> {
                                        event.onClick(dialog, BtnLabel.CANCEL)
                                    }

                                    else -> showPopup(code)
                                }
                            }
                        })
                    STBAgent.autoQrLogin = false
                }

                // 추가적인 로그인 성공 처리...
                if (isSuccess) {
                    qrUpdateJob?.cancel() // 로그인 성공 시 QR 업데이트 작업 취소
                    // 로그인 성공 후 처리 로직...
                }
            }

            override fun onFailure(
                webSocket: WebSocket,
                t: Throwable,
                response: okhttp3.Response?
            ) {
                // 네트워크 오류 등의 실패 처리
                t.printStackTrace()
            }
        }
        // 웹소켓 연결
        val webSocket = client.newWebSocket(request, webSocketListener)
    }
}