package com.homechoice.ott.vod.ui.my.notice

import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.homechoice.ott.vod.R

import com.homechoice.ott.vod.databinding.ItemWishListBinding
import com.homechoice.ott.vod.model.wish.WishItem
import com.homechoice.ott.vod.util.Logger

class WishListAdapter(var logListLayout: LinearLayout, private var items: ArrayList<WishItem>, private val actionHandler: Handler) {

    private var viewList: ArrayList<ViewHolder> = arrayListOf()

    init {
        Logger.Log(Log.DEBUG, this, "onBindViewHolder init : ${items.size}")

        for (index in items.indices) {
            onBindViewHolder(onCreateViewHolder(logListLayout, index), index)
        }
        if (viewList.size > 0)
            actionHandler.obtainMessage(0, 0, 0, viewList[0]).sendToTarget()
    }

    private fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.apply {
            bind(item)
        }
        viewList.add(holder)
        logListLayout.addView(holder.binding.root)
    }

    fun focus(cur: Int, pre: Int) {
        if (cur >=0 && cur < viewList.size) {
            viewList[cur].focus()
            if (pre > -1 && pre < viewList.size) {
                viewList[pre].unfocus()
            } else {
                Logger.Log(Log.ERROR, this, "Invalid index for focus(): $cur")
            }
        }
//        viewList[cur].focus()
//        if (pre > -1)
//            viewList[pre].unfocus()
    }

    fun unfocus(cur: Int) {
        viewList[cur].unfocus()
    }

    fun removeItem(index: Int) {
        logListLayout.removeViewAt(index)
        items.removeAt(index)
        viewList.removeAt(index)
        actionHandler.obtainMessage(2).sendToTarget()
    }

    private fun onCreateViewHolder(parent: ViewGroup, index: Int): ViewHolder {
        val binding = ItemWishListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding, actionHandler, index)
    }

    class ViewHolder(val binding: ItemWishListBinding, private val actionHandler: Handler, val index: Int) {
        lateinit var wishItem: WishItem
        fun bind(item: WishItem) {
            wishItem = item
            binding.apply {
                log = WishListViewModel(item)
            }
            binding.executePendingBindings()
        }

        fun focus() {
            Logger.Log(Log.DEBUG, this, "focus adapterPosition $index")
            binding.myWishPosterFrame?.requestFocus()
            binding.myWishPosterFrame?.setBackgroundResource(R.drawable.border_red2)
            actionHandler.obtainMessage(0, index, 0, this).sendToTarget()
        }

        fun unfocus() {
            Logger.Log(Log.DEBUG, this, "unfocus adapterPosition $index")
            binding.myWishPosterFrame?.clearFocus()
            binding.myWishPosterFrame?.setBackgroundResource(R.color.transparent)
        }

        fun select() {
            Logger.Log(Log.DEBUG, this, "select")
            binding.myWishPosterFrame?.isSelected = true
            actionHandler.obtainMessage(1).sendToTarget()
        }

        fun unSelect() {
            Logger.Log(Log.DEBUG, this, "unSelect")
            binding.myWishPosterFrame?.isSelected = false
        }
    }

}