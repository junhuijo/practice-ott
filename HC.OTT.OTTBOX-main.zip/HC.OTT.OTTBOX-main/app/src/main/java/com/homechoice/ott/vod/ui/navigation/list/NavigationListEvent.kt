package com.homechoice.ott.vod.ui.navigation.list

interface NavigationListEvent {
    fun focusChange()
    fun plusLineChange()
    fun minusLineChange()
}