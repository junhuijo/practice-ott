package com.homechoice.ott.vod.ui.popup.normal

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.widget.TextView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogThreeLineBinding
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.PopupViewModel
import com.homechoice.ott.vod.ui.popup.component.PopupButtonView
import com.homechoice.ott.vod.util.Logger

class ThreeLinePopupView(ctx: Context, type: PopupType.NormalPopupType, event: PopupEvent) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {
    private var binding: DialogThreeLineBinding
    private var model: PopupViewModel
    private var btns: ArrayList<PopupButtonView> = arrayListOf()

    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        binding = DialogThreeLineBinding.inflate(LayoutInflater.from(ctx))
        model = PopupViewModel(type)
        binding.apply {
            viewModel = model
        }
        setContentView(binding.root)

        for (item in model.content.value?.buttons!!) {
            Logger.Log(Log.DEBUG, this, "item ${item.label}")
            val btnView = PopupButtonView(
                ctx,
                binding.btnLayout,
                item.label
            )
            btns.add(btnView)
            btnView.btn.setOnClickListener {
                event.onClick(this, (it as TextView).text.toString())
            }
        }
        if (type.timer > 0)
            Handler().postDelayed({
                dismiss()
                event.onClick(this, BtnLabel.OK)
            }, type.timer * 1000L)

        if (btns.isNotEmpty())
            btns.first().focus()
    }

}