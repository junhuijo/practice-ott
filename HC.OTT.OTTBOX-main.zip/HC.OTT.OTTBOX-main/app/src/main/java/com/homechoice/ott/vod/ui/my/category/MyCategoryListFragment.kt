package com.homechoice.ott.vod.ui.my.category

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.Category
import com.homechoice.ott.vod.agent.CategoryAgent
import com.homechoice.ott.vod.agent.CategoryTarget
import com.homechoice.ott.vod.agent.Constant
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.SessionState
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.io.PVSClient
import com.homechoice.ott.vod.model.ResponseContentGroup
import com.homechoice.ott.vod.model.response.ResponseAdultCheckState
import com.homechoice.ott.vod.model.response.ResponseCategoryList
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.ui.detail.DetailFragment
import com.homechoice.ott.vod.ui.home.HomeActivity2
import com.homechoice.ott.vod.ui.home.category.CategoryView
import com.homechoice.ott.vod.ui.my.MyActivity2
import com.homechoice.ott.vod.ui.my.notice.NoticeListFragment
import com.homechoice.ott.vod.ui.navigation.navigator.NavigatorModel
import com.homechoice.ott.vod.ui.navigation.view.NavigationData
import com.homechoice.ott.vod.ui.navigation.view.NavigationEvent
import com.homechoice.ott.vod.ui.navigation.view.NavigationModel
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.ui.search.SearchActivity
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.dialog_hidden.terminalKey
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * @param targetId -> 왼쪽 카테고리 리스트를 가져오기 위한 Category ID
 * @param targetIndex -> 왼쪽 카테고리 포커스 인덱스
 * @param targetInfo -> 오른쪽 메뉴 노출 시 텝 이동을 위한 Category ID
 * */
class MyCategoryListFragment(val activityHandler: Handler, private val targetId: Int = 0, val targetIndex: Int = 0, targetInfo: String) :
    NavigationView2() {

    private lateinit var category: Category
    private lateinit var viewHolder: MyCategoryView
    private lateinit var subViewHolder: CategoryListAdapter.ViewHolder
    private lateinit var headTextView: TextView
    private lateinit var userNameTextView: TextView

    private lateinit var rightRecyclerView: RecyclerView
    private lateinit var rightAdapter: CategoryListAdapter
    private lateinit var actionHandler: Handler

    private lateinit var linearLayout: LinearLayout

    private var categoryList: ArrayList<Category> = arrayListOf()
    private var viewList: ArrayList<MyCategoryView> = arrayListOf()
    private var categoryViewList = mutableMapOf<Int, CategoryView>()

    private var backPosition: Int = 0

    @SuppressLint("InflateParams", "SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_my_category_list2, null)

        headTextView = view.findViewById(R.id.head)
        linearLayout = view.findViewById(R.id.category_list)
        rightRecyclerView = view.findViewById(R.id.sub_category_list)
        userNameTextView = view.findViewById(R.id.login_username)

        (STBAgent.userName.takeIf { it.isNotEmpty() })?.let {
            userNameTextView.text = "${it}님"
        } ?: run {
            userNameTextView.text = getString(R.string.mycategory_login_username)
        }

        actionHandler = Handler {

            when (it.what) {
                0 -> {
                    viewHolder = it.obj as MyCategoryView
                    category = viewHolder.category
                    activityHandler.obtainMessage(0, category).sendToTarget()
                }
                1 -> {
                    viewHolder = it.obj as MyCategoryView
                    category = viewHolder.category
                    rightAdapter.update(CategoryAgent.getMyCategoryList(category.id))

                    activityHandler.obtainMessage(3, category).sendToTarget()
                }
                2 -> {
                    subViewHolder = it.obj as CategoryListAdapter.ViewHolder
                    category = viewHolder.category
                    activityHandler.obtainMessage(0, category).sendToTarget()
                }
                3 -> {
                    subViewHolder = it.obj as CategoryListAdapter.ViewHolder
                    category = viewHolder.category
                    rightAdapter.update(CategoryAgent.getMyCategoryList(category.id))
                }
            }
            true
        }

        Logger.Log(Log.DEBUG, this, "targetId: $targetId")

        categoryList = CategoryAgent.getMyCategoryList(targetId)

        if (categoryList.size > 0) {
            setLeftMenu(categoryList, targetIndex)
            rightAdapter = CategoryListAdapter(CategoryAgent.getMyCategoryList(100), actionHandler)
            rightRecyclerView.adapter = rightAdapter
        } else {
            // 장애팝업 처리
            Logger.Log(Log.DEBUG, this, "장애팝업 처리 targetId: $targetId")
        }

        return view
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (!category.leaf) {
                    backPosition = controller.getCurIndex()
                    setLeftMenu(rightAdapter.getItems(), 0)
                } else {
                    activityHandler.obtainMessage(1, category).sendToTarget()
                }
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (category.parentId > 0) {
                    val parent = CategoryAgent.getMyCategory(category.parentId)
                    val list = CategoryAgent.getMyCategoryList(parent?.parentId!!)
                    setLeftMenu(list, parent.displayOrder)
                }
                true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                controller.decrease()
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                controller.increase()
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                true
            }
            else -> false
        }
    }

    override fun active() {
    }

    private fun setLeftMenu(list: ArrayList<Category>, pos: Int) {
        linearLayout.removeAllViews()
        viewList.clear()

        for (index in list.indices) {
            viewList.add(MyCategoryView(context!!, linearLayout, list[index], index, actionHandler))
        }
        if (viewList.size > 0)
            viewList[pos].focus(false)

        setModel(list, pos)
    }

    private fun setModel(list: ArrayList<Category>, index: Int) {
        headTextView.text = CategoryAgent.getMyCategory(list[index].parentId)?.name

        setModel(
            NavigationModel(
                NavigationData(
                    curIndex = index,
                    rightFixedIndex = list.size - 1,
                    visibleThreshold = list.size,
                    totalCount = list.size,
                    startIndex = 0,
                    visibleIndex = 0,
                    isEmpty = true
                ).build(
                    list
                )
            ), object : NavigationEvent {
                override fun rightLineChange(position: Int) {
                    Logger.Log(Log.DEBUG, this, "rightLineChange position:$position")
                }

                override fun leftLineChange() {
                    Logger.Log(Log.DEBUG, this, "leftLineChange")
                }

                override fun lastLineChange() {
                    Logger.Log(Log.DEBUG, this, "lastLineChange")
                }

                override fun firstLineChange() {
                    Logger.Log(Log.DEBUG, this, "firstLineChange")
                }

                override fun focusChange() {
                    Logger.Log(Log.DEBUG, this, "focusChange")
                    viewList[controller.getCurIndex()].focus(false)
                    if (controller.getPreIndex() > -1)
                        viewList[controller.getPreIndex()].unfocus()
                }

                override fun addEmptyRow() {
                    Logger.Log(Log.DEBUG, this, "addEmptyRow")
                }

                override fun lineChange(isDown: Boolean) {
                    Logger.Log(Log.DEBUG, this, "lineChange isDown :$isDown")
                }
            }
        )
    }

    fun update(){
        viewList.forEach { categoryView ->
            categoryView.update()
        }
    }

    fun focus() {
        viewList[controller.getCurIndex()].focus(true)
    }

    fun select(){
        viewList[controller.getCurIndex()].select()
    }

    override fun setVisible(visible: Int) {
        linearLayout.visibility = visible
    }

    override fun lateActive() {

    }

    fun back(){
        if (category.parentId > 0) {
            val parent = CategoryAgent.getMyCategory(category.parentId)
            val list = CategoryAgent.getMyCategoryList(parent?.parentId!!)
            setLeftMenu(list, parent.displayOrder)
        }
    }
}