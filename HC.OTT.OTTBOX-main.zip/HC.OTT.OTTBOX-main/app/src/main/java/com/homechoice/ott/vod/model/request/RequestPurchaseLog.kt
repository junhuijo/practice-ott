package com.homechoice.ott.vod.model.request

data class RequestPurchaseLog(
    val terminalKey: String,
    val purchaseId: Long,
    val isVisible: Boolean
)
