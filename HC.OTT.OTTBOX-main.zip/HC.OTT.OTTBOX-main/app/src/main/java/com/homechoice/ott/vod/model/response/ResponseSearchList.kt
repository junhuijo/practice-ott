package com.homechoice.ott.vod.model.response

import com.homechoice.ott.vod.model.search.SearchItem

data class ResponseSearchList(
    val transactionId: String = "",
    val errorString: String = "",
    val sessionState: String = "",
    val totalCount: Int = 0,
    val searchItemList: List<SearchItem>
)