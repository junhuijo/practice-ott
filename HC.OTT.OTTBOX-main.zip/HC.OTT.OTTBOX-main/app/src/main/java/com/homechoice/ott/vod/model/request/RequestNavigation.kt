package com.homechoice.ott.vod.model.request

data class RequestNavigation(
    val terminalKey: String,
    val assetType: String,
    val assetId: Long,
    val enterPath: String
)