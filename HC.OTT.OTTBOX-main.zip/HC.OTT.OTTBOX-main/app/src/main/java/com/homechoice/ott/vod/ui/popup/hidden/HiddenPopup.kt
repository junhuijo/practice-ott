package com.homechoice.ott.vod.ui.popup.hidden

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.core.content.ContextCompat.startActivity
import com.homechoice.ott.vod.BuildConfig
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.databinding.DialogHiddenBinding
import com.homechoice.ott.vod.io.RetrofitClient
import com.homechoice.ott.vod.ui.MainActivity
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@SuppressLint("SetTextI18n")
class HiddenPopup(ctx: Context) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {

    private var binding: DialogHiddenBinding = DialogHiddenBinding.inflate(LayoutInflater.from(ctx))

    private var selectAppMode = ""

    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setContentView(binding.root)

        binding.btnClose.setOnClickListener {
            dismiss()
        }
        val data: Array<String> = CMBApp.RES.getStringArray(R.array.app_type)

        val appMode = CMBApp.prefs.getString("app_mode", CMBApp.RES.getString(R.string.app_mode))

        binding.textVersion.text = BuildConfig.VERSION_NAME
        binding.textAppCode.text = CMBApp.RES.getString(R.string.app_code)
        binding.switchLog.isChecked = (Logger.logMode)
        binding.switchLog.text = CMBApp.RES.getString(R.string.app_log_mode)
        binding.switchPackage.isChecked = (CMBApp.RES.getString(R.string.app_code) == "com.homechoice.ott.vod")
        binding.switchPackage.text = CMBApp.prefs.getString("app_code", CMBApp.RES.getString(R.string.app_code))
        binding.textMacAddress.text = STBAgent.getAndroidId(ctx)
        binding.terminalKey.text = MBSAgent.terminalKey


        binding.currentDescription.text = "MBS : ${RetrofitClient.BASE_URL} "

        binding.saveDescription.text =
            "MBS : ${getMBSServer(data, getAppModePos(data, appMode))} "

        val adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, data)

        binding.spinner.adapter = adapter

        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Logger.Log(Log.ERROR, this, "onItemSelected position:$position")
                binding.selectedDescription.text = "MBS : ${getMBSServer(data, position)}"

                selectAppMode = data[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        for (index in data.indices) {
            Logger.Log(Log.ERROR, this, "data[index] ${data[index]} / ${CMBApp.RES.getString(R.string.app_mode)}")
            if (data[index] == appMode) {
                binding.spinner.setSelection(index)
                break
            }
        }

        binding.switchPackage.setOnCheckedChangeListener { _, onSwitch ->
            CMBApp.prefs.setString("app_code", if (onSwitch) CMBApp.RES.getString(R.string.app_code) else "com.homechoice.ott.vod")
            binding.switchPackage.text = if (onSwitch) CMBApp.RES.getString(R.string.app_code) else "com.homechoice.ott.vod"
        }

        binding.switchLog.setOnCheckedChangeListener { _, onSwitch ->
            //  스위치가 켜지면
            Logger.logMode = onSwitch
            binding.switchLog.text = if (onSwitch) "on" else "off"
            RetrofitClient.init(RetrofitClient.BASE_URL)
            MBSAgent.init()
        }

        binding.textVersion.requestFocus()

        binding.btnDetail.setOnClickListener {
            if (selectAppMode != "") {
                Logger.Log(Log.ERROR, this, "selectAppMode:$selectAppMode")
                CMBApp.prefs.setString("app_mode", selectAppMode)

                GlobalScope.launch(Dispatchers.Default) {
                    delay(300)
                    val intent = Intent(ctx, MainActivity::class.java)
                    startActivity(ctx, intent, Bundle())
                    System.exit(0)
                }
            }
        }
        show()
    }

    private fun getAppModePos(data: Array<String>, mode: String): Int {
        var i = 0
        for (index in data.indices) {
            Logger.Log(Log.ERROR, this, "data[index] ${data[index]} / $mode")
            if (data[index] == mode) {
                i = index
                break
            }
        }
        return i
    }
    //필요없는 url제거
    fun getMBSServer(data: Array<String>, position: Int): String {
        var resourceId: Int = R.array.
        dev
        Logger.Log(Log.ERROR, this, "getMBSServer position:$position / ${data[position]}")
        when (data[position]) {
            "debug" -> {
                resourceId = R.array.debug
            }
            "prod" -> {
                resourceId = R.array.prod
            }
            "dev" -> {
                resourceId = R.array.dev
            }
        }
        val infos = CMBApp.RES.getStringArray(resourceId)
        return infos[0]
    }

}
