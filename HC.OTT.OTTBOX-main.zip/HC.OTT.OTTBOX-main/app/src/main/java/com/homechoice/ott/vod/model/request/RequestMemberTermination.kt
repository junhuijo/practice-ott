package com.homechoice.ott.vod.model.request

data class RequestMemberTermination(
    val terminalKey: String = ""
)
