package com.homechoice.ott.vod.ui.detail.series

import AgeGrade
import android.app.Dialog
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.android.exoplayer2.util.Log
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.ActivityChangeAgent
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import kotlinx.coroutines.delay


@Composable
fun SeriesScreen(context: Context, viewModel: SeriesViewModel) {
    val backgroundColorDetail by viewModel.backgroundColorDetail.collectAsState()
    val backgroundColorLike by viewModel.backgroundColorLike.collectAsState()
    val backgroundColorPlay by viewModel.backgroundColorPlay.collectAsState()
    val currentEpisode by viewModel.currentEpisode.collectAsState()
    val isLiked by viewModel.isLiked.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    val playerManager = remember { PlayerManager(context, viewModel) }
    val playButtonFocusRequester = FocusRequester()

    var isPlayButtonEnabled by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(500)
        playButtonFocusRequester.requestFocus()
        delay(200)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(450.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    BoxWithConstraints {
                        AsyncImage(
                            model = viewModel.series.value?.posterUrl,
                            contentDescription = "Series Poster",
                            modifier = Modifier
                                .fillMaxWidth()
                                .matchParentSize(),
                            contentScale = ContentScale.FillWidth,
                            alignment = Alignment.TopCenter
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color.Transparent,
                                            Color.Transparent,
                                            Color.Black,
                                            Color.Black
                                        )
                                    )
                                )
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color.Black,
                                            Color.Transparent,
                                            Color.Black
                                        ),
                                        endX = 0.45f * LocalDensity.current.density * LocalConfiguration.current.screenWidthDp
                                    )
                                )
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 24.dp, end = 24.dp, bottom = 45.dp),
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = viewModel.getFormattedEpisodeTitle(currentEpisode?.title),
                            fontSize = 23.sp,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .padding(top = 4.dp)
                        ) {
                            currentEpisode?.rating?.let { rating ->
                                AgeGrade(
                                    grade = rating,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = viewModel.getEpisodeInfo(currentEpisode),
                                color = Color.White,
                                modifier = Modifier.offset(y = (-1).dp),
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                        ) {
                            TextButton(
                                onClick = {
                                    if (isPlayButtonEnabled) {
                                        currentEpisode?.let { episode ->
                                            playerManager.processPlay(episode, skipOffset = false)
                                        }
                                        isPlayButtonEnabled = false
                                    }
                                },
                                enabled = isPlayButtonEnabled,
                                modifier = Modifier
                                    .weight(0.382f)
                                    .onFocusChanged { focusState ->
                                        viewModel.updateBackgroundColor(
                                            "play",
                                            focusState.isFocused
                                        )
                                    }
                                    .focusRequester(playButtonFocusRequester)
                                    .focusable()
                                    .background(
                                        color = backgroundColorPlay,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .height(40.dp)
                            ) {
                                Text(
                                    text = "▶ 재생하기",
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(2.dp))
                            TextButton(
                                onClick = {
                                    showDialog = true
                                },
                                modifier = Modifier
                                    .weight(0.309f)
                                    .onFocusChanged { focusState ->
                                        viewModel.updateBackgroundColor(
                                            "detail",
                                            focusState.isFocused
                                        )
                                    }
                                    .focusable()
                                    .background(
                                        color = backgroundColorDetail,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .height(40.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.detailbutton),
                                    contentDescription = "Detail Icon",
                                    modifier = Modifier
                                        .size(18.dp)
                                        .align(Alignment.CenterVertically)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "상세정보",
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(2.dp))
                            TextButton(
                                onClick = {
                                    currentEpisode?.let { episode ->
                                        viewModel.handleLikeAction(
                                            content = episode,
                                            isLike = !isLiked,
                                            onAdultContent = {
                                                ActivityChangeAgent.goToKidsLockMenu(context)
                                            },
                                            onSuccess = {
                                                if (!isLiked) {
                                                    PopupAgent.showOneLineNoBtn(
                                                        context,
                                                        PopupType.NormalPopupType.REG_ZZIM,
                                                        object : PopupEvent {
                                                            override fun onClick(d: Dialog, btn: String) {
                                                                viewModel.updateCurrentEpisode()
                                                            }
                                                        })
                                                } else {
                                                    viewModel.updateCurrentEpisode()
                                                }
                                            },
                                            onLoginRequired = {
                                                PopupAgent.showLoginPopup(context, object : LoginPopupEvent {
                                                    override fun onLogin(loginDialog: Dialog, btn: String) {
                                                        when (btn) {
                                                            BtnLabel.SUCCESS -> {
                                                                viewModel.handleLikeAction(
                                                                    content = episode,
                                                                    isLike = !isLiked,
                                                                    onAdultContent = {
                                                                        ActivityChangeAgent.goToKidsLockMenu(context)
                                                                    },
                                                                    onSuccess = {
                                                                        viewModel.updateCurrentEpisode()
                                                                    },
                                                                    onLoginRequired = {}
                                                                )
                                                            }
                                                            BtnLabel.CANCEL -> {
                                                                loginDialog.dismiss()
                                                            }
                                                        }
                                                    }
                                                })
                                            }
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .weight(0.309f)
                                    .onFocusChanged { focusState ->
                                        viewModel.updateBackgroundColor(
                                            "like",
                                            focusState.isFocused
                                        )
                                    }
                                    .focusable()
                                    .background(
                                        color = backgroundColorLike,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .height(40.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = if (isLiked) R.drawable.heart2 else R.drawable.heart),
                                    contentDescription = "heart icon",
                                    modifier = Modifier
                                        .size(
                                            width = if (isLiked) 15.dp else 15.dp,
                                            height = 15.dp
                                        )
                                        .align(Alignment.CenterVertically)
                                )
                                Spacer(modifier = Modifier.size(4.dp))
                                Text(text = " 찜하기", color = Color.White)
                            }
                        }
                    }
                }
                ContentList(
                    viewModel.contents,
                    Modifier.weight(1f),
                    viewModel,
                    playerManager
                )
            }
        }
    }
    if (showDialog) {
        currentEpisode?.let { episode ->
            SeriesPopupDialog(
                genre = episode.genre.orEmpty(),
                duration = episode.runTime.orEmpty(),
                rating = episode.rating.orEmpty(),
                synopsis = episode.synopsis.orEmpty(),
                director = episode.director.orEmpty(),
                cast = episode.actor?.split(",").orEmpty(),
                onDismiss = { showDialog = false }
            )
        }
    }

    LaunchedEffect(isPlayButtonEnabled) {
        if(!isPlayButtonEnabled) {
            delay(3000)
            isPlayButtonEnabled = true
        }
    }
}