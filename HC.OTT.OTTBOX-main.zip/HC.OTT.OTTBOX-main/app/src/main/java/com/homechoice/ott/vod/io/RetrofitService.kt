package com.homechoice.ott.vod.io;

import com.homechoice.ott.vod.model.HomeCategoryList
import com.homechoice.ott.vod.model.ResponseContentGroup
import com.homechoice.ott.vod.model.request.*
import com.homechoice.ott.vod.model.response.*
import retrofit2.Call
import retrofit2.http.*

interface RetrofitService {

    /**
     * 홈메뉴 / 카테고리 / 카테고리 아이템
     * */
    @GET("/mbs/mainCategoryList")
    fun homeCategoryList(
        @Query("terminalKey") terminalKey: String,
        @Query("includeAdult") includeAdult: Boolean,
        @Query("includeRrated") includeRrated: Boolean,
        @Query("needItem") needItem: Boolean
    ): Call<HomeCategoryList>

    @GET("/mbs/categoryList")
    fun getCategoryList(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("parentCategoryId") parentCategoryId: Int,
        @Query("needItem") needItem: Boolean,
        @Query("includeAdult") includeAdult: Boolean,
        @Query("includeRrated") includeRrated: Boolean,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseCategoryList>

    @GET("/mbs/siblingCategoryList")
    fun getSiblingCategoryList(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("categoryId") parentCategoryId: Int,
        @Query("needItem") needItem: Boolean,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseSiblingCategoryList>

    @GET("/mbs/categoryItemList")
    fun getCategoryItemList(
        @Query("terminalKey") terminalKey: String,
        @Query("transactionId") transactionId: String,
        @Query("categoryId") categoryId: Int,
        @Query("includeAdult") includeAdult: Boolean,
        @Query("includeRrated") includeRrated: Boolean,
        @Query("needItem") needItem: Boolean = true,
        @Query("startIdx") startIdx: Int = 1,
        @Query("pageSize") pageSize: Int = 0
    ): Call<ResponseCategoryItemList>

    @GET("/mbs/wishItemList")
    fun getWishItemList(
        @Query("terminalKey") terminalKey: String,
        @Query("transactionId") transactionId: String,
        @Query("isAdult") isAdult: Boolean,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseWishItemList>

    /**
     * 컨텐츠 그룹 / 시리즈
     * */
//    @GET("http://192.168.1.2:3000/mbs/contentGroup")
    @GET("/mbs/contentGroup")
    fun getContentGroup(
        @Query("terminalKey") terminalKey: String,
        @Query("contentGroupId") contentGroupId: Long,
        @Query("transcodingType") transcodingType: String,
        @Query("drmType") drmType: String
    ): Call<ResponseContentGroup>

    @GET("/mbs/series")
//    @GET("http://218.156.103.58/mbs/series")
    fun getSeries(
        @Query("terminalKey") terminalKey: String,
        @Query("seriesId") seriesId: Long,
    ): Call<ResponseSeries>

//    기존 series
//    @GET("/mbs/series")
////    @GET("http://218.156.103.58/mbs/series")
//    fun getSeries(
//        @Query("terminalKey") terminalKey: String,
//        @Query("seriesId") seriesId: Long,
//        @Query("needEpisode") needEpisode: Boolean,
//        @Query("transcodingType") transcodingType: String,
//        @Query("drmType") drmType: String
//    ): Call<ResponseSeries>

    @GET("/mbs/content")
    //@GET("http://3.35.8.88:3000/mbs/content")
    fun getContent(
        @Query("terminalKey") terminalKey: String,
        @Query("seriesId") seriesId: Long,
        @Query("episodeNo") episodeNo: Int,
        @Query("transcodingType") transcodingType: String,
        @Query("drmType") drmType: String
    ): Call<ResponseContent>

    /**
     * 재생 관련 API
     * */
    @GET("/mbs/playOffset")
    fun playOffset(
        @Query("terminalKey") terminalKey: String,
        @Query("contentId") contentId: Long,
        @Query("startDatetime") startDatetime: String,
        @Query("endDatetime") endDatetime: String
    ): Call<ResponsePlayOffset>

    @POST("/mbs/play-start")
    fun playStart(
        @Body playStart: RequestPlayStart
    ): Call<ResponsePlayStart>

    @POST("/mbs/play-stop")
    fun playStop(
        @Body playStop: RequestPlayStop
    ): Call<ResponseNoBody>

    @POST("/mbs/reviewRating")
    fun reviewRating(
        @Body reviewRating: RequestReviewRating
    ): Call<ResponseNoBody>

    /**
     * 세션, 회원관리 관련 API
     * */
    @POST("/mbs/session-auth")
    fun sessionAuth(
        @Body auth: RequestAuth
    ): Call<ResponseAuth>

    @POST("/mbs/member-register")
    fun postMemberRegister(
        @Body mobile: RequestMobile
    ): Call<ResponseRegister>

    @FormUrlEncoded
    @POST("/mbs/member-register-confirm")
    fun memberRegisterConfirm(
        @Field("terminalKey") terminalKey: String,
        @Field("registerTransactionId") registerTransactionId: String
    ): Call<ResponseNoBody>

    @PUT("/mbs/member-register")
    fun putMemberRegister(
        @Body mobile: RequestMobile
    ): Call<ResponseNoBody>

    @POST("/mbs/member-termination")
    fun memberTermination(
        @Body memberTermination: RequestMemberTermination
    ): Call<ResponseNoBody>

    @POST("/mbs/memberAccount-find")
    fun memberAccountFind(
        @Body mobile: RequestMobile
    ): Call<ResponseNoBody>

    @POST("/mbs/login")
    fun login(
        @Body login: RequestLogin
    ): Call<ResponseLogin>

    @POST("/mbs/login/v2")
    fun loginV2(
        @Body login: RequestLogin
    ): Call<ResponseLogin>

    @POST("/mbs/logout")
    fun logout(@Body mobile: RequestLogout): Call<ResponseNoBody>

    @FormUrlEncoded
    @GET("/mbs/adultCheckState")
    fun adultCheckState(@Query("isCheck") isCheck: Int): Call<ResponseNoBody>

    @POST("/mbs/adult-auth")
    fun adultAuth(
        @Field("terminalKey") terminalKey: String,
        @Field("mobileNumber") mobileNumber: String
    ): Call<ResponseAdultAuth>

    @POST("/mbs/adult-auth-check")
    fun adultAuthCheck(
        @Body adultAuthCheck: RequestAdultAuthCheck
    ): Call<ResponseAdultAuth>

    @POST("/mbs/wishItem")
    //@POST("http://3.35.8.88:3000/mbs/wishItem")
    fun wishItem(
        @Body wishItem: ResponseWishItem
    ): Call<ResponseNoBody>

    @POST("/mbs/adultPw-check")
    fun adultPwCheck(
        @Body adultPwCheck: RequestAdultPwCheck
    ): Call<ResponseNoBody>

    @POST("/mbs/adultPw-modify")
    fun adultPwModify(
        @Body adultPwModify: RequestAdultPwModify
    ): Call<ResponseNoBody>

    @POST("/mbs/pw-replace")
    fun pwReplace(
        @Body pwReplace: RequestPwReplace
    ): Call<ResponseNoBody>

    @GET("/mbs/v3/checkPermission")
    fun checkPermission()

    @FormUrlEncoded
    @POST("/mbs/linkPayment-start")
    fun linkPaymentStart(
        @Field("terminalKey") terminalKey: String,
        @Field("mobileNumber") mobileNumber: String,
        @Field("offerId") offerId: Long,
        @Field("purchaseType") purchaseType: Int,
        @Field("price") price: Int
    ): Call<ResponsePurchase>

    @FormUrlEncoded
    @POST("/mbs/linkPayment-confirm")
    fun linkPaymentConfirm(
        @Field("terminalKey") terminalKey: String,
        @Field("offerId") offerId: Long
    ): Call<ResponseNoBody>

    @POST("/mbs/easyPayment")
//    @POST("http://192.168.1.2:3000/mbs/easyPayment")
    fun easyPayment(
        @Body easyPayment: RequestEasyPayment
    ): Call<ResponsePurchase>

    @POST("/mbs/payment-cancel")
    fun paymentCancel(
        @Body paymentCancel: RequestPaymentCancel
    ): Call<ResponseNoBody>


    @POST("/mbs/navigation")
    fun navigation(
        @Body navigation: RequestNavigation
    ): Call<ResponseNoBody>

    //@GET("http://3.35.8.88:3000/mbs/recommend")
    @GET("/mbs/recommend")
    fun recommend(
        @Query("terminalKey") terminalKey: String,
        @Query("srcType") srcType: String,
        @Query("srcId") srcId: Long,
        @Query("includeAdult") includeAdult: Boolean,
        @Query("includeRrated") includeRrated: Boolean,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseCategoryItemList>

    @GET("/mbs/purchaseLogList")
    fun purchaseLogList(
        @Query("terminalKey") terminalKey: String,
        @Query("startDatetime") startDatetime: String,
        @Query("endDatetime") endDatetime: String,
        @Query("isAdult") isAdult: Boolean,
        @Query("groupType") groupType: String,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponsePurchaseLogList>

    @GET("/mbs/purchaseLogList")
    fun purchaseLogList(
        @Query("terminalKey") terminalKey: String,
        @Query("startDatetime") startDatetime: String,
        @Query("endDatetime") endDatetime: String,
        @Query("isAdult") isAdult: Boolean,
        @Query("groupTypes") groupTypes: ArrayList<String>,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponsePurchaseLogList>

    @PUT("/mbs/purchaseLog")
    fun purchaseLog(
        @Body purchaseLog: RequestPurchaseLog
    ): Call<ResponseNoBody>

    @PUT("/mbs/serviceLog")
    fun serviceLog(
        @Body serviceLog: RequestServiceLog
    ): Call<ResponseNoBody>

    @POST("/mbs/card-replace")
    fun postCardReplace(
        @Body cardReplace: RequestCardReplace
    ): Call<ResponseNoBody>

    @GET("/mbs/card")
    fun getCard(
        @Query("terminalKey") terminalKey: String
    ): Call<ResponseCardName>

    @GET("/mbs/serviceLogList")
    fun serviceLogList(
        @Query("terminalKey") terminalKey: String,
        @Query("isAdult") isAdult: Boolean,
        @Query("startDatetime") startDatetime: String,
        @Query("endDatetime") endDatetime: String,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseServiceLogList>

    @GET("/mbs/noticeList")
    fun noticeList(
        @Query("terminalKey") terminalKey: String,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseNoticeList>

    @GET("/mbs/faqList")
    fun faqList(
        @Query("terminalKey") terminalKey: String,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseFaqList>

    @GET("/mbs/pointFaqList")
    fun pointFaqList(
        @Query("terminalKey") terminalKey: String,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseFaqList>

    //@GET("http://172.30.1.18:3000/mbs/offerContent")
    @GET("/mbs/offerContent")
    fun offerContent(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("offerId") offerId: Long
    ): Call<ResponseOfferContent>

    @GET("/mbs/recommendListForSearch")
//    @GET("http://218.156.103.190:3000/mbs/recommend")
    fun recommendListForSearch(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseCategoryItemList>

    //    @GET("http://192.168.1.2:3000/mbs/search")
    @GET("/mbs/search")
    fun search(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("searchWord") searchWord: String,
        @Query("includeAdult") includeAdult: Boolean,
        @Query("includeRrated") includeRrated: Boolean,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseSearchList>

    @GET("/mbs/keywordForSearch")
    fun keywordForSearch(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("searchWord") searchWord: String,
        @Query("includeAdult") includeAdult: Boolean,
        @Query("count") count: Int
    ): Call<ResponseKeyWord>

    //        @GET("http://218.156.103.190:3000/mbs/eventList")
    @GET("/mbs/eventList")
    fun eventList(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("usePushPopup") usePushPopup: Boolean,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int

    ): Call<ResponseEventList>

    //@GET("http://211.244.244.60:3000/mbs/pointProductList")
//    @GET("http://3.35.8.88:3000/mbs/pointProductList")
    @GET("/mbs/pointProductList")
    fun pointProductList(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponsePointProductList>

    //    @GET("http://211.244.244.60:3000/mbs/pointBalance")
    // @GET("http://3.35.8.88:3000/mbs/pointBalance")
    @GET("/mbs/pointBalance")
    fun pointBalance(
        @Query("terminalKey") terminalKey: String
    ): Call<ResponsePoint>

    //    @POST("http://220.85.201.231:3000/mbs/pointProduct-purchase")
    //@POST("http://3.35.8.88:3000/mbs/pointProduct-purchase")
    @POST("/mbs/pointProduct-purchase")
    fun purchasePointProduct(
        @Body purchasePointProduct: RequestPurchasePointProduct
    ): Call<ResponsePoint>

    @POST("/mbs/pointPinNo")
    fun pointPinNo(
        @Body pointPinNo : RequestPointPinNo
    ): Call<ResponsePointPinNo>

    //    @POST("http://211.244.244.60:3000/mbs/pointHistoryList")
    @GET("/mbs/pointHistoryList")
    fun pointHistoryList(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponsePointHistoryList>

    //    @GET("http://3.35.8.88:3000/mbs/pointNotiList")
    @GET("/mbs/pointNotiList")
    fun pointNotiList(
        @Query("transactionId") transactionId: String,
        @Query("terminalKey") terminalKey: String,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponsePointProductList>

    @POST("/mbs/pointNoti-confirm")
    fun pointNotiConfirm(
        @Body pointPinNo: RequestPointNoticeConfirm
    ): Call<ResponseNoBody>

    @GET("/mbs/drmToken")
    fun drmToken(
        @Query("terminalKey") terminalKey: String,
        @Query("contentId") contentId: String,
        @Query("drmType") drmType: String
    ): Call<ResponseDrmToken>

    //CP별 리스트
    @GET("/mbs/cpItemList")
    fun cpItemList(
        @Query("terminalKey") terminalKey: String,
        @Query("cpId") cpId: Int,
        @Query("includeAdult") includeAdult: Boolean,
        @Query("includeRrated") includeRrated: Boolean,
        @Query("startIdx") startIdx: Int,
        @Query("pageSize") pageSize: Int
    ): Call<ResponseCpItemList>

    @GET("mbs/v3/checkPermission")
    fun checkPermission(
        @Query("terminalKey") terminalKey: String,
        @Query("contentId") contentId: Long,
        @Query("offerList") offerList: Long
    ): Call<CheckPermissionResponse>

    @GET("/mbs/adultCheckState")
    fun adultCheckState(
        @Query("terminalKey") terminalKey: String
    ): Call<ResponseAdultCheck>

    @GET("/mbs/userInfo")
    fun userInfo(
        @Query("terminalKey") terminalKey: String
    ): Call<ResponseUserInfo>
}