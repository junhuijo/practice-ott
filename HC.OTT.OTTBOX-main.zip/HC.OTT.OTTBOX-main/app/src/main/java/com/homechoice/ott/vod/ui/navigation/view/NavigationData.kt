package com.homechoice.ott.vod.ui.navigation.view

data class NavigationData(
    var curIndex: Int = 0, // 전체 모델중 데이터 현재 인덱스
    var preIndex: Int = -1, // 전체 모델중 데이터 이전 인덱스
    var totalIndex: Int = 0, // 전체 모델 중 저장된 데이터의 마지막 인덱스
    var totalCount: Int = 0, // 전체 모델 데이터 갯수
    var leftFixedIndex: Int = 0, // 이전 고정 인덱스
    var rightFixedIndex: Int = 0, // 다음 고정 인덱스
    var visibleThreshold: Int = 0, // 첫 시작 시 렌더링 할 인덱스
    var visibleIndex: Int = 0, // 노출 중 현재 인덱스
    var startIndex: Int = 0, // 화면에 노출중인 첫 인덱스
    var requestIndex: Int = 0, // MBS 요청 시 시작 인덱스
    var requestSize: Int = 0, // MBS 요청 시 갯수,
    var isLoaded:Boolean = false,
    var isEmpty:Boolean = false,
    var list: ArrayList<Any> = arrayListOf()
) {
    fun build(itemList: List<Any>): NavigationData {
        val arrayList: ArrayList<Any> = arrayListOf()
        for (item in itemList) {
            arrayList.add(item)
        }
        list = arrayList
        totalIndex = itemList.size - 1
        toString()
        return this
    }

    override fun toString() =
        "cur:$curIndex / preIndex: $preIndex / totalIndex: $totalIndex / totalCount : $totalCount / startIndex:$startIndex / visibleIndex: $visibleIndex / visibleThreshold: $visibleThreshold / rightFixedIndex : $rightFixedIndex / leftFixedIndex : $leftFixedIndex"
}