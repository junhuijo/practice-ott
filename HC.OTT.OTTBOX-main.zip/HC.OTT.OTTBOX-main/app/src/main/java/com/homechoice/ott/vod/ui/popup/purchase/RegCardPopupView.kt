package com.homechoice.ott.vod.ui.popup.purchase

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.DialogRegCardBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.popup.Phone
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.PhonePopupViewModel
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegCardPopupView(ctx: Context, phone: Phone, val event: PopupEvent) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {
    private var binding: DialogRegCardBinding = DialogRegCardBinding.inflate(LayoutInflater.from(ctx))
    private var model: PhonePopupViewModel = PhonePopupViewModel(phone)
    private val dialog = this

    init {
        binding.apply {
            viewModel = model
        }

        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setContentView(binding.root)

        val keyPadList: ArrayList<LinearLayout> =
            arrayListOf(
                binding.numDel, // 0 <-
                binding.num0, // 1
                binding.numOk, // 2
                binding.num1, // 3 <-
                binding.num2, // 4
                binding.num3, // 5
                binding.num4, // 6 <-
                binding.num5, // 7
                binding.num6, // 8
                binding.num7, // 9 <-
                binding.num8, // 10
                binding.num9  // 11
            )

        for (item in keyPadList) {
            item.setOnClickListener {
                pushKey(it)
            }
        }

        setOnKeyListener { _, kCode, kEvent ->
            val result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                    }
                }
            }
            result
        }
        binding.num0.requestFocus()
        show()
    }

    private fun pushKey(view: View) {
        when (view.id) {
            binding.numOk.id -> okNumber()
            binding.numDel.id -> removeNumber()
            else ->
                appendNumber(view.tag as String)
        }
    }

    private fun appendNumber(num: String) {
        // PhoneNumberUtils.formatNumber(yourStringPhone, Locale.getDefault().getCountry())
        Logger.Log(Log.DEBUG, this, "appendNumber $num")
        var number = binding.regJoinNumber.text.toString()
        number += num
        binding.regJoinNumber.text = number
    }

    private fun removeNumber() {
        var numbers = binding.regJoinNumber.text
        if (numbers.isNotEmpty())
            numbers = numbers.substring(0, numbers.length - 1)
        binding.regJoinNumber.text = numbers
        binding.warnText.visibility = View.INVISIBLE
    }

    //
    private fun okNumber() {
        val numbers = binding.regJoinNumber.text.toString()
        if (UIAgent.isValidCellPhoneNumber(numbers)) {
            Logger.Log(Log.DEBUG, this, "전화번호 형식 맞음")

            MBSAgent.postCardReplace(numbers, object : Callback<ResponseNoBody> {
                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                    PopupAgent.showNormalPopup(
                        context,
                        PopupType.getErrorType(
                            TYPE.AUTH,
                            CODE.NONE
                        ),
                        object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                when (btn) {
                                    BtnLabel.OK -> {
                                        d.dismiss()
                                    }
                                }
                            }
                        })
                }

                override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                    if (response.isSuccessful && response.body() != null) {
                        PopupAgent.showNormalPopup(
                            context,
                            PopupType.NormalPopupType.CARD_ADD,
                            object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    d.dismiss()
                                    event.onClick(dialog, btn)
                                }
                            })

                    } else {
                        when (response.code()) {
                            CODE.CONFLICT -> {
                                UIAgent.showPopup(context, response.code(), object : RetryCallback {
                                    override fun call() {
                                        okNumber()
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                val error = response.errorBody()?.let { MBSAgent.error(it) }
                                PopupAgent.showNormalPopup(
                                    context,
                                    PopupType.getErrorType(
                                        TYPE.AUTH,
                                        response.code(),
                                        error?.errorString!!
                                    ),
                                    object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            when (btn) {
                                                BtnLabel.OK -> {
                                                    d.dismiss()
                                                }
                                            }
                                        }
                                    })
                            }
                        }

                    }
                }

            })


        } else {
            Logger.Log(Log.DEBUG, this, "전화번호 형식 아님")
            binding.warnText.visibility = View.VISIBLE
        }
    }

}