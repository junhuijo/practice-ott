package com.homechoice.ott.vod.model.popup

import android.widget.ImageView

data class Login(
    val defaultIdText: String = "아이디를 입력해 주세요.",
    val defaultPwText: String = "비밀번호를 입력해 주세요.",
    val defaultBodyText: String = "성인인증이 필요한 화면입니다.\n성인인증 비밀번호를 입력해 주세요.",
    var bodyText: String = "",
    var forceLogin: Boolean = false,
    var isAdult: Boolean = false,
    val loginId: String = "",
    var errorString: String = "",
    var loginqr: ImageView?,
    val password: StringBuffer = StringBuffer(),
    val terminalKey: String = ""
)