package com.homechoice.ott.vod.ui.my.point

import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentPointHistoryListBinding

import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.point.PointHistory
import com.homechoice.ott.vod.model.response.ResponsePoint
import com.homechoice.ott.vod.model.response.ResponsePointHistoryList
import com.homechoice.ott.vod.ui.navigation.list.NavigationListData
import com.homechoice.ott.vod.ui.navigation.list.NavigationListEvent
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.point.PointPopupView
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_point_history_list.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class PointHistoryListFragment(private val activityHandler: Handler, val categoryTarget: String) :
    NavigationListView() {

    private lateinit var adapter: PointHistoryListAdapter
    private lateinit var viewHolder: PointHistoryListAdapter.ViewHolder
    private lateinit var bind: FragmentPointHistoryListBinding
    private var logList: ArrayList<PointHistory> = arrayListOf()

    var head = UIAgent.createLoginHead(categoryTarget)
    var description: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        bind = DataBindingUtil.inflate(inflater, R.layout.fragment_point_history_list, container, false)
        bind.frg = this
        bind.lifecycleOwner = this
        description = "포인트 내역입니다. \n항목 선택 시 상세한 내용을 확인하실 수 있습니다."

        requestPointHistoryList()
        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requestPointBalance()
    }

    fun getPointBalance(): Int {
        return STBAgent.pointBalance
    }

    fun getPoint(): String {
        return String.format("%,d", STBAgent.pointBalance)
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume")
    }

    private fun requestPointBalance() {
        MBSAgent.pointBalance(object : Callback<ResponsePoint> {
            override fun onResponse(call: Call<ResponsePoint>, response: Response<ResponsePoint>) {
                if (response.isSuccessful && response.body() != null) {
                    STBAgent.pointBalance = response.body()!!.point
                    bind?.invalidateAll()
                }
            }

            override fun onFailure(call: Call<ResponsePoint>, t: Throwable) {
                STBAgent.pointBalance = -1
            }
        })
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "ServiceLogListFragment onKeyDown keyCode $keyCode")
        if (!::viewHolder.isInitialized) {
            return false
        }
        if (!STBAgent.enableKeyInput(150L)) {
            return true
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (viewHolder.binding.itemWishListLayout.isSelected) {
                    true
                } else {
                    controller.decrease()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (viewHolder.binding.itemWishListLayout.isSelected) {
                    true
                } else {
                    controller.increase()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                !viewHolder.binding.itemWishListLayout.isSelected
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (viewHolder.binding.itemWishListLayout.isSelected) {
                    viewHolder.binding.btnDetail.hasFocus()
                } else {
                    adapter.unfocus(controller.getCurIndex())
                    activityHandler.obtainMessage(2).sendToTarget()
                    true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER, 96 -> {
                selectItem()
                true
            }

            KeyEvent.KEYCODE_BACK, 97 -> {
                if (viewHolder.binding.itemWishListLayout.isSelected) {
                    viewHolder.unSelect()
                } else {
                    adapter.unfocus(controller.getCurIndex())
                    activityHandler.obtainMessage(2).sendToTarget()
                }
                true
            }
            else -> false
        }
    }

    private fun selectItem() {
        val pointHistory = viewHolder.pointHistory
        context?.let { PointPopupView(context = it, pointHistory = pointHistory).show() }
    }

    override fun active() {
        focus()
    }

    private fun requestPointHistoryList() {
        GlobalScope.launch(Dispatchers.Main) {
            /**
             * 409 return api
             * */
            MBSAgent.pointHistoryList(
                startIdx = 1,
                pageSize = 0,
                transactionId = UUID.randomUUID().toString(),
                callback = object : Callback<ResponsePointHistoryList> {
                    override fun onFailure(call: Call<ResponsePointHistoryList>, t: Throwable) {
                        Logger.Log(Log.ERROR, this, "onFailure ${t.message}")
                    }

                    override fun onResponse(
                        call: Call<ResponsePointHistoryList>,
                        res: Response<ResponsePointHistoryList>
                    ) {
                        if (res.isSuccessful && res.body() != null) {
                            val response = res.body()
                            if (response != null) {
                                val itemList = response.historyList
                                val totalCount = response.totalCount

                                if (totalCount > 0) {
                                    val actionHandler = Handler {
                                        Logger.Log(Log.DEBUG, this, "actionHandler ${it.what}")
                                        when (it.what) {
                                            0 -> {
                                                viewHolder = it.obj as PointHistoryListAdapter.ViewHolder
                                            }
                                        }
                                        true
                                    }

                                    logList.clear()
                                    for (item in itemList) {
                                        logList.add(item)
                                    }
                                    adapter = PointHistoryListAdapter(bind.logList!!, logList, actionHandler)

                                    setModel(
                                        NavigationListData(
                                            curIndex = 0,
                                            visibleThreshold = 6
                                        ).build(itemList), object : NavigationListEvent {
                                            override fun focusChange() {
                                                adapter.focus(controller.getCurIndex(), controller.getPreIndex())
                                                checkArrow()
                                            }

                                            override fun plusLineChange() {
                                                log_list_scroll_view.smoothScrollBy(
                                                    0,
                                                    CMBApp.getPixelSize(R.dimen.my_purchase_log_height)
                                                )
                                            }

                                            override fun minusLineChange() {
                                                log_list_scroll_view.smoothScrollBy(
                                                    0,
                                                    -CMBApp.getPixelSize(R.dimen.my_purchase_log_height)
                                                )
                                            }
                                        })

                                    log_list_layout?.visibility = View.VISIBLE
                                    checkArrow()
                                    activityHandler.obtainMessage(11).sendToTarget()
                                    if (isLateActive) {
                                        active()
                                    }
                                } else {
                                    login_line?.visibility = View.VISIBLE
                                    log_list_empty_layout?.visibility = View.VISIBLE
                                    activityHandler.obtainMessage(2).sendToTarget()
                                }
                            } else {
                                login_line?.visibility = View.VISIBLE
                                log_list_empty_layout?.visibility = View.VISIBLE
                                activityHandler.obtainMessage(2).sendToTarget()
                            }
                        } else {
                            context?.let {
                                UIAgent.showPopupForMyMenu(it, res.code(), object : RetryCallback {
                                    override fun call() {
                                        activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                        activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                    }

                                    override fun cancel() {
                                        activityHandler.obtainMessage(12).sendToTarget()
                                    }
                                })
                            }
                        }
                    }
                })
        }
    }

    private fun checkArrow() {
        if (controller.getTotalCount() > controller.getVisibleThreshold()) {
            if (controller.isLastItem())
                table_arrow?.visibility = View.INVISIBLE
            else
                table_arrow?.visibility = View.VISIBLE
        }
    }

    private fun isEnable(): Boolean {
        return bind.logListLayout.isVisible
    }

    fun focus() {
        if (isEnable()) {
            adapter.focus(controller.getCurIndex(), controller.getPreIndex())
        } else {
            activityHandler.obtainMessage(2).sendToTarget()
        }
    }

    var isLateActive: Boolean = false

    override fun lateActive() {
        isLateActive = true
    }

    override fun setVisible(visible: Int) {
        bind.root.visibility = visible
    }
}