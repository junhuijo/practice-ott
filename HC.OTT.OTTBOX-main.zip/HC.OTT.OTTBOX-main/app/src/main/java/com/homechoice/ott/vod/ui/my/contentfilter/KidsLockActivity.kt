package com.homechoice.ott.vod.ui.my.contentfilter

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import com.homechoice.ott.vod.ui.screens.my.kidsLock.KidsLockScreen

class KidsLockActivity : AppCompatActivity() {
    private var target: String = "none"
    var ctx = this
    private var canHandleKeyEvents = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        target = intent?.getStringExtra("TARGET_INFO").toString()

        setContent {
            KidsLockScreen()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            canHandleKeyEvents = true
        }, 500)
    }

    override fun onResume() {
        super.onResume()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!canHandleKeyEvents) { return true }
        if (event.action == KeyEvent.ACTION_DOWN) {
//            Logger.Log(Log.ERROR, this, "dispatchKeyEvent event.keyCode : ${event.keyCode}")
            when (event.keyCode) {
                KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE, 97 -> {
                    finish()
                    return true
                }
                KeyEvent.KEYCODE_ENTER -> {
                    return false
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { }
}