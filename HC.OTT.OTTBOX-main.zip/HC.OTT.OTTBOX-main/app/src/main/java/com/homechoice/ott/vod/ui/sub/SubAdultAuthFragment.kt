package com.homechoice.ott.vod.ui.sub

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentSubAdultAuthBinding
import com.homechoice.ott.vod.model.popup.Phone
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.adult.AdultAuthPopupView
import com.homechoice.ott.vod.ui.sub.SubCategoryActivity.ActionType.CONTENTS_FOCUS
import com.homechoice.ott.vod.ui.sub.SubCategoryActivity.ActionType.MAIN_CATEGORY_FOCUS
import com.homechoice.ott.vod.ui.sub.SubCategoryActivity.ActionType.TOP_CATEGORY_UPDATE
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SubAdultAuthFragment(private val categoryId: Int, private val activityHandler: Handler, val isFocus: Boolean) : NavigationView2() {

    private lateinit var binding: FragmentSubAdultAuthBinding

    private var pinNumber = ""
    private var pinInput: ArrayList<TextView?> = arrayListOf()

    @SuppressLint("InflateParams")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentSubAdultAuthBinding.inflate(inflater)
        pinInput = arrayListOf(binding.newKeypadInput0, binding.newKeypadInput1, binding.newKeypadInput2, binding.newKeypadInput3)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if (isFocus)
            focus()
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume====================")
        val keyPadList: ArrayList<ImageView> =
            arrayListOf(
                binding.numDel, // 0 <-
                binding.num0, // 1
                binding.numOk, // 2
                binding.num1, // 3 <-
                binding.num2, // 4
                binding.num3, // 5
                binding.num4, // 6 <-
                binding.num5, // 7
                binding.num6, // 8
                binding.num7, // 9 <-
                binding.num8, // 10
                binding.num9  // 11
            )

        Logger.Log(Log.DEBUG, this, "keyPadList size ${keyPadList.size}")

        for (item in keyPadList) {
            Logger.Log(Log.DEBUG, this, "keyPadList")
            item.setOnClickListener {
                Logger.Log(Log.DEBUG, this, "pushKey setOnClickListener")
                pushKey(it)
            }
        }
    }

    private fun pushKey(view: View) {
        when (view.id) {
            binding.numOk.id -> okNumber()
            binding.numDel.id -> removeNumber()
            else ->
                appendNumber(view.tag as String)
        }
    }

    private fun appendNumber(num: String) {
        // PhoneNumberUtils.formatNumber(yourStringPhone, Locale.getDefault().getCountry())
        Logger.Log(Log.DEBUG, this, "appendNumber $num")
        if (pinNumber.length < 4)
            pinNumber += num
        showPinNumber()
    }

    private fun removeNumber() {
        if (pinNumber.isNotEmpty())
            pinNumber = pinNumber.substring(0, pinNumber.length - 1)
        showPinNumber()
    }

    private fun showPinNumber() {
        for (i in 0..3) {
            if (i > pinNumber.length - 1) {
                pinInput[i]?.text = ""
            }
            else {
                pinInput[i]?.text = "●"
            }
        }
        if (pinNumber.length == 4) {
            binding.numOk.requestFocus()
        }
        else if (pinNumber.isEmpty()) {
            binding.warnText.text = "최초 비밀번호는 0000입니다."
        }
    }

    //
    private fun okNumber() {
        if (pinNumber.length > 3) {
            MBSAgent.adultPwCheck(STBAgent.encrypt(pinNumber)!!, object : Callback<ResponseNoBody> {
                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                    PopupAgent.showNormalPopup(
                        context!!,
                        PopupType.getErrorType(
                            TYPE.AUTH,
                            CODE.NONE
                        ),
                        object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                when (btn) {
                                    BtnLabel.OK -> {
                                        d.dismiss()
                                    }
                                }
                            }
                        })
                }

                override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                    if (response.isSuccessful && response.body() != null) {
                        STBAgent.isAdultAuth = true
                        activityHandler.obtainMessage(TOP_CATEGORY_UPDATE, categoryId, CONTENTS_FOCUS).sendToTarget()
                    }
                    else {
                        // 초기화 처리
                        when (response.code()) {
                            401 -> {
                                binding.warnText.text = "* 잘못된 비밀번호 입니다."
                                pinNumber = ""
                                showPinNumber()
                                STBAgent.isAdultAuth = false
                            }
                            412 -> {
                                binding.warnText.text = "* 성인인증 번호를 등록해주세요."
                                pinNumber = ""
                                showPinNumber()
                                STBAgent.isAdultAuth = false
                            }
                            CODE.CONFLICT -> {
                                UIAgent.showPopup(context!!, CODE.CONFLICT, null)
                            }
                            else -> {
                                binding.warnText.text = "* 잘못된 비밀번호 입니다."
                                pinNumber = ""
                                showPinNumber()
                                STBAgent.isAdultAuth = false
                            }
                        }
                    }
                    pinNumber = ""
                    showPinNumber()
                }
            })
        }
        else {
            binding.warnText.text = "비밀번호 4자리를 입력해 주세요."
        }
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (binding.numDel.hasFocus() || binding.num1.hasFocus() || binding.num4.hasFocus() || binding.num7.hasFocus()) {
                    activityHandler.obtainMessage(MAIN_CATEGORY_FOCUS).sendToTarget()
                    true
                }
                else
                    false
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                false
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                binding.num7.hasFocus() || binding.num8.hasFocus() || binding.num9.hasFocus()
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                binding.numDel.hasFocus() || binding.num0.hasFocus() || binding.numOk.hasFocus()
            }
            KeyEvent.KEYCODE_BACK, 97 -> {
                activityHandler.obtainMessage(2).sendToTarget()
                true
            }
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_DPAD_CENTER, 96 -> {
                if (binding.numDel.hasFocus()) {
                    pushKey(binding.numDel)
                }
                else if (binding.num0.hasFocus()) {
                    pushKey(binding.num0)
                }
                else if (binding.numOk.hasFocus()) {
                    pushKey(binding.numOk)
                }
                else if (binding.num1.hasFocus()) {
                    pushKey(binding.num1)
                }
                else if (binding.num2.hasFocus()) {
                    pushKey(binding.num2)
                }
                else if (binding.num3.hasFocus()) {
                    pushKey(binding.num3)
                }
                else if (binding.num4.hasFocus()) {
                    pushKey(binding.num4)
                }
                else if (binding.num5.hasFocus()) {
                    pushKey(binding.num5)
                }
                else if (binding.num6.hasFocus()) {
                    pushKey(binding.num6)
                }
                else if (binding.num7.hasFocus()) {
                    pushKey(binding.num7)
                }
                else if (binding.num8.hasFocus()) {
                    pushKey(binding.num8)
                }
                else if (binding.num9.hasFocus()) {
                    pushKey(binding.num9)
                }
                true
            }
            else -> false
        }
    }

    override fun active() {
        focus()
    }

    fun focus() {
        Logger.Log(Log.DEBUG, this, "로그 리스트 focus")
        binding.num0.requestFocus()
    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        binding.root.visibility = visible
    }

}