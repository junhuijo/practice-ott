package com.homechoice.ott.vod.ui.my.serviceLog

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TabModel : ViewModel(){
    val NORMAL: Int = 0
    val ADULT: Int = 1
    val FOCUS_NORMAL: Int = 2
    val FOCUS_ADULT: Int = 3
    var tabStatus: MutableLiveData<Int> = MutableLiveData()

}