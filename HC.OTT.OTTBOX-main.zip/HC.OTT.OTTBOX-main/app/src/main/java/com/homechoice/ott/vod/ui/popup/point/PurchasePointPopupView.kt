package com.homechoice.ott.vod.ui.popup.point

import android.app.Dialog
import android.content.Context
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.DialogPurchasePointBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.point.PointProduct

import com.homechoice.ott.vod.model.response.ResponsePoint
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.purchase.PurchaseFailPopupView
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList

class PurchasePointPopupView(
    ctx: Context,
    pointProduct: PointProduct,
    val event: PopupEvent
) : Dialog(
    ctx,
    R.style.Theme_Design_NoActionBar
) {
    private var binding: DialogPurchasePointBinding = DialogPurchasePointBinding.inflate(LayoutInflater.from(ctx))
    private var model: PurchasePointPopupViewModel = PurchasePointPopupViewModel(pointProduct)
    private val dialog = this

    init {
        binding.apply {
            viewModel = model

        }

        setContentView(binding.root)

        val keyPadList: ArrayList<LinearLayout> =
            arrayListOf(
                binding.numDel, // 0 <-
                binding.num0, // 1
                binding.numOk, // 2
                binding.num1, // 3 <-
                binding.num2, // 4
                binding.num3, // 5
                binding.num4, // 6 <-
                binding.num5, // 7
                binding.num6, // 8
                binding.num7, // 9 <-
                binding.num8, // 10
                binding.num9  // 11
            )

        for (item in keyPadList) {
            item.setOnClickListener {
                pushKey(it)
            }
        }

        setOnKeyListener { _, kCode, kEvent ->
            val result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                    }
                }
            }
            result
        }
        binding.num0.requestFocus()
        show()
    }

    private fun pushKey(view: View) {
        when (view.id) {
            binding.numOk.id -> okNumber()
            binding.numDel.id -> removeNumber()
            else ->
                appendNumber(view.tag as String)
        }
    }

    private fun appendNumber(num: String) {
        // PhoneNumberUtils.formatNumber(yourStringPhone, Locale.getDefault().getCountry())
        Logger.Log(Log.DEBUG, this, "appendNumber $num")
        var number = model.password.value
        if(number.isNullOrBlank() || number.length < 4) {
            number += num
            model.password.value = number
            binding.invalidateAll();
        }

    }

    private fun removeNumber() {
        var numbers = model.password.value
        if (!numbers.isNullOrEmpty())
            numbers = numbers.substring(0, numbers.length - 1)
        model.password.value = numbers
        binding.invalidateAll();
        binding.warnText.visibility = View.INVISIBLE
    }

    //
    private fun okNumber(){
        val pointProduct  = model.pointProduct
        val numbers = model.password.value
        numbers?.let { purchasePointProduct(productId = pointProduct.id ,productTitle = pointProduct.name, price = pointProduct.price, paymentPw = it) }
    }

    interface PointBalanceCallback{
        fun success()
    }

    private fun getPointBalance(callback: PointBalanceCallback){
        MBSAgent.pointBalance(object : Callback<ResponsePoint>{
            override fun onResponse(call: Call<ResponsePoint>, response: Response<ResponsePoint>) {
                if(response.isSuccessful && response.body() != null) {
                    STBAgent.pointBalance = response.body()!!.point
                    callback.success()
                }
            }

            override fun onFailure(call: Call<ResponsePoint>, t: Throwable) {
                PopupAgent.showNormalPopup(
                    context,
                    PopupType.getErrorType(
                        TYPE.AUTH,
                        CODE.NONE
                    ),
                    object : PopupEvent {
                        override fun onClick(d: Dialog, btn: String) {
                            when (btn) {
                                BtnLabel.OK -> {
                                    d.dismiss()
                                }
                            }
                        }
                    })
            }

        })
    }

    private fun purchasePointProduct(productId : Long , productTitle : String , price : Int, paymentPw : String) {
        val numbers = model.password.value
        if (!numbers.isNullOrBlank()) {
            MBSAgent.purchasePointProduct(productId = productId , productTitle = productTitle , price = price,paymentPw = paymentPw ,transactionId = UUID.randomUUID().toString(), callback = object : Callback<ResponsePoint> {
                override fun onFailure(call: Call<ResponsePoint>, t: Throwable) {
                    PopupAgent.showNormalPopup(
                        context,
                        PopupType.getErrorType(
                            TYPE.AUTH,
                            CODE.NONE
                        ),
                        object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                when (btn) {
                                    BtnLabel.OK -> {
                                        d.dismiss()
                                    }
                                }
                            }
                        })
                }

                override fun onResponse(call: Call<ResponsePoint>, response: Response<ResponsePoint>) {
                    if (response.isSuccessful && response.body() != null) {
                        STBAgent.pointBalance = response.body()!!.point
                        PurchasePointSuccessPopupView(
                            ctx = context,
                            type = PopupType.NormalPopupType.PURCHASE_POINT,
                            balance = STBAgent.pointBalance,
                            event = object : PopupEvent {
                                override fun onClick(d: Dialog, btn: String) {
                                    d.dismiss()
                                    event.onClick(dialog, btn)
                                }
                            }).show()
                    } else {
                        when (response.code()) {
                            CODE.UNAUTHORIZED -> {
                                binding.warnText.visibility = View.VISIBLE
                            }
                            CODE.PIN_CHECK,
                            CODE.PIN_FAIL,
                            CODE.UNAVAILABLE_CARD -> {
                                // 사용할 수 없는 카드 입니다.
                                val type = when (response.code()) {
                                    CODE.PIN_CHECK -> {
                                        val t = PopupType.NormalPopupType.PURCHASE_PIN_CHECK
                                        val error = response.errorBody()?.let { MBSAgent.error(it) }
                                        t.body = error?.errorString!!
                                        t
                                    }
                                    CODE.PIN_FAIL -> {
                                        val t = PopupType.NormalPopupType.PURCHASE_PIN_FAIL
                                        val error = response.errorBody()?.let { MBSAgent.error(it) }
                                        t.body = error?.errorString!!
                                        t
                                    }
                                    else -> PopupType.NormalPopupType.PURCHASE_FAIL
                                }
                                PurchaseFailPopupView(
                                    ctx = context,
                                    code = response.code(),
                                    popupType = type,
                                    event = object : PopupEvent {
                                        override fun onClick(d: Dialog, text: String) {
                                            when (text) {
                                                BtnLabel.OK -> {
                                                    d.dismiss()
                                                }
                                            }
                                        }
                                    })
                            }
                            CODE.CONFLICT -> {
                                UIAgent.showPopup(context, CODE.CONFLICT, object : RetryCallback {
                                    override fun call() {
                                        okNumber()
                                    }

                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                val error = response.errorBody()?.let { MBSAgent.error(it) }
                                PopupAgent.showNormalPopup(
                                    context,
                                    PopupType.getErrorType(
                                        TYPE.AUTH,
                                        response.code(),
                                        error?.errorString!!
                                    ),
                                    object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            when (btn) {
                                                BtnLabel.OK -> {
                                                    d.dismiss()
                                                }
                                            }
                                        }
                                    })
                            }
                        }
                    }
                }

            })


        } else {
            binding.warnText.visibility = View.VISIBLE
        }
    }

}