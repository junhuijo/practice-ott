package com.homechoice.ott.vod.ui.search

import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.CONTENT_FOCUS
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.CONTENT_LOADED
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.HIDE_KEYWORD
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.INPUT_FOCUS
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.RESULT_UPDATE
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.SEARCH_EXIT
import com.homechoice.ott.vod.ui.search.input.SearchInputFragment
import com.homechoice.ott.vod.ui.search.result.SearchResultFragment
import com.homechoice.ott.vod.util.Logger

class SearchActivity : AppCompatActivity() {

    private lateinit var activityHandler: Handler
    private lateinit var searchInputFragment: SearchInputFragment
    private lateinit var searchResultFragment: SearchResultFragment

    object ActionType {
        const val INPUT_FOCUS = 0
        const val RESULT_UPDATE = 1
        const val RECOMMEND_VISIBLE = 5
        const val SEARCH_EXIT = 6
        const val CONTENT_FOCUS = 7
        const val CONTENT_LOADED = 8
        const val HIDE_KEYWORD = 9
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        activityHandler = Handler {
            Logger.Log(Log.DEBUG, this, "activityHandler it.what $it")
            var result = true
            when (it.what) {
                INPUT_FOCUS -> {
                    searchInputFragment.focus()
                    searchInputFragment.hideKeyWordListView()
                }
                RESULT_UPDATE -> {
                    Logger.Log(Log.DEBUG, this, "activityHandler it.what ${it.obj}")
                    searchInputFragment.hideKeyWordListView()
                    searchResultFragment = SearchResultFragment(it.obj as String, it.arg1 == 1, activityHandler)
                    fragmentTransaction(
                        R.id.search_result_layout,
                        searchResultFragment,
                        searchResultFragment::class.simpleName!!
                    )
                }
                SEARCH_EXIT -> {
                    finish()
                }
                CONTENT_FOCUS -> {
                    val fragment = supportFragmentManager.findFragmentById(R.id.search_result_layout)
                    Logger.Log(Log.DEBUG, this, "activityHandler it.what $fragment")

                    fragment?.let {
                        if (it == searchResultFragment) {
                            searchResultFragment.active()
                            result = false
                        }
                    } ?: run {
                        Logger.Log(Log.DEBUG, this, "search_result_layout fragment is null")
                    }
                }
                CONTENT_LOADED -> {
                    searchInputFragment.setSearching(false)
                    searchInputFragment.hideKeyWordListView()
                }
                HIDE_KEYWORD -> {
                    searchInputFragment.hideKeyWordListView()
                }
            }
            result
        }

        searchInputFragment = SearchInputFragment(activityHandler)


        fragmentTransaction(
            R.id.search_input_layout,
            searchInputFragment,
            searchInputFragment::class.simpleName!!
        )

    }



    private fun fragmentTransaction(layoutId: Int, fragment: Fragment?, tag: String) {
        supportFragmentManager.beginTransaction().replace(layoutId, fragment!!, tag)
//            .addToBackStack(tag)
            .commit()
    }

}