package com.homechoice.ott.vod.ui.play

import android.widget.LinearLayout
import com.castis.castisplayer.CastisPlayer
import com.homechoice.ott.vod.databinding.ActivityPlayerBinding
import com.homechoice.ott.vod.util.StringUtil
import kotlin.math.max
import kotlin.math.min

class PlayerSeekManager(
    private val player: CastisPlayer,
    private val playStatus: PlayerActivity.PlayStatus,
    private val binding: ActivityPlayerBinding

) {

    fun forwardAndUpdateProgressBar() {
        val forwardSec = 10 // 앞으로 갈 초 단위 (예시: 10초)
        val newPosition = min(player.currentPositionSec + forwardSec, player.durationSec)
        player.seekToSec(newPosition)
        playStatus.curPosition = newPosition
        updateProgressBar(newPosition)
    }

    fun backwardAndUpdateProgressBar() {
        val backwardSec = 10 // 뒤로 갈 초 단위 (예시: 10초)
        val newPosition = max(player.currentPositionSec - backwardSec, 0)
        player.seekToSec(newPosition)
        playStatus.curPosition = newPosition
        updateProgressBar(newPosition)
    }

    fun updateProgressBar(currentPositionSec: Int) {
        val barLayoutParams = binding.playerProgressbar.layoutParams as LinearLayout.LayoutParams
        // 전체 길이
        val totalTime: Float = (player.durationSec.toFloat() / 100)
        // 재생 시간
        val currentTime: Float = (currentPositionSec.toFloat() / totalTime)
        // 남은 시간
        val remainingTimeSec = player.durationSec - currentPositionSec

        barLayoutParams.weight = currentTime
        binding.playerProgressbar.layoutParams = barLayoutParams

        binding.currentTime.text = StringUtil.getInstance().getTimeStr(currentPositionSec)
        binding.duration.text = StringUtil.getInstance().getTimeStr(remainingTimeSec)
    }


}