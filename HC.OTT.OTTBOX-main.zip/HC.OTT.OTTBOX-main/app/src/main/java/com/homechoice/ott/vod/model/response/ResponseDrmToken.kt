package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseDrmToken(
    val transactionId: String = "",
    val errorString: String = "",
    val drmToken: String = ""
) : Parcelable