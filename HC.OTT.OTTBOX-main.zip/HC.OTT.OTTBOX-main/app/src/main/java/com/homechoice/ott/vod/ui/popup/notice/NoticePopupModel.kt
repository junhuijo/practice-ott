package com.homechoice.ott.vod.ui.popup.notice

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel


class NoticePopupModel : ViewModel() {
    var title: MutableLiveData<String> = MutableLiveData()

    var imgUrl: MutableLiveData<String> = MutableLiveData()

    var description : MutableLiveData<String> = MutableLiveData()
}