package com.homechoice.ott.vod.model.request

data class RequestPwReplace (
    val terminalKey: String,
    val mobileNumber: String,
    val type:String
)