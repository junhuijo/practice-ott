package com.homechoice.ott.vod.ui.pack

import android.app.Dialog
import android.graphics.Paint
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.databinding.FragmentPackageBinding
import com.homechoice.ott.vod.model.content.Content
import com.homechoice.ott.vod.model.content.OfferContent
import com.homechoice.ott.vod.model.response.ResponseOfferContent
import com.homechoice.ott.vod.model.response.ResponsePoint
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.CODE
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class PackageFragment(private var offerContent: OfferContent, private val enterPath: String) : Fragment() {

    private lateinit var binding: FragmentPackageBinding
    private lateinit var adapter: PackageListAdapter
    private var poster: View? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentPackageBinding.inflate(inflater)
        binding.apply {
            lifecycleOwner = this@PackageFragment
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        offerContent.contentList = if (offerContent.contentList.size > 4) offerContent.contentList.subList(0, 4) else offerContent.contentList

        binding.viewModel = PackageViewModel(offerContent)
        binding.productInfo.paintFlags = binding.productInfo.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        binding.productList.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        adapter = PackageListAdapter(offerContent.contentList)
        binding.productList.adapter = adapter
        binding.packageTitle?.isSelected = true
        initLayout()
    }

    private fun initLayout() {
        if (offerContent.isPurchase!!) {
            binding.viewablePeriodStr.visibility = View.INVISIBLE
            binding.btnLayout.visibility = View.INVISIBLE
            binding.productInfo.visibility = View.INVISIBLE
            binding.price.visibility = View.INVISIBLE
            binding.won.visibility = View.INVISIBLE
            binding.viewablePeriod.visibility = View.VISIBLE
        } else {
            binding.btnLayout.visibility = View.VISIBLE
            binding.productInfo.visibility = View.VISIBLE
            binding.price.visibility = View.VISIBLE
            binding.won.visibility = View.VISIBLE
            binding.viewablePeriodStr.visibility = View.VISIBLE
            binding.viewablePeriod.visibility = View.INVISIBLE
            binding.btnPurchase.requestFocus()
        }
    }

    private fun isActiveBtn(): Boolean {
        return binding.btnLayout.visibility == View.VISIBLE
    }

    private fun is19(): Boolean {
        var result = false
        for (item in offerContent.contentList) {
            if (item.rating == "19세")
                result = true
        }
        return result
    }

    private fun goToPackageDetail() {
        val content = binding.root.findFocus().tag as Content
        PopupAgent.showPackageDetailPopup(context!!, content, offerContent.isPurchase!!, object : PopupEvent {
            override fun onClick(d: Dialog, btn: String) {
                when (btn) {
                    "자세히 보기",
                    "개별구매" -> {
                        goToDetail()
                    }
                }
                d.dismiss()
            }

        })

    }

    private fun goToDetail() {
        val content = binding.root.findFocus().tag as Content
        ActivityChangeAgent.goToContent(context!!, content.contentGroupId!!, UIAgent.createEnterPath(EnterPath.PACKAGE_OFFER, offerContent.id), null)
    }

    private fun goToPurchase() {
        Logger.Log(Log.DEBUG, this, "구매팝업")
        MBSAgent.pointBalance(object : Callback<ResponsePoint> {
            override fun onResponse(call: Call<ResponsePoint>, response: Response<ResponsePoint>) {
                if (response.isSuccessful && response.body() != null) {
                    STBAgent.pointBalance = response.body()!!.point
                    showPackagePurchase()
                }
            }

            override fun onFailure(call: Call<ResponsePoint>, t: Throwable) {
                STBAgent.pointBalance = -1
                showPackagePurchase()
            }
        })
    }

    private fun showPackagePurchase() {
        PopupAgent.showPackagePurchase(
            context!!,
            offerContent,
            UIAgent.createEnterPath(EnterPath.PACKAGE_OFFER, offerContent.id),
            object : PopupEvent {
                override fun onClick(d: Dialog, btn: String) {
                    Logger.Log(Log.DEBUG, this, "btn $btn")
                    when (btn) {
                        BtnLabel.SUCCESS -> {
                            update(d)
                        }
                    }
                }
            })
    }

    private fun showAdultAuth() {
        Logger.Log(Log.DEBUG, this, "성인인증")
        PopupAgent.showAdultPopup(context!!, object : PopupEvent {
            override fun onClick(d: Dialog, btn: String) {
                d.dismiss()
                when (btn) {
                    BtnLabel.OK -> goToPurchase()
                }
            }
        })
    }

    private fun update(d: Dialog) {
        val transactionId = UUID.randomUUID().toString()
        MBSAgent.offerContent(transactionId = transactionId, offerId = offerContent.id, callback = object :
            Callback<ResponseOfferContent> {
            override fun onFailure(call: Call<ResponseOfferContent>, t: Throwable) {
                Logger.Log(Log.ERROR, this, t.message.orEmpty())
                UIAgent.showPopup(context!!, CODE.NONE, null)
            }

            override fun onResponse(
                call: Call<ResponseOfferContent>,
                response: Response<ResponseOfferContent>
            ) {
                // 로그인 이후 업데이트이기 때문에 state 체크는 하지 않음.
                if (response.isSuccessful && response.body() != null) {
                    offerContent = response.body()!!.offerContent
                    Logger.Log(Log.DEBUG, this, "구매여부  ${offerContent.isPurchase!!}")
                    if (offerContent.isPurchase!!) {
                        initLayout()
                        adapter.init()
                        binding.viewModel = PackageViewModel(offerContent)
                        binding.executePendingBindings()
                    }
                }
                d.dismiss()
            }
        })
    }

    fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        Logger.Log(Log.ERROR, this, "keyCode : $keyCode")
        var result = false
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (!binding.btnPurchase.hasFocus() && isActiveBtn()) {
                        poster = binding.root.findFocus()
                    }
                }
                KeyEvent.KEYCODE_DPAD_UP -> {
                    if (binding.btnPurchase.hasFocus()) {
                        if (poster == null)
                            poster = adapter.getView()

                        poster?.requestFocus()
                        result = true
                    }
                }
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (binding.root.findFocus() == binding.btnPurchase) {
                        result = true
                    }
                }
                KeyEvent.KEYCODE_ENTER, 96,
                KeyEvent.KEYCODE_DPAD_CENTER -> {
                    // 성인콘텐츠 포함인경우는 묶음상품 상새 진입 전에 체크를 했음.

                    if (binding.btnPurchase.hasFocus()) {

                        if (STBAgent.isAuth) {
                            if (is19()) {
                                if (STBAgent.isAdultAuth) {
                                    goToPurchase()
                                } else {
                                    showAdultAuth()
                                }
                            } else {
                                goToPurchase()
                            }
                        } else {
                            if(STBAgent.linkedHomeChoice){
                                PopupAgent.showNormalPopup(context!!,
                                    PopupType.NormalPopupType.LOGIN_GUIDE,
                                    object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            d.dismiss()
                                        }
                                    })
                            } else {
                                processLogin()
                            }
                        }
                    } else {
                        goToPackageDetail()
                    }
                }
            }
        }
        return result
    }

    private fun processLogin() {
        // 로그인
        Logger.Log(Log.DEBUG, this, "로그인")
        PopupAgent.showLoginPopup(context!!, object : LoginPopupEvent {
            override fun onLogin(loginDialog: Dialog, btn: String) {
                Logger.Log(Log.DEBUG, this, "dismiss $btn")
                when (btn) {
                    BtnLabel.SUCCESS -> {
                        // 로그인 이후 19세 포함이면 성인인증 필요
                        // 구매여부를 위해 컨텐츠 업데이트 필요
                        val transactionId = UUID.randomUUID().toString()
                        MBSAgent.offerContent(transactionId = transactionId, offerId = offerContent.id, callback = object :
                            Callback<ResponseOfferContent> {
                            override fun onFailure(call: Call<ResponseOfferContent>, t: Throwable) {
                                Logger.Log(Log.ERROR, this, t.message.orEmpty())
                                UIAgent.showPopup(context!!, CODE.NONE, null)
                            }

                            override fun onResponse(
                                call: Call<ResponseOfferContent>,
                                response: Response<ResponseOfferContent>
                            ) {
                                // 로그인 이후 업데이트이기 때문에 state 체크는 하지 않음.
                                // 성인콘텐츠 포함인 경우는 이미 성인인증을 하고 진입 했기 때문에, 여기서 로그인은 성인콘텐트 포함이 아님.
                                // 하지만 19세 콘텐츠 확인은 필요
                                if (response.isSuccessful && response.body() != null) {
                                    offerContent = response.body()!!.offerContent
                                    Logger.Log(Log.DEBUG, this, "구매여부  ${offerContent.isPurchase!!}")
                                    if (offerContent.isPurchase!!) {
                                        initLayout()
                                        adapter.init()
                                        binding.viewModel = PackageViewModel(offerContent)
                                        binding.executePendingBindings()
                                    } else {
                                        if (is19()) {
                                            if (STBAgent.isAdultAuth) {
                                                goToPurchase()
                                            } else {
                                                showAdultAuth()
                                            }
                                        } else {
                                            goToPurchase()
                                        }
                                    }
                                }
                            }
                        })
                    }
                    BtnLabel.CANCEL -> {
                        loginDialog.dismiss()
                    }
                }
            }
        })
    }
}