package com.homechoice.ott.vod.model.popup

import android.util.Log
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.util.Logger
import java.text.DecimalFormat

/**
 * 결제에 필요한 변수를 추가를 해줘야 함
 * */
data class Purchase(
    val offerId: Long = -1,
    val head: String = "",
    val posterUrl: String = "",
    val title: String = "",
    val offerTitle: String = "",
    val rating: Int = 15,
    val contentInfo: String = "",
    val viewablePeriod: String = "",
    val contentType: String = "",
    val productHead: String = "",
    val payment: ArrayList<Payment> = arrayListOf(),
    var isAuth: Boolean = false,
    val password: StringBuffer = StringBuffer(),
    var noticeStr: String = "",
    val targetType: String = "",
    val targetId: Long = -1,
    val contentId: Long = -1,
    val episodeNo: Int = 0,
    val maxLines: Int = 2,
    var isExpand: Boolean = false,
    var expandText: String,
    var enterPath: String = "",
    var isDiscount: Boolean = false,

    var price: Int = 0,
    var discountPrice: Int = 0,
    var priceStr: String = "",
    var discountPriceStr: String = "",
    var enoughPoint: Boolean = false,
    var hasPointProductList: Boolean = false,
    var pointBalance: Int = 0,
    var pointBalanceStr: String = "잔액 0원",

    var hasPayment: Boolean = false,

    var normalPrice: Int = 0,
    var pointPrice: Int = 0,
    var pointPolicyId: Long = 0,
    var pointPolicyType: String = "",
    var pointPolicyValue: Int = 0
) {
    init {
        build()
    }

    fun build() {
        Logger.Log(Log.ERROR, this, "===================================STBAgent.pointBalance ${STBAgent.pointBalance}")
        if (discountPrice > 0) {
            isDiscount = true
            priceStr = getPriceStr(discountPrice)
            discountPriceStr = getPriceStr(price) + "원"
        } else {
            priceStr = getPriceStr(price)
        }

        if (STBAgent.pointBalance < 0) {
            enoughPoint = true
            pointBalance = 0
            pointBalanceStr = "포인트 조회 실패"
        } else {
            enoughPoint = if (isDiscount) {
                (discountPrice <= STBAgent.pointBalance)
            } else {
                (price <= STBAgent.pointBalance)
            }
            pointBalance = STBAgent.pointBalance
            pointBalanceStr = "잔액 " + getPriceStr(pointBalance) + "원"
        }

        /** 카드가 등록되어 있는 경우 포인트 잔액에 따라 화면에 노출 필요  */
        hasPayment = payment[0].paymentName != "등록 필요"
//        if (hasPayment) {
//            hasPayment = !enoughPoint
//        }

        Logger.Log(Log.ERROR, this, "hasPayment $hasPayment")
        Logger.Log(Log.ERROR, this, "enoughPoint $enoughPoint")
    }

    private fun getPriceStr(intPrice: Int): String {
        val myFormatter = DecimalFormat("###,###");
        return myFormatter.format(intPrice)
    }
}

data class Payment(
    val paymentType: String = "", // 결제 수단 타입 ex) 카드간편 결제
    val paymentName: String = ""  // 결제 수단 이름 ex) 신한카드
)


