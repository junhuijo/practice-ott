package com.homechoice.ott.vod.ui.my.pay

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.homechoice.ott.vod.agent.CategoryTarget
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentAdultAuthBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.fragment_adult_auth.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AdultAuthFragment(private val activityHandler: Handler, val type: String) : NavigationListView() {
    private lateinit var binding: FragmentAdultAuthBinding
    private lateinit var adapter: PurchaseLogListAdapter
    private lateinit var viewHolder: PurchaseLogListAdapter.ViewHolder
    private val SERVICE_LOG = "serviceLog"
    private val FAV = "fav"
    private var pinNumber = ""
    private var pinInput: ArrayList<TextView?> = arrayListOf()

    @SuppressLint("InflateParams")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAdultAuthBinding.inflate(inflater)
        val keyPadList: ArrayList<ImageView> =
            arrayListOf(
                binding.numDel, // 0 <-
                binding.num0, // 1
                binding.numOk, // 2
                binding.num1, // 3 <-
                binding.num2, // 4
                binding.num3, // 5
                binding.num4, // 6 <-
                binding.num5, // 7
                binding.num6, // 8
                binding.num7, // 9 <-
                binding.num8, // 10
                binding.num9  // 11
            )

        pinInput = arrayListOf(binding.newKeypadInput0, binding.newKeypadInput1, binding.newKeypadInput2, binding.newKeypadInput3)

        for (item in keyPadList) {
            item.setOnClickListener {
                pushKey(it)
            }
        }

        //        binding.adultAuth.setOnClickListener {
        //            AdultAuthPopupView(
        //                context!!,
        //                Phone(head = "성인인증 하기", body = "홈초이스의 성인 콘텐츠를 시청하기\n위해서는 성인인증이 필요합니다.\n성인인증을 위해 휴대폰 번호를\n입력해 주세요"),
        //                object : PopupEvent {
        //                    override fun onClick(d: Dialog, btn: String) {
        //                        Logger.Log(Log.DEBUG, this, "adultAuth btn:$btn")
        //                        when (btn) {
        //                            BtnLabel.ADULT_AUTH -> {
        //                                binding.warnText.visibility = View.INVISIBLE
        //                                binding.num0.requestFocus()
        //                                d.dismiss()
        //                            }
        //                        }
        //                    }
        //                }).show()
        //        }
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if (type == SERVICE_LOG) {
            description.text = "최근 성인 콘텐츠 시청내역으로 최대 7일간 노출됩니다.\n시청 콘텐츠를 선택하여 OK 버튼을 누르면 시청, 구매, 삭제 하실 수 있습니다"
        }
        else if (type == FAV) {
            description.text = "관심있는 콘텐츠를 찜한 목록입니다. \n무제한으로 찜하기가 가능하며, 홈초이스에서 찜한 모든 콘텐츠를 한번에 확인하실 수 있습니다."
        }
        else {
            description.text = "최근 구매한 성인 콘텐츠 목록으로 월정액을 제외한 모든 콘텐츠는 최대 60일간 노출됩니다.\n구매한 콘텐츠를 선택하여 OK 버튼을 누르면 시청, 구매, 삭제, 및 (월정액) 해지 하실 수 있습니다."
        }
        showPinNumber(true)
    }

    private fun pushKey(view: View) {
        when (view.id) {
            binding.numOk.id -> okNumber()
            binding.numDel.id -> removeNumber()
            else ->
                appendNumber(view.tag as String)
        }
    }

    private fun appendNumber(num: String) {
        // PhoneNumberUtils.formatNumber(yourStringPhone, Locale.getDefault().getCountry())
        Logger.Log(Log.DEBUG, this, "appendNumber $num")
        if (pinNumber.length < 4)
            pinNumber += num
        showPinNumber(true)
    }

    private fun removeNumber() {
        if (pinNumber.isNotEmpty())
            pinNumber = pinNumber.substring(0, pinNumber.length - 1)
        showPinNumber(true)
    }

    private fun showPinNumber(isShowDefaultText: Boolean) {
        for (i in 0..3) {
            if (i > pinNumber.length - 1) {
                pinInput[i]?.text = ""
            }
            else {
                pinInput[i]?.text = "●"
            }
        }
        if (pinNumber.length == 4) {
            binding.numOk.requestFocus()
        }
        if (isShowDefaultText) {
            binding.warnText.text = "최초 비밀번호는 0000입니다."
            binding.warnText.visibility = View.VISIBLE
        }
    }

    private fun okNumber() {
        MBSAgent.adultPwCheck(STBAgent.encrypt(pinNumber)!!, object : Callback<ResponseNoBody> {
            override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                PopupAgent.showNormalPopup(
                    context!!,
                    PopupType.getErrorType(
                        TYPE.AUTH,
                        CODE.NONE
                    ),
                    object : PopupEvent {
                        override fun onClick(d: Dialog, btn: String) {
                            when (btn) {
                                BtnLabel.OK -> {
                                    d.dismiss()
                                }
                            }
                        }
                    })
            }

            override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                if (response.isSuccessful && response.body() != null) {
                    STBAgent.isMyAdultAuth = true
                    STBAgent.isAdultAuth = true
                    activityHandler.obtainMessage(10).sendToTarget()
                }
                else {
                    // 초기화 처리
                    when (response.code()) {
                        CODE.UNAUTHORIZED -> {
                            binding.warnText.text = "* 잘못된 비밀번호 입니다."
                            binding.warnText.visibility = View.VISIBLE
                            pinNumber = ""
                            STBAgent.isMyAdultAuth = false
                            showPinNumber(false)
                        }
                        412 -> {
                            binding.warnText.text = "* 성인인증 번호를 등록해주세요."
                            binding.warnText.visibility = View.VISIBLE
                            pinNumber = ""
                            STBAgent.isMyAdultAuth = false
                            showPinNumber(false)
                        }
                        CODE.CONFLICT -> {
                            UIAgent.showPopupForMyMenu(context!!, CODE.CONFLICT, object : RetryCallback {
                                override fun call() {
                                    activityHandler.obtainMessage(12, CategoryTarget.LOGIN).sendToTarget()
                                    activityHandler.obtainMessage(6, CategoryTarget.LOGIN).sendToTarget()
                                }

                                override fun cancel() {
                                    activityHandler.obtainMessage(12).sendToTarget()
                                }
                            })
                        }
                        else -> {
                            binding.warnText.text = "* 잘못된 비밀번호 입니다."
                            binding.warnText.visibility = View.VISIBLE
                            pinNumber = ""
                            STBAgent.isMyAdultAuth = false
                            showPinNumber(false)
                        }
                    }

                }
            }
        })
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(Log.DEBUG, this, "onKeyDown keyCode $keyCode")
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (binding.numDel.hasFocus() || binding.num1.hasFocus() || binding.num4.hasFocus() || binding.num7.hasFocus()) {
                    activityHandler.obtainMessage(2).sendToTarget()
                    true
                }
                else
                    false
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                false
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                binding.num7.hasFocus() || binding.num8.hasFocus() || binding.num9.hasFocus()
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                binding.numDel.hasFocus() || binding.num0.hasFocus() || binding.numOk.hasFocus()
            }

            KeyEvent.KEYCODE_BACK, 97 -> {
                activityHandler.obtainMessage(2).sendToTarget()
                true
            }
            else -> false
        }
    }

    override fun active() {
        focus()
    }

    fun focus() {
        Logger.Log(Log.DEBUG, this, "로그 리스트 focus")
        binding.num0.requestFocus()
    }

    override fun lateActive() {

    }

    override fun setVisible(visible: Int) {
        binding.root.visibility = visible
    }

}