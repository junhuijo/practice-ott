package com.homechoice.ott.vod.ui.navigation.linear

import com.homechoice.ott.vod.model.CategoryItem

class NavigationLinearLayoutModel(
    cur: Int = 0,
    pre: Int = -1,
    left: Int = 0,
    right: Int = 0,
    threshold: Int = 0,
    visible: Int = 0,
    var list: List<Any>? = listOf()
) {
    private var totalLenIndex: Int = 0
    var data: LinearLayoutModel =
        list?.size?.let { LinearLayoutModel(cur, pre, left, right, it - 1, threshold, visible, list) }!!

    var cData: CalculationModel = CalculationModel(cur, pre, initLenList(), totalLenIndex, -1)

    private fun initLenList(): List<Int> {
        val lenList = mutableListOf<Int>()
        var size: Int
        for (index in list?.indices!!) {
            size = (list!![index] as CategoryItem).posterSizeLevel
            lenList.add(size)
            totalLenIndex += size
        }
        totalLenIndex--
        return lenList
    }

    fun getCurIndex(): Int {
        return data.curIndex
    }

    fun getPreIndex(): Int {
        return data.preIndex
    }

    fun getCurItem(): Any {
        return data.list?.get(data.curIndex)!!
    }

}

data class CalculationModel(var curIndex: Int, var preIndex: Int, var lenList: List<Int>, var totalIndex: Int, var visibleIndex: Int) {
    operator fun get(index: Int): Int {
        return lenList[index]
    }
}

data class LinearLayoutModel(
    var curIndex: Int,
    var preIndex: Int,
    var leftFixedIndex: Int,
    var rightFixedIndex: Int,
    var totalIndex: Int,
    var visibleThreshold: Int,
    var visibleIndex: Int,
    var list: List<Any>?
)