package com.homechoice.ott.vod.model.request

data class RequestEasyPayment(
    val terminalKey: String = "",
    val offerId: Long = 0,
    val paymentPw: String = "",
    val price: Int = 0,
    val discountPrice: Int = 0,
    val normalPrice: Int = 0,
    val pointPrice: Int = 0,
    val targetType: String = "",
    val targetId: Long = -1,
    val episodeNo: Int = 0,
    val contentId: Long = -1,
    val enterPath: String = "",
    val pointPolicyId: Long = 0
)
