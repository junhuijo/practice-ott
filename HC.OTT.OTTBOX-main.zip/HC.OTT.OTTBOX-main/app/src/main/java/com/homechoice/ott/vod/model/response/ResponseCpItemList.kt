package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.CategoryList
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseCpItemList(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    var cpItemList: List<CategoryItem>
) : Parcelable