package com.homechoice.ott.vod.ui.my

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.children
import androidx.fragment.app.Fragment
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.ActivityChangeAgent.goToAdultPasswordSettingMenu
import com.homechoice.ott.vod.agent.ActivityChangeAgent.goToKidsLockMenu
import com.homechoice.ott.vod.agent.Category
import com.homechoice.ott.vod.agent.CategoryAgent
import com.homechoice.ott.vod.agent.CategoryTarget
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.ui.home.HomeActivity2
import com.homechoice.ott.vod.ui.my.category.MyCategoryListFragment
import com.homechoice.ott.vod.ui.my.member.*
import com.homechoice.ott.vod.ui.my.notice.EventListFragment
import com.homechoice.ott.vod.ui.my.notice.NoticeListFragment
import com.homechoice.ott.vod.ui.my.notice.ServiceCenterFragment
import com.homechoice.ott.vod.ui.my.notice.WishListFragment
import com.homechoice.ott.vod.ui.my.pay.*
import com.homechoice.ott.vod.ui.my.point.PointHistoryListFragment
import com.homechoice.ott.vod.ui.my.point.PointProductListFragment
import com.homechoice.ott.vod.ui.my.point.PointRegisterFragment
import com.homechoice.ott.vod.ui.my.serviceLog.ServiceLogListFragment
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.util.Logger
import kotlinx.coroutines.*
import kotlin.system.exitProcess

class MyActivity2 : AppCompatActivity() {

    var ctx = this
    var context = this

    private var keyTag = "MY_CATEGORY_LIST"

    private lateinit var categoryListFragment: MyCategoryListFragment
    private var purchaseLogListFragment: PurchaseLogListFragment? = null
    private var monthListFragment: MonthListFragment? = null
    private var memberLoginFragment: MemberLoginFragment? = null
    private var memberLogoutFragment: MemberLogoutFragment? = null
    private var changeCardFragment: ChangeCardFragment? = null
    private var serviceLogListFragment: ServiceLogListFragment? = null
    private var changePasswordFragment: ChangePasswordFragment? = null
    private var changeUserInfoFragment: ChangeUserInfoFragment? = null
    private var changeAdultPinNumberFragment: ChangeAdultPinNumberFragment? = null
    private var noticeListFragment: NoticeListFragment? = null
    private var eventListFragment: EventListFragment? = null
    private var serviceCenterFragment: ServiceCenterFragment? = null
    private var wishListFragment: WishListFragment? = null
    private lateinit var activityHandler: Handler
    private lateinit var activeFragment: NavigationListView
    private lateinit var currentCategory: Category
    private var isLoaded = false
    private val hiddenKeyList = arrayListOf(90, 90, 90, 89, 89, 89, 90, 89)
    private var inputHiddenKeyList = arrayListOf<Int>()

    private var job: Job = Job()

    private val authListener = object : AuthListener {
        override fun next() {
        }
    }

    data class Target(
        val info: String = "",
        var id: Int = 0,
        var index: Int = 0
    )

    object ActionType {
        const val MY_SUB_MENU_UPDATE = 0
        const val MY_SUB_MENU_FOCUS = 1
        const val MY_CATEGORY_FOCUS = 2
        const val MY_SUB_MENU_HIDE = 3
        const val MY_MENU_EXIT = 5

        const val CATEGORY_0 = 0
        const val CATEGORY_1 = 1
        const val CATEGORY_2 = 2
        const val CATEGORY_3 = 3
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my)
        STBAgent.setBackgroundImage(findViewById(R.id.background_image))
        CategoryAgent.init()
        CategoryAgent.onUserDataLoaded()

        // 진입 시 초기화 삭제 -> 앱 구동 시 한번 인증만 하도록 수정
        // STBAgent.isMyAdultAuth = false

        val target = setTarget(Target(info = intent.getStringExtra("TARGET_INFO")!!))

        activityHandler = Handler {
            Logger.Log(Log.DEBUG, this, "activityHandler it.what ${it.what}")
            when (it.what) {
                0 -> {
                    // 깜빡이는 현상으로 인해, Fragment 내부에 넣지 못함.
                    findViewById<FrameLayout>(R.id.my_menu_layout).visibility = View.VISIBLE
                    currentCategory = it.obj as Category

                }
                1 -> {
                    if (isLoaded) {
                        categoryListFragment.select()
                        entrySubMenu(currentCategory)
                    }
                }
                2 -> {
                    keyTag = "MY_CATEGORY_LIST"
                    categoryListFragment.focus()
                }
                3 -> {
                    if (::activeFragment.isInitialized) {
                        supportFragmentManager.beginTransaction().remove(activeFragment).commit()
                    }

                    findViewById<FrameLayout>(R.id.my_menu_layout).visibility = View.INVISIBLE
                    purchaseLogListFragment?.setVisible(View.INVISIBLE)
                    monthListFragment?.setVisible(View.INVISIBLE)
                    serviceLogListFragment?.setVisible(View.INVISIBLE)
                }
                4 -> {
                    showMemberLogin(authListener)
                    keyTag = "MY_CATEGORY_LIST"
                    categoryListFragment.update()
                    categoryListFragment.focus()
                }
                5 -> {
                    finish()
                }
                6 -> {
                    // 로그인 메뉴로 이동
                    val targetCategory = setTarget(Target(it.obj as String))
                    Logger.Log(Log.INFO, this, "targetCategory $targetCategory")
                    categoryListFragment = MyCategoryListFragment(
                        activityHandler = activityHandler,
                        targetId = targetCategory.id,
                        targetIndex = targetCategory.index,
                        targetInfo = targetCategory.info
                    )
                    fragmentTransaction(
                        R.id.my_category_list_layout,
                        categoryListFragment,
                        "MY_CATEGORY_LIST"
                    )
                    keyTag = "MY_CATEGORY_LIST"
                }

                7 -> {
                    //showMemberLogin()
                    keyTag = "MY_CATEGORY_LIST"
                    categoryListFragment.update()
                    categoryListFragment.focus()
                    categoryListFragment.back()
                }
                10 -> {
                    syncShowSubMenu(currentCategory)
                    activeFragment.lateActive()
                    keyTag = activeFragment::class.simpleName!!
                }
                11 -> {
                    isLoaded = true
                    val message = activityHandler.obtainMessage(1, currentCategory)
                    activityHandler.sendMessage(message)

                }
                12 -> {
                    showMemberLogin(authListener)
                    categoryListFragment.update()
                }
                13 -> {
                    goToHome()
                }

            }
            true
        }

        categoryListFragment = MyCategoryListFragment(
            activityHandler = activityHandler,
            targetId = target.id,
            targetIndex = target.index,
            targetInfo = target.info
        )

        fragmentTransaction(
            R.id.my_category_list_layout,
            categoryListFragment,
            "MY_CATEGORY_LIST"
        )
    }

    override fun onResume() {
        super.onResume()
        Logger.Log(Log.DEBUG, this, "onResume")
        CategoryAgent.onUserDataLoaded()
        categoryListFragment.update()
    }

    private fun setTarget(target: Target): Target {
        if (target.info != CategoryTarget.ROOT) {
            var category = CategoryAgent.getTargetCategory(target.info)
            Logger.Log(Log.INFO, this, "category $category")
            if (category != null) {
                if (category.leaf) {
                    if (category.hasCategory) {
                        target.id = category.id
                        target.index = 0
                    }
                    else {
                        target.id = CategoryAgent.getMyCategory(category.parentId)?.id!!
                        target.index = category.displayOrder
                    }
                }
                else {
                    // 하위 카테고리를 포함하는 지 확인
                    if (category.hasCategory) {
                        target.id = category.parentId
                        target.index = category.displayOrder
                    }
                    else {
                        category = CategoryAgent.getMyCategory(category.parentId)
                        target.id = category!!.parentId
                        target.index = category.displayOrder
                    }
                }
            }
        }
        return target
    }

    private fun entrySubMenu(category: Category) {
        Logger.Log(Log.DEBUG, this, "entrySubMenu ${category.name}")
        if (isLoaded) {
            when (category.target) {
                CategoryTarget.USER -> {
                }
                CategoryTarget.PAY -> {
                }
                CategoryTarget.WAT -> {
                }
                CategoryTarget.FAV -> {
                }
                CategoryTarget.NOTICE -> {
                }

                CategoryTarget.LOGIN -> {
                    entryMemberLogin()
                }
                CategoryTarget.CARD -> {
                    keyTag = "CHANGE_CARD"
                    changeCardFragment?.focus()
                }
//                CategoryTarget.PIN_ADULT -> {
//                    keyTag = "CHANGE_ADULT"
//                    changeAdultPinNumberFragment?.focus()
//                }
                CategoryTarget.PW -> {
                    keyTag = "CHANGE_PASSWORD"
                    changePasswordFragment?.focus()
                }

                CategoryTarget.INFO -> {
                    keyTag = "CHANGE_USER_INFO"
                    changeUserInfoFragment?.focus()
                }
                CategoryTarget.PIN_ADULT,
                CategoryTarget.POINT_REGISTER,
                CategoryTarget.POINT_PURCHASE,
                CategoryTarget.POINT_HISTORY,
                CategoryTarget.POINT_FAQ,
                CategoryTarget.FAV_NORMAL,
                CategoryTarget.FAV_ADULT,
                CategoryTarget.PAY_NORMAL,
                CategoryTarget.PAY_SERIES,
                CategoryTarget.PAY_MONTH,
                CategoryTarget.PAY_BUNDLE,
                CategoryTarget.WAT_NORMAL,
                CategoryTarget.WAT_ADULT,
                CategoryTarget.PAY_ADULT -> {
                    entryPurchaseLogFragment(category.target)
                }

                CategoryTarget.NOTICE_LIST -> {
                    keyTag = "NOTICE_LIST"
                    noticeListFragment?.focus()
                }

                CategoryTarget.EVENT -> {
                    keyTag = "EVENT_LIST"
                    eventListFragment?.focus()
                }
                CategoryTarget.SERVICE -> {
                }
            }
        }
    }

    private fun entryMemberLogin() {
        if (!STBAgent.isAuth) {
            keyTag = "MEMBER_LOGIN"
            memberLoginFragment?.focus()
        }
        else {
            keyTag = "MEMBER_LOGOUT"
            memberLogoutFragment?.focus()
        }
    }

    private fun showMemberLogin(listener: AuthListener) {
        if (STBAgent.isAuth) {
            MemberLogoutFragment(activityHandler = activityHandler).also { memberLogoutFragment = it }
            fragmentTransaction(
                R.id.my_menu_layout,
                memberLogoutFragment,
                "MEMBER_LOGOUT"
            )
        } else {
            PopupAgent.appStartShowLoginPopup(this, Login(forceLogin = true, terminalKey = MBSAgent.terminalKey, loginqr = null), object : LoginPopupEvent {
                override fun onLogin(loginDialog: Dialog, btn: String) {
                    when (btn) {
                        BtnLabel.SUCCESS -> {
                            listener.next()
                            goToHome()
//                            removeCurrentFragment()
                        }
                        else -> {
                            goToHome()
                        }
                    }
                }
            })
        }
    }

    private fun syncShowSubMenu(category: Category) {
        when (category.target) {
            CategoryTarget.POINT_REGISTER,
            CategoryTarget.POINT_PURCHASE,
            CategoryTarget.POINT_HISTORY,
            CategoryTarget.POINT_FAQ,
            CategoryTarget.FAV_NORMAL,
            CategoryTarget.FAV_ADULT,
            CategoryTarget.PAY_NORMAL,
            CategoryTarget.PAY_SERIES,
            CategoryTarget.PAY_MONTH,
            CategoryTarget.PAY_BUNDLE,
            CategoryTarget.WAT_NORMAL,
            CategoryTarget.WAT_ADULT,
            CategoryTarget.PIN_ADULT,
            CategoryTarget.PAY_ADULT -> {
                if (job.isActive) {
                    job.cancel()
                }
                selectFragment(category)
            }
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun showSubMenu(category: Category) {
        isLoaded = false
        when (category.target) {

            CategoryTarget.LOGIN -> {
                showMemberLogin(authListener)
                isLoaded = true
            }

            CategoryTarget.WAT_NORMAL,
            CategoryTarget.FAV_NORMAL -> {
                if (!STBAgent.isAuth) {
                    showMemberLogin(authListener)
                } else {
                    if (job.isActive) {
                        job.cancel()
                    }
                    job = GlobalScope.launch(Dispatchers.Main) {
                        delay(200L)
                        selectFragment(category)
                    }
                }
            }

            CategoryTarget.NOTICE_LIST -> {
                NoticeListFragment(activityHandler = activityHandler, category = category).also {
                    noticeListFragment = it
                    fragmentTransaction(
                        R.id.my_menu_layout,
                        it,
                        "NOTICE_LIST"
                    )
                }
                isLoaded = true
            }

            CategoryTarget.PIN_ADULT,
            CategoryTarget.POINT_REGISTER,
            CategoryTarget.POINT_PURCHASE,
            CategoryTarget.POINT_HISTORY,
            CategoryTarget.POINT_FAQ,
            CategoryTarget.FAV_ADULT,
            CategoryTarget.PAY_NORMAL,
            CategoryTarget.PAY_SERIES,
            CategoryTarget.PAY_MONTH,
            CategoryTarget.PAY_BUNDLE,
            CategoryTarget.WAT_ADULT,
            CategoryTarget.PAY_ADULT -> {
                if (job.isActive) {
                    job.cancel()
                }
                job = GlobalScope.launch(Dispatchers.Main) {
                    delay(200L)
                    selectFragment(category)
                }
            }

            CategoryTarget.ADULT -> {
                goToAdultPasswordSettingMenu(ctx)
            }

            CategoryTarget.KIDS_LOCK -> {
                goToKidsLockMenu(ctx)
            }

            CategoryTarget.EXIT -> {
                exitPopup()
            }
        }
    }

    private fun selectFragment(category: Category) {
        val categoryTarget = category.target
        Logger.Log(Log.ERROR, this, "selectFragment : $categoryTarget")
        if (STBAgent.isAuth) {
            activeFragment =
                if (categoryTarget == CategoryTarget.PAY_ADULT || categoryTarget == CategoryTarget.WAT_ADULT || categoryTarget == CategoryTarget.FAV_ADULT) {
                    if (STBAgent.isMyAdultAuth) {
                        // 성인인증 미필요
                        when (categoryTarget) {
                            CategoryTarget.PAY_MONTH -> MonthListFragment(activityHandler = activityHandler)
                            CategoryTarget.WAT_ADULT, CategoryTarget.WAT_NORMAL -> {
                                ServiceLogListFragment(activityHandler, categoryTarget)
                            }
                            CategoryTarget.FAV_ADULT, CategoryTarget.FAV_NORMAL -> {
                                WishListFragment(activityHandler, categoryTarget)
                            }
                            CategoryTarget.PAY_ADULT -> {
                                // 성인인증 화면
                                AdultPurchaseLogListFragment(activityHandler = activityHandler)
                            }
                            else -> PurchaseLogListFragment(activityHandler = activityHandler, categoryTarget = categoryTarget)
                        }
                    }
                    else {
                        // 성인인증 필요
                        isLoaded = true
                        val type = when (categoryTarget) {
                            CategoryTarget.WAT_ADULT -> "serviceLog"
                            CategoryTarget.FAV_ADULT -> "fav"
                            else -> "purchaseLog"
                        }
                        AdultAuthFragment(activityHandler = activityHandler, type = type)
                    }
                }
                else if (categoryTarget == CategoryTarget.PIN_ADULT) {
                    isLoaded = true
                    ChangeAdultPinNumberFragment(activityHandler = activityHandler).also { changeAdultPinNumberFragment = it }
                }
                else {
                    // 성인인증 미필요
                    when (categoryTarget) {
                        CategoryTarget.WAT_ADULT, CategoryTarget.WAT_NORMAL -> {
                            ServiceLogListFragment(activityHandler, categoryTarget)
                        }
                        CategoryTarget.FAV_ADULT, CategoryTarget.FAV_NORMAL -> {
                            WishListFragment(activityHandler, categoryTarget)
                        }
                        CategoryTarget.POINT_REGISTER -> {
                            PointRegisterFragment(activityHandler = activityHandler, categoryTarget = categoryTarget)
                        }
                        CategoryTarget.POINT_PURCHASE -> {
                            PointProductListFragment(activityHandler = activityHandler, categoryTarget = categoryTarget)
                        }
                        CategoryTarget.POINT_HISTORY -> {
                            PointHistoryListFragment(activityHandler = activityHandler, categoryTarget = categoryTarget)
                        }
                        CategoryTarget.POINT_FAQ -> {
                            NoticeListFragment(activityHandler = activityHandler, category = category)
                        }
                        else -> PurchaseLogListFragment(activityHandler = activityHandler, categoryTarget = categoryTarget)
                    }
                }
        }
        else {
            when (categoryTarget) {
                CategoryTarget.POINT_FAQ -> {
                    activeFragment = NoticeListFragment(activityHandler = activityHandler, category = category)
                }
                else -> {
                    // 로그인 노출
                    activeFragment = LoginButtonFragment(activityHandler = activityHandler, categoryTarget = categoryTarget)
                    isLoaded = true
                }
            }
        }

        fragmentTransaction(
            R.id.my_menu_layout,
            activeFragment,
            activeFragment::class.simpleName!!
        )
    }

    private fun entryPurchaseLogFragment(categoryTarget: String) {
        activeFragment.active()
        keyTag = activeFragment::class.simpleName!!
    }

    private fun fragmentTransaction(layoutId: Int, fragment: Fragment?, tag: String) {
        supportFragmentManager.beginTransaction().replace(layoutId, fragment!!, tag).addToBackStack(tag).commit()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        return if (event.action == KeyEvent.ACTION_DOWN) {
            Logger.Log(Log.ERROR, this, "dispatchKeyEvent event.keyCode : ${event.keyCode}")
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, 96 -> {
                    if(findViewById<FrameLayout>(R.id.my_menu_layout).childCount == 0) {
                        showSubMenu(currentCategory)

                        val message = activityHandler.obtainMessage(1, currentCategory)
                        activityHandler.sendMessage(message)
                    }
                    true
                }
                KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE, 97 -> {
                    if(findViewById<FrameLayout>(R.id.my_menu_layout).childCount>0){
                        removeLogoutFragment()
                        Log.d("layout's child", findViewById<FrameLayout>(R.id.my_menu_layout).children.toString())
                    }
                    else{
                        finish()
                        true
                    }
                    true
                }
            }

            if (supportFragmentManager.findFragmentByTag(keyTag) is NavigationView2) {
                if ((supportFragmentManager.findFragmentByTag(keyTag) as NavigationView2).onKeyDown(event.keyCode)) {
                    true
                }
                else {
                    super.dispatchKeyEvent(event)
                }
            }
            else {
                if ((supportFragmentManager.findFragmentByTag(keyTag) as NavigationListView).onKeyDown(event.keyCode)) {
                    true
                }
                else {
                    super.dispatchKeyEvent(event)
                }
            }
        }
        else {
            when (event.keyCode) {
                else -> {
                    super.dispatchKeyEvent(event)
                }
            }
        }
    }

    private fun exitPopup() {
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        val dialogView = layoutInflater.inflate(R.layout.dialog_app_exit, null)

        val confirmBtn = dialogView.findViewById<TextView>(R.id.btn_confirm)
        val cancelBtn = dialogView.findViewById<TextView>(R.id.btn_cancel)

        builder.setView(dialogView)
        val dialog = builder.create()

        //팝업 흰색 배경 제거
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
        cancelBtn.requestFocus()

        confirmBtn.setOnKeyListener { view, keyCode, keyEvent ->
            if (keyEvent.action==KeyEvent.ACTION_DOWN){
                when(keyCode){
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER->{
                        dialog.dismiss()
                        finishAffinity()
                        exitProcess(0)
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT->{
                        cancelBtn.requestFocus()
                        false
                    }
                    KeyEvent.KEYCODE_BACK->{
                        dialog.dismiss()
                        true
                    }
                }
            }
            false
        }
        cancelBtn.setOnKeyListener { view, keyCode, keyEvent ->
            if (keyEvent.action==KeyEvent.ACTION_DOWN){
                when(keyCode){
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER->{
                        dialog.dismiss()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT->{
                        confirmBtn.requestFocus()
                        false
                    }
                    KeyEvent.KEYCODE_BACK->{
                        dialog.dismiss()
                        true
                    }
                }
            }
            false
        }
    }

    private fun removeLogoutFragment() {
        val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_my_member_logout_list)
        currentFragment?.let { fragment ->
            supportFragmentManager.beginTransaction().remove(fragment).commit()
        }
    }

    private fun goToHome() {
        val intent = Intent(this, HomeActivity2::class.java)
        intent.putExtra("TARGET_INFO", CategoryTarget.ROOT)
        finish()
    }

    private interface AuthListener {
        fun next()
    }
}