package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class ResponseCardName(
    val transactionId: String,
    val errorString: String,
    val cardName: String,
    val sessionState: String = ""
) : Parcelable