package com.homechoice.ott.vod.ui.navigation.popup

import android.util.Log
import com.homechoice.ott.vod.util.Logger

class NavigationPopupController(var model: NavigationPopupModel, var event: NavigationPopupEvent) {
    val data = model.data
    fun decrease(): Boolean {
        return if (data.curIndex > 0) {
            data.preIndex = data.curIndex
            data.curIndex--
            event.unfocusChange(data.preIndex)
            event.focusChange(data.curIndex)
            true
        } else {
            printString()
            false
        }
    }

    fun increase(): Boolean {
        return if (data.curIndex < (data.totalCount - 1)) {
            data.preIndex = data.curIndex
            data.curIndex++
            event.unfocusChange(data.preIndex)
            event.focusChange(data.curIndex)
            printString()
            true
        } else {
            printString()
            false
        }
    }

    fun decreaseRow(): Boolean {
        return if ((data.curIndex - data.colCount) >= 0) {
            data.preIndex = data.curIndex
            data.curIndex -= data.colCount
            event.unfocusChange(data.preIndex)
            event.focusChange(data.curIndex)
            printString()
            true
        } else{
            printString()
            false
        }
    }

    fun increaseRow(): Boolean {
        return if ((data.curIndex + data.colCount) <= (data.totalCount - 1)) {
            data.preIndex = data.curIndex
            data.curIndex += data.colCount
            event.unfocusChange(data.preIndex)
            event.focusChange(data.curIndex)
            printString()
            true
        } else {
            printString()
            false
        }
    }

    fun getCurIndex(): Int {
        return data.curIndex
    }

    fun setCurIndex(index: Int) {
        data.preIndex = data.curIndex
        data.curIndex = index
    }

    private fun printString() {
        Logger.Log(
            Log.DEBUG,
            this,
            "NavigationView ${data.toString()}"
        )
    }

    fun getCurItem(): Any? {
        return data.list[data.curIndex]
    }

    private fun getPreItem(): Any? {
        return data.list[data.preIndex]
    }

}