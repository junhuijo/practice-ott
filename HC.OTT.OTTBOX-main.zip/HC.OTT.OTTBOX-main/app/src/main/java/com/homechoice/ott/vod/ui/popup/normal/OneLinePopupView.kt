package com.homechoice.ott.vod.ui.popup.normal

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.view.LayoutInflater
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.databinding.DialogOneLineNoBtnBinding
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.PopupViewModel

class OneLinePopupView(ctx: Context, model: PopupViewModel, event: PopupEvent) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {
    private var binding: DialogOneLineNoBtnBinding

    init {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        setCancelable(false)
        binding = DialogOneLineNoBtnBinding.inflate(LayoutInflater.from(ctx))
        binding.apply {
            viewModel = model
        }
        setContentView(binding.root)

        Handler().postDelayed({
            dismiss()
            event.onClick(this, BtnLabel.OK)
        }, 3 * 1000L)

        event.onClick(this, BtnLabel.SUCCESS)
    }

}