package com.homechoice.ott.vod.ui.popup.pay

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.DialogUnSubscriptionPurchaseLogBinding
import com.homechoice.ott.vod.event.RetryCallback
import com.homechoice.ott.vod.model.purchaseLog.PurchaseLog
import com.homechoice.ott.vod.model.response.ResponseNoBody
import com.homechoice.ott.vod.popup.*
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


@SuppressLint("SetTextI18n")
class UnSubscriptionPopupView(
    ctx: Context,
    val log: PurchaseLog,
    val event: PopupEvent
) : Dialog(ctx, R.style.Theme_Design_NoActionBar) {
    private var binding: DialogUnSubscriptionPurchaseLogBinding = DialogUnSubscriptionPurchaseLogBinding.inflate(LayoutInflater.from(ctx))
    private val dialog = this

    init {
        if (log.title.length > 16)
            log.title = "${log.title.substring(0, 15)}.."
        binding.title.text = "<${log.title}>을 해지하시겠습니까?"
        setContentView(binding.root)
        binding.num0.requestFocus()

        val keyPadList: ArrayList<LinearLayout> =
            arrayListOf(
                binding.numDel, // 0 <-
                binding.num0, // 1
                binding.numOk, // 2
                binding.num1, // 3 <-
                binding.num2, // 4
                binding.num3, // 5
                binding.num4, // 6 <-
                binding.num5, // 7
                binding.num6, // 8
                binding.num7, // 9 <-
                binding.num8, // 10
                binding.num9  // 11
            )

        for (item in keyPadList) {
            item.setOnClickListener {
                pushKey(it)
            }
        }

        setOnKeyListener { _, kCode, kEvent ->
            val result = false
            Logger.Log(Log.DEBUG, this, "kCode:$kCode")
            if (kEvent.action == KeyEvent.ACTION_DOWN) {
                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                    }
                }
            }
            result
        }

        show()
    }

    private fun pushKey(view: View) {
        when (view.id) {
            binding.numOk.id -> okNumber()
            binding.numDel.id -> removeNumber()
            else ->
                appendNumber(view.tag as String)
        }
    }

    private fun appendNumber(num: String) {
        // PhoneNumberUtils.formatNumber(yourStringPhone, Locale.getDefault().getCountry())
        Logger.Log(Log.DEBUG, this, "appendNumber $num")
        var number = binding.regJoinNumber.text.toString()
        number += num
        binding.regJoinNumber.text = number
    }

    private fun removeNumber() {
        var numbers = binding.regJoinNumber.text
        if (numbers.isNotEmpty())
            numbers = numbers.substring(0, numbers.length - 1)
        binding.regJoinNumber.text = numbers
        binding.warnText.visibility = View.INVISIBLE
    }

    private fun okNumber() {
        val numbers = binding.regJoinNumber.text.toString()
        if (numbers.isNotEmpty()) {
            MBSAgent.paymentCancel(log.purchaseId, numbers, "termination", object : Callback<ResponseNoBody> {
                override fun onFailure(call: Call<ResponseNoBody>, t: Throwable) {
                    PopupAgent.showNormalPopup(
                        context,
                        PopupType.getErrorType(
                            TYPE.AUTH,
                            CODE.NONE
                        ),
                        object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                when (btn) {
                                    BtnLabel.OK -> {
                                        d.dismiss()
                                    }
                                }
                            }
                        })
                }

                override fun onResponse(call: Call<ResponseNoBody>, response: Response<ResponseNoBody>) {
                    if (response.isSuccessful && response.body() != null) {
                        PopupAgent.showNormalPopup(context, PopupType.NormalPopupType.UN_SUBSCRIPTION, object : PopupEvent {
                            override fun onClick(d: Dialog, btn: String) {
                                d.dismiss()
                                event.onClick(dialog, BtnLabel.OK)
                            }
                        })
                    } else {
                        // 초기화 처리
                        when (response.code()) {
                            CODE.CONFLICT -> {
                                UIAgent.showPopup(context, response.code(), object : RetryCallback {
                                    override fun call() {
                                        okNumber()
                                    }
                                    override fun cancel() {
                                    }
                                })
                            }
                            else -> {
                                binding.regJoinNumber.text = ""
                                binding.warnText.visibility = View.VISIBLE
                            }
                        }
                    }
                }
            })
        } else {
            binding.warnText.visibility = View.VISIBLE
        }

    }

}