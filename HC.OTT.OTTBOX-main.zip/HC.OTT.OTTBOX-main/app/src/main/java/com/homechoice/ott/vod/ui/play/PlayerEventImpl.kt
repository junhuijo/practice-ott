package com.homechoice.ott.vod.ui.play

import android.os.Handler
import android.util.Log
import com.homechoice.ott.vod.util.Logger
import com.google.android.exoplayer2.ExoPlaybackException
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.Timeline
import com.google.android.exoplayer2.source.TrackGroupArray
import com.google.android.exoplayer2.trackselection.TrackSelectionArray

class PlayerEventImpl(var handler: Handler, var errorEventHandler: Handler) : Player.DefaultEventListener() {

    override fun onTimelineChanged(timeline: Timeline, reason: Int) {
        Logger.playerLog(Log.INFO, "onTimelineChanged reason $reason")
        handler.obtainMessage(PlayerActivity.CustomPlayEvent.TIMELINE_CHANGED).sendToTarget()
    }

    override fun onTracksChanged(trackGroups: TrackGroupArray, trackSelections: TrackSelectionArray) {
        Logger.playerLog(Log.INFO, "onTracksChanged")
        handler.obtainMessage(PlayerActivity.CustomPlayEvent.TRACKS_CHANGED).sendToTarget()
    }

    /**
     * LOG 상으론 true 때 currentPosition 바뀜
     * */
    override fun onLoadingChanged(isLoading: Boolean) {
        Logger.playerLog(Log.INFO, "onLoadingChanged($isLoading)")
        if (isLoading)
            handler.obtainMessage(PlayerActivity.CustomPlayEvent.LOADING_CHANGED).sendToTarget()
    }

    override fun onPlayerStateChanged(playWhenReady: Boolean, playbackState: Int) {
        Logger.playerLog(Log.INFO, "onPlayerStateChanged playWhenReady:$playWhenReady / playbackState:$playbackState")
        when (playbackState) {
            ExoPlayer.STATE_IDLE -> {
            }
            ExoPlayer.STATE_BUFFERING -> {
            }
            ExoPlayer.STATE_READY -> {
            }
            ExoPlayer.STATE_ENDED -> {
            }
            else -> {
            }
        }
        handler.obtainMessage(playbackState).sendToTarget()
    }

    override fun onPlayerError(e: ExoPlaybackException) {
        var errorString = ""
        when (e.type) {
            ExoPlaybackException.TYPE_SOURCE -> errorString = e.sourceException.toString()
            ExoPlaybackException.TYPE_RENDERER -> errorString = e.rendererException.toString()
            ExoPlaybackException.TYPE_REMOTE -> errorString = e.toString()
            ExoPlaybackException.TYPE_UNEXPECTED -> errorString = e.unexpectedException.toString()
        }
        Logger.playerLog(Log.ERROR, "onPlayerError : (${e.type}) / errorString:$errorString")
        errorEventHandler.obtainMessage(e.type, errorString).sendToTarget()
    }

    override fun onSeekProcessed() {
        Logger.Log(Log.INFO, this, "onSeekProcessed")
    }
}