package com.homechoice.ott.vod.event

interface MBSCallback {
    fun success()
    fun error(responseCode: Int)
    fun failure(responseCode: Int)
}