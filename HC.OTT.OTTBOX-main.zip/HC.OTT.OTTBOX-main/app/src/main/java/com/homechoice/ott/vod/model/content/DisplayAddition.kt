package com.homechoice.ott.vod.model.content

data class DisplayAddition(
    val isLeftButtonIndicator: Boolean,
    val isRightButtonIndicator: Boolean,
    val episodeIndicatorVisible: Boolean
)