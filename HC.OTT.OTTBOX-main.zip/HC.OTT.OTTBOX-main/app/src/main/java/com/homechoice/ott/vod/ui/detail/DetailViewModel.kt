package com.homechoice.ott.vod.ui.detail

import android.util.Log
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.*
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.content.*
import com.homechoice.ott.vod.model.response.CheckPermissionResponse
import com.homechoice.ott.vod.ui.navigation.navigator.NavigatorModel
import com.homechoice.ott.vod.util.Logger
import kotlinx.android.synthetic.main.button_item.view.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.DecimalFormat


class DetailViewModel : ViewModel() {
    var display: MutableLiveData<Display> = MutableLiveData()
    var recommendDisplay: MutableLiveData<RecommendDisplay> = MutableLiveData()
    var isLike: MutableLiveData<Boolean> = MutableLiveData()
    var displayAddition: MutableLiveData<DisplayAddition> = MutableLiveData<DisplayAddition>().also {
        it.value = DisplayAddition(
            isRightButtonIndicator = false,
            isLeftButtonIndicator = false,
            episodeIndicatorVisible = false
        )
    }

    private val _offerList = MutableLiveData<List<Offer>?>()
    val offerList: LiveData<List<Offer>?> = _offerList

    lateinit var buttonListModel: NavigatorModel

    private var likeModel: LikeModel = LikeModel()

    private var offerContentList: ArrayList<OfferContent> = arrayListOf()

    lateinit var listener: DetailViewModelListener

    lateinit var recommendListModel: NavigatorModel
    var categoryItemList: List<CategoryItem>? = null
    //찜하기 버튼 제거
    private val _isAdultContent = MutableLiveData<Boolean>()
    val isAdultContent: LiveData<Boolean> = _isAdultContent

    private val _isPurchased = MutableLiveData<Boolean>()
    val isPurchased: LiveData<Boolean> = _isPurchased

    private var isButtonClickable = true

    // 버튼 생성 및 레이아웃에 추가하는 함수
    // 콘텐츠 그룹의 오퍼 내용에 따라 동적으로 버튼을 생성하고 텍스트를 설정
    // 미리보기와 예고편 버튼도 조건에 따라 추가
    fun createButton(parent: LinearLayout, contentGroup: ContentGroup, vararg oferrValue: List<Offer>) {
        parent.removeAllViews()
        val offerContents: List<OfferContent> = contentGroup.offerContentList
        for (offerContent in offerContents) {
            when (offerContent.productType) {
                ProductType.SUBSCRIPTION -> {
                    val view = LayoutInflater.from(parent.context).inflate(R.layout.button_month_item, parent, false)
                    val button = view.detail_button
                    button.text = getButtonText(offerContent, oferrValue.firstOrNull() ?: emptyList())
                    parent.addView(view)
                }
                else -> {
                    val view = LayoutInflater.from(parent.context).inflate(R.layout.button_item, parent, false)
                    val button = view.detail_button
                    button.text = getButtonText(offerContent, oferrValue.firstOrNull() ?: emptyList())
                    parent.addView(view)
                }
            }
        }
    }

//    private fun previewPlay(contentGroup: ContentGroup, content: Content, isPreview: Boolean, isTrailer: Boolean) {
//        var url = contentGroup.previewUrl
//        if (isTrailer)
//            url = contentGroup.trailerUrl
//
//        val contentIdStr = parseContentId(content.movieUrl)
//        MBSAgent.getDrmToken(MBSAgent.terminalKey, contentIdStr, object : Callback<ResponseDrmToken> {
//            override fun onResponse(call: Call<ResponseDrmToken>, response: Response<ResponseDrmToken>) {
//                val drmToken = response.body();
//                val playContent = PlayContent(
//                    id = content.id, //TODO: contentId  static으로 들어있음
//                    title = contentGroup.title ?: "",
//                    movieUrl = url ?: "",
//                    genre = content.genre ?: "",
//                    thumbnailUrl = content.thumbnailUrl ?: "",
//                    thumbnailServerInfo = content.thumbnailServerInfo ?: "",
//                    offset = 0,
//                    advUrl = contentGroup.advUrl ?: "",
//                    isTrailer = isTrailer,
//                    isPreview = isPreview,
//                    isPurchase = false,
//                    rating = content.rating!!,
//                    previewDurationInSec = contentGroup.previewDurationInSec!!,
//                    drmToken = drmToken?.drmToken!!
//                )
//                play(playContent)
//            }
//
//            override fun onFailure(call: Call<ResponseDrmToken>, t: Throwable) {
//            }
//        })
//    }
//
//    private fun play(playContent: PlayContent) {
//        val intent = Intent(context, PlayerActivity::class.java)
//        intent.putExtra("content", playContent)
//        startActivity(intent)
//    }

    // 무료 콘텐츠를 오퍼 목록에 추가하는 private 함수
    private fun appendFreeContent(offerContent: OfferContent) {
        val newOffer = OfferContent(
            offerContent.id,
            offerContent.title,
            offerContent.posterUrl,
            offerContent.packageType,
            offerContent.productType,
            0,
            0,
            offerContent.rentalPeriod,
            offerContent.eventType,
            offerContent.isPurchase,
            offerContent.viewablePeriod,
            offerContent.pointPolicyId,
            offerContent.pointPolicyType,
            offerContent.pointPolicyValue,
            offerContent.contentList
        )
        offerContentList.add(newOffer)
    }

    // 오퍼 콘텐츠에 따라 버튼 텍스트를 결정하는 private 함수
    private fun getButtonText(offerContent: OfferContent, vararg oferrValue: List<Offer>): String {
        if (offerContent.productType == ProductType.RENT && offerContent.packageType == PackageType.SINGLE) {
            if (offerContent.price == 0 || oferrValue.any { it.isNotEmpty() }) {
                val translationType: String = if (offerContent.contentList.isNotEmpty()) {
                    when (offerContent.contentList[0].translationType) {
                        TranslationType.NOR -> "(일반)"
                        TranslationType.SUB -> "(자막)"
                        TranslationType.DUB -> "(더빙)"
                        TranslationType.ENSUB -> "(자막)"
                        else -> ""
                    }
                } else {
                    ""
                }
                return "시청${translationType}"
            } else {
                val translationType = when (offerContent.contentList[0].translationType) {
                    TranslationType.NOR -> "하기"
                    TranslationType.SUB -> "(자막)"
                    TranslationType.DUB -> "(더빙)"
                    TranslationType.ENSUB -> "(자막)"
                    else -> ""
                }
                return "결제${translationType}"
            }
        } else {
            if (offerContent.isPurchase == true || offerContent.price == 0) {
                Logger.Log(Log.ERROR, this, "offercontent title : ${offerContent.title}")
                val translationType: String = if (offerContent.contentList.isNotEmpty()) {
                    when (offerContent.contentList[0].translationType) {
                        TranslationType.NOR -> "(일반)"
                        TranslationType.SUB -> "(자막)"
                        TranslationType.DUB -> "(더빙)"
                        TranslationType.ENSUB -> "(자막)"  //TODO: 영문자막 확인
                        else -> ""
                    }
                } else {
                    ""
                }
                return "시청${translationType}"
            } else {
                var price = "${DecimalFormat("#,###").format(offerContent.price)}원"
                if (offerContent.discountPrice!! > 0) {
                    price = "${DecimalFormat("#,###").format(offerContent.discountPrice)}원"
                }
                return if (offerContent.productType == ProductType.SUBSCRIPTION) {
                    val translationType = when (offerContent.contentList[0].translationType) {
                        TranslationType.NOR -> "(일반)"
                        TranslationType.SUB -> "(자막)"
                        TranslationType.DUB -> "(더빙)"
                        TranslationType.ENSUB -> "(자막)"  //TODO: 영문자막 확인
                        else -> ""
                    }
                    "${offerContent.title}${translationType} $price"
                } else {
                    val rentalType = when (offerContent.productType) {
                        ProductType.RENT -> "단편"
                        ProductType.BUY -> "소장"
                        else -> ""
                    }
                    val translationType = when (offerContent.contentList[0].translationType) {
                        TranslationType.NOR -> "(일반)"
                        TranslationType.SUB -> "(자막)"
                        TranslationType.DUB -> "(더빙)"
                        TranslationType.ENSUB -> "(자막)"  //TODO: 영문자막 확인
                        else -> ""
                    }
                    if (offerContent.packageType == PackageType.SERIES) {
                        "시리즈${translationType} $price"
                    } else if (offerContent.packageType == PackageType.PACKAGE) {
                        "묶음상품"
                    } else {
                        "$rentalType${translationType} $price"
                    }
                }
            }
        }
    }

    fun isButtonClickable(): Boolean = isButtonClickable

    fun disableButton() {
        isButtonClickable = false
        viewModelScope.launch {
            delay(3000L) // 3초 지연
            isButtonClickable = true
        }
    }

    // 사용자가 선택한 액션을 처리하는 함수
    fun enter() {
        if (likeModel.isActive) {
            val like = isLike.value ?: false
            listener.like(getSelectedOffContent().contentList[0], !like)
        } else if (buttonListModel.isActive) {
            listener.select(getSelectedOffContent())
        } else if (::recommendListModel.isInitialized && recommendListModel.isActive) {
            recommendListModel.isActive = false
            buttonListModel.isActive = true
            listener.recommendFocused(recommendListModel.currentIndex, false)
            listener.buttonListFocused(buttonListModel.currentIndex)
            listener.select(this.categoryItemList!![recommendListModel.currentIndex])
        }
    }

    // 현재 선택된 오퍼 콘텐츠를 반환하는 함수
    fun getSelectedOffContent(): OfferContent {
        Logger.Log(Log.ERROR, this, "getSelectedOffContent ${buttonListModel.currentIndex} / offerContentList.size ${offerContentList.size}")
        return if (buttonListModel.currentIndex < offerContentList.size)
            offerContentList[buttonListModel.currentIndex]
        else
            offerContentList[0]
    }

    // 오른쪽 방향키 입력을 처리하는 함수
    fun right() {
        if (likeModel.isActive) {

        } else if (buttonListModel.isActive) {
            buttonListModel.right()
            createDisplay()
            listener.update()
        } else if (::recommendListModel.isInitialized && recommendListModel.isActive) {
            recommendListModel.right()
        }
    }

    // 현재 선택된 오퍼 콘텐츠에 대한 디스플레이 정보를 생성하는 private 함수
    private fun createDisplay() {
        UIAgent.createDisplay(offerContent = getSelectedOffContent())
            .also {
                display.value = it
                this.isLike.value = it.isWish
            }
    }

    // 위쪽 방향키 입력을 처리하는 함수
    fun up() {
        if (buttonListModel.isActive) {
            if (display.value?.genre != "성인") {
                likeModel.isActive = true
                listener.likeFocused()
            }
        } else if (::recommendListModel.isInitialized && recommendListModel.isActive) {
            recommendListModel.isActive = false
            buttonListModel.isActive = true
            listener.recommendFocused(recommendListModel.currentIndex, false)
            listener.buttonListFocused(buttonListModel.currentIndex)
        }
    }

    // 아래쪽 방향키 입력을 처리하는 함수
    fun down() {
        if (likeModel.isActive) {
            likeModel.isActive = false
            listener.buttonListFocused(buttonListModel.currentIndex)
        } else if (buttonListModel.isActive && ::recommendListModel.isInitialized) {
            buttonListModel.isActive = false
            recommendListModel.isActive = true
            listener.recommendFocused(recommendListModel.currentIndex, true)
        } else if (::recommendListModel.isInitialized && recommendListModel.isActive) {
            recommendListModel.isActive = false
            buttonListModel.isActive = true
            listener.recommendFocused(recommendListModel.currentIndex, false)
            listener.buttonListFocused(buttonListModel.currentIndex)
        }
    }

    // 왼쪽 방향키 입력을 처리하는 함수
    fun left() {
        if (likeModel.isActive) {

        } else if (buttonListModel.isActive) {
            buttonListModel.left()
            createDisplay()
            listener.update()
        } else if (::recommendListModel.isInitialized && recommendListModel.isActive) {
            recommendListModel.left()
        }
    }

    // 콘텐츠 그룹을 설정하고 관련 데이터를 초기화하는 프로퍼티
    var contentGroup: ContentGroup? = null
        set(value) {
            field = value
            val offerContentList = value?.offerContentList
            if (!offerContentList.isNullOrEmpty()) {
                this.offerContentList.addAll(offerContentList.toTypedArray())

                val offerContent = offerContentList[0]
                UIAgent.createDisplay(offerContent).also {
                    display.value = it
                    this.isLike.value = it.isWish
                }

            }
        }

    // 추천 콘텐츠 디스플레이를 생성하는 함수
    fun createRecommend(categoryItemList: List<CategoryItem>) {
        this.recommendDisplay.value = UIAgent.createRecommendDisplay(categoryItemList)
    }

    // 콘텐츠 접근 권한을 확인하는 함수
    fun checkContentPermission(contentId: Long, offerId: Long) {
        MBSAgent.checkPermission(
            contentId = contentId,
            offerId = offerId,
            object : Callback<CheckPermissionResponse> {
                override fun onResponse(
                    call: Call<CheckPermissionResponse>,
                    response: Response<CheckPermissionResponse>
                ) {
                    if (response.isSuccessful) {
                        val offers = response.body()?.offerList ?: emptyList()
                        _offerList.postValue(offers)
                        _isPurchased.postValue(offers.isNotEmpty())
                    } else {
                        _offerList.postValue(emptyList())
                        _isPurchased.postValue(false)
                    }
                }

                override fun onFailure(call: Call<CheckPermissionResponse>, t: Throwable) {
                    _offerList.postValue(emptyList())
                    _isPurchased.postValue(false)
                }
            }
        )
    }
}