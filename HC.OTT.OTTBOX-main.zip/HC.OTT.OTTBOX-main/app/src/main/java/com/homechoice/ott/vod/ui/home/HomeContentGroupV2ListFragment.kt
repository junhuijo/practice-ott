package com.homechoice.ott.vod.ui.home

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.view.marginEnd
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.CMBApp
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.agent.ActivityChangeAgent
import com.homechoice.ott.vod.agent.CategoryItemType
import com.homechoice.ott.vod.agent.EnterPath
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.FillInItem
import com.homechoice.ott.vod.model.popup.AdDetail
import com.homechoice.ott.vod.ui.detail.series.SeriesActivity
import com.homechoice.ott.vod.ui.navigation.view.NavigationView2
import com.homechoice.ott.vod.ui.popup.ad.AdDetailView

class HomeContentGroupV2ListFragment(val title: String, private var itemList: List<CategoryItem>,val firstFlag:Boolean) : NavigationView2() {

    var ctx = HomeActivity2()

    // 이 함수는 UI 내의 아이템 선택 이벤트 핸들러에서 호출됩니다.
    private fun onDramaSelected(categoryItem: CategoryItem) {
        val intent = Intent(requireContext(), SeriesActivity::class.java).apply {
            putExtra("posterUrl", categoryItem.posterUrl)
            putExtra("seriesId", categoryItem.id)  // 추가적인 필요한 데이터 전달
        }
        startActivity(intent)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        if(title.contains("TOP")){
            val tag = "top10"
        }else{
            val tag = ""
        }

        val view = inflater.inflate(R.layout.home_content_group_listv2, container, false)
        if(title =="님이 좋아할만한 콘텐츠"){
            Log.d("userName","${STBAgent.userName}")
        }
        if(title=="님이 좋아할만한 콘텐츠"&&STBAgent.userName!=""){
            view.findViewById<TextView>(R.id.home_category_list_title).text = STBAgent.userName+title
        }else{
            view.findViewById<TextView>(R.id.home_category_list_title).text = title
        }
        val contentListLayout = view.findViewById<LinearLayout>(R.id.home_content_group_list)
        val horizontalScrollView = view.findViewById<HorizontalScrollView>(R.id.home_content_group_list_scrollview)

        val contentGroupCategory = view.findViewById<LinearLayout>(R.id.content_group_category)

        itemList.forEach { item ->
            val content = layoutInflater.inflate(R.layout.home_content_list_item3,null)
            val poster = content.findViewById<ImageView>(R.id.main_content_poster3)
            val posterBorder = content.findViewById<FrameLayout>(R.id.content_poster_border3)
            val numberIndicator3: ImageView = content.findViewById(R.id.number_indicator3)
            if(firstFlag&&itemList.indexOf(item)==0){
                posterBorder.requestFocus()
            }
            if (title.contains("TOP")) {
                // TextView의 visibility를 VISIBLE로 설정
                numberIndicator3.visibility = View.VISIBLE

                // FrameLayout의 layout_marginStart를 75dp로 설정
                val contentPosterBorder3: FrameLayout = content.findViewById(R.id.content_poster_border3)
                val layoutParams = contentPosterBorder3.layoutParams as ViewGroup.MarginLayoutParams
                layoutParams.marginStart = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, 85f, resources.displayMetrics
                ).toInt()
                contentPosterBorder3.layoutParams = layoutParams

                // itemList에서 item의 인덱스에 따라 numberIndicator3의 배경을 동적으로 변경
                val context = content.context
                val index = itemList.indexOf(item) + 1
                var resourceId = R.drawable.letter_rank1
                if(index<=15){
                    resourceId = context.resources.getIdentifier("letter_rank${index}", "drawable", context.packageName)
                }
                numberIndicator3.setImageResource(resourceId)
            }
            if(firstFlag){
                posterBorder.nextFocusUpId = posterBorder.id
            }
            //스크롤에 필요한 위치값


            Glide.with(this).load(item.posterUrl).override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height)).placeholder(R.drawable.main_poster_1_d).into(poster)
            poster.clipToOutline = true
            // View에서 OnKeyListener를 설정합니다.

            posterBorder.setOnKeyListener { v, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_BUTTON_A || keyCode == KeyEvent.KEYCODE_DPAD_CENTER)) {
                    val focusedView = activity?.currentFocus
                    if (focusedView != null) {
                        val enterPath = UIAgent.createEnterPath(EnterPath.MAIN_CATEGORY, 0)
                        // 포커스된 View를 확인하고 원하는 작업을 수행합니다.
                        when(item.type){
                            CategoryItemType.CONTENTGROUP -> {
                                ActivityChangeAgent.goToContent(context!!, item.id, enterPath, null)
                            }
                            CategoryItemType.SERIES -> {
                                ActivityChangeAgent.goToSeriesContent(item.id, 0, context!!, enterPath, null)
                            }
                        }
                    }
                }
                false // 이벤트 처리가 완료되지 않았음을 나타냅니다.
            }

            posterBorder.setOnFocusChangeListener { v, b ->
                if(b){
                    val scrollView = findScrollViewInActivity()
                    val location = IntArray(2)
                    v.getLocationOnScreen(location)
                    //convert DP to PX
                    val density = resources.displayMetrics.density
                    val dpValue = 53
                    val pxValue = (dpValue * density + 0.5f).toInt()

                    scrollView!!.smoothScrollBy(0,location[1]-pxValue)
                    val locationTwo = IntArray(2)
                    horizontalScrollView.getLocationOnScreen(locationTwo)
                    //가로 스크롤뷰의 시작 위치 + (포스터 width + margin)* 3 = 4번째 포스터 위치
                    val fourthLocation = locationTwo[0] + (posterBorder.width+posterBorder.marginEnd)*3
                    //오른쪽으로 스크롤 할 때
                    if(location[0]>fourthLocation){
                        horizontalScrollView.smoothScrollBy(location[0]-fourthLocation,0)
                    }
                    //랭킹 카테고리 왼쪽으로 스크롤 할 때
                    if(numberIndicator3.visibility ==View.VISIBLE &&
                        locationTwo[0]+numberIndicator3.width>location[0]){
                        horizontalScrollView.smoothScrollBy(-numberIndicator3.width,0)
                    }
                }
            }
//            광고 있을 때 마지막 인덱스 확인
//            if(itemList.lastIndex == itemList.indexOf(item)&&itemList.size>=5){
            if(itemList.lastIndex == itemList.indexOf(item)){
                posterBorder.nextFocusRightId = posterBorder.id
            }

            contentListLayout.addView(content)
        }
//        광고 채워넣기
//        var fillIndex = 0
//        if(itemList.size in 1..4){
//            val fillInList = MutableList<FillInItem>(5 - itemList.size) { FillInItem() }
//
//            fillInList.forEach { fillItem ->
//                val fillContent = layoutInflater.inflate(R.layout.home_content_list_item3, null)
//                val fillPoster = fillContent.findViewById<ImageView>(R.id.main_content_poster3)
//                val fillPosterBorder =
//                    fillContent.findViewById<FrameLayout>(R.id.content_poster_border3)
//                val adIcon = fillContent.findViewById<ImageView>(R.id.poster_ad_icon)
//
////                Glide.with(this).load(R.drawable.ad_icon).placeholder(R.drawable.main_poster_1_d).into(fillPoster)
//                //더미 광고 설정
//                when(fillIndex){
//                    0->{
//                        Glide.with(this).load(R.drawable.dummy_ad_1).override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height)).placeholder(R.drawable.main_poster_1_d).into(fillPoster)
//                    }
//                    1->{
//                        Glide.with(this).load(R.drawable.dummy_ad_2).override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height)).placeholder(R.drawable.main_poster_1_d).into(fillPoster)
//                    }
//                    2->{
//                        Glide.with(this).load(R.drawable.dummy_ad_3).override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height)).placeholder(R.drawable.main_poster_1_d).into(fillPoster)
//                    }
//                    3->{
//                        fillItem.posterUrl = "https://www.scs.co.kr/resources/ckimage/7cd61667-f4a0-47eb-bf2b-4990f2f973db"
//                        Glide.with(this).load(fillItem.posterUrl).override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height)).placeholder(R.drawable.main_poster_1_d).into(fillPoster)
//                    }
//
//                }
////                fillItem.posterUrl = "https://www.scs.co.kr/resources/ckimage/7cd61667-f4a0-47eb-bf2b-4990f2f973db"
////                Glide.with(this).load(fillItem.posterUrl).override(CMBApp.getPixelSize(R.dimen.home_content_poster_width), CMBApp.getPixelSize(R.dimen.home_content_poster_height)).placeholder(R.drawable.main_poster_1_d).into(fillPoster)
//                fillPoster.clipToOutline = true
//                adIcon.visibility = View.VISIBLE
//
//                fillPosterBorder.setOnFocusChangeListener { v, b ->
//                    if (b) {
//                        val scrollView = findScrollViewInActivity()
//                        val location = IntArray(2)
//                        v.getLocationOnScreen(location)
//                        //convert DP to PX
//                        val density = resources.displayMetrics.density
//                        val dpValue = 53
//                        val pxValue = (dpValue * density + 0.5f).toInt()
//
//                        scrollView!!.smoothScrollBy(0, location[1] - pxValue)
//                        val locationTwo = IntArray(2)
//                        horizontalScrollView.getLocationOnScreen(locationTwo)
//                        //가로 스크롤뷰의 시작 위치 + (포스터 width + margin)* 3 = 4번째 포스터 위치
//                        val fourthLocation = locationTwo[0] + (fillPosterBorder.width+fillPosterBorder.marginEnd)*3
//                        if(location[0]>fourthLocation){
//                            horizontalScrollView.smoothScrollBy(location[0]-fourthLocation,0)
//                        }
//                    }
//                }
//
//                fillPosterBorder.setOnKeyListener { v, keyCode, event ->
//
//                    if(event.action == KeyEvent.ACTION_DOWN){
//                        when(keyCode){
//                            KeyEvent.KEYCODE_ENTER,KeyEvent.KEYCODE_DPAD_CENTER->{
//                                val focusedView = activity?.currentFocus
//                                if (focusedView != null) {
//                                    //팝업 광고
////                                    val adDetail = AdDetail("영화 <웡카> VOD 론칭 이벤트",
////                                        "초콜릿이 가득한 환상의 마법!\n" +
////                                            "극장을 뜨겁게 달구고 있는 영화 <웡카>가 여러분의 안방을 찾아갑니다!\n" +
////                                            "\n" +
////                                            "보기만 해도 달콤한 영화와 환상 궁합!\n" +
////                                            "영화 보고 핫 초콜릿 기프티콘 받고~ 지금 바로 케이블 TV VOD에서 만나보세요 :)")
////                                    showAdDetailView(adDetail)
//                                    // 포커스된 View를 확인하고 원하는 작업을 수행합니다.
//                                    when (fillItem.type) {
//                                    }
//                                }
//                            }
//                        }
//                    }
//                    false // 이벤트 처리가 완료되지 않았음을 나타냅니다.
//                }
//                if (fillIndex == fillInList.lastIndex) {
//                    fillPosterBorder.nextFocusRightId = fillPosterBorder.id
//                }
//
//                contentListLayout.addView(fillContent)
//                fillIndex++
//            }
//
//        }

        return view
    }

    override fun onKeyDown(keyCode: Int): Boolean {
        TODO("Not yet implemented")
    }

    override fun active() {
        TODO("Not yet implemented")
    }

    override fun lateActive() {
        TODO("Not yet implemented")
    }

    override fun setVisible(visible: Int) {
        TODO("Not yet implemented")
    }

    private fun findScrollViewInActivity(): ScrollView?{
        val activity = activity ?: return null
        val categoryScrollView = activity.findViewById<ScrollView>(R.id.home_category_scrollview)
        val contentScrollView = activity.findViewById<ScrollView>(R.id.home_content_main_scrollview)

        return when(contentScrollView.visibility){
            View.GONE ->{
                categoryScrollView
            }
            else -> {
                contentScrollView
            }
        }
    }

    private fun showAdDetailView(adDetail: AdDetail) {
        val adDetailView = AdDetailView(adDetail)
        adDetailView.show(requireActivity().supportFragmentManager,"ad_detail_view")
    }

}

