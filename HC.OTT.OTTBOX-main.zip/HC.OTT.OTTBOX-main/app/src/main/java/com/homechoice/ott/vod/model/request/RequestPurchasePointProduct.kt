package com.homechoice.ott.vod.model.request

data class RequestPurchasePointProduct (
    val terminalKey: String = "",
    val productId : Long,
    val productTitle : String,
    val paymentPw : String,
    val price : Int
)