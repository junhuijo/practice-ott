package com.homechoice.ott.vod.model

import android.os.Parcelable
import android.util.Log
import kotlinx.android.parcel.Parcelize

@Parcelize
data class HomeCategoryList(
    val transactionId: String = "",
    val errorString: String = "",
    val sessionState: String = "",
    var categoryList: List<CategoryList> = listOf()
) : Parcelable {
    fun build(): HomeCategoryList {
        val list: ArrayList<CategoryList> = arrayListOf()

        //        {
        //            "id": 756,
        //            "title": "님이 좋아할 만한 컨텐츠",
        //            "type": "category",
        //            "parentId":-1,
        //            "depth": 1,
        //            "displayOrder": 2,
        //            "isAdult": false,
        //            "isVisible": true,
        //            "adultImgUrl": "",
        //            "totalCount": 8,
        //            "categoryItemList": []
        //        }

        //        var id: Int = 0,
        //        var title: String = "",
        //        var type: String = "",
        //        var parentId: Int = -1,
        //        var depth: Int = 0,
        //        var displayOrder: Int = 0,
        //        var isAdult: Boolean = false,
        //        var adultImgUrl: String = "",
        //        var isVisible: Boolean = false,
        //        var categoryItemList: List<CategoryItem> = listOf()

        val mainBanner = CategoryList(
            id = 9000,
            title = "메인배너",
            type = "mainBanner",
            parentId = -1,
            depth = 0,
            displayOrder = 0,
            isAdult = false,
            adultImgUrl = "",
            isVisible = false,
            categoryItemList = listOf(
                CategoryItem(
                    id = 53,
                    title = "",
                    subtitle = "",
                    type = "banner",
                    description = "",
                    posterUrl = "https://0d0a-119-197-56-15.jp.ngrok.io/images/banners/banner_img.png",
                    posterSizeLevel = 1,
                    unselectedIconUrl = "",
                    selectedIconUrl = "",
                    isAdult = false,
                    popupType = "img_txt",
                    popupImgUrl = "https://www.castislive-slb.com:19080/homechoice/images/banner/92/92_popup_1668140735328.jpg",
                    popupTxt = "육사오 이벤트페이지입니다.",
//                    rating = "19세",
                    linkType = "contentGroup",
                    linkInfo = "21262"
                ),))
//                CategoryItem(
//                    id = 48,
//                    title = "",
//                    subtitle = "",
//                    type = "banner",
//                    description = "",
//                    posterUrl = "https://www.castislive-slb.com:19080/homechoice/images/banner/87/87_event_1668145649044.jpg",
//                    posterSizeLevel = 1,
//                    unselectedIconUrl = "",
//                    selectedIconUrl = "",
//                    isAdult = false,
//                    popupType = "txt",
//                    popupImgUrl = "",
//                    popupTxt = "100% 페이백 무한지급부터 월정액 100원가입 혜택까지!\\n레전드/최신 드라마, 예능 10편 (모범형사2, 아다마스, 미스터션샤인, 히든싱어7 등)\\n육아도우미 키즈 10편(반짝반짝 캐치!티니핑, 뽀롱뽀롱뽀로로시즌7. 헬로카봇시즌11 등)",
//                    linkType = "none",
//                    linkInfo = ""
//                ),
//                CategoryItem(
//                    id = 49,
//                    title = "",
//                    subtitle = "",
//                    type = "banner",
//                    description = "",
//                    posterUrl = "https://www.castislive-slb.com:19080/homechoice/images/banner/88/88_event_1667915158651.jpg",
//                    posterSizeLevel = 1,
//                    unselectedIconUrl = "",
//                    selectedIconUrl = "",
//                    isAdult = false,
//                    popupType = "txt",
//                    popupImgUrl = "",
//                    popupTxt = "영화, 해외드라마부터 다큐, 스포츠 등을 포함한 라이프 콘텐츠까지! 이 모든 콘텐츠를 월 3,000원에 (부가세별도) 무제한으로 만나보세요!\n지금 청춘초이스 월정액을 가입하시면, 월정액 100월 가입 및 추첨을 통해 10분께 홍삼 세트를 드립니다!",
//                    linkType = "none",
//                    linkInfo = ""
//                ),
//                CategoryItem(
//                    id = 50,
//                    title = "",
//                    subtitle = "",
//                    type = "banner",
//                    description = "",
//                    posterUrl = "https://www.castislive-slb.com:19080/homechoice/images/banner/89/89_event_1667915220427.jpg",
//                    posterSizeLevel = 1,
//                    unselectedIconUrl = "",
//                    selectedIconUrl = "",
//                    isAdult = false,
//                    popupType = "txt",
//                    popupImgUrl = "",
//                    popupTxt = "우리가 FLEX할게, 누가 CHOICE 할래?\\n중국, 일본 등 아시아 드라마가 총 집합한 아시아초이스 월정액! 약 3만여편의 명작, 최신 해외드라마를 월 5,000원에 (부가세별도) 무제한으로 만나보세요!\\n11월 가입자 전원 500원 가입 / 추첨을 통한 최신형 태블릿 PC 5명, 치킨 기프티콘 50명 경품 증정",
//                    linkType = "none",
//                    linkInfo = ""
//                ),
//                CategoryItem(
//                    id = 51,
//                    title = "",
//                    subtitle = "",
//                    type = "banner",
//                    description = "",
//                    posterUrl = "https://0d0a-119-197-56-15.jp.ngrok.io/images/banners/banner_img_2.png",
//                    posterSizeLevel = 1,
//                    unselectedIconUrl = "",
//                    selectedIconUrl = "",
//                    isAdult = false,
//                    popupType = "txt",
//                    popupImgUrl = "",
//                    popupTxt = "대한민국 국가대표 응원하고, 카타르시스를 느낄 수 있는 역대급 혜택을 누려보세요!\n11/1~30 기간 내 1만원 이상 구매자 대상으로 대한민국 N강 진출 시 VOD 쿠폰 지급!",
//                    rating = "19세",
//                    linkType = "category",
//                    linkInfo = "757"
//                ),
//                CategoryItem(
//                    id = 52,
//                    title = "",
//                    subtitle = "",
//                    type = "banner",
//                    description = "",
//                    posterUrl = "https://0d0a-119-197-56-15.jp.ngrok.io/images/banners/banner_img_3.png",
//                    posterSizeLevel = 1,
//                    unselectedIconUrl = "",
//                    selectedIconUrl = "",
//                    isAdult = false,
//                    popupType = "txt",
//                    popupImgUrl = "",
//                    popupTxt = "우리가 FLEX할게, 누가 CHOICE 할래?\n중국, 일본 등 아시아 드라마가 총 집합한 아시아초이스 월정액! 약 3만여편의 명작, 최신 해외드라마를 월 5,000원에 (부가세별도) 무제한으로 만나보세요!\n11월 가입자 전원 500원 가입 / 추첨을 통한 최신형 태블릿 PC 5명, 치킨 기프티콘 50명 경품 증정",
//                    rating = "19세",
//                    linkType = "series",
//                    linkInfo = "2372"
//                )
//            )
//        )
//        mainBanner.build()
//        list.add(mainBanner)
        for (item in categoryList) {
            item.build()
            list.add(item)
        }
        categoryList = list
        return this
    }
}