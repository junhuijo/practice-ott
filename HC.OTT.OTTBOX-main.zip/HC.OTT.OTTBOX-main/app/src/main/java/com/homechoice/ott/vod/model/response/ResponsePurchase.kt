package com.homechoice.ott.vod.model.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponsePurchase(
    val transactionId: String,
    val errorString: String,
    val sessionState: String = "",
    val purchaseId: Long,
    val point: Int
) : Parcelable