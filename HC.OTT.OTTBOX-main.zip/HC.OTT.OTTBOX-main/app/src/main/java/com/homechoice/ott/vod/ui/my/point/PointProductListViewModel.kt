package com.homechoice.ott.vod.ui.my.point

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.point.PointProduct

class PointProductListViewModel(value: PointProduct) : ViewModel() {
    var pointProductItem: MutableLiveData<PointProduct> = MutableLiveData()

    init {
        pointProductItem.value = value
    }
}