package com.homechoice.ott.vod.ui.navigation.navigator

class EpisodeNavigatorModel {
    var isActive: Boolean = false
    var currentIndex: Int = 0
        get() = field
    val totalSize: Int
    private val thresholdIndex: Int
    private val pageSize: Int
    val callback: Callback
    private val circleLinkedList : CircleLinkedList

    constructor(currentIndex: Int, totalSize: Int, pageSize: Int, thresholdIndex: Int, callback: Callback) {
        this.currentIndex = currentIndex
        this.totalSize = totalSize
        this.callback = callback
        this.pageSize = pageSize
        this.thresholdIndex = thresholdIndex
        this.circleLinkedList = CircleLinkedList(totalSize)


        callback.init( index=currentIndex, indexes = getCurrentIndexes(currentIndex,pageSize,thresholdIndex,totalSize) , indexInPage = getIndexInPage() )
    }

    fun left() {
        val previousIndex = this.currentIndex

        if (currentIndex > 0) {
            this.currentIndex--
        } else {
            this.currentIndex = totalSize - 1
        }




        callback.focusChanged(previousIndex= previousIndex, index =  this.currentIndex, indexInPage = getIndexInPage() ,indexes =  getCurrentIndexes(currentIndex,pageSize,thresholdIndex,totalSize))
    }

    fun getIndexInPage() : Int{
        var index : Int
        if(totalSize < pageSize){
            index = currentIndex
        }else{
            index = thresholdIndex
        }
        return index

    }

    fun getCurrentIndexes(currentIndex: Int, pageSize: Int, thresholdIndex: Int, totalSize: Int): List<Int> {

        val indexes: MutableList<Int> = mutableListOf()

        if(totalSize >= pageSize) {
            var current: ListNode
            current = this.circleLinkedList.list[currentIndex]

            for (index in 0 until thresholdIndex) {
                current = current.previous!!
            }

            indexes.add(current.data)
            for (index in 1 until pageSize) {
                current = current.next!!
                indexes.add(current.data)
            }
        }else{
            this.circleLinkedList.list.forEach{
                    e -> indexes.add(e.data)
            }
        }
        return indexes
    }

    fun right() {
        val previousIndex = this.currentIndex
        if (currentIndex < totalSize - 1) {
            this.currentIndex++
        } else {
            this.currentIndex = 0
        }

        callback.focusChanged(previousIndex = previousIndex, index = this.currentIndex, indexInPage = getIndexInPage() ,  indexes  = getCurrentIndexes(currentIndex,pageSize,thresholdIndex,totalSize))
    }

    interface Callback {
        fun init(index: Int, indexInPage : Int ,  indexes:List<Int>)
        fun pageStartIndexChanged()
        fun focusChanged(previousIndex: Int, index: Int, indexInPage: Int ,indexes: List<Int>)
    }


}