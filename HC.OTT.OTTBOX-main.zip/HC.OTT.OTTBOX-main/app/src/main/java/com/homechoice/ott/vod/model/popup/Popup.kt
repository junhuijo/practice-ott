package com.homechoice.ott.vod.model.popup

import com.homechoice.ott.vod.popup.PopupType

data class Popup(
    val head: String = "",
    var sub: String = "",
    var body: String = "",
    val buttons: ArrayList<PopupType.Label> = arrayListOf(),
    var code: String = ""
)