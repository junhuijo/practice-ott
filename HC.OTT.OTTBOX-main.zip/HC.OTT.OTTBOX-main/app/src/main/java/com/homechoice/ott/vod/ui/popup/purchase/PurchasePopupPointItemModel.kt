package com.homechoice.ott.vod.ui.popup.purchase

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.point.PointProduct

class PurchasePopupPointItemModel(data: PointProduct) : ViewModel() {
    var product: MutableLiveData<PointProduct> = MutableLiveData()

    init {
        product.value = data
    }
}