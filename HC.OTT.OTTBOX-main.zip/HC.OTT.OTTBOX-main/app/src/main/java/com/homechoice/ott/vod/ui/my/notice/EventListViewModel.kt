package com.homechoice.ott.vod.ui.my.notice

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.homechoice.ott.vod.model.event.Event

class EventListViewModel(value: Event) : ViewModel() {
    var eventItem: MutableLiveData<Event> = MutableLiveData()

    init {
        eventItem.value = value
    }
}