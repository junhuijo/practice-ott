package com.homechoice.ott.vod.ui.popup.banner

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.KeyEvent
import android.view.View
import android.view.Window
import android.widget.TextView
import com.bumptech.glide.Glide
import com.homechoice.ott.vod.R
import com.homechoice.ott.vod.model.CategoryItem
import com.homechoice.ott.vod.model.event.Event
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.ui.popup.PopupEvent
import kotlinx.android.synthetic.main.dialog_banner_image_text.*


class ImageWithTextPopup : Dialog {

    constructor(ctx: Context, item: CategoryItem, event: PopupEvent) : super(ctx) {
        val dialog = this
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setCancelable(false)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setContentView(R.layout.dialog_banner_image_text)
        if (item.linkType == "none") {
            findViewById<TextView>(R.id.btn_detail).visibility = View.GONE
        } else {
            findViewById<TextView>(R.id.btn_detail).setOnClickListener {
                event.onClick(dialog, BtnLabel.OK)
            }
        }
        findViewById<TextView>(R.id.btn_close).setOnClickListener {
            dismiss()
        }
        findViewById<TextView>(R.id.btn_detail).requestFocus()
        if (item.popupTxt != "")
            content_text.text = item.popupTxt
        if (item.popupImgUrl != "")
            Glide.with(ctx).load(item.popupImgUrl).placeholder(R.drawable.popup_banner_d).into(banner_image)
        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {

                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                        result = true
                    }
                }
            }
            result
        }
        show()
    }

    constructor(ctx: Context, item: Event, event: PopupEvent) : super(ctx) {
        val dialog = this
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setCancelable(false)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setContentView(R.layout.dialog_banner_image_text)
        if (item.linkType == "none") {
            findViewById<TextView>(R.id.btn_detail).visibility = View.GONE
        } else {
            findViewById<TextView>(R.id.btn_detail).setOnClickListener {
                event.onClick(dialog, BtnLabel.OK)
            }
        }
        findViewById<TextView>(R.id.btn_close).setOnClickListener {
            dismiss()
        }
        findViewById<TextView>(R.id.btn_detail).requestFocus()
        if (item.popupTxt != "")
            content_text.text = item.popupTxt
        if (item.popupImgUrl != "")
            Glide.with(ctx).load(item.popupImgUrl).placeholder(R.drawable.popup_banner_d).into(banner_image)
        setOnKeyListener { _, kCode, kEvent ->
            var result = false
            if (kEvent.action == KeyEvent.ACTION_DOWN) {

                when (kCode) {
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        dismiss()
                        result = true
                    }
                }
            }
            result
        }
        show()
    }

}