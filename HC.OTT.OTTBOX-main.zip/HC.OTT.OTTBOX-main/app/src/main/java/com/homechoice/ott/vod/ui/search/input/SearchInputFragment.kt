package com.homechoice.ott.vod.ui.search.input

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.homechoice.ott.vod.agent.MBSAgent
import com.homechoice.ott.vod.agent.STBAgent
import com.homechoice.ott.vod.agent.UIAgent
import com.homechoice.ott.vod.databinding.FragmentSearchInputBinding
import com.homechoice.ott.vod.databinding.FragmentSearchResultBinding
import com.homechoice.ott.vod.model.popup.Login
import com.homechoice.ott.vod.model.response.ResponseKeyWord
import com.homechoice.ott.vod.popup.BtnLabel
import com.homechoice.ott.vod.popup.PopupAgent
import com.homechoice.ott.vod.popup.PopupType
import com.homechoice.ott.vod.ui.my.member.MemberLoginViewModel
import com.homechoice.ott.vod.ui.navigation.list.NavigationListView
import com.homechoice.ott.vod.ui.popup.PopupEvent
import com.homechoice.ott.vod.ui.popup.auth.LoginPopupEvent
import com.homechoice.ott.vod.ui.search.SearchActivity
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.CONTENT_FOCUS
import com.homechoice.ott.vod.ui.search.SearchActivity.ActionType.SEARCH_EXIT
import com.homechoice.ott.vod.util.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*


class SearchInputFragment(private val eventHandler: Handler) : NavigationListView() {

    private lateinit var binding: FragmentSearchInputBinding
    private lateinit var bind: FragmentSearchResultBinding
    private lateinit var adapter: SearchKeywordAdapter
    private lateinit var imm: InputMethodManager
    private lateinit var transactionId: String
    private var isSearching = false
    private var isShowIme = false

    @SuppressLint("InflateParams")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        binding = FragmentSearchInputBinding.inflate(inflater)
        binding.apply {}
        imm = context!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        adapter = SearchKeywordAdapter(listOf(), eventHandler)
        binding.searchKeywordListView.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        binding.searchKeywordListView.adapter = adapter

        binding.searchEditTextView.setOnEditorActionListener { _, action, _ ->
            Logger.Log(Log.DEBUG, this, "setOnEditorActionListener action $action")
            if (action == EditorInfo.IME_ACTION_SEARCH) {
                val keyword = binding.searchEditTextView.text.toString()
                if (keyword.isNotEmpty() && !UIAgent.hasSpecialText(keyword)) {
                    binding.searchInputBox.isSelected = false
                    imm.hideSoftInputFromWindow(binding.searchEditTextView.windowToken, 0)
                    val msg = Message()
                    msg.what = SearchActivity.ActionType.RESULT_UPDATE
                    msg.obj = keyword
                    msg.arg1 = if (binding.checkBox.isSelected) 1 else 0
                    eventHandler.sendMessage(msg)
                    isSearching = true
                    // -> 검색 요청
                } else {
                    imm.hideSoftInputFromWindow(binding.searchEditTextView.windowToken, 0)
                }
                true
            } else if (action == EditorInfo.IME_ACTION_DONE) {
                false
            } else {
                false
            }
        }

        binding.searchEditTextView.setModelListener(object : MemberLoginViewModel.ModelListener {
            override fun focused(focusType: MemberLoginViewModel.FocusType) {
                Logger.Log(Log.DEBUG, this, "focused focusType $focusType")
            }

            override fun buttonFocused(index: Int) {
                Logger.Log(Log.DEBUG, this, "buttonFocused index : $index")
            }

            override fun select(focusType: MemberLoginViewModel.FocusType, currentIndex: Int) {
                Logger.Log(Log.DEBUG, this, "select focusType : $focusType")
            }

            override fun back(focusType: MemberLoginViewModel.FocusType) {
                Logger.Log(Log.DEBUG, this, "back focusType : $focusType")
            }

            override fun hideIME() {
                Logger.Log(Log.DEBUG, this, "hideIME")
                isShowIme = false
            }
        })

        binding.searchEditTextView.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                Logger.Log(Log.DEBUG, this, "beforeTextChanged s $s / start $start / count $count")
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                Logger.Log(
                    Log.DEBUG,
                    this,
                    "onTextChanged s ${s.toString()} / start $start / count $count"
                )
                transactionId = UUID.randomUUID().toString()

                if (!isSearching && s.toString().isNotEmpty()) {
                    if (UIAgent.hasSpecialText(s.toString())) {
                        hideKeyWordListView()
                        binding.warnText.visibility = View.VISIBLE
                        binding.descText.visibility = View.GONE
                    } else {
                        binding.warnText.visibility = View.GONE
                        binding.descText.visibility = View.VISIBLE
//                        MBSAgent.keywordForSearch(
//                            transactionId,
//                            s.toString(),
//                            binding.checkBox.isSelected,
//                            5,
//                            object : Callback<ResponseKeyWord> {
//                                override fun onResponse(
//                                    call: Call<ResponseKeyWord>,
//                                    response: Response<ResponseKeyWord>
//                                ) {
//                                    if (response.isSuccessful) {
//                                        val res = response.body()
//                                        if (transactionId == res?.transactionId) {
//                                            Logger.Log(
//                                                Log.DEBUG,
//                                                this,
//                                                "res.keywordList ${res.keywordList}"
//                                            )
//                                            if (res.keywordList.isNotEmpty()) {
//                                                adapter.setItems(res.keywordList)
//                                                showKeyWordListView()
//                                            } else {
//                                                hideKeyWordListView()
//                                            }
//                                        } else {
//                                            hideKeyWordListView()
//                                            adapter.setItems(listOf())
//                                        }
//                                    } else {
//                                        hideKeyWordListView()
//                                        adapter.setItems(listOf())
//                                    }
//                                }
//
//                                override fun onFailure(call: Call<ResponseKeyWord>, t: Throwable) {
//                                    hideKeyWordListView()
//                                    adapter.setItems(listOf())
//                                }
//                            })
                    }
                } else {
                    binding.warnText.visibility = View.GONE
                    binding.descText.visibility = View.VISIBLE
                    // 인기 검색 콘텐츠 노출
                    hideKeyWordListView()
                    adapter.setItems(listOf())
                }
            }

            override fun afterTextChanged(s: Editable?) {
                Logger.Log(Log.DEBUG, this, "afterTextChanged s $s")
            }
        })

        /**
         * 키 이벤트
         * return false: 키 이벤트 넘기기
         * return true: 키 이벤트 넘기지 않기
         * */
        val onKeyListener: View.OnKeyListener = View.OnKeyListener { v, keyCode, event ->
            Logger.Log(Log.DEBUG, this, "onKeyListener keyCode $keyCode / event.action ${event.action} / isShowIme : $isShowIme")
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        if (!isShowIme) {
                            imm.hideSoftInputFromWindow(binding.searchEditTextView.windowToken, 0)
                            binding.searchInputBox.isSelected = false
                            hideKeyWordListView()
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER, 96 -> {
                        binding.searchInputBox.isSelected = true
                        binding.searchEditTextView.requestFocus()
                        imm.showSoftInput(binding.searchEditTextView, 0)
                        isShowIme = true
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        if (binding.searchKeywordListView.isVisible) {
                            binding.searchInputBox.isSelected = false
                            false
                        } else {
                            binding.searchInputBox.isSelected = false
                            eventHandler.obtainMessage(CONTENT_FOCUS).sendToTarget()
                            true
                        }
                    }
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        eventHandler.obtainMessage(SEARCH_EXIT).sendToTarget()
                        true
                    }
                    else -> {
                        false
                    }
                }

            } else {
                false
            }
        }

        binding.searchInputBox.setOnKeyListener(onKeyListener)
        binding.searchEditTextView.setOnKeyListener(onKeyListener)

        binding.checkBox.setOnKeyListener { v, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        binding.searchInputBox.requestFocus()
//                        keywordVisible()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER, 96 -> {
                        if (STBAgent.isAuth) {
                            if (STBAgent.isSearchAdultAuth) {
                                //
                                binding.checkBox.isSelected = !binding.checkBox.isSelected
                                adapter.setIncludeAdult(binding.checkBox.isSelected)
                            } else {
                                // 성인인증
                                PopupAgent.showAdultPopup(
                                    context!!,
                                    Login(bodyText = "성인 에로 범위까지 검색이 가능합니다.\n성인인증 비밀번호를 입력해 주세요.", loginqr = null),
                                    object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            d.dismiss()
                                            STBAgent.isSearchAdultAuth = true
                                            binding.checkBox.isSelected = !binding.checkBox.isSelected
                                            adapter.setIncludeAdult(binding.checkBox.isSelected)
                                        }
                                    })
                            }
                        } else {
                            // 로그인
                            if(STBAgent.linkedHomeChoice){
                                PopupAgent.showNormalPopup(context!!,
                                    PopupType.NormalPopupType.LOGIN_GUIDE,
                                    object : PopupEvent {
                                        override fun onClick(d: Dialog, btn: String) {
                                            d.dismiss()
                                        }
                                    })
                            } else {
                                PopupAgent.showLoginPopup(context!!, Login(isAdult = true, loginqr = null), object : LoginPopupEvent {
                                    override fun onLogin(loginDialog: Dialog, btn: String) {
                                        when (btn) {
                                            BtnLabel.SUCCESS -> {
                                                STBAgent.isAuth = true
                                                PopupAgent.showAdultPopup(
                                                    context!!,
                                                    Login(bodyText = "성인 에로 범위까지 검색이 가능합니다.\n성인인증 비밀번호를 입력해 주세요.", loginqr = null),
                                                    object : PopupEvent {
                                                        override fun onClick(d: Dialog, btn: String) {
                                                            d.dismiss()
                                                            binding.checkBox.isSelected = !binding.checkBox.isSelected
                                                            adapter.setIncludeAdult(binding.checkBox.isSelected)
                                                        }
                                                    })
                                                loginDialog.dismiss()
                                            }
                                            BtnLabel.CANCEL -> {
                                                loginDialog.dismiss()
                                            }
                                        }
                                    }
                                })
                            }
                        }
                        true
                    }
                    KeyEvent.KEYCODE_BACK, 97 -> {
                        eventHandler.obtainMessage(SEARCH_EXIT).sendToTarget()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        eventHandler.obtainMessage(CONTENT_FOCUS).sendToTarget()
                        true
                    }
                    else -> {
                        false
                    }
                }
            } else {
                false
            }
        }

//        binding.searchInputBox.setOnKeyListener { v, keyCode, event ->
//            if (event.action == KeyEvent.ACTION_DOWN) {
//                when (keyCode) {
//
//        KeyEvent.KEYCODE_DPAD_RIGHT -> {
//
//        }
//        KeyEvent.KEYCODE_DPAD_CENTER,
//        KeyEvent.KEYCODE_ENTER -> {
//
//        }
//                }
//                true
//            } else {
//                false
//            }
//        }
        hideKeyWordListView()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        isShowIme = false
    }

    /**
     * 키 이벤트
     * return false: 키 이벤트 넘기기
     * return true: 키 이벤트 넘기지 않기
     * */
    override fun onKeyDown(keyCode: Int): Boolean {
        Logger.Log(
            Log.DEBUG,
            this,
            "onKeyDown keyCode $keyCode / imm.isActive ${imm.isActive}"
        )
        return true
    }

    override fun active() {

    }

    fun setSearching(value: Boolean) {
        isSearching = value
    }

    fun focus() {
        Logger.Log(Log.DEBUG, this, "itemCount ${binding.searchKeywordListView.adapter?.itemCount!!}")
//        keywordVisible()
        binding.searchInputBox.requestFocus()
    }

    private fun keywordVisible() {
        if (binding.searchKeywordListView.adapter?.itemCount!! > 0) {
            showKeyWordListView()
        } else {
            hideKeyWordListView()
        }
    }

    fun select() {
    }

    override fun setVisible(visible: Int) {
    }

    override fun lateActive() {

    }

    fun hideKeyWordListView() {
        binding.searchKeywordListView.visibility = View.INVISIBLE
    }

    fun showKeyWordListView() {
        binding.searchKeywordListView.visibility = View.VISIBLE
    }

    fun back() {
    }

}